# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_mech_panels.py
# v0.1.5.1: Mechanical Panels / Grilles / Covers — reusable TECHNICAL
# details (not prefab props). Pattern-based generator with two modes:
#   geometry  -> plate with real slats/bars; holes shown as recesses
#   cutter    -> only the pattern volumes (full depth, CUT_, wire) to
#                subtract with the Boolean Workflow for REAL holes
# Standing plates: width = X, height = Z, thickness = Y, centered on the
# 3D cursor. Collection: PRO_HardSurface_MechanicalPanels.
# ──────────────────────────────────────────────────────────────────────

from math import cos, sin, pi, radians

import bpy
import bmesh
from mathutils import Matrix, Vector

from . import creation_utils as cu
from . import hardsurface_utils as hs
from . import ops_hardsurface_booleans as hb

COLL_MECH = "PRO_HardSurface_MechanicalPanels"


# ═══════════════════════════════════════════════════════════════════════
#  GEOMETRY HELPERS (XZ standing, thickness Y, centered)
# ═══════════════════════════════════════════════════════════════════════

def _box(bm, w, t, h, cx=0.0, cz=0.0, cy=0.0, rot_x=0.0):
    ret = bmesh.ops.create_cube(bm, size=1.0)
    rot = Matrix.Rotation(rot_x, 4, 'X') if rot_x else None
    for v in ret["verts"]:
        v.co.x *= w
        v.co.y *= t
        v.co.z *= h
        if rot:
            v.co = rot @ v.co
        v.co.x += cx
        v.co.y += cy
        v.co.z += cz
    return ret["verts"]


def _cyl_y(bm, r, length, segments=12, cx=0.0, cz=0.0, cy=0.0, hexa=False):
    ret = bmesh.ops.create_cone(bm, cap_ends=True, segments=6 if hexa else segments,
                                radius1=r, radius2=r, depth=length)
    for v in ret["verts"]:
        x, y, z = v.co.x, v.co.y, v.co.z
        v.co = Vector((x + cx, z + cy, -y + cz))
    return ret["verts"]


def _grid_cells(p, w, h, margin):
    """Yield (cx, cz) centers for rows × columns inside the margin."""
    cols, rows = max(p.hs_panel_columns, 1), max(p.hs_panel_rows, 1)
    iw, ih = w - 2 * margin, h - 2 * margin
    for r in range(rows):
        for c in range(cols):
            cx = -iw / 2 + iw * (c + 0.5) / cols
            cz = -ih / 2 + ih * (r + 0.5) / rows
            yield cx, cz


def _pattern(bm, p, w, h, pattern, depth, cy=0.0):
    """Add the pattern volumes (depth along Y, centered on cy)."""
    m = min(w, h) * 0.08
    iw, ih = w - 2 * m, h - 2 * m
    cols, rows = max(p.hs_panel_columns, 1), max(p.hs_panel_rows, 1)
    n = 0
    if pattern == 'CIRCULAR':
        r = min(p.hs_panel_hole_radius, iw / cols / 2.2, ih / rows / 2.2)
        for cx, cz in _grid_cells(p, w, h, m):
            _cyl_y(bm, r, depth, 12, cx=cx, cz=cz, cy=cy)
            n += 1
    elif pattern == 'HEX':
        r = min(p.hs_panel_hole_radius, iw / cols / 2.2, ih / rows / 2.2)
        for cx, cz in _grid_cells(p, w, h, m):
            _cyl_y(bm, r, depth, cx=cx, cz=cz, cy=cy, hexa=True)
            n += 1
    elif pattern == 'RECT_SLOTS':
        sw = min(p.hs_panel_slot_width, iw / cols * 0.85)
        sh = min(p.hs_panel_slot_height, ih / rows * 0.6)
        for cx, cz in _grid_cells(p, w, h, m):
            _box(bm, sw, depth, sh, cx=cx, cz=cz, cy=cy)
            n += 1
    elif pattern == 'LONG_SLOTS':
        sh = min(p.hs_panel_slot_height, ih / rows * 0.55)
        for r_i in range(rows):
            cz = -ih / 2 + ih * (r_i + 0.5) / rows
            _box(bm, iw, depth, sh, cz=cz, cy=cy)
            n += 1
    elif pattern in ('LOUVER_H', 'LOUVER_V'):
        count = rows if pattern == 'LOUVER_H' else cols
        for i in range(count):
            if pattern == 'LOUVER_H':
                cz = -ih / 2 + ih * (i + 0.5) / count
                _box(bm, iw, depth * 0.4, ih / count * 0.55,
                     cz=cz, cy=cy, rot_x=radians(38))
            else:
                cx = -iw / 2 + iw * (i + 0.5) / count
                verts = _box(bm, iw / count * 0.55, depth * 0.4, ih,
                             cx=0.0, cy=cy)
                rot = Matrix.Rotation(radians(38), 4, 'Z')
                for v in verts:
                    v.co = rot @ v.co
                    v.co.x += cx
            n += 1
    elif pattern == 'GRID_BARS':
        bar = max(min(iw, ih) * 0.03, 0.002)
        for r_i in range(rows + 1):
            cz = -ih / 2 + ih * r_i / rows
            _box(bm, iw, depth, bar, cz=cz, cy=cy)
        for c_i in range(cols + 1):
            cx = -iw / 2 + iw * c_i / cols
            _box(bm, bar, depth, ih, cx=cx, cy=cy)
        n = rows + cols + 2
    elif pattern == 'MESH_LINES':
        bar = max(min(iw, ih) * 0.015, 0.0015)
        dr, dc = max(rows * 2, 2), max(cols * 2, 2)
        for r_i in range(dr + 1):
            cz = -ih / 2 + ih * r_i / dr
            _box(bm, iw, depth, bar, cz=cz, cy=cy)
        for c_i in range(dc + 1):
            cx = -iw / 2 + iw * c_i / dc
            _box(bm, bar, depth, ih, cx=cx, cy=cy)
        n = dr + dc + 2
    return n


def _frame(bm, p, w, h, t):
    fw = min(w, h) * 0.06
    _box(bm, w, t, fw, cz=h / 2 - fw / 2)
    _box(bm, w, t, fw, cz=-h / 2 + fw / 2)
    _box(bm, fw, t, h - 2 * fw, cx=-w / 2 + fw / 2)
    _box(bm, fw, t, h - 2 * fw, cx=w / 2 - fw / 2)


def _screw(bm, t, cx, cz):
    _cyl_y(bm, 0.006, t * 1.6, cx=cx, cz=cz, hexa=True)


def _corner_screws(bm, p, w, h, t):
    off_x, off_z = w / 2 * 0.85, h / 2 * 0.85
    for sx in (-off_x, off_x):
        for sz in (-off_z, off_z):
            _screw(bm, t, sx, sz)


def _plate(bm, p, w, h, t):
    _box(bm, w, t, h)


def _rounded_plate(bm, p, w, h, t):
    r = min(w, h) * 0.12
    _box(bm, w - 2 * r, t, h)
    _box(bm, w, t, h - 2 * r)
    for sx in (-(w / 2 - r), w / 2 - r):
        for sz in (-(h / 2 - r), h / 2 - r):
            _cyl_y(bm, r, t, 12, cx=sx, cz=sz)


def _handle(bm, p, w, h, t):
    hw = w * 0.4
    _box(bm, 0.02, 0.05, 0.02, cx=-hw / 2, cy=-(t / 2 + 0.025))
    _box(bm, 0.02, 0.05, 0.02, cx=hw / 2, cy=-(t / 2 + 0.025))
    _box(bm, hw + 0.02, 0.02, 0.02, cy=-(t / 2 + 0.05))


def _hinges(bm, p, w, h, t):
    for cz in (-h * 0.3, h * 0.3):
        _cyl_y(bm, 0.012, 0.06, 10, cx=-w / 2 - 0.006, cz=cz)


# ═══════════════════════════════════════════════════════════════════════
#  TOOL TABLE  (suffix -> label, build steps)
#  step codes: plate / rplate / frame / pattern:<TYPE|PROP> / screws /
#              handle / hinges / recessed
# ═══════════════════════════════════════════════════════════════════════

TOOLS = {
    "vent_grille":      ("Create Vent Grille", 0.30, 0.20,
                         ["frame", "pattern:LOUVER_H"]),
    "louvered_vent":    ("Create Louvered Vent", 0.24, 0.16,
                         ["frame", "pattern:LOUVER_V"]),
    "perforated_panel": ("Create Perforated Panel", 0.30, 0.30,
                         ["plate", "pattern:CIRCULAR"]),
    "access_cover":     ("Create Access Cover", 0.25, 0.18,
                         ["rplate", "screws"]),
    "maintenance_hatch": ("Create Maintenance Hatch", 0.45, 0.35,
                          ["plate", "frame", "screws", "handle", "hinges"]),
    "screw_plate":      ("Create Screw Plate", 0.12, 0.12,
                         ["rplate", "screws"]),
    "bolt_pattern":     ("Create Bolt Pattern", 0.16, 0.16, ["bolt_ring"]),
    "circular_vent":    ("Create Circular Vent", 0.22, 0.22, ["circ_vent"]),
    "speaker_grille":   ("Create Speaker Grille", 0.22, 0.22,
                         ["disc", "pattern:CIRCULAR"]),
    "filter_panel":     ("Create Filter Panel", 0.30, 0.22,
                         ["frame", "pattern:MESH_LINES"]),
    "metal_mesh_panel": ("Create Metal Mesh Panel", 0.30, 0.30,
                         ["pattern:MESH_LINES"]),
    "technical_door_panel": ("Create Technical Door Panel", 0.45, 0.60,
                             ["plate", "frame", "handle", "hinges"]),
    "corner_screws":    ("Create Corner Screws", 0.20, 0.20, ["screws"]),
    "handle_plate":     ("Create Handle Plate", 0.22, 0.10,
                         ["rplate", "handle"]),
    "hinge_plate":      ("Create Hinge Plate", 0.16, 0.10,
                         ["rplate", "hinges", "screws"]),
    "recessed_cover":   ("Create Recessed Cover", 0.25, 0.18, ["recessed"]),
    "slot_pattern":     ("Create Slot Pattern", 0.30, 0.22,
                         ["plate", "pattern:LONG_SLOTS"]),
    "grid_pattern":     ("Create Grid Pattern", 0.30, 0.30,
                         ["frame", "pattern:GRID_BARS"]),
    "hex_hole_pattern": ("Create Hex Hole Pattern", 0.30, 0.30,
                         ["plate", "pattern:HEX"]),
    "rounded_rect_plate": ("Create Rounded Rectangle Plate", 0.30, 0.20,
                           ["rplate"]),
}


def _build_tool(bm, p, w, h, steps, as_cutter):
    """Run the build steps. In cutter mode only pattern/bolt volumes are
    built (full through depth)."""
    t = p.hs_panel_thickness
    through = t * 4.0
    desc = []
    for step in steps:
        if step.startswith("pattern:"):
            kind = step.split(":")[1]
            if kind == 'PROP':
                kind = p.hs_panel_pattern_type
            depth = through if as_cutter else t * 0.6
            cy = 0.0 if as_cutter else -t * 0.25
            n = _pattern(bm, p, w, h, kind, depth, cy=cy)
            desc.append(f"{kind.lower()} ×{n}")
        elif as_cutter:
            if step == "bolt_ring":
                rr = min(w, h) * 0.38
                for i in range(8):
                    a = 2 * pi * i / 8
                    _cyl_y(bm, 0.008, through, 10,
                           cx=cos(a) * rr, cz=sin(a) * rr)
                desc.append("bolt ring (cutter)")
            # plates/frames/screws are skipped in cutter mode
        elif step == "plate":
            _plate(bm, p, w, h, t)
            desc.append("plate")
        elif step == "rplate":
            _rounded_plate(bm, p, w, h, t)
            desc.append("rounded plate")
        elif step == "frame":
            _frame(bm, p, w, h, t * 1.4)
            desc.append("frame")
        elif step == "screws":
            _corner_screws(bm, p, w, h, t)
            desc.append("corner screws")
        elif step == "handle":
            _handle(bm, p, w, h, t)
            desc.append("handle")
        elif step == "hinges":
            _hinges(bm, p, w, h, t)
            desc.append("hinges")
        elif step == "recessed":
            hs.add_panel_with_field(bm, w, t, h, min(w, h) * 0.08, t * 0.4)
            # recenter (helper builds standing at z0=0)
            for v in bm.verts:
                v.co.z -= h / 2.0
            desc.append("recessed field")
        elif step == "bolt_ring":
            _rounded_plate(bm, p, w, h, t)
            rr = min(w, h) * 0.38
            for i in range(8):
                a = 2 * pi * i / 8
                _screw(bm, t, cos(a) * rr, sin(a) * rr)
            desc.append("bolt ring")
        elif step == "disc":
            ret = bmesh.ops.create_cone(bm, cap_ends=True, segments=24,
                                        radius1=min(w, h) / 2,
                                        radius2=min(w, h) / 2, depth=t)
            for v in ret["verts"]:
                x, y, z = v.co.x, v.co.y, v.co.z
                v.co = Vector((x, z, -y))
            desc.append("disc")
        elif step == "circ_vent":
            radius = min(w, h) / 2
            hs.add_ring(bm, radius, radius * 0.92, t, 24, z0=-t / 2)
            for v in list(bm.verts):
                pass
            # concentric slat rings + spokes (built flat XY then stood up)
            for f in (0.7, 0.45, 0.2):
                hs.add_ring(bm, radius * f + radius * 0.04, radius * f,
                            t * 0.6, 20, z0=-t * 0.3)
            rot = Matrix.Rotation(radians(90), 4, 'X')
            for v in bm.verts:
                v.co = rot @ v.co
            desc.append("circular vent")
    return ", ".join(desc)


def _make_tool_op(suffix):
    label, w_def, h_def, steps = TOOLS[suffix]

    class _Op(bpy.types.Operator):
        bl_idname = f"object.pro_hs_mech_{suffix}"
        bl_label = label
        bl_description = (f"{label} — detalle técnico reutilizable (geometría "
                          "o cutter según 'Create as Cutter')")
        bl_options = {'REGISTER', 'UNDO'}

        width: bpy.props.FloatProperty(name="Width", default=w_def,
                                       min=0.02, soft_max=3.0, unit='LENGTH')
        height: bpy.props.FloatProperty(name="Height", default=h_def,
                                        min=0.02, soft_max=3.0, unit='LENGTH')

        @classmethod
        def poll(cls, context):
            return context.mode == 'OBJECT'

        def execute(self, context):
            p = context.scene.pro_toolkit
            as_cutter = p.hs_panel_create_as_cutter
            has_pattern = any(s.startswith("pattern:") or s == "bolt_ring"
                              for s in steps)
            if as_cutter and not has_pattern:
                self.report({'WARNING'},
                            f"{label} no tiene patrón perforable — se crea "
                            "como geometría normal.")
                as_cutter = False

            bm = bmesh.new()
            desc = _build_tool(bm, p, self.width, self.height, steps, as_cutter)
            if not bm.verts:
                bm.free()
                self.report({'WARNING'}, "Nada que construir con estos parámetros.")
                return {'CANCELLED'}
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            name = (f"CUT_Mech_{suffix}" if as_cutter else f"HS_Mech_{suffix}")
            me = bpy.data.meshes.new(name)
            bm.to_mesh(me)
            bm.free()

            obj = bpy.data.objects.new(name, me)
            if as_cutter:
                hb._link_to_cutters(context, obj)
                obj.data.materials.append(hb._cutter_material("CUTTER_Orange"))
                hb._setup_cutter(obj)
                p.hs_last_created_cutter = obj
            else:
                coll = bpy.data.collections.get(COLL_MECH)
                if coll is None:
                    coll = bpy.data.collections.new(COLL_MECH)
                if COLL_MECH not in context.scene.collection.children:
                    try:
                        context.scene.collection.children.link(coll)
                    except RuntimeError:
                        pass
                coll.objects.link(obj)
                if p.hs_create_materials:
                    hs.assign_hs_material(obj, "HS_Metal_Light")
                if p.hs_panel_bevel_amount > 0.0001:
                    mod = obj.modifiers.new("PRO_Mech_Bevel", 'BEVEL')
                    mod.width = p.hs_panel_bevel_amount
                    mod.segments = 2
                    mod.limit_method = 'ANGLE'
                    mod.use_clamp_overlap = True
                if p.hs_panel_use_weighted_normals:
                    hs.add_weighted_normal_modifier(obj)
            obj.location = context.scene.cursor.location.copy()

            for o in context.selected_objects:
                o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({'INFO'},
                        f"'{obj.name}' creado ({desc})"
                        + (" — CUTTER listo para Add Difference to Target"
                           if as_cutter else f" en {COLL_MECH}"))
            return {'FINISHED'}

    _Op.__name__ = f"OBJECT_OT_pro_hs_mech_{suffix}"
    return _Op


classes = tuple(_make_tool_op(s) for s in TOOLS)
