# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  material_utils.py
# v0.1.6 Material / Texture / Baking Pro Suite — shared material helpers.
#
# RULES (never broken):
#   - existing materials are NEVER modified without a copy/backup,
#   - destructive operations are explicit and confirmed,
#   - every batch action can be reported (counts + names).
# ──────────────────────────────────────────────────────────────────────

import os
import re
import tempfile

import bpy

BACKUP_SUFFIX = "_MATBAK"
PBR_PREFIX = "PBR_"

# Heuristic thresholds for "heavy" materials
HEAVY_NODE_COUNT = 40
HEAVY_IMAGE_COUNT = 6

_DUP_RE = re.compile(r"^(.*?)\.\d{3}$")


# ═══════════════════════════════════════════════════════════════════════
#  REPORT WRITING (same convention as ops_uv_audit)
# ═══════════════════════════════════════════════════════════════════════

def report_dir():
    return bpy.path.abspath("//") if bpy.data.is_saved else tempfile.gettempdir()


def write_report(filename, lines):
    """Write a markdown report next to the .blend (or temp dir). Returns path."""
    path = os.path.join(report_dir(), filename)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


# ═══════════════════════════════════════════════════════════════════════
#  SCOPE / USAGE
# ═══════════════════════════════════════════════════════════════════════

def scope_objects(context, scope):
    """Mesh objects for an audit scope: 'SELECTED' | 'SCENE'."""
    if scope == 'SELECTED':
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs and context.active_object \
                and context.active_object.type == 'MESH':
            objs = [context.active_object]
        return objs
    return [o for o in context.scene.objects if o.type == 'MESH']


def material_users():
    """dict material -> list of objects whose slots reference it."""
    users = {}
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        for slot in obj.material_slots:
            if slot.material is not None:
                users.setdefault(slot.material, []).append(obj)
    return users


def used_materials():
    return set(material_users().keys())


def unused_materials():
    used = used_materials()
    return [m for m in bpy.data.materials
            if m not in used and not m.is_grease_pencil]


def is_backup_material(mat):
    return BACKUP_SUFFIX in mat.name


# ═══════════════════════════════════════════════════════════════════════
#  NODE / PBR INSPECTION
# ═══════════════════════════════════════════════════════════════════════

def get_principled(mat):
    if mat is None or not mat.use_nodes or mat.node_tree is None:
        return None
    return next((n for n in mat.node_tree.nodes
                 if n.type == 'BSDF_PRINCIPLED'), None)


def material_image_nodes(mat):
    if mat is None or not mat.use_nodes or mat.node_tree is None:
        return []
    return [n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE']


def material_images(mat):
    return [n.image for n in material_image_nodes(mat) if n.image is not None]


def has_missing_images(mat):
    from . import texture_utils
    return any(texture_utils.image_is_missing(img)
               for img in material_images(mat))


def has_absolute_paths(mat):
    return any(img.filepath and not img.filepath.startswith("//")
               and img.packed_file is None
               for img in material_images(mat))


def is_pbr(mat):
    """PBR = use_nodes + a Principled BSDF wired to an output."""
    principled = get_principled(mat)
    if principled is None:
        return False
    for link in mat.node_tree.links:
        if link.from_node is principled:
            return True
    # principled directly on output even without links traversal issues
    return any(n.type == 'OUTPUT_MATERIAL' for n in mat.node_tree.nodes) \
        and len(principled.outputs[0].links) > 0


def is_heavy(mat):
    if mat is None or not mat.use_nodes:
        return False
    n_nodes = len(mat.node_tree.nodes)
    n_images = len(material_images(mat))
    return n_nodes > HEAVY_NODE_COUNT or n_images > HEAVY_IMAGE_COUNT


def base_color_of(mat):
    """Viewport-ish base color used for duplicate-by-color comparison."""
    principled = get_principled(mat)
    if principled is not None:
        inp = principled.inputs.get("Base Color")
        if inp is not None and not inp.is_linked:
            return tuple(inp.default_value)[:3]
    return tuple(mat.diffuse_color)[:3]


# ═══════════════════════════════════════════════════════════════════════
#  DUPLICATES
# ═══════════════════════════════════════════════════════════════════════

def duplicate_groups_by_name():
    """Groups of materials that are name-duplicates: Mat / Mat.001 / Mat.002.
    Returns dict base_name -> [materials] (only groups with 2+ and an
    existing base material first if present)."""
    groups = {}
    for mat in bpy.data.materials:
        m = _DUP_RE.match(mat.name)
        base = m.group(1) if m else mat.name
        groups.setdefault(base, []).append(mat)
    out = {}
    for base, mats in groups.items():
        if len(mats) < 2:
            continue
        mats.sort(key=lambda m: (m.name != base, m.name))
        out[base] = mats
    return out


def duplicate_groups_by_color(tolerance=0.02):
    """Groups of node-less-equivalent materials whose base colors match
    within *tolerance*. Conservative: only materials with the same
    image set qualify."""
    buckets = []
    for mat in bpy.data.materials:
        if is_backup_material(mat):
            continue
        col = base_color_of(mat)
        imgs = frozenset(i.name for i in material_images(mat))
        placed = False
        for bucket in buckets:
            bcol, bimgs, mats = bucket
            if bimgs == imgs and all(abs(a - b) <= tolerance
                                     for a, b in zip(col, bcol)):
                mats.append(mat)
                placed = True
                break
        if not placed:
            buckets.append((col, imgs, [mat]))
    return [mats for _c, _i, mats in buckets if len(mats) >= 2]


def remap_material(old, new):
    """Repoint every slot using *old* to *new*. Returns slots changed."""
    n = 0
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        for slot in obj.material_slots:
            if slot.material is old:
                slot.material = new
                n += 1
    return n


# ═══════════════════════════════════════════════════════════════════════
#  BACKUP / NAMING
# ═══════════════════════════════════════════════════════════════════════

def backup_material(mat):
    """Full copy with fake user; survives file save. Returns the copy,
    or the existing backup if one was already made."""
    name = f"{mat.name}{BACKUP_SUFFIX}"
    existing = bpy.data.materials.get(name)
    if existing is not None:
        return existing
    cp = mat.copy()
    cp.name = name
    cp.use_fake_user = True
    return cp


_CLEAN_RE = re.compile(r"[^A-Za-z0-9]+")


def clean_name_token(text):
    """'old metal.001 dark!' -> 'Old_Metal_Dark' (suffix digits dropped)."""
    text = _DUP_RE.match(text).group(1) if _DUP_RE.match(text) else text
    parts = [p for p in _CLEAN_RE.split(text) if p and not p.isdigit()]
    return "_".join(p[:1].upper() + p[1:] for p in parts) or "Material"


def pipeline_name(mat_name, prefix="MAT_", variant="A"):
    """Pipeline format: MAT_Metal_Dark_A."""
    token = clean_name_token(mat_name)
    for p in ("MAT_", "PBR_", "TOON_", "PRO_Mat_", "SF_Mat_"):
        if token.startswith(p.rstrip("_") + "_"):
            token = token[len(p.rstrip("_") + "_"):]
    return f"{prefix}{token}_{variant}"


# ═══════════════════════════════════════════════════════════════════════
#  COLOR ID
# ═══════════════════════════════════════════════════════════════════════

GOLDEN = 0.61803398875


def distinct_color(index):
    """Clearly distinct flat RGBA via golden-ratio hue stepping."""
    import colorsys
    h = (index * GOLDEN) % 1.0
    s = 0.85 if index % 2 == 0 else 0.65
    v = 0.95 if index % 3 != 2 else 0.7
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    return (r, g, b, 1.0)


def build_id_material(name, color):
    """Flat emission-style ID material (bakes clean, no shading)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    out.name = out.label = "PRO ID Output"
    out.location = (200, 0)
    emit = nt.nodes.new('ShaderNodeEmission')
    emit.name = emit.label = "PRO ID Emission"
    emit.location = (0, 0)
    emit.inputs['Color'].default_value = color
    nt.links.new(emit.outputs[0], out.inputs['Surface'])
    mat.diffuse_color = color
    return mat
