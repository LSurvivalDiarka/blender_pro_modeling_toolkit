# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_retopo.py
# v0.1.5: retopo setup (collections, shrinkwrap stacks, displays, lock)
# and drawing helpers (patches, strips, projection, relax, loop guides).
# The SOURCE mesh is never modified by any of these tools.
# ──────────────────────────────────────────────────────────────────────

from math import cos, sin, pi

import bpy
import bmesh
from mathutils import Vector

from . import character_utils as ch
from . import retopo_utils as rt


def _need_target(self, context, retopo_obj=None):
    target = rt.get_target(context, retopo_obj)
    if target is None:
        self.report({'WARNING'},
                    "Sin target: fija 'Retopo Target' en el panel o "
                    "selecciona también la malla fuente.")
    return target


# ═══════════════════════════════════════════════════════════════════════
#  RETOPO SETUP
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_retopo_create_setup(bpy.types.Operator):
    """ONE CLICK: prepare the active mesh as retopo source and create the
    retopo object (blue material, in-front, shrinkwrap, optional mirror,
    face snapping). The source is never modified destructively"""
    bl_idname = "object.pro_retopo_create_setup"
    bl_label = "Create Retopo Setup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        src = context.active_object

        ch.link_to_coll(context, src, ch.COLL_AI_SOURCE)
        p.retopo_target_object = src
        if p.retopo_display_xray:
            ch.save_materials(src)
            ch.assign_char_material(src, "PRO_Source_XRay")

        # retopo object: one starting quad floating in front of the source
        corners = [src.matrix_world @ Vector(c) for c in src.bound_box]
        center = sum(corners, Vector()) / 8.0
        start = center + Vector((0.0, -src.dimensions.y * 0.6 - 0.05, 0.0))
        size = max(min(src.dimensions) * 0.15, 0.02)
        obj = rt.new_grid_object(
            context, f"RETOPO_{src.name}", 1, 1, size, start,
            target=src, offset=p.retopo_shrinkwrap_offset,
            mirror=p.retopo_use_mirror)

        rt.enable_face_snapping(context)
        self.report({'INFO'},
                    f"Retopo listo: '{obj.name}' (shrinkwrap → {src.name}"
                    + (", mirror X" if p.retopo_use_mirror else "")
                    + ", snapping a caras activo). Entra en Edit Mode y dibuja.")
        return {'FINISHED'}


class _RetopoGridCreate:
    """Base: create a small retopo grid at the 3D cursor."""
    _cols, _rows = 1, 1
    _label = "Retopo Plane"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.pro_toolkit
        target = rt.get_target(context)
        obj = rt.new_grid_object(
            context, f"RETOPO_{self._label.replace(' ', '_')}",
            self._cols, self._rows, p.retopo_patch_size,
            context.scene.cursor.location.copy(),
            target=target, offset=p.retopo_shrinkwrap_offset,
            mirror=p.retopo_use_mirror)
        self.report({'INFO'},
                    f"'{obj.name}' creado"
                    + (f" con shrinkwrap → {target.name}" if target else
                       " (sin target — añade Shrinkwrap después)"))
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_create_mesh(_RetopoGridCreate, bpy.types.Operator):
    """Create an empty retopo mesh (single quad) at the cursor"""
    bl_idname = "object.pro_retopo_create_mesh"
    bl_label = "Create Retopo Mesh"
    bl_options = {'REGISTER', 'UNDO'}
    _cols, _rows, _label = 1, 1, "Mesh"


class OBJECT_OT_pro_retopo_create_plane(_RetopoGridCreate, bpy.types.Operator):
    """Create a single retopo quad at the cursor"""
    bl_idname = "object.pro_retopo_create_plane"
    bl_label = "Create Retopo Plane"
    bl_options = {'REGISTER', 'UNDO'}
    _cols, _rows, _label = 1, 1, "Plane"


class OBJECT_OT_pro_retopo_create_strip(_RetopoGridCreate, bpy.types.Operator):
    """Create a 1×6 retopo strip at the cursor"""
    bl_idname = "object.pro_retopo_create_strip"
    bl_label = "Create Retopo Strip"
    bl_options = {'REGISTER', 'UNDO'}
    _cols, _rows, _label = 6, 1, "Strip"


class OBJECT_OT_pro_retopo_create_patch(_RetopoGridCreate, bpy.types.Operator):
    """Create an N×N retopo patch at the cursor (size from settings)"""
    bl_idname = "object.pro_retopo_create_patch"
    bl_label = "Create Retopo Patch"
    bl_options = {'REGISTER', 'UNDO'}
    _cols, _rows, _label = 4, 4, "Patch"


class OBJECT_OT_pro_retopo_add_shrinkwrap(bpy.types.Operator):
    """Add (or update) the PRO shrinkwrap on the active object toward the
    retopo target"""
    bl_idname = "object.pro_retopo_add_shrinkwrap"
    bl_label = "Add Shrinkwrap to Target"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        target = _need_target(self, context, obj)
        if target is None or target is obj:
            return {'CANCELLED'}
        rt.add_shrinkwrap(obj, target, p.retopo_shrinkwrap_offset)
        self.report({'INFO'},
                    f"Shrinkwrap → '{target.name}' "
                    f"(offset {p.retopo_shrinkwrap_offset:.4f})")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_add_mirror_stack(bpy.types.Operator):
    """Add the classic retopo stack: Mirror (X, clip) BEFORE Shrinkwrap"""
    bl_idname = "object.pro_retopo_add_mirror_stack"
    bl_label = "Add Mirror + Shrinkwrap Retopo Stack"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        target = _need_target(self, context, obj)
        if target is None or target is obj:
            return {'CANCELLED'}
        rt.add_shrinkwrap(obj, target, p.retopo_shrinkwrap_offset)
        rt.add_mirror(obj)
        self.report({'INFO'},
                    f"Stack retopo: Mirror X + Shrinkwrap → '{target.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_create_material(bpy.types.Operator):
    """Create/assign the blue semi-transparent retopo material"""
    bl_idname = "object.pro_retopo_create_material"
    bl_label = "Create Retopo Material"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        ch.assign_char_material(obj, "PRO_Retopo_Blue")
        self.report({'INFO'}, f"PRO_Retopo_Blue asignado a '{obj.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_xray_view(bpy.types.Operator):
    """Toggle the retopology overlay (or X-Ray fallback) in the viewport"""
    bl_idname = "object.pro_retopo_xray_view"
    bl_label = "Create X-Ray Retopo View"
    bl_options = {'REGISTER'}

    def execute(self, context):
        space = context.space_data
        if space is None or space.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run this from the 3D Viewport.")
            return {'CANCELLED'}
        overlay = space.overlay
        if hasattr(overlay, "show_retopology"):
            overlay.show_retopology = not overlay.show_retopology
            state = "ON" if overlay.show_retopology else "OFF"
            self.report({'INFO'}, f"Retopology overlay: {state}")
        else:
            space.shading.show_xray = not space.shading.show_xray
            state = "ON" if space.shading.show_xray else "OFF"
            self.report({'INFO'}, f"X-Ray: {state} (fallback)")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_toggle_in_front(bpy.types.Operator):
    """Toggle 'In Front' display on the active (retopo) object"""
    bl_idname = "object.pro_retopo_toggle_in_front"
    bl_label = "Toggle Retopo In Front"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        obj.show_in_front = not obj.show_in_front
        self.report({'INFO'},
                    f"In Front {'ON' if obj.show_in_front else 'OFF'} "
                    f"en '{obj.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_set_retopo_display(bpy.types.Operator):
    """Standard retopo display on the active object (in front + wires)"""
    bl_idname = "object.pro_retopo_set_retopo_display"
    bl_label = "Set Retopo Object Display"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        rt.set_retopo_display(context.active_object, in_front=True)
        self.report({'INFO'}, "Display de retopo aplicado (in front + wire)")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_set_source_display(bpy.types.Operator):
    """Calm display for the source: textured, behind, no wires"""
    bl_idname = "object.pro_retopo_set_source_display"
    bl_label = "Set Source Object Display"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        obj.show_in_front = False
        obj.display_type = 'TEXTURED'
        obj.show_wire = False
        self.report({'INFO'}, f"Display de fuente aplicado a '{obj.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_lock_source(bpy.types.Operator):
    """Make the retopo target unselectable (no accidental clicks)"""
    bl_idname = "object.pro_retopo_lock_source"
    bl_label = "Lock Source Object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = rt.get_target(context, context.active_object)
        if target is None:
            self.report({'WARNING'}, "Sin target de retopo que bloquear.")
            return {'CANCELLED'}
        target.hide_select = True
        self.report({'INFO'}, f"'{target.name}' bloqueado (no seleccionable)")
        return {'FINISHED'}


class OBJECT_OT_pro_retopo_unlock_source(bpy.types.Operator):
    """Make the retopo target (and any frozen AI sources) selectable again"""
    bl_idname = "object.pro_retopo_unlock_source"
    bl_label = "Unlock Source Object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = 0
        target = rt.get_target(context, context.active_object)
        objs = set()
        if target is not None:
            objs.add(target)
        coll = bpy.data.collections.get(ch.COLL_AI_SOURCE)
        if coll:
            objs.update(coll.objects)
        for o in objs:
            if o.hide_select:
                o.hide_select = False
                n += 1
        self.report({'INFO'}, f"{n} fuente(s) desbloqueada(s)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  DRAWING HELPERS (Edit Mode on the retopo object)
# ═══════════════════════════════════════════════════════════════════════

def _cursor_local(context):
    obj = context.edit_object
    return obj.matrix_world.inverted() @ context.scene.cursor.location


def _project_verts(self, context, verts_only_selected=True, use_normal_ray=False):
    """Move (selected) verts of the edit object onto the target surface."""
    p = context.scene.pro_toolkit
    obj = context.edit_object
    target = _need_target(self, context, obj)
    if target is None:
        return None
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    verts = [v for v in bm.verts if v.select] if verts_only_selected else list(bm.verts)
    if not verts:
        self.report({'WARNING'}, "No vertices selected.")
        return None
    mw = obj.matrix_world
    inv = mw.inverted()
    moved = 0
    for v in verts:
        world = mw @ v.co
        loc, normal = rt.closest_point_world(target, world)
        if loc is None:
            continue
        v.co = inv @ (loc + normal * p.retopo_project_offset)
        moved += 1
    bmesh.update_edit_mesh(me)
    return moved


class MESH_OT_pro_retopo_add_quad_patch(bpy.types.Operator):
    """Add a small quad patch at the 3D cursor inside the retopo mesh"""
    bl_idname = "mesh.pro_retopo_add_quad_patch"
    bl_label = "Add Quad Patch"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        for v in bm.verts:
            v.select = False
        ret = bmesh.ops.create_grid(bm, x_segments=2, y_segments=2,
                                    size=p.retopo_patch_size / 2.0)
        at = _cursor_local(context)
        for v in ret["verts"]:
            v.co += at
            v.select = True
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me, destructive=True)
        self.report({'INFO'}, "Quad patch añadido en el cursor (proyéctalo a la superficie)")
        return {'FINISHED'}


class MESH_OT_pro_retopo_add_edge_strip(bpy.types.Operator):
    """Add a 1×4 quad strip at the 3D cursor"""
    bl_idname = "mesh.pro_retopo_add_edge_strip"
    bl_label = "Add Edge Strip"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        for v in bm.verts:
            v.select = False
        ret = bmesh.ops.create_grid(bm, x_segments=4, y_segments=1,
                                    size=p.retopo_patch_size / 2.0)
        at = _cursor_local(context)
        for v in ret["verts"]:
            v.co = Vector((v.co.x * 2.0, v.co.y * 0.5, v.co.z)) + at
            v.select = True
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me, destructive=True)
        self.report({'INFO'}, "Edge strip añadido en el cursor")
        return {'FINISHED'}


class MESH_OT_pro_retopo_bridge_edges(bpy.types.Operator):
    """Bridge two selected retopo edge loops with quads"""
    bl_idname = "mesh.pro_retopo_bridge_edges"
    bl_label = "Bridge Retopo Edges"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        try:
            bpy.ops.mesh.bridge_edge_loops()
        except RuntimeError as e:
            self.report({'WARNING'}, f"Bridge falló: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, "Loops puenteados")
        return {'FINISHED'}


class MESH_OT_pro_retopo_fill_quad(bpy.types.Operator):
    """Fill the selected boundary with quads (grid fill, F fallback)"""
    bl_idname = "mesh.pro_retopo_fill_quad"
    bl_label = "Fill Retopo Quad"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        try:
            bpy.ops.mesh.fill_grid()
            self.report({'INFO'}, "Grid fill aplicado")
        except RuntimeError:
            try:
                bpy.ops.mesh.edge_face_add()
                self.report({'INFO'}, "Cara creada (fallback F)")
            except RuntimeError as e:
                self.report({'WARNING'}, f"No se pudo rellenar: {e}")
                return {'CANCELLED'}
        return {'FINISHED'}


class MESH_OT_pro_retopo_project_to_surface(bpy.types.Operator):
    """Project the selected vertices onto the source surface (+ offset)"""
    bl_idname = "mesh.pro_retopo_project_to_surface"
    bl_label = "Project Selected to Surface"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        moved = _project_verts(self, context, verts_only_selected=True)
        if moved is None:
            return {'CANCELLED'}
        self.report({'INFO'}, f"{moved} verts proyectados a la superficie")
        return {'FINISHED'}


class MESH_OT_pro_retopo_relax(bpy.types.Operator):
    """Relax the selected retopo vertices and re-project them onto the
    source so they stay glued to the surface"""
    bl_idname = "mesh.pro_retopo_relax"
    bl_label = "Relax Retopo Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.edit_object
        target = _need_target(self, context, obj)
        if target is None:
            return {'CANCELLED'}
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        if len(sel) < 2:
            self.report({'WARNING'}, "Select at least 2 vertices.")
            return {'CANCELLED'}
        factor = p.retopo_relax_strength
        for v in sel:
            if v.is_boundary:
                continue
            nbrs = [e.other_vert(v) for e in v.link_edges]
            if nbrs:
                avg = sum((n.co for n in nbrs), Vector()) / len(nbrs)
                v.co = v.co.lerp(avg, factor)
        bmesh.update_edit_mesh(me)
        _project_verts(self, context, verts_only_selected=True)
        self.report({'INFO'}, f"{len(sel)} verts relajados y reproyectados")
        return {'FINISHED'}


class MESH_OT_pro_retopo_shrinkwrap_selected(bpy.types.Operator):
    """Snap ONLY the selected vertices to the source surface"""
    bl_idname = "mesh.pro_retopo_shrinkwrap_selected"
    bl_label = "Shrinkwrap Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        moved = _project_verts(self, context, verts_only_selected=True)
        if moved is None:
            return {'CANCELLED'}
        self.report({'INFO'}, f"{moved} verts pegados a la fuente")
        return {'FINISHED'}


class MESH_OT_pro_retopo_snap_all(bpy.types.Operator):
    """Snap EVERY vertex of the retopo mesh to the source surface"""
    bl_idname = "mesh.pro_retopo_snap_all"
    bl_label = "Snap Retopo to Source"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        moved = _project_verts(self, context, verts_only_selected=False)
        if moved is None:
            return {'CANCELLED'}
        self.report({'INFO'}, f"Toda la malla pegada ({moved} verts)")
        return {'FINISHED'}


class MESH_OT_pro_retopo_extrude_strip(bpy.types.Operator):
    """Extrude the selected boundary edges one step outward and glue the
    new vertices to the source surface"""
    bl_idname = "mesh.pro_retopo_extrude_strip"
    bl_label = "Extrude Retopo Edge Strip"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.edit_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        edges = [e for e in bm.edges if e.select and e.is_boundary]
        if not edges:
            self.report({'WARNING'}, "Selecciona aristas de borde (boundary).")
            return {'CANCELLED'}

        # outward direction: away from the average of the linked faces
        ret = bmesh.ops.extrude_edge_only(bm, edges=edges)
        new_verts = [el for el in ret["geom"]
                     if isinstance(el, bmesh.types.BMVert)]
        step = p.retopo_patch_size / 3.0
        face_pull = Vector()
        for e in edges:
            for f in e.link_faces:
                face_pull += f.calc_center_median()
        if edges and face_pull.length > 0:
            face_pull /= sum(len(e.link_faces) for e in edges) or 1
            edge_center = sum((e.verts[0].co + e.verts[1].co for e in edges),
                              Vector()) / (2 * len(edges))
            out_dir = (edge_center - face_pull)
            out_dir = out_dir.normalized() if out_dir.length > 1e-9 else Vector((0, 0, 1))
        else:
            out_dir = Vector((0, 0, 1))
        bmesh.ops.translate(bm, verts=new_verts, vec=out_dir * step)

        for v in bm.verts:
            v.select = False
        for v in new_verts:
            v.select = True
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me, destructive=True)
        _project_verts(self, context, verts_only_selected=True)
        self.report({'INFO'}, f"Strip extruido ({len(new_verts)} verts, pegado a la fuente)")
        return {'FINISHED'}


def _make_loop_guide_op(suffix, label, segments, radius_factor):
    class _Op(bpy.types.Operator):
        bl_idname = f"mesh.pro_retopo_{suffix}"
        bl_label = label
        bl_description = (f"Add a {segments}-vert guide loop at the 3D cursor "
                          "(starting ring for limbs/face/joints)")
        bl_options = {'REGISTER', 'UNDO'}

        @classmethod
        def poll(cls, context):
            return ch.edit_mesh_poll(context)

        def execute(self, context):
            p = context.scene.pro_toolkit
            me = context.edit_object.data
            bm = bmesh.from_edit_mesh(me)
            for v in bm.verts:
                v.select = False
            at = _cursor_local(context)
            r = p.retopo_patch_size * radius_factor
            verts = []
            for i in range(segments):
                a = 2.0 * pi * i / segments
                v = bm.verts.new(at + Vector((cos(a) * r, sin(a) * r, 0.0)))
                v.select = True
                verts.append(v)
            for i in range(segments):
                bm.edges.new((verts[i], verts[(i + 1) % segments]))
            bm.select_flush_mode()
            bmesh.update_edit_mesh(me, destructive=True)
            self.report({'INFO'},
                        f"{label} ({segments} verts) en el cursor — "
                        "proyéctalo y puentea con el resto")
            return {'FINISHED'}

    _Op.__name__ = f"MESH_OT_pro_retopo_{suffix}"
    return _Op


MESH_OT_pro_retopo_limb_loop_guide = _make_loop_guide_op(
    "limb_loop_guide", "Create Loop Around Limb Guide", 8, 0.6)
MESH_OT_pro_retopo_face_loop_guide = _make_loop_guide_op(
    "face_loop_guide", "Create Face Loop Guide", 12, 0.8)
MESH_OT_pro_retopo_joint_loop_guide = _make_loop_guide_op(
    "joint_loop_guide", "Create Joint Loop Guide", 8, 0.45)


classes = (
    OBJECT_OT_pro_retopo_create_setup,
    OBJECT_OT_pro_retopo_create_mesh,
    OBJECT_OT_pro_retopo_create_plane,
    OBJECT_OT_pro_retopo_create_strip,
    OBJECT_OT_pro_retopo_create_patch,
    OBJECT_OT_pro_retopo_add_shrinkwrap,
    OBJECT_OT_pro_retopo_add_mirror_stack,
    OBJECT_OT_pro_retopo_create_material,
    OBJECT_OT_pro_retopo_xray_view,
    OBJECT_OT_pro_retopo_toggle_in_front,
    OBJECT_OT_pro_retopo_set_retopo_display,
    OBJECT_OT_pro_retopo_set_source_display,
    OBJECT_OT_pro_retopo_lock_source,
    OBJECT_OT_pro_retopo_unlock_source,
    MESH_OT_pro_retopo_add_quad_patch,
    MESH_OT_pro_retopo_add_edge_strip,
    MESH_OT_pro_retopo_bridge_edges,
    MESH_OT_pro_retopo_fill_quad,
    MESH_OT_pro_retopo_project_to_surface,
    MESH_OT_pro_retopo_relax,
    MESH_OT_pro_retopo_shrinkwrap_selected,
    MESH_OT_pro_retopo_snap_all,
    MESH_OT_pro_retopo_extrude_strip,
    MESH_OT_pro_retopo_limb_loop_guide,
    MESH_OT_pro_retopo_face_loop_guide,
    MESH_OT_pro_retopo_joint_loop_guide,
)
