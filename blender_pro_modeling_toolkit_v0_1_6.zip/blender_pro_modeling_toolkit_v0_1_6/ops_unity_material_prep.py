# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_unity_material_prep.py
# v0.1.6 — Unity / Game Material Prep: readiness checks, game material
# audit, game-friendly conversion and the Unity report.
# Export itself is NOT here (planned for v0.1.8).
# ──────────────────────────────────────────────────────────────────────

import bpy

from . import material_utils as mu
from . import texture_utils as tu
from . import ops_pbr_builder

EXPORT_COLL = "PRO_Export_Preview"


def _mat_game_info(mat, props):
    """Per-material game readiness facts + issue list."""
    bsdf = mu.get_principled(mat)
    images = mu.material_images(mat)
    info = {
        "name": mat.name,
        "images": [(i.name, *tu.image_size(i)) for i in images],
        "is_pbr": mu.is_pbr(mat),
        "has_alpha": False,
        "has_normal": False,
        "has_roughness_map": False,
        "heavy": mu.is_heavy(mat),
        "nodes": len(mat.node_tree.nodes) if mat.use_nodes else 0,
        "issues": [],
    }
    if bsdf is not None:
        a = bsdf.inputs.get('Alpha')
        info["has_alpha"] = bool(a is not None
                                 and (a.is_linked or a.default_value < 1.0))
        n = bsdf.inputs.get('Normal')
        info["has_normal"] = bool(n is not None and n.is_linked)
        r = bsdf.inputs.get('Roughness')
        info["has_roughness_map"] = bool(r is not None and r.is_linked)
    if props.unity_require_pbr and not info["is_pbr"]:
        info["issues"].append("no es PBR (sin Principled BSDF conectado)")
    for name, w, h in info["images"]:
        if max(w, h) > props.unity_max_texture_size:
            info["issues"].append(
                f"textura '{name}' {w}x{h} > {props.unity_max_texture_size}px")
        if w and h and ((w & (w - 1)) or (h & (h - 1))):
            info["issues"].append(f"textura '{name}' no potencia de 2")
    if mu.has_missing_images(mat):
        info["issues"].append("texturas perdidas")
    if mu.has_absolute_paths(mat):
        info["issues"].append("rutas absolutas")
    if info["heavy"]:
        info["issues"].append(f"shader complejo ({info['nodes']} nodos)")
    if info["has_normal"]:
        # tangent-space normal needs UVs to be meaningful in Unity
        pass
    return info


def _audit(context, objs):
    props = context.scene.pro_toolkit
    rows = []
    mat_cache = {}
    for obj in objs:
        mats = [s.material for s in obj.material_slots if s.material]
        infos = []
        for m in mats:
            if m not in mat_cache:
                mat_cache[m] = _mat_game_info(m, props)
            infos.append(mat_cache[m])
        issues = []
        if len(mats) > props.unity_max_materials_per_object:
            issues.append(f"{len(mats)} materiales > "
                          f"{props.unity_max_materials_per_object} por objeto")
        if not obj.data.uv_layers:
            issues.append("sin UVs (las normales tangentes no funcionarán)")
        if any(i["has_normal"] for i in infos) and not obj.data.uv_layers:
            issues.append("normal map sin UVs")
        rows.append({"object": obj.name, "materials": infos,
                     "obj_issues": issues})
    return rows


class OBJECT_OT_pro_unity_audit(bpy.types.Operator):
    """Game Material Audit: materials per object, textures, sizes, alpha,
    normal/roughness wiring, shader complexity (read-only)"""
    bl_idname = "object.pro_unity_audit"
    bl_label = "Game Material Audit"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == 'MESH'] \
            or mu.scope_objects(context, 'SCENE')
        if not objs:
            self.report({'ERROR'}, "No hay objetos mesh.")
            return {'CANCELLED'}
        rows = _audit(context, objs)
        n_issues = sum(len(r["obj_issues"])
                       + sum(len(i["issues"]) for i in r["materials"])
                       for r in rows)
        props = context.scene.pro_toolkit
        props.unity_audit_issues = n_issues
        props.unity_audit_done = True
        if n_issues == 0:
            self.report({'INFO'},
                        f"Game audit OK: {len(rows)} objeto(s) sin "
                        "problemas. ✅")
        else:
            self.report({'WARNING'},
                        f"Game audit: {n_issues} problema(s) en "
                        f"{len(rows)} objeto(s). Genera el informe Unity "
                        "para el detalle.")
        return {'FINISHED'}


class OBJECT_OT_pro_unity_readiness(bpy.types.Operator):
    """Unity Material Readiness Check: pass/fail verdict per object
    against the panel limits (texture size, materials/object, PBR)"""
    bl_idname = "object.pro_unity_readiness"
    bl_label = "Unity Readiness Check"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == 'MESH'] \
            or mu.scope_objects(context, 'SCENE')
        if not objs:
            self.report({'ERROR'}, "No hay objetos mesh.")
            return {'CANCELLED'}
        rows = _audit(context, objs)
        failed = [r["object"] for r in rows
                  if r["obj_issues"]
                  or any(i["issues"] for i in r["materials"])]
        if not failed:
            self.report({'INFO'},
                        f"READY ✅ — {len(rows)} objeto(s) listos para Unity.")
        else:
            self.report({'WARNING'},
                        f"NOT READY — {len(failed)}/{len(rows)} objeto(s) "
                        "con problemas: " + ", ".join(failed[:5])
                        + ("…" if len(failed) > 5 else ""))
        return {'FINISHED'}


class OBJECT_OT_pro_unity_report(bpy.types.Operator):
    """Write V016_UNITY_MATERIAL_REPORT.md with the full game-readiness
    analysis and a final recommendation"""
    bl_idname = "object.pro_unity_report"
    bl_label = "Create Unity Material Report"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        objs = [o for o in context.selected_objects if o.type == 'MESH'] \
            or mu.scope_objects(context, 'SCENE')
        if not objs:
            self.report({'ERROR'}, "No hay objetos mesh.")
            return {'CANCELLED'}
        rows = _audit(context, objs)
        n_issues = sum(len(r["obj_issues"])
                       + sum(len(i["issues"]) for i in r["materials"])
                       for r in rows)
        lines = ["# V016 UNITY MATERIAL REPORT", "",
                 f"Límites: textura ≤ {props.unity_max_texture_size}px · "
                 f"materiales/objeto ≤ {props.unity_max_materials_per_object}"
                 f" · PBR requerido: {props.unity_require_pbr}", "",
                 "## Resumen",
                 f"- Objetos: **{len(rows)}**",
                 f"- Problemas: **{n_issues}**", ""]
        for r in rows:
            mats = r["materials"]
            lines.append(f"## {r['object']} — {len(mats)} material(es)")
            for iss in r["obj_issues"]:
                lines.append(f"- ⚠️ {iss}")
            for i in mats:
                lines += [
                    f"### {i['name']}",
                    f"- PBR: {'✅' if i['is_pbr'] else '❌'} · "
                    f"Alpha: {'sí' if i['has_alpha'] else 'no'} · "
                    f"Normal map: {'sí' if i['has_normal'] else 'no'} · "
                    f"Roughness map: {'sí' if i['has_roughness_map'] else 'no'}",
                    "- Texturas: "
                    + (", ".join(f"{n} ({w}x{h})" for n, w, h in i["images"])
                       or "(ninguna)"),
                ]
                lines += [f"- ⚠️ {x}" for x in i["issues"]]
            lines.append("")
        ready = n_issues == 0
        lines += ["## Veredicto",
                  "**RECOMENDADO para Unity ✅**" if ready else
                  f"**NO recomendado todavía — {n_issues} problema(s).** "
                  "Usa Convert to Game Friendly y Texture Manager, y "
                  "vuelve a auditar."]
        path = mu.write_report("V016_UNITY_MATERIAL_REPORT.md", lines)
        self.report({'INFO'}, f"Informe escrito: {path}")
        return {'FINISHED'}


class OBJECT_OT_pro_unity_convert_game_friendly(bpy.types.Operator):
    """Convert the materials of the selected objects to game-friendly PBR
    copies (PBR_<name>; originals kept with fake user)"""
    bl_idname = "object.pro_unity_convert_game_friendly"
    bl_label = "Convert Materials to Game Friendly"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        return bpy.ops.material.pro_pbr_convert_selected('EXEC_DEFAULT')


class OBJECT_OT_pro_unity_export_duplicate(bpy.types.Operator):
    """Create export duplicates of the selected objects in
    PRO_Export_Preview with clean PBR materials (sources untouched)"""
    bl_idname = "object.pro_unity_export_duplicate"
    bl_label = "Create Export Duplicate (Clean Materials)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        from . import baking_utils as bu
        props = context.scene.pro_toolkit
        coll = bu.ensure_collection(EXPORT_COLL)
        done_mats = {}
        n = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            dup = obj.copy()
            dup.data = obj.data.copy()
            dup.name = f"{obj.name}_export"
            coll.objects.link(dup)
            for slot in dup.material_slots:
                mat = slot.material
                if mat is None:
                    continue
                if mat.name.startswith(mu.PBR_PREFIX):
                    continue
                if mat not in done_mats:
                    new, _found = ops_pbr_builder._convert_safe(props, mat)
                    mat.use_fake_user = True
                    done_mats[mat] = new
                slot.material = done_mats[mat]
            n += 1
        self.report({'INFO'},
                    f"{n} duplicado(s) de export en {EXPORT_COLL} con "
                    f"{len(done_mats)} material(es) limpios. Originales "
                    "intactos.")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_unity_audit,
    OBJECT_OT_pro_unity_readiness,
    OBJECT_OT_pro_unity_report,
    OBJECT_OT_pro_unity_convert_game_friendly,
    OBJECT_OT_pro_unity_export_duplicate,
)
