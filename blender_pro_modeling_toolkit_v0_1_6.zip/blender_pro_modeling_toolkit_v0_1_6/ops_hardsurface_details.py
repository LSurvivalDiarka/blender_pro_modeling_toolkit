# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_details.py
# v0.1.4 Hard Surface Pro Suite: small mechanical details.
# Low-poly, editable, real-world sized pieces that snap onto blockouts:
# screws, hinges, handles, buttons, knobs, grilles, clamps, plates.
# Everything is filed in PRO_HardSurface_Details with a simple material.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu
from . import hardsurface_utils as hs


class _DetailOp:
    bl_options = {'REGISTER', 'UNDO'}
    pro_collection = hs.COLL_HS_DETAILS
    pro_material = "HS_Metal_Light"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        scale = context.scene.pro_toolkit.hs_detail_scale
        bm = bmesh.new()
        name = self.build(context, bm)
        if abs(scale - 1.0) > 1e-6:
            bmesh.ops.scale(bm, vec=(scale, scale, scale), verts=bm.verts[:])
        hs.finalize_hs_object(context, self, name, bm,
                              self.pro_collection, self.pro_material,
                              at_floor=False)
        return {'FINISHED'}


class OBJECT_OT_pro_hs_create_screw(_DetailOp, bpy.types.Operator):
    """Create a low-poly screw head with a cross drive hint
    (radius 0.015 m, height 0.008 m)"""
    bl_idname = "object.pro_hs_create_screw"
    bl_label = "Create Screw / Bolt"

    radius: bpy.props.FloatProperty(name="Head Radius", default=0.015, min=0.002, soft_max=0.1, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Head Height", default=0.008, min=0.001, soft_max=0.05, unit='LENGTH')

    def build(self, context, bm):
        r, h = self.radius, self.height
        cu.add_cylinder(bm, r, h, 12, radius_top=r * 0.85)
        slot_w, slot_d = r * 1.2, r * 0.18
        cu.add_box(bm, slot_w, slot_d, h * 0.3, z0=h * 0.95)
        cu.add_box(bm, slot_d, slot_w, h * 0.3, z0=h * 0.95)
        return "HS_Screw"


class OBJECT_OT_pro_hs_create_washer(_DetailOp, bpy.types.Operator):
    """Create a flat washer ring"""
    bl_idname = "object.pro_hs_create_washer"
    bl_label = "Create Washer"

    radius: bpy.props.FloatProperty(name="Outer Radius", default=0.018, min=0.003, soft_max=0.1, unit='LENGTH')
    hole_radius: bpy.props.FloatProperty(name="Hole Radius", default=0.008, min=0.001, soft_max=0.09, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Thickness", default=0.002, min=0.0005, soft_max=0.02, unit='LENGTH')

    def build(self, context, bm):
        ri = min(self.hole_radius, self.radius * 0.85)
        hs.add_ring(bm, self.radius, ri, self.height, 16)
        return "HS_Washer"


class OBJECT_OT_pro_hs_create_hinge(_DetailOp, bpy.types.Operator):
    """Create a door hinge: two leaves and a knuckle pin
    (0.08 x 0.03 x 0.20 m)"""
    bl_idname = "object.pro_hs_create_hinge"
    bl_label = "Create Hinge"

    width: bpy.props.FloatProperty(name="Width", default=0.08, min=0.02, soft_max=0.3, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Leaf Thickness", default=0.006, min=0.002, soft_max=0.03, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.20, min=0.04, soft_max=0.6, unit='LENGTH')

    def build(self, context, bm):
        w, d, h = self.width, self.depth, self.height
        pin_r = 0.012
        leaf = (w - pin_r) / 2.0
        cu.add_box(bm, leaf, d, h, cx=-(pin_r + leaf) / 2.0)
        cu.add_box(bm, leaf, d, h, cx=(pin_r + leaf) / 2.0)
        cu.add_cylinder(bm, pin_r, h * 1.04, 10, z0=-h * 0.02)
        return "HS_Hinge"


class OBJECT_OT_pro_hs_create_handle(_DetailOp, bpy.types.Operator):
    """Create a bar handle on two round standoffs
    (0.25 m wide, 0.06 m standoff)"""
    bl_idname = "object.pro_hs_create_handle"
    bl_label = "Create Handle"

    length: bpy.props.FloatProperty(name="Width", default=0.25, min=0.05, soft_max=1.5, unit='LENGTH')
    standoff: bpy.props.FloatProperty(name="Standoff", default=0.06, min=0.01, soft_max=0.3, unit='LENGTH')
    bar_radius: bpy.props.FloatProperty(name="Bar Radius", default=0.012, min=0.003, soft_max=0.05, unit='LENGTH')

    def build(self, context, bm):
        r, s = self.bar_radius, self.standoff
        half = (self.length - 2 * r) / 2.0
        cu.add_cylinder(bm, r, s, 10, cx=-half)
        cu.add_cylinder(bm, r, s, 10, cx=half)
        # grip bar across the top, lying along X
        ret = bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False,
                                    segments=10, radius1=r, radius2=r,
                                    depth=self.length)
        for v in ret["verts"]:
            x, y, z = v.co.x, v.co.y, v.co.z
            v.co.x = z
            v.co.y = y
            v.co.z = x + s + r
        return "HS_Handle"


class OBJECT_OT_pro_hs_create_rubber_foot(_DetailOp, bpy.types.Operator):
    """Create a small tapered rubber foot"""
    bl_idname = "object.pro_hs_create_rubber_foot"
    bl_label = "Create Rubber Foot"
    pro_material = "HS_Rubber_Dark"

    radius: bpy.props.FloatProperty(name="Radius", default=0.025, min=0.005, soft_max=0.1, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.02, min=0.004, soft_max=0.1, unit='LENGTH')

    def build(self, context, bm):
        cu.add_cylinder(bm, self.radius, self.height, 12,
                        radius_top=self.radius * 0.8)
        return "HS_Rubber_Foot"


class OBJECT_OT_pro_hs_create_small_button(_DetailOp, bpy.types.Operator):
    """Create a small push button on a base plate
    (0.04 x 0.04 x 0.015 m)"""
    bl_idname = "object.pro_hs_create_small_button"
    bl_label = "Create Small Button"
    pro_material = "HS_Button_Dark"

    size: bpy.props.FloatProperty(name="Size", default=0.04, min=0.01, soft_max=0.2, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.015, min=0.003, soft_max=0.1, unit='LENGTH')

    def build(self, context, bm):
        s, h = self.size, self.height
        cu.add_box(bm, s, s, h * 0.4)                           # base plate
        cu.add_cylinder(bm, s * 0.35, h, 12, radius_top=s * 0.32)
        return "HS_Small_Button"


class OBJECT_OT_pro_hs_create_switch(_DetailOp, bpy.types.Operator):
    """Create a rocker switch: base plate with a tilted rocker wedge"""
    bl_idname = "object.pro_hs_create_switch"
    bl_label = "Create Switch"
    pro_material = "HS_Plastic_Black"

    width: bpy.props.FloatProperty(name="Width", default=0.03, min=0.01, soft_max=0.15, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.05, min=0.01, soft_max=0.2, unit='LENGTH')

    def build(self, context, bm):
        w, d = self.width, self.depth
        cu.add_box(bm, w * 1.4, d * 1.2, 0.004)                 # face plate
        hs.add_wedge(bm, w, d * 0.8, 0.014, 0.006, z0=0.004)    # rocker
        return "HS_Switch"


class OBJECT_OT_pro_hs_create_knob(_DetailOp, bpy.types.Operator):
    """Create a rotary knob with a position indicator"""
    bl_idname = "object.pro_hs_create_knob"
    bl_label = "Create Knob"
    pro_material = "HS_Plastic_Black"

    radius: bpy.props.FloatProperty(name="Radius", default=0.02, min=0.005, soft_max=0.1, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.02, min=0.005, soft_max=0.1, unit='LENGTH')

    def build(self, context, bm):
        r, h = self.radius, self.height
        cu.add_cylinder(bm, r, h * 0.45, 14)                    # base skirt
        cu.add_cylinder(bm, r * 0.75, h, 14, radius_top=r * 0.7)
        cu.add_box(bm, r * 0.12, r * 0.8, h * 0.18,
                   cy=-r * 0.25, z0=h * 0.98)                   # indicator
        return "HS_Knob"


class OBJECT_OT_pro_hs_create_vent_grille(_DetailOp, bpy.types.Operator):
    """Create a vent grille: frame with louver slats (0.40 x 0.15 m)"""
    bl_idname = "object.pro_hs_create_vent_grille"
    bl_label = "Create Vent Grille"

    width: bpy.props.FloatProperty(name="Width", default=0.40, min=0.05, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.15, min=0.05, soft_max=2.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.02, min=0.005, soft_max=0.1, unit='LENGTH')
    slats: bpy.props.IntProperty(name="Slats", default=4, min=1, max=20)

    def build(self, context, bm):
        w, h, d, f = self.width, self.height, self.depth, 0.015
        cu.add_box(bm, f, d, h, cx=-(w - f) / 2.0)
        cu.add_box(bm, f, d, h, cx=(w - f) / 2.0)
        cu.add_box(bm, w - 2 * f, d, f)
        cu.add_box(bm, w - 2 * f, d, f, z0=h - f)
        span = (h - 2 * f) / (self.slats + 1)
        for i in range(1, self.slats + 1):
            cu.add_box(bm, w - 2 * f, d * 0.5, 0.008,
                       z0=f + span * i - 0.004)
        return "HS_Vent_Grille"


class OBJECT_OT_pro_hs_create_cable_clamp(_DetailOp, bpy.types.Operator):
    """Create a cable clamp: base plate with a saddle over the cable"""
    bl_idname = "object.pro_hs_create_cable_clamp"
    bl_label = "Create Cable Clamp"
    pro_material = "HS_Plastic_White"

    cable_radius: bpy.props.FloatProperty(name="Cable Radius", default=0.008, min=0.002, soft_max=0.05, unit='LENGTH')

    def build(self, context, bm):
        r = self.cable_radius
        w = r * 5.0
        cu.add_box(bm, w, r * 3.0, 0.003)                       # base plate
        # saddle: half-tube over the cable, modeled as an arch band along Y
        hs.add_cylinder_y(bm, r * 1.5, r * 2.6, 10, cz=0.003 + r * 0.4)
        return "HS_Cable_Clamp"


class OBJECT_OT_pro_hs_create_metal_plate(_DetailOp, bpy.types.Operator):
    """Create a thin metal plate with four corner screw heads"""
    bl_idname = "object.pro_hs_create_metal_plate"
    bl_label = "Create Metal Plate"

    width: bpy.props.FloatProperty(name="Width", default=0.2, min=0.02, soft_max=2.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.12, min=0.02, soft_max=2.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.004, min=0.001, soft_max=0.05, unit='LENGTH')

    def build(self, context, bm):
        w, d, t = self.width, self.depth, self.thickness
        cu.add_box(bm, w, d, t)
        m = min(0.018, w / 5.0, d / 5.0)
        for sx in (-1, 1):
            for sy in (-1, 1):
                cu.add_cylinder(bm, 0.006, 0.004, 8,
                                cx=sx * (w / 2.0 - m),
                                cy=sy * (d / 2.0 - m), z0=t)
        return "HS_Metal_Plate"


class OBJECT_OT_pro_hs_create_corner_protector(_DetailOp, bpy.types.Operator):
    """Create an L-angle corner protector strip"""
    bl_idname = "object.pro_hs_create_corner_protector"
    bl_label = "Create Corner Protector"

    height: bpy.props.FloatProperty(name="Height", default=0.5, min=0.05, soft_max=3.0, unit='LENGTH')
    wing: bpy.props.FloatProperty(name="Wing Width", default=0.04, min=0.01, soft_max=0.2, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.004, min=0.001, soft_max=0.02, unit='LENGTH')

    def build(self, context, bm):
        w, t, h = self.wing, self.thickness, self.height
        cu.add_box(bm, w, t, h, cx=w / 2.0 - t / 2.0, cy=-t / 2.0)
        cu.add_box(bm, t, w - t, h, cx=-t / 2.0 + t, cy=(w - t) / 2.0 - t)
        return "HS_Corner_Protector"


classes = (
    OBJECT_OT_pro_hs_create_screw,
    OBJECT_OT_pro_hs_create_washer,
    OBJECT_OT_pro_hs_create_hinge,
    OBJECT_OT_pro_hs_create_handle,
    OBJECT_OT_pro_hs_create_rubber_foot,
    OBJECT_OT_pro_hs_create_small_button,
    OBJECT_OT_pro_hs_create_switch,
    OBJECT_OT_pro_hs_create_knob,
    OBJECT_OT_pro_hs_create_vent_grille,
    OBJECT_OT_pro_hs_create_cable_clamp,
    OBJECT_OT_pro_hs_create_metal_plate,
    OBJECT_OT_pro_hs_create_corner_protector,
)
