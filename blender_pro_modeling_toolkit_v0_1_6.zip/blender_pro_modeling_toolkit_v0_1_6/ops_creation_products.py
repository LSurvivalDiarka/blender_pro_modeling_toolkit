# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_creation_products.py
# v0.1.3 Pro Modeling Creation Suite: Product & Prop bases.
# Low-poly editable placeholders at real shelf-product scale, ready to
# be detailed into final assets.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu


class _CreateOp:
    bl_options = {'REGISTER', 'UNDO'}
    pro_collection = cu.COLL_PRODUCTS
    pro_material = "SF_Blockout_Product"

    @classmethod
    def poll(cls, context):
        return cu.object_mode_poll(context)

    def execute(self, context):
        bm = bmesh.new()
        name = self.build(context, bm)
        cu.finalize_new_object(context, self, name, bm,
                               self.pro_collection, self.pro_material)
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Packaged products
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_product_box(_CreateOp, bpy.types.Operator):
    """Create a product box base (cereal/detergent style packaging)"""
    bl_idname = "object.pro_create_product_box"
    bl_label = "Product Box"

    size: bpy.props.EnumProperty(
        name="Size",
        items=(('SMALL', "Small (0.12 x 0.05 x 0.18)", ""),
               ('MEDIUM', "Medium (0.18 x 0.07 x 0.25)", ""),
               ('CUSTOM', "Custom", "Use the width/depth/height values")),
        default='MEDIUM')
    width: bpy.props.FloatProperty(name="Width", default=0.18, min=0.01, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.07, min=0.01, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.25, min=0.01, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        dims = {'SMALL': (0.12, 0.05, 0.18),
                'MEDIUM': (0.18, 0.07, 0.25),
                'CUSTOM': (self.width, self.depth, self.height)}[self.size]
        cu.add_box(bm, *dims)
        suffix = {'SMALL': "_S", 'MEDIUM': "_M", 'CUSTOM': ""}[self.size]
        return f"PRO_Product_Box{suffix}"


class OBJECT_OT_pro_create_product_can(_CreateOp, bpy.types.Operator):
    """Create a product can base (0.065 m diameter x 0.12 m tall)"""
    bl_idname = "object.pro_create_product_can"
    bl_label = "Product Can"

    diameter: bpy.props.FloatProperty(name="Diameter", default=0.065, min=0.01, soft_max=0.5, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.12, min=0.01, soft_max=0.6, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=16, min=6, max=64)

    def build(self, context, bm):
        cu.add_cylinder(bm, self.diameter / 2.0, self.height, self.segments)
        return "PRO_Product_Can"


class OBJECT_OT_pro_create_product_bottle(_CreateOp, bpy.types.Operator):
    """Create a product bottle base (body + shoulder + neck, 0.28 m tall)"""
    bl_idname = "object.pro_create_product_bottle"
    bl_label = "Product Bottle"

    diameter: bpy.props.FloatProperty(name="Body Diameter", default=0.075, min=0.01, soft_max=0.5, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Total Height", default=0.28, min=0.05, soft_max=1.0, unit='LENGTH')
    neck_diameter: bpy.props.FloatProperty(name="Neck Diameter", default=0.03, min=0.005, soft_max=0.2, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=16, min=6, max=64)

    def build(self, context, bm):
        r_body = self.diameter / 2.0
        r_neck = min(self.neck_diameter / 2.0, r_body)
        h_body = self.height * 0.70
        h_shoulder = self.height * 0.12
        h_neck = self.height - h_body - h_shoulder
        cu.add_cylinder(bm, r_body, h_body, self.segments)
        cu.add_cylinder(bm, r_body, h_shoulder, self.segments,
                        z0=h_body, radius_top=r_neck)
        cu.add_cylinder(bm, r_neck, h_neck, self.segments,
                        z0=h_body + h_shoulder)
        return "PRO_Product_Bottle"


class OBJECT_OT_pro_create_snack_bag(_CreateOp, bpy.types.Operator):
    """Create a snack bag placeholder (pinched-top box)"""
    bl_idname = "object.pro_create_snack_bag"
    bl_label = "Snack Bag Placeholder"

    width: bpy.props.FloatProperty(name="Width", default=0.14, min=0.02, soft_max=0.6, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.05, min=0.01, soft_max=0.3, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.20, min=0.02, soft_max=0.6, unit='LENGTH')

    def build(self, context, bm):
        verts = cu.add_box(bm, self.width, self.depth, self.height)
        top_z = max(v.co.z for v in verts)
        for v in verts:                       # pinch the top like a sealed bag
            if abs(v.co.z - top_z) < 1e-6:
                v.co.y *= 0.15
        return "PRO_Snack_Bag"


class OBJECT_OT_pro_create_milk_carton(_CreateOp, bpy.types.Operator):
    """Create a milk/juice carton with gable top (0.09 x 0.09 x 0.22 m)"""
    bl_idname = "object.pro_create_milk_carton"
    bl_label = "Carton / Milk Box"

    width: bpy.props.FloatProperty(name="Width", default=0.09, min=0.02, soft_max=0.4, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.09, min=0.02, soft_max=0.4, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Total Height", default=0.22, min=0.05, soft_max=0.6, unit='LENGTH')

    def build(self, context, bm):
        gable = self.height * 0.18
        body_h = self.height - gable
        hw, hd = self.width / 2.0, self.depth / 2.0
        cu.add_box(bm, self.width, self.depth, body_h)
        # Gable top: prism with ridge along X
        c1 = bm.verts.new((-hw, -hd, body_h))
        c2 = bm.verts.new((hw, -hd, body_h))
        c3 = bm.verts.new((hw, hd, body_h))
        c4 = bm.verts.new((-hw, hd, body_h))
        r1 = bm.verts.new((-hw, 0.0, self.height))
        r2 = bm.verts.new((hw, 0.0, self.height))
        bm.faces.new((c1, c2, r2, r1))
        bm.faces.new((c3, c4, r1, r2))
        bm.faces.new((c2, c3, r2))
        bm.faces.new((c4, c1, r1))
        return "PRO_Milk_Carton"


# ═══════════════════════════════════════════════════════════════════════
#  Labels / signage
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_label_plane(_CreateOp, bpy.types.Operator):
    """Create a vertical label plane for product artwork"""
    bl_idname = "object.pro_create_label_plane"
    bl_label = "Label Plane"

    width: bpy.props.FloatProperty(name="Width", default=0.10, min=0.01, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.06, min=0.01, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        hw = self.width / 2.0
        vs = [bm.verts.new((-hw, 0.0, 0.0)),
              bm.verts.new((hw, 0.0, 0.0)),
              bm.verts.new((hw, 0.0, self.height)),
              bm.verts.new((-hw, 0.0, self.height))]
        bm.faces.new(vs)
        return "PRO_Label_Plane"


class OBJECT_OT_pro_create_price_tag(_CreateOp, bpy.types.Operator):
    """Create a shelf price tag (0.12 x 0.04 x 0.005 m)"""
    bl_idname = "object.pro_create_price_tag"
    bl_label = "Price Tag"

    width: bpy.props.FloatProperty(name="Width", default=0.12, min=0.02, soft_max=0.5, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.04, min=0.01, soft_max=0.3, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.005, min=0.001, soft_max=0.05, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.thickness, self.height)
        return "PRO_Price_Tag"


class OBJECT_OT_pro_create_simple_sign(_CreateOp, bpy.types.Operator):
    """Create a simple sign panel, optionally on a post"""
    bl_idname = "object.pro_create_simple_sign"
    bl_label = "Simple Sign"
    pro_material = "SF_Blockout_Prop"

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.1, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.1, soft_max=3.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.02, min=0.005, soft_max=0.2, unit='LENGTH')
    with_post: bpy.props.BoolProperty(
        name="On Post", description="Raise the sign on a 0.05 m post", default=False)
    post_height: bpy.props.FloatProperty(name="Post Height", default=1.6, min=0.2, soft_max=4.0, unit='LENGTH')

    def build(self, context, bm):
        z0 = 0.0
        if self.with_post:
            cu.add_box(bm, 0.05, 0.05, self.post_height)
            z0 = self.post_height
        cu.add_box(bm, self.width, self.thickness, self.height, z0=z0)
        return "PRO_Simple_Sign"


# ═══════════════════════════════════════════════════════════════════════
#  Store equipment blockouts
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_cash_register(_CreateOp, bpy.types.Operator):
    """Create a cash register blockout (0.45 x 0.45 x 0.35 m)"""
    bl_idname = "object.pro_create_cash_register"
    bl_label = "Cash Register Blockout"
    pro_material = "SF_Blockout_Prop"

    width: bpy.props.FloatProperty(name="Width", default=0.45, min=0.1, soft_max=1.5, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.45, min=0.1, soft_max=1.5, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.35, min=0.1, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        body_h = self.height * 0.55
        cu.add_box(bm, self.width, self.depth, body_h)
        # Display screen block, tilted footprint at the back
        cu.add_box(bm, self.width * 0.8, self.depth * 0.15,
                   self.height - body_h, cy=self.depth * 0.3, z0=body_h)
        return "PRO_Cash_Register_Blockout"


class OBJECT_OT_pro_create_fridge_blockout(_CreateOp, bpy.types.Operator):
    """Create an upright fridge blockout (1.20 x 0.75 x 2.10 m)"""
    bl_idname = "object.pro_create_fridge_blockout"
    bl_label = "Fridge Blockout"
    pro_material = "SF_Blockout_Metal"

    width: bpy.props.FloatProperty(name="Width", default=1.2, min=0.4, soft_max=4.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.75, min=0.3, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.1, min=0.8, soft_max=3.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.depth, 0.12)              # base plinth
        cu.add_box(bm, self.width, self.depth, self.height - 0.12, z0=0.12)
        return "PRO_Fridge_Blockout"


class OBJECT_OT_pro_create_freezer_chest(_CreateOp, bpy.types.Operator):
    """Create a freezer chest blockout (1.50 x 0.75 x 0.90 m)"""
    bl_idname = "object.pro_create_freezer_chest"
    bl_label = "Freezer Chest Blockout"
    pro_material = "SF_Blockout_Metal"

    width: bpy.props.FloatProperty(name="Width", default=1.5, min=0.4, soft_max=4.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.75, min=0.3, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.9, min=0.3, soft_max=1.5, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.depth, self.height - 0.03)
        # Lid hint (slightly inset slab)
        cu.add_box(bm, self.width - 0.04, self.depth - 0.04, 0.03,
                   z0=self.height - 0.03)
        return "PRO_Freezer_Chest_Blockout"


class OBJECT_OT_pro_create_shopping_basket(_CreateOp, bpy.types.Operator):
    """Create a shopping basket blockout (tapered, 0.45 x 0.30 x 0.25 m)"""
    bl_idname = "object.pro_create_shopping_basket"
    bl_label = "Shopping Basket Blockout"
    pro_material = "SF_Blockout_Prop"

    width: bpy.props.FloatProperty(name="Top Width", default=0.45, min=0.1, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Top Depth", default=0.30, min=0.1, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.25, min=0.05, soft_max=0.6, unit='LENGTH')

    def build(self, context, bm):
        verts = cu.add_box(bm, self.width, self.depth, self.height)
        for v in verts:                       # taper the bottom inwards
            if v.co.z < 1e-6:
                v.co.x *= 0.85
                v.co.y *= 0.85
        return "PRO_Shopping_Basket_Blockout"


class OBJECT_OT_pro_create_shopping_cart(_CreateOp, bpy.types.Operator):
    """Create a simple shopping cart blockout (basket + chassis + handle)"""
    bl_idname = "object.pro_create_shopping_cart"
    bl_label = "Shopping Cart Blockout"
    pro_material = "SF_Blockout_Metal"

    def build(self, context, bm):
        # Wheels (4 stubby boxes)
        for cx in (-0.22, 0.22):
            for cy in (-0.35, 0.35):
                cu.add_box(bm, 0.06, 0.06, 0.12, cx=cx, cy=cy)
        cu.add_box(bm, 0.50, 0.85, 0.04, z0=0.12)              # lower tray
        # Tapered basket
        verts = cu.add_box(bm, 0.55, 0.85, 0.35, z0=0.55)
        for v in verts:
            if v.co.z < 0.55 + 1e-6:
                v.co.x *= 0.85
                v.co.y = (v.co.y - 0.06) * 0.85 + 0.06
        # Handle bar
        cu.add_box(bm, 0.59, 0.04, 0.04, cy=0.47, z0=0.95)
        cu.add_box(bm, 0.04, 0.04, 0.12, cx=-0.275, cy=0.47, z0=0.83)
        cu.add_box(bm, 0.04, 0.04, 0.12, cx=0.275, cy=0.47, z0=0.83)
        return "PRO_Shopping_Cart_Blockout"


classes = (
    OBJECT_OT_pro_create_product_box,
    OBJECT_OT_pro_create_product_can,
    OBJECT_OT_pro_create_product_bottle,
    OBJECT_OT_pro_create_snack_bag,
    OBJECT_OT_pro_create_milk_carton,
    OBJECT_OT_pro_create_label_plane,
    OBJECT_OT_pro_create_price_tag,
    OBJECT_OT_pro_create_simple_sign,
    OBJECT_OT_pro_create_cash_register,
    OBJECT_OT_pro_create_fridge_blockout,
    OBJECT_OT_pro_create_freezer_chest,
    OBJECT_OT_pro_create_shopping_basket,
    OBJECT_OT_pro_create_shopping_cart,
)
