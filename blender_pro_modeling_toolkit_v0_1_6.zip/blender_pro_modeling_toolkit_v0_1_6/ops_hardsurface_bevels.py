# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_bevels.py
# v0.1.4 Hard Surface Pro Suite: bevel + normal tools.
# Non-destructive by default. Never touches UVs or materials; the only
# destructive op (Apply Bevel Stack Safely) creates a backup first.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
import math

from . import core_toolkit
from . import hardsurface_utils as hs


class _HSObjectOp:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))


class _HSEditOp:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.active_object is not None)


def _shade_smooth_by_angle(obj, angle_deg=30.0):
    """Enable smooth shading with a sharp-angle threshold, compatible with
    Blender 4.1+ (Smooth by Angle modifier era) without relying on ops."""
    for poly in obj.data.polygons:
        poly.use_smooth = True
    # Mark edges sharper than the threshold so bevel/WN keep crisp corners
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    limit = math.radians(angle_deg)
    for e in bm.edges:
        if len(e.link_faces) == 2:
            e.smooth = e.calc_face_angle() <= limit
    bm.to_mesh(me)
    bm.free()
    me.update()


class OBJECT_OT_pro_hs_smart_bevel(_HSObjectOp, bpy.types.Operator):
    """Add a complete bevel setup to the selected objects: Bevel modifier
    (clamped for small objects) + Weighted Normal + smooth shading.
    Non-destructive by default; warns about unapplied scale"""
    bl_idname = "object.pro_hs_smart_bevel"
    bl_label = "Smart Bevel"

    def execute(self, context):
        props = context.scene.pro_toolkit
        done = 0
        for obj in hs.selected_mesh_objects(context):
            hs.warn_or_apply_scale(self, context, obj)

            if props.hs_non_destructive:
                mod = hs.add_bevel_modifier(obj, props)
                if props.hs_auto_weighted_normals:
                    hs.add_weighted_normal_modifier(obj)
                _shade_smooth_by_angle(obj)
                if mod.width < props.hs_bevel_amount - 1e-9:
                    self.report({'INFO'},
                                f"'{obj.name}': bevel clamped to {mod.width:.3f} m "
                                "(10% of smallest dimension) to avoid blow-out.")
            else:
                if obj.data.users > 1:
                    self.report({'WARNING'},
                                f"'{obj.name}': shared mesh data — skipped "
                                "destructive bevel (make single-user first).")
                    continue
                backup = core_toolkit.backup_object(obj)
                mod = hs.add_bevel_modifier(obj, props)
                with context.temp_override(object=obj, active_object=obj):
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                if props.hs_auto_weighted_normals:
                    hs.add_weighted_normal_modifier(obj)
                _shade_smooth_by_angle(obj)
                self.report({'INFO'},
                            f"'{obj.name}': bevel applied. Backup: {backup.name}")
            done += 1
        if not done:
            return {'CANCELLED'}
        self.report({'INFO'}, f"Smart Bevel set up on {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_weighted_normal(_HSObjectOp, bpy.types.Operator):
    """Add a Weighted Normal setup (modifier + smooth shading + sharp edges
    by angle) to the selected objects. Fixes shading on beveled hard surfaces"""
    bl_idname = "object.pro_hs_weighted_normal"
    bl_label = "Weighted Normal"

    def execute(self, context):
        done = 0
        for obj in hs.selected_mesh_objects(context):
            hs.add_weighted_normal_modifier(obj)
            _shade_smooth_by_angle(obj)
            done += 1
        self.report({'INFO'}, f"Weighted Normal set up on {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_auto_smooth(_HSObjectOp, bpy.types.Operator):
    """Smooth shading with sharp edges above the angle threshold
    (Auto Smooth / Smooth by Angle equivalent, no extra modifiers)"""
    bl_idname = "object.pro_hs_auto_smooth"
    bl_label = "Auto Smooth / Smooth by Angle"

    angle: bpy.props.FloatProperty(
        name="Angle", description="Edges sharper than this stay hard",
        default=30.0, min=1.0, max=90.0, subtype='UNSIGNED')

    def execute(self, context):
        done = 0
        for obj in hs.selected_mesh_objects(context):
            _shade_smooth_by_angle(obj, self.angle)
            done += 1
        self.report({'INFO'},
                    f"Smooth by angle ({self.angle:.0f}°) on {done} object(s).")
        return {'FINISHED'}


class MESH_OT_pro_hs_mark_sharp(_HSEditOp, bpy.types.Operator):
    """Mark the selected edges as sharp (if nothing is selected,
    mark every edge above 30 degrees)"""
    bl_idname = "mesh.pro_hs_mark_sharp"
    bl_label = "Mark Sharp Edges"

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [e for e in bm.edges if e.select]
        if sel:
            for e in sel:
                e.smooth = False
            n = len(sel)
        else:
            limit = math.radians(30.0)
            n = 0
            for e in bm.edges:
                if len(e.link_faces) == 2 and e.calc_face_angle() > limit:
                    e.smooth = False
                    n += 1
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, f"{n} edge(s) marked sharp.")
        return {'FINISHED'}


class MESH_OT_pro_hs_clear_sharp(_HSEditOp, bpy.types.Operator):
    """Clear sharp marking from the selected edges
    (if nothing is selected, clear the whole mesh)"""
    bl_idname = "mesh.pro_hs_clear_sharp"
    bl_label = "Clear Sharp Edges"

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [e for e in bm.edges if e.select] or bm.edges[:]
        n = 0
        for e in sel:
            if not e.smooth:
                e.smooth = True
                n += 1
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, f"Sharp cleared on {n} edge(s).")
        return {'FINISHED'}


class MESH_OT_pro_hs_bevel_edges(_HSEditOp, bpy.types.Operator):
    """Bevel the selected edges using the Hard Surface bevel settings"""
    bl_idname = "mesh.pro_hs_bevel_edges"
    bl_label = "Bevel Selected Edges"

    def execute(self, context):
        props = context.scene.pro_toolkit
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        edges = [e for e in bm.edges if e.select]
        if not edges:
            self.report({'WARNING'}, "No edges selected.")
            return {'CANCELLED'}
        width = hs.safe_bevel_width(obj, props.hs_bevel_amount)
        bmesh.ops.bevel(bm, geom=edges, offset=width, offset_type='OFFSET',
                        segments=props.hs_bevel_segments,
                        profile=props.hs_bevel_profile,
                        affect='EDGES', clamp_overlap=True)
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'},
                    f"{len(edges)} edge(s) beveled at {width:.3f} m.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_bevel_object_nd(_HSObjectOp, bpy.types.Operator):
    """Add an angle-limited Bevel modifier to the selected objects
    (modifier only — nothing is applied)"""
    bl_idname = "object.pro_hs_bevel_object_nd"
    bl_label = "Bevel Object Non-Destructive"

    def execute(self, context):
        props = context.scene.pro_toolkit
        done = 0
        for obj in hs.selected_mesh_objects(context):
            hs.warn_or_apply_scale(self, context, obj)
            hs.add_bevel_modifier(obj, props)
            done += 1
        self.report({'INFO'}, f"Bevel modifier added to {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_add_bevel_modifier(_HSObjectOp, bpy.types.Operator):
    """Add a plain Bevel modifier with the current Hard Surface settings"""
    bl_idname = "object.pro_hs_add_bevel_modifier"
    bl_label = "Add Bevel Modifier"

    def execute(self, context):
        props = context.scene.pro_toolkit
        done = 0
        for obj in hs.selected_mesh_objects(context):
            hs.add_bevel_modifier(obj, props)
            done += 1
        self.report({'INFO'}, f"Bevel modifier added to {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_add_wn_modifier(_HSObjectOp, bpy.types.Operator):
    """Add a plain Weighted Normal modifier (Keep Sharp enabled)"""
    bl_idname = "object.pro_hs_add_wn_modifier"
    bl_label = "Add Weighted Normal Modifier"

    def execute(self, context):
        done = 0
        for obj in hs.selected_mesh_objects(context):
            hs.add_weighted_normal_modifier(obj)
            done += 1
        self.report({'INFO'}, f"Weighted Normal added to {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_apply_bevel_stack(_HSObjectOp, bpy.types.Operator):
    """Apply the Bevel and Weighted Normal modifiers of the selected objects.
    Creates a backup first; multi-user meshes are skipped with a report.
    UVs and materials are preserved"""
    bl_idname = "object.pro_hs_apply_bevel_stack"
    bl_label = "Apply Bevel Stack Safely"

    def execute(self, context):
        applied = skipped = 0
        for obj in hs.selected_mesh_objects(context):
            mods = [m for m in obj.modifiers
                    if m.type in {'BEVEL', 'WEIGHTED_NORMAL'}]
            if not mods:
                continue
            if obj.data.users > 1:
                self.report({'WARNING'},
                            f"'{obj.name}': shared mesh data — skipped "
                            "(make single-user first).")
                skipped += 1
                continue
            backup = core_toolkit.backup_object(obj)
            with context.temp_override(object=obj, active_object=obj):
                for m in mods:
                    bpy.ops.object.modifier_apply(modifier=m.name)
            self.report({'INFO'},
                        f"'{obj.name}': {len(mods)} modifier(s) applied. "
                        f"Backup: {backup.name}")
            applied += 1
        if not applied and not skipped:
            self.report({'INFO'}, "No Bevel/Weighted Normal modifiers found.")
            return {'CANCELLED'}
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_hs_smart_bevel,
    OBJECT_OT_pro_hs_weighted_normal,
    OBJECT_OT_pro_hs_auto_smooth,
    MESH_OT_pro_hs_mark_sharp,
    MESH_OT_pro_hs_clear_sharp,
    MESH_OT_pro_hs_bevel_edges,
    OBJECT_OT_pro_hs_bevel_object_nd,
    OBJECT_OT_pro_hs_add_bevel_modifier,
    OBJECT_OT_pro_hs_add_wn_modifier,
    OBJECT_OT_pro_hs_apply_bevel_stack,
)
