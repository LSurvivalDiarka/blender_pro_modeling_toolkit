# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_topology_audit.py
# v0.1.5: professional organic topology audit. Threshold-based selectors
# (poles, density, slivers, tiny faces, holes, loose parts) + a full
# audit with a Retopo Readiness score and a markdown report.
# Density/tiny detections are relative to the mesh's own averages and
# are labelled ESTIMATED. N-gon/Tri selection reuses the v0.1.1 ops.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import character_utils as ch

TOPO_REPORT_NAME = "V015_TOPOLOGY_AUDIT_REPORT.md"


# ═══════════════════════════════════════════════════════════════════════
#  SELECTION TOOLS (enter Edit Mode automatically)
# ═══════════════════════════════════════════════════════════════════════

class _TopoSelectOp:
    bl_options = {'REGISTER', 'UNDO'}
    _mode = 'VERT'          # VERT / EDGE / FACE
    _msg = "Selected"

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        obj = context.active_object
        if obj.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (
            self._mode == 'VERT', self._mode == 'EDGE', self._mode == 'FACE')
        bpy.ops.mesh.select_all(action='DESELECT')
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        count = self._select(context, bm)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"{self._msg}: {count}")
        return {'FINISHED'}


class MESH_OT_pro_char_select_poles5(_TopoSelectOp, bpy.types.Operator):
    """Select poles: vertices with 5 or more edges"""
    bl_idname = "mesh.pro_char_select_poles5"
    bl_label = "Select Poles 5+"
    _msg = "Poles 5+ seleccionados"

    def _select(self, context, bm):
        n = 0
        for v in bm.verts:
            if len(v.link_edges) >= 5:
                v.select = True
                n += 1
        return n


class MESH_OT_pro_char_select_high_valence(_TopoSelectOp, bpy.types.Operator):
    """Select extreme poles: vertices with 6 or more edges"""
    bl_idname = "mesh.pro_char_select_high_valence"
    bl_label = "Select High Valence Vertices"
    _msg = "Vértices de valencia 6+ seleccionados"

    def _select(self, context, bm):
        n = 0
        for v in bm.verts:
            if len(v.link_edges) >= 6:
                v.select = True
                n += 1
        return n


class MESH_OT_pro_char_select_dense_areas(_TopoSelectOp, bpy.types.Operator):
    """Select vertices in unusually dense areas (ESTIMATED, relative to
    the mesh's average edge length)"""
    bl_idname = "mesh.pro_char_select_dense_areas"
    bl_label = "Select Dense Areas (est.)"
    _msg = "Vértices en zonas densas (estimado)"

    def _select(self, context, bm):
        p = context.scene.pro_toolkit
        lens = [e.calc_length() for e in bm.edges]
        if not lens:
            return 0
        thr = (sum(lens) / len(lens)) * p.topology_dense_threshold
        n = 0
        for v in bm.verts:
            if v.link_edges and (sum(e.calc_length() for e in v.link_edges)
                                 / len(v.link_edges)) < thr:
                v.select = True
                n += 1
        return n


class MESH_OT_pro_char_select_thin_faces(_TopoSelectOp, bpy.types.Operator):
    """Select sliver faces (very low area for their perimeter)"""
    bl_idname = "mesh.pro_char_select_thin_faces"
    bl_label = "Select Thin Faces"
    _mode = 'FACE'
    _msg = "Caras sliver seleccionadas"

    def _select(self, context, bm):
        n = 0
        for f in bm.faces:
            per = sum(e.calc_length() for e in f.edges)
            if per > 1e-9:
                compact = 12.566 * f.calc_area() / (per * per)   # 4πA/P²
                if compact < 0.12:
                    f.select = True
                    n += 1
        return n


class MESH_OT_pro_char_select_tiny_faces(_TopoSelectOp, bpy.types.Operator):
    """Select faces far smaller than the mesh average (ESTIMATED)"""
    bl_idname = "mesh.pro_char_select_tiny_faces"
    bl_label = "Select Tiny Faces (est.)"
    _mode = 'FACE'
    _msg = "Caras diminutas (estimado)"

    def _select(self, context, bm):
        p = context.scene.pro_toolkit
        areas = [f.calc_area() for f in bm.faces]
        if not areas:
            return 0
        thr = (sum(areas) / len(areas)) * p.topology_tiny_face_threshold
        n = 0
        for f in bm.faces:
            if f.calc_area() < thr:
                f.select = True
                n += 1
        return n


class MESH_OT_pro_char_select_boundary_holes(_TopoSelectOp, bpy.types.Operator):
    """Select open boundary edges (holes in the surface)"""
    bl_idname = "mesh.pro_char_select_boundary_holes"
    bl_label = "Select Boundary Holes"
    _mode = 'EDGE'
    _msg = "Aristas de borde abiertas seleccionadas"

    def _select(self, context, bm):
        n = 0
        for e in bm.edges:
            if e.is_boundary:
                e.select = True
                n += 1
        return n


class MESH_OT_pro_char_select_loose_parts(_TopoSelectOp, bpy.types.Operator):
    """Select every island except the biggest one (floating/loose parts).
    With 'Only Tiny' on, only islands under the AI threshold"""
    bl_idname = "mesh.pro_char_select_loose_parts"
    bl_label = "Select Loose Parts"
    _msg = "Partes sueltas seleccionadas (verts)"

    only_tiny: bpy.props.BoolProperty(
        name="Only Tiny Islands",
        description="Limit the selection to islands below the AI cleanup threshold",
        default=False)

    def _select(self, context, bm):
        p = context.scene.pro_toolkit
        islands = ch.vert_islands(bm)
        if len(islands) <= 1:
            return 0
        biggest = max(islands, key=len)
        thr = max(int(p.ai_cleanup_threshold), 3)
        bm.verts.ensure_lookup_table()
        n = 0
        for isl in islands:
            if isl is biggest:
                continue
            if self.only_tiny and len(isl) >= thr:
                continue
            for i in isl:
                bm.verts[i].select = True
                n += 1
        return n


class OBJECT_OT_pro_char_check_edge_flow(bpy.types.Operator):
    """Quick edge-flow health summary: quad ratio, pole pressure and
    boundary count (heuristic, informative)"""
    bl_idname = "object.pro_char_check_edge_flow"
    bl_label = "Check Edge Flow"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        s = ch.mesh_stats(context.active_object)
        total_f = max(s["faces"], 1)
        quad_pct = 100.0 * s["quads"] / total_f
        pole_pct = 100.0 * s["poles5"] / max(s["verts"], 1)
        verdict = ("limpio" if quad_pct > 90 and pole_pct < 3 else
                   "aceptable" if quad_pct > 70 else "problemático")
        self.report(
            {'INFO'} if verdict != "problemático" else {'WARNING'},
            f"Edge flow {verdict}: {quad_pct:.0f}% quads, "
            f"{s['poles5']} poles 5+ ({pole_pct:.1f}%), "
            f"{s['boundary_edges']} aristas de borde")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  FULL AUDIT + READINESS SCORE
# ═══════════════════════════════════════════════════════════════════════

def readiness_score(obj, stats):
    """0-100 score + Good/Medium/Bad verdict for retopo/production use."""
    s = stats
    score = 100.0
    total_f = max(s["faces"], 1)
    if s["ngons"]:
        score -= min(30, 10 + s["ngons"] * 0.05)
    score -= min(20, 100.0 * s["poles5"] / max(s["verts"], 1) * 4)
    if s["non_manifold"]:
        score -= 20
    tri_pct = 100.0 * s["tris"] / total_f
    if tri_pct > 30:
        score -= 10
    if s["islands"] > 1:
        score -= min(10, s["islands"] - 1)
    if s["dense_verts"] > s["verts"] * 0.25:
        score -= 10
    score = max(0.0, score)
    verdict = "Good" if score >= 75 else "Medium" if score >= 45 else "Bad"
    return score, verdict


class OBJECT_OT_pro_char_topology_audit(bpy.types.Operator):
    """Full organic topology audit + markdown report with a
    Retopo Readiness score (V015_TOPOLOGY_AUDIT_REPORT.md)"""
    bl_idname = "object.pro_char_topology_audit"
    bl_label = "Character Topology Audit"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        s = ch.mesh_stats(obj, dense_factor=p.topology_dense_threshold,
                          tiny_factor=p.topology_tiny_face_threshold)
        score, verdict = readiness_score(obj, s)
        mods = [m.type for m in obj.modifiers]

        lines = [
            f"# TOPOLOGY AUDIT — {obj.name}", "",
            f"vertices: {s['verts']:,}",
            f"edges: {s['edges']:,}",
            f"faces: {s['faces']:,}",
            f"tris: {s['tris']:,}",
            f"quads: {s['quads']:,}",
            f"n-gons: {s['ngons']:,}",
            f"poles 5+: {s['poles5']:,}  (valencia 6+: {s['high_valence']:,})",
            f"non-manifold: {s['non_manifold']}",
            f"loose parts: {s['islands']} islas ({s['tiny_islands']} diminutas, estimado)",
            f"open boundaries: {s['boundary_edges']} aristas",
            f"dense areas (estimado): {s['dense_verts']:,} verts",
            f"average face area: {s['avg_face_area']:.6f} m²",
            f"tiny faces (estimado): {s['tiny_faces']:,}",
            f"material slots: {len([m for m in obj.data.materials if m])}",
            f"UV maps: {len(obj.data.uv_layers)}",
            f"mirror modifier present: {'sí' if 'MIRROR' in mods else 'no'}",
            f"shrinkwrap modifier present: {'sí' if 'SHRINKWRAP' in mods else 'no'}",
            "",
            f"## Retopo Readiness: {verdict}  ({score:.0f}/100)",
        ]
        path = ch.write_report(TOPO_REPORT_NAME, lines)
        level = {'Good': 'INFO', 'Medium': 'INFO', 'Bad': 'WARNING'}[verdict]
        self.report({level},
                    f"Topology Audit: Readiness {verdict} ({score:.0f}/100) — "
                    f"{s['quads']:,} quads / {s['tris']:,} tris / "
                    f"{s['ngons']} n-gons / {s['poles5']} poles. Informe: {path}")
        return {'FINISHED'}


class OBJECT_OT_pro_char_check_retopo_readiness(bpy.types.Operator):
    """Quick Retopo Readiness verdict (no report file)"""
    bl_idname = "object.pro_char_check_retopo_readiness"
    bl_label = "Check Retopo Readiness"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        s = ch.mesh_stats(obj, dense_factor=p.topology_dense_threshold,
                          tiny_factor=p.topology_tiny_face_threshold)
        score, verdict = readiness_score(obj, s)
        self.report({'INFO'} if verdict != "Bad" else {'WARNING'},
                    f"Retopo Readiness: {verdict} ({score:.0f}/100)")
        return {'FINISHED'}


classes = (
    MESH_OT_pro_char_select_poles5,
    MESH_OT_pro_char_select_high_valence,
    MESH_OT_pro_char_select_dense_areas,
    MESH_OT_pro_char_select_thin_faces,
    MESH_OT_pro_char_select_tiny_faces,
    MESH_OT_pro_char_select_boundary_holes,
    MESH_OT_pro_char_select_loose_parts,
    OBJECT_OT_pro_char_check_edge_flow,
    OBJECT_OT_pro_char_topology_audit,
    OBJECT_OT_pro_char_check_retopo_readiness,
)
