# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_ai_cleanup.py
# v0.1.5: cleanup/prep for AI-generated meshes (Tripo, Rodin, Meshy...).
# The original model is NEVER deleted; destructive steps honour the
# ai_cleanup_create_backup property and selection-based "detect" tools
# reuse the Topology Audit selectors. Estimations are labelled as such.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from mathutils import Vector

from . import character_utils as ch
from . import retopo_utils as rt

AI_REPORT_NAME = "V015_AI_MODEL_CLEANUP_REPORT.md"


def _atlas_guess(obj):
    """(likely_atlas, materials, uv_maps, images) — heuristic, estimated."""
    me = obj.data
    mats = [m for m in me.materials if m]
    images = set()
    for m in mats:
        if m.use_nodes:
            for n in m.node_tree.nodes:
                if n.type == 'TEX_IMAGE' and n.image:
                    images.add(n.image.name)
    likely = len(mats) <= 1 and len(me.uv_layers) == 1 and len(images) == 1
    return likely, len(mats), len(me.uv_layers), sorted(images)


class OBJECT_OT_pro_char_ai_audit(bpy.types.Operator):
    """Full audit of an AI-generated mesh + markdown report
    (V015_AI_MODEL_CLEANUP_REPORT.md next to the .blend)"""
    bl_idname = "object.pro_char_ai_audit"
    bl_label = "Audit AI Generated Mesh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        s = ch.mesh_stats(obj, dense_factor=0.35,
                          tiny_factor=p.topology_tiny_face_threshold)
        atlas, n_mats, n_uvs, images = _atlas_guess(obj)

        recs = []
        if s["non_manifold"]:
            recs.append(f"Reparar {s['non_manifold']} aristas non-manifold antes de retopo.")
        if s["tiny_islands"]:
            recs.append(f"Eliminar {s['tiny_islands']} islas diminutas (Clean Small Loose Parts).")
        if s["dense_verts"] > s["verts"] * 0.25:
            recs.append("Densidad muy irregular (estimado) — considerar voxel remesh suave.")
        if s["ngons"]:
            recs.append(f"{s['ngons']} n-gons — la malla NO es apta como retopo final.")
        if atlas:
            recs.append("Posible textura atlas única: conservar UVs al limpiar "
                        "(organic_preserve_uvs activo).")
        if not recs:
            recs.append("Malla razonable: lista para Prepare AI Mesh for Retopo.")

        lines = [
            f"# AI MODEL CLEANUP REPORT — {obj.name}", "",
            f"Vértices: {s['verts']:,}",
            f"Caras: {s['faces']:,}",
            f"Tris aproximados: {ch.approx_tri_count(obj):,}",
            f"Quads: {s['quads']:,}   Tris: {s['tris']:,}   N-gons: {s['ngons']:,}",
            f"Non-manifold: {s['non_manifold']}",
            f"Loose parts (islas): {s['islands']} "
            f"({s['tiny_islands']} diminutas, estimado)",
            f"Vértices en zonas de densidad extrema (estimado): {s['dense_verts']:,}",
            f"Materiales: {n_mats}",
            f"UV maps: {n_uvs}",
            f"Imágenes en materiales: {', '.join(images) if images else 'ninguna'}",
            f"Posible textura atlas: {'SÍ (estimado)' if atlas else 'no aparente'}",
            "", "## Recomendaciones",
        ] + [f"- {r}" for r in recs]

        path = ch.write_report(AI_REPORT_NAME, lines)
        self.report({'INFO'},
                    f"AI audit: {s['verts']:,}v / {s['faces']:,}f, "
                    f"{s['islands']} parts, {s['non_manifold']} non-manifold. "
                    f"Informe: {path}")
        return {'FINISHED'}


class MESH_OT_pro_char_detect_bad_normals(bpy.types.Operator):
    """Select faces whose normal points inward (ESTIMATED — heuristic
    against the mesh center; works best on mostly convex AI meshes)"""
    bl_idname = "mesh.pro_char_detect_bad_normals"
    bl_label = "Detect Bad Normals (est.)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        obj = context.active_object
        if obj.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (False, False, True)
        bpy.ops.mesh.select_all(action='DESELECT')
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        bm.faces.ensure_lookup_table()
        if not bm.faces:
            self.report({'WARNING'}, "Mesh has no faces.")
            return {'CANCELLED'}
        center = sum((f.calc_center_median() for f in bm.faces), Vector()) / len(bm.faces)
        count = 0
        for f in bm.faces:
            if f.normal.dot(f.calc_center_median() - center) < 0:
                f.select = True
                count += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"{count} faces possibly inward (estimated). "
                    "Use Fix Inside-Out / Recalculate Normals to repair.")
        return {'FINISHED'}


class OBJECT_OT_pro_char_detect_atlas_risk(bpy.types.Operator):
    """Report whether the model likely depends on a single texture atlas
    (so cleanup must preserve UVs)"""
    bl_idname = "object.pro_char_detect_atlas_risk"
    bl_label = "Detect Texture Atlas Risk"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        atlas, n_mats, n_uvs, images = _atlas_guess(obj)
        if atlas:
            self.report({'WARNING'},
                        f"ATLAS LIKELY (estimated): 1 material, {n_uvs} UV map, "
                        f"image '{images[0]}'. Keep UVs intact when cleaning!")
        else:
            self.report({'INFO'},
                        f"No obvious atlas: {n_mats} material(s), {n_uvs} UV map(s), "
                        f"{len(images)} image(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_char_ai_prepare_for_retopo(bpy.types.Operator):
    """One-click prep of an AI mesh as retopo SOURCE: backup, PRO_AI_Source
    collection, outward normals, smooth shading and set as retopo target.
    The original is never deleted"""
    bl_idname = "object.pro_char_ai_prepare_for_retopo"
    bl_label = "Prepare AI Mesh for Retopo"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        steps = []

        if p.ai_cleanup_create_backup:
            ch.backup_object(context, obj, "_ai_original")
            steps.append("backup")

        ch.link_to_coll(context, obj, ch.COLL_AI_SOURCE)
        steps.append(ch.COLL_AI_SOURCE)
        ch.get_coll(context, ch.COLL_RETOPO)

        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            if bm.calc_volume(signed=True) < 0:
                bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
                steps.append("inside-out corregido")
            bm.to_mesh(obj.data)
            obj.data.update()
        finally:
            bm.free()
        steps.append("normales")

        for poly in obj.data.polygons:
            poly.use_smooth = True
        steps.append("smooth shading")

        if p.retopo_display_xray:
            ch.save_materials(obj)
            ch.assign_char_material(obj, "PRO_Source_XRay")
            steps.append("X-Ray material (originales guardados)")

        p.retopo_target_object = obj
        steps.append("set retopo target")
        self.report({'INFO'}, f"'{obj.name}' listo como fuente: " + ", ".join(steps))
        return {'FINISHED'}


class OBJECT_OT_pro_char_ai_create_retopo_duplicate(bpy.types.Operator):
    """Create a safe working duplicate of the source mesh in PRO_AI_Source"""
    bl_idname = "object.pro_char_ai_create_retopo_duplicate"
    bl_label = "Create Retopo Duplicate"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        dup = obj.copy()
        dup.data = obj.data.copy()
        dup.name = f"{obj.name}_WorkCopy"
        ch.get_coll(context, ch.COLL_AI_SOURCE).objects.link(dup)
        self.report({'INFO'},
                    f"'{dup.name}' creado en {ch.COLL_AI_SOURCE} "
                    "(el original queda intacto)")
        return {'FINISHED'}


class _AssignSourceMat:
    _mat = "PRO_Source_XRay"

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        n = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                ch.save_materials(obj)
                ch.assign_char_material(obj, self._mat)
                n += 1
        self.report({'INFO'},
                    f"{self._mat} en {n} objeto(s) — materiales originales "
                    "guardados (Restore Source Materials los devuelve)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_ai_low_visibility_material(_AssignSourceMat, bpy.types.Operator):
    """Assign a faint ghost material to the source (originals saved)"""
    bl_idname = "object.pro_char_ai_low_visibility_material"
    bl_label = "Create Low Visibility Source Material"
    bl_options = {'REGISTER', 'UNDO'}
    _mat = "PRO_Source_Ghost"


class OBJECT_OT_pro_char_ai_xray_material(_AssignSourceMat, bpy.types.Operator):
    """Assign a semi-transparent X-Ray material to the source (originals saved)"""
    bl_idname = "object.pro_char_ai_xray_material"
    bl_label = "Create X-Ray Source Material"
    bl_options = {'REGISTER', 'UNDO'}
    _mat = "PRO_Source_XRay"


class OBJECT_OT_pro_char_ai_restore_materials(bpy.types.Operator):
    """Restore the materials saved before X-Ray/Ghost/Clay overrides"""
    bl_idname = "object.pro_char_ai_restore_materials"
    bl_label = "Restore Source Materials"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        n = sum(1 for obj in context.selected_objects
                if obj.type == 'MESH' and ch.restore_materials(obj))
        if not n:
            self.report({'WARNING'}, "Nothing to restore on the selection.")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Materiales restaurados en {n} objeto(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_ai_freeze_source(bpy.types.Operator):
    """Freeze the source mesh: unselectable in the viewport so retopo
    clicks never grab it (Unlock Source reverses it)"""
    bl_idname = "object.pro_char_ai_freeze_source"
    bl_label = "Freeze Source Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        obj.hide_select = True
        self.report({'INFO'},
                    f"'{obj.name}' congelado (no seleccionable). "
                    "Retopo Setup > Unlock Source para revertir.")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_char_ai_audit,
    MESH_OT_pro_char_detect_bad_normals,
    OBJECT_OT_pro_char_detect_atlas_risk,
    OBJECT_OT_pro_char_ai_prepare_for_retopo,
    OBJECT_OT_pro_char_ai_create_retopo_duplicate,
    OBJECT_OT_pro_char_ai_low_visibility_material,
    OBJECT_OT_pro_char_ai_xray_material,
    OBJECT_OT_pro_char_ai_restore_materials,
    OBJECT_OT_pro_char_ai_freeze_source,
)
