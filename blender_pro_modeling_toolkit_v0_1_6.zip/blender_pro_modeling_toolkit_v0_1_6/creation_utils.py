# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  creation_utils.py
# v0.1.3 Pro Modeling Creation Suite: shared helpers.
# Collections, blockout materials and bmesh part builders used by the
# ops_creation_* modules. Geometry is always built at real-world size so
# new objects start with scale (1, 1, 1) — no apply-scale debt.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from math import cos, sin, pi


# ═══════════════════════════════════════════════════════════════════════
#  COLLECTIONS
# ═══════════════════════════════════════════════════════════════════════

ROOT_COLLECTION = "PRO_Toolkit_Generated"

COLL_BLOCKOUT = "PRO_Blockout"
COLL_ARCHITECTURE = "PRO_Architecture"
COLL_PRODUCTS = "PRO_Products"
COLL_SUPERMARKET = "PRO_Supermarket_Flower"
COLL_HELPERS = "PRO_Scale_Helpers"


def get_or_create_collection(context, name):
    """Return collection *name* parented under PRO_Toolkit_Generated,
    creating both if needed."""
    root = bpy.data.collections.get(ROOT_COLLECTION)
    if root is None:
        root = bpy.data.collections.new(ROOT_COLLECTION)
    if ROOT_COLLECTION not in context.scene.collection.children:
        context.scene.collection.children.link(root)

    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
    if name not in root.children:
        try:
            root.children.link(coll)
        except RuntimeError:
            pass  # already linked elsewhere in this scene — keep as is
    return coll


def link_to_collection(context, obj, coll_name):
    """Link *obj* into the organized collection (or the active collection,
    depending on the creation_collection_mode scene property)."""
    props = context.scene.pro_toolkit
    if getattr(props, "creation_collection_mode", 'ORGANIZED') == 'ORGANIZED':
        coll = get_or_create_collection(context, coll_name)
    else:
        coll = context.collection
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)
    return coll


# ═══════════════════════════════════════════════════════════════════════
#  BLOCKOUT MATERIALS  (simple Principled setups, no textures, no node webs)
# ═══════════════════════════════════════════════════════════════════════

# name: (base color RGBA, roughness, metallic, alpha)
BLOCKOUT_MATERIALS = {
    "PRO_Blockout_Grey":   ((0.50, 0.50, 0.50, 1.0), 0.80, 0.0, 1.0),
    "PRO_Blockout_Green":  ((0.22, 0.60, 0.28, 1.0), 0.80, 0.0, 1.0),
    "PRO_Blockout_Yellow": ((0.88, 0.72, 0.14, 1.0), 0.80, 0.0, 1.0),
    "PRO_Blockout_Red":    ((0.72, 0.16, 0.14, 1.0), 0.80, 0.0, 1.0),
    "SF_Blockout_Wall":    ((0.76, 0.74, 0.68, 1.0), 0.90, 0.0, 1.0),
    "SF_Blockout_Floor":   ((0.42, 0.43, 0.45, 1.0), 0.60, 0.0, 1.0),
    "SF_Blockout_Product": ((0.30, 0.50, 0.80, 1.0), 0.70, 0.0, 1.0),
    "SF_Blockout_Prop":    ((0.80, 0.52, 0.26, 1.0), 0.75, 0.0, 1.0),
    "SF_Blockout_Glass":   ((0.62, 0.80, 0.88, 1.0), 0.10, 0.0, 0.30),
    "SF_Blockout_Metal":   ((0.62, 0.64, 0.66, 1.0), 0.35, 1.0, 1.0),
}


def get_blockout_material(name):
    """Get or create one of the simple blockout materials."""
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    color, rough, metal, alpha = BLOCKOUT_MATERIALS.get(
        name, BLOCKOUT_MATERIALS["PRO_Blockout_Grey"])

    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Roughness"].default_value = rough
        bsdf.inputs["Metallic"].default_value = metal
        if alpha < 1.0:
            bsdf.inputs["Alpha"].default_value = alpha
    # Viewport solid-mode color so blockouts read at a glance
    mat.diffuse_color = (color[0], color[1], color[2], alpha)
    if alpha < 1.0:
        # Transparency flags differ between EEVEE Legacy / EEVEE Next
        if hasattr(mat, "blend_method"):
            mat.blend_method = 'BLEND'
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = 'BLENDED'
    return mat


def assign_material(obj, mat_name):
    """Replace slot 0 (or add it) with the named blockout material."""
    mat = get_blockout_material(mat_name)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


# ═══════════════════════════════════════════════════════════════════════
#  BMESH PART BUILDERS (compose several parts into one bm, then finalize)
# ═══════════════════════════════════════════════════════════════════════

def add_box(bm, width, depth, height, cx=0.0, cy=0.0, z0=0.0):
    """Add a box: centered on (cx, cy) in XY, base resting at z0."""
    ret = bmesh.ops.create_cube(bm, size=1.0)
    for v in ret["verts"]:
        v.co.x = v.co.x * width + cx
        v.co.y = v.co.y * depth + cy
        v.co.z = (v.co.z + 0.5) * height + z0
    return ret["verts"]


def add_cylinder(bm, radius, height, segments, cx=0.0, cy=0.0, z0=0.0,
                 radius_top=None):
    """Add a capped cylinder (or truncated cone): base resting at z0."""
    r2 = radius if radius_top is None else radius_top
    ret = bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=segments,
        radius1=radius, radius2=r2, depth=height)
    for v in ret["verts"]:
        v.co.x += cx
        v.co.y += cy
        v.co.z += height / 2.0 + z0
    return ret["verts"]


def add_plane(bm, width, depth, cx=0.0, cy=0.0, z=0.0):
    """Add a single horizontal quad."""
    hw, hd = width / 2.0, depth / 2.0
    vs = [bm.verts.new((cx - hw, cy - hd, z)),
          bm.verts.new((cx + hw, cy - hd, z)),
          bm.verts.new((cx + hw, cy + hd, z)),
          bm.verts.new((cx - hw, cy + hd, z))]
    bm.faces.new(vs)
    return vs


def add_arch_band(bm, width, depth, thickness, segments=8, z0=0.0):
    """Add a semicircular arch ribbon (half annulus extruded in Y).
    *width* is the clear opening; the band adds *thickness* outwards."""
    ri = width / 2.0
    ro = ri + thickness
    hd = depth / 2.0
    front_in, front_out, back_in, back_out = [], [], [], []
    for i in range(segments + 1):
        a = pi * i / segments
        xi, zi = cos(a) * ri, sin(a) * ri + z0
        xo, zo = cos(a) * ro, sin(a) * ro + z0
        front_in.append(bm.verts.new((xi, -hd, zi)))
        front_out.append(bm.verts.new((xo, -hd, zo)))
        back_in.append(bm.verts.new((xi, hd, zi)))
        back_out.append(bm.verts.new((xo, hd, zo)))
    for i in range(segments):
        bm.faces.new((front_in[i], front_out[i],
                      front_out[i + 1], front_in[i + 1]))      # front
        bm.faces.new((back_out[i], back_in[i],
                      back_in[i + 1], back_out[i + 1]))        # back
        bm.faces.new((front_out[i], back_out[i],
                      back_out[i + 1], front_out[i + 1]))      # outer
        bm.faces.new((back_in[i], front_in[i],
                      front_in[i + 1], back_in[i + 1]))        # inner
    # end caps (arch feet)
    bm.faces.new((front_in[0], back_in[0], back_out[0], front_out[0]))
    bm.faces.new((front_out[-1], back_out[-1], back_in[-1], front_in[-1]))


def delete_faces_keep_edges(bm):
    """Turn the current solid geometry into a wire cage (helpers)."""
    bmesh.ops.delete(bm, geom=bm.faces[:], context='FACES_ONLY')


# ═══════════════════════════════════════════════════════════════════════
#  FINALIZE — mesh → object → collection → material → selection → report
# ═══════════════════════════════════════════════════════════════════════

def finalize_new_object(context, operator, name, bm, coll_name,
                        mat_name=None, wire=False, at_floor=None):
    """Standard tail for every creation operator. Returns the new object."""
    props = context.scene.pro_toolkit

    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()

    obj = bpy.data.objects.new(name, me)
    coll = link_to_collection(context, obj, coll_name)

    # Place at the 3D cursor; optionally pinned to the floor (Z = 0)
    loc = context.scene.cursor.location.copy()
    align = (props.creation_align_to_floor if at_floor is None else at_floor)
    if align:
        loc.z = 0.0
    obj.location = loc

    if wire:
        obj.display_type = 'WIRE'
    if mat_name and props.creation_create_material and not wire:
        assign_material(obj, mat_name)

    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj

    d = obj.dimensions
    operator.report(
        {'INFO'},
        f"{name} created ({d.x:.2f} x {d.y:.2f} x {d.z:.2f} m) "
        f"in '{coll.name}' — scale is already (1, 1, 1)")
    return obj


# Common poll for creation operators
def object_mode_poll(context):
    return context.mode == 'OBJECT'
