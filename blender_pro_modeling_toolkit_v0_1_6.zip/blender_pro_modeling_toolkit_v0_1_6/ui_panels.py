# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ui_panels.py
# N-Panel layout, subpanels and property groups
# ──────────────────────────────────────────────────────────────────────

import bpy

from . import core_toolkit
from . import ops_toon_presets
from . import ops_procedural_materials
from . import profile_revolve_utils

ADDON_VERSION_STR = "0.1.7.1"


# ═══════════════════════════════════════════════════════════════════════
#  PROPERTY GROUP – Search & Audit data
# ═══════════════════════════════════════════════════════════════════════

class ProToolkitProperties(bpy.types.PropertyGroup):
    """Scene-level storage for search bar and audit results."""

    search_query: bpy.props.StringProperty(
        name="Search",
        description="Filter tools by name",
        default="",
    )

    # Audit results
    audit_done: bpy.props.BoolProperty(default=False)
    audit_object_name: bpy.props.StringProperty(default="")
    audit_ngons: bpy.props.IntProperty(default=0)
    audit_tris: bpy.props.IntProperty(default=0)
    audit_non_manifold: bpy.props.IntProperty(default=0)
    audit_doubles: bpy.props.IntProperty(default=0)
    audit_loose: bpy.props.IntProperty(default=0)
    audit_total_verts: bpy.props.IntProperty(default=0)
    audit_total_edges: bpy.props.IntProperty(default=0)
    audit_total_faces: bpy.props.IntProperty(default=0)

    # ── Pro UV Suite ─────────────────────────────────────────────
    uv_checker_scale: bpy.props.FloatProperty(
        name="Checker Scale", description="Checker tiling repeat",
        default=8.0, min=0.25, max=128.0)
    uv_texture_size: bpy.props.IntProperty(
        name="Texture Size", description="Texture size (px) used for texel density",
        default=1024, min=16, max=16384)
    uv_target_density: bpy.props.FloatProperty(
        name="Target Density", description="Target texel density in px/m",
        default=512.0, min=1.0, max=16384.0)
    uv_density_result: bpy.props.FloatProperty(default=0.0)

    # UV audit results
    uv_audit_done: bpy.props.BoolProperty(default=False)
    uv_audit_object: bpy.props.StringProperty(default="")
    uv_audit_has_uv: bpy.props.BoolProperty(default=False)
    uv_audit_active_map: bpy.props.StringProperty(default="-")
    uv_audit_map_count: bpy.props.IntProperty(default=0)
    uv_audit_faces: bpy.props.IntProperty(default=0)
    uv_audit_materials: bpy.props.IntProperty(default=0)
    uv_audit_islands: bpy.props.IntProperty(default=0)
    uv_audit_overlaps: bpy.props.IntProperty(default=0)
    uv_audit_outside: bpy.props.IntProperty(default=0)
    uv_audit_zero_area: bpy.props.IntProperty(default=0)
    uv_audit_flipped: bpy.props.IntProperty(default=0)
    uv_audit_density: bpy.props.FloatProperty(default=0.0)
    uv_audit_density_var: bpy.props.FloatProperty(default=0.0)
    uv_audit_warnings: bpy.props.StringProperty(default="")

    # ── Pro Cel Shading Suite ────────────────────────────────────
    cel_base_color: bpy.props.FloatVectorProperty(
        name="Base Color", subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.8, 0.8, 0.8, 1.0))
    cel_shadow_color: bpy.props.FloatVectorProperty(
        name="Shadow Color", subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.25, 0.25, 0.32, 1.0))
    cel_highlight_color: bpy.props.FloatVectorProperty(
        name="Highlight Color", subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(1.0, 0.95, 0.9, 1.0))
    cel_ramp_threshold: bpy.props.FloatProperty(
        name="Shadow Threshold", default=0.5, min=0.01, max=0.99)
    cel_ramp_hardness: bpy.props.FloatProperty(
        name="Hardness", description="1.0 = hard cel cut, lower = soft bands",
        default=1.0, min=0.0, max=1.0)
    cel_rim_color: bpy.props.FloatVectorProperty(
        name="Rim Color", subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(1.0, 1.0, 1.0, 1.0))
    cel_rim_strength: bpy.props.FloatProperty(
        name="Rim Strength", default=0.6, min=0.0, max=2.0)
    cel_outline_color: bpy.props.FloatVectorProperty(
        name="Outline Color", subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.0, 0.0, 0.0, 1.0))
    cel_outline_thickness: bpy.props.FloatProperty(
        name="Outline Thickness", subtype='DISTANCE',
        default=0.02, min=0.0005, max=0.5)
    cel_material_preset: bpy.props.EnumProperty(
        name="Preset", items=ops_toon_presets.PRESET_ENUM_ITEMS,
        default='BASIC_3TONE')

    # ── v0.1.2.1 — Cel application mode (texture preserving) ────
    cel_preserve_existing_texture: bpy.props.BoolProperty(
        name="Preserve Existing Texture",
        description="Keep existing textures and build toon shading on top "
                    "(base color, normal map and roughness are detected and reused)",
        default=True)
    cel_duplicate_original_material: bpy.props.BoolProperty(
        name="Duplicate Original Material",
        description="Put a TOON_<name> copy in the slot and keep the original "
                    "material untouched in the file",
        default=True)
    cel_keep_original_material_slot: bpy.props.BoolProperty(
        name="Protect Originals (Fake User)",
        description="Mark original materials with a fake user so they are "
                    "never lost when saving",
        default=True)
    cel_apply_to_all_material_slots: bpy.props.BoolProperty(
        name="Apply to All Material Slots",
        description="Convert every material slot (multi-material objects keep "
                    "their slot layout); off = only the active slot",
        default=True)
    cel_replace_material: bpy.props.BoolProperty(
        name="Flat Toon Replace",
        description="Replace all slots with one flat preset material "
                    "(removes the visual texture setup). Only use this when "
                    "you explicitly want a flat toon",
        default=False)

    # ── v0.1.3 — Pro Modeling Creation Suite ────────────────────
    creation_width: bpy.props.FloatProperty(
        name="Width", description="Target width (X) for Set Dimensions",
        default=1.0, min=0.001, soft_max=50.0, unit='LENGTH')
    creation_depth: bpy.props.FloatProperty(
        name="Depth", description="Target depth (Y) for Set Dimensions",
        default=1.0, min=0.001, soft_max=50.0, unit='LENGTH')
    creation_height: bpy.props.FloatProperty(
        name="Height", description="Target height (Z) for Set Dimensions",
        default=1.0, min=0.001, soft_max=50.0, unit='LENGTH')
    creation_thickness: bpy.props.FloatProperty(
        name="Thickness", description="Default thickness for new panels",
        default=0.02, min=0.002, soft_max=1.0, unit='LENGTH')
    creation_segments: bpy.props.IntProperty(
        name="Segments", description="Default segments for round shapes",
        default=16, min=6, max=64)
    creation_radius: bpy.props.FloatProperty(
        name="Radius", description="Default radius for round shapes / cutters",
        default=0.05, min=0.001, soft_max=2.0, unit='LENGTH')
    creation_apply_scale: bpy.props.BoolProperty(
        name="Apply Scale",
        description="Apply scale after Set Dimensions (creation tools always "
                    "build geometry at real size, so their scale is already 1)",
        default=True)
    creation_align_to_floor: bpy.props.BoolProperty(
        name="Align to Floor",
        description="Place new objects with their base at Z = 0 instead of "
                    "the 3D cursor height",
        default=True)
    creation_create_material: bpy.props.BoolProperty(
        name="Assign Blockout Material",
        description="Assign a simple color-coded blockout material to new objects",
        default=True)
    creation_collection_mode: bpy.props.EnumProperty(
        name="Collections",
        description="Where new objects are filed",
        items=(('ORGANIZED', "Organized",
                "File new objects into PRO_Toolkit_Generated sub-collections"),
               ('ACTIVE', "Active Collection",
                "Link new objects to the active collection")),
        default='ORGANIZED')

    # Profile Revolve / Lathe Pro
    lathe_axis: bpy.props.EnumProperty(
        name="Axis",
        description="Axis used by the Screw/Revolve modifier",
        items=(('X', "X", "Revolve around local X"),
               ('Y', "Y", "Revolve around local Y"),
               ('Z', "Z", "Revolve around local Z")),
        default='Z')
    lathe_profile_preset: bpy.props.EnumProperty(
        name="Profile Preset",
        description="Editable side profile used by the profile creation buttons",
        items=profile_revolve_utils.preset_items(),
        default='SIMPLE_BOTTLE')
    lathe_draw_mode: bpy.props.EnumProperty(
        name="Mode",
        description="Drawing/tracing setup to prepare for Lathe profile work",
        items=profile_revolve_utils.draw_mode_items(),
        default='CURVE')
    lathe_auto_front_view: bpy.props.BoolProperty(
        name="Auto Front View",
        description="Try to switch the 3D View to front view for tracing",
        default=True)
    lathe_create_axis_guide: bpy.props.BoolProperty(
        name="Create Axis Guide",
        description="Create a visible center axis when starting draw modes",
        default=True)
    lathe_axis_height: bpy.props.FloatProperty(
        name="Axis Height",
        description="Height of the visual lathe axis guide",
        default=3.0, min=0.1, soft_max=10.0, unit='LENGTH')
    lathe_axis_color: bpy.props.FloatVectorProperty(
        name="Axis Color",
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 0.82, 0.05, 1.0))
    lathe_draw_profile_name: bpy.props.StringProperty(
        name="Profile Name",
        description="Name used for new curve draw profiles",
        default="LATHE_Draw_Profile")
    lathe_use_tablet_friendly_mode: bpy.props.BoolProperty(
        name="Tablet Friendly",
        description="Use tablet-oriented draw mode defaults where possible",
        default=True)
    lathe_gp_stroke_thickness: bpy.props.IntProperty(
        name="GP Stroke Thickness",
        description="Preferred Grease Pencil stroke thickness",
        default=2, min=1, max=20)
    lathe_curve_resolution: bpy.props.IntProperty(
        name="Curve Resolution",
        description="Curve resolution for draw and Bezier profiles",
        default=12, min=1, max=64)
    lathe_trace_simplify_amount: bpy.props.FloatProperty(
        name="Trace Simplify",
        description="Reserved simplification amount for traced profiles",
        default=0.0, min=0.0, max=1.0)
    lathe_angle: bpy.props.FloatProperty(
        name="Angle",
        description="Revolve angle in degrees",
        default=360.0, min=1.0, max=360.0)
    lathe_segments: bpy.props.IntProperty(
        name="Segments",
        description="Screw/Revolve segment count",
        default=64, min=3, max=256)
    lathe_merge_center: bpy.props.BoolProperty(
        name="Merge Center",
        description="Merge vertices on the revolve axis",
        default=True)
    lathe_merge_distance: bpy.props.FloatProperty(
        name="Merge Distance",
        description="Distance used by the Screw modifier center merge",
        default=0.001, min=0.000001, max=0.1, precision=5,
        unit='LENGTH')
    lathe_use_smooth: bpy.props.BoolProperty(
        name="Smooth",
        description="Use smooth shading for the revolve surface",
        default=True)
    lathe_add_subdivision: bpy.props.BoolProperty(
        name="Add Subdivision",
        description="Add a light Subdivision modifier after the Screw modifier",
        default=False)
    lathe_add_bevel: bpy.props.BoolProperty(
        name="Add Bevel",
        description="Add a small non-destructive bevel with the revolve setup",
        default=False)
    lathe_bevel_amount: bpy.props.FloatProperty(
        name="Bevel Amount",
        description="Lathe bevel width",
        default=0.01, min=0.0, soft_max=0.1, unit='LENGTH')
    lathe_use_weighted_normals: bpy.props.BoolProperty(
        name="Weighted Normals",
        description="Add Weighted Normals for clean cylindrical shading",
        default=True)
    lathe_cap_top: bpy.props.BoolProperty(
        name="Cap Top",
        description="Close the top endpoint to the revolve axis",
        default=True)
    lathe_cap_bottom: bpy.props.BoolProperty(
        name="Cap Bottom",
        description="Close the bottom endpoint to the revolve axis",
        default=True)
    lathe_non_destructive: bpy.props.BoolProperty(
        name="Non Destructive",
        description="Keep the Screw/Revolve stack editable",
        default=True)
    lathe_apply_safely: bpy.props.BoolProperty(
        name="Apply Safely",
        description="Create a backup before applying or converting the revolve",
        default=True)
    lathe_audit_done: bpy.props.BoolProperty(default=False)
    lathe_audit_object: bpy.props.StringProperty(default="")
    lathe_audit_warnings: bpy.props.IntProperty(default=0)

    # ── v0.1.4 — Hard Surface Pro Suite ─────────────────────────
    hs_bevel_amount: bpy.props.FloatProperty(
        name="Bevel Amount", description="Bevel width (clamped to 10% of the "
        "smallest dimension on small objects)",
        default=0.03, min=0.0005, soft_max=0.5, unit='LENGTH')
    hs_bevel_segments: bpy.props.IntProperty(
        name="Segments", description="Bevel segments",
        default=2, min=1, max=12)
    hs_bevel_profile: bpy.props.FloatProperty(
        name="Profile", description="Bevel profile shape (0.5 = round)",
        default=0.5, min=0.0, max=1.0)
    hs_auto_weighted_normals: bpy.props.BoolProperty(
        name="Auto Weighted Normals",
        description="Add a Weighted Normal modifier after Smart Bevel",
        default=True)
    hs_apply_scale_if_needed: bpy.props.BoolProperty(
        name="Apply Scale if Needed",
        description="When a bevel tool meets unapplied scale, apply it "
                    "automatically (reported; multi-user meshes are skipped). "
                    "Off = warn only, never touch the object",
        default=False)
    hs_non_destructive: bpy.props.BoolProperty(
        name="Non-Destructive",
        description="Hard Surface tools work with modifiers and never bake "
                    "geometry unless you press an Apply button",
        default=True)
    hs_cutter_width: bpy.props.FloatProperty(
        name="Width", description="Default cutter width (X)",
        default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')
    hs_cutter_depth: bpy.props.FloatProperty(
        name="Depth", description="Default cutter depth (Y)",
        default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')
    hs_cutter_height: bpy.props.FloatProperty(
        name="Height", description="Default cutter height (Z)",
        default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')
    hs_cutter_radius: bpy.props.FloatProperty(
        name="Radius", description="Default cutter radius",
        default=0.05, min=0.001, soft_max=2.0, unit='LENGTH')
    hs_cutter_segments: bpy.props.IntProperty(
        name="Segments", description="Default segments for round cutters",
        default=16, min=6, max=64)
    hs_boolean_operation: bpy.props.EnumProperty(
        name="Operation", description="Default boolean operation",
        items=(('DIFFERENCE', "Difference", "Subtract the cutter"),
               ('UNION', "Union", "Merge the cutter"),
               ('INTERSECT', "Intersect", "Keep only the overlap")),
        default='DIFFERENCE')
    hs_apply_boolean: bpy.props.BoolProperty(
        name="Apply Immediately",
        description="Run Apply Boolean Safely right after adding a boolean "
                    "(a backup is stored first). Off = modifier only",
        default=False)
    hs_keep_cutter: bpy.props.BoolProperty(
        name="Keep Cutters",
        description="Keep cutters in the scene after applying booleans "
                    "(they are hidden, never deleted automatically)",
        default=True)
    hs_panel_width: bpy.props.FloatProperty(
        name="Width", description="Default panel width",
        default=0.6, min=0.01, soft_max=5.0, unit='LENGTH')
    hs_panel_height: bpy.props.FloatProperty(
        name="Height", description="Default panel height",
        default=0.4, min=0.01, soft_max=5.0, unit='LENGTH')
    hs_panel_depth: bpy.props.FloatProperty(
        name="Thickness", description="Default panel thickness",
        default=0.02, min=0.002, soft_max=0.5, unit='LENGTH')
    hs_panel_margin: bpy.props.FloatProperty(
        name="Margin", description="Default panel border / margin width",
        default=0.03, min=0.005, soft_max=0.5, unit='LENGTH')
    hs_panel_spacing: bpy.props.FloatProperty(
        name="Spacing", description="Default spacing between repeated elements",
        default=0.02, min=0.002, soft_max=0.5, unit='LENGTH')
    hs_panel_count: bpy.props.IntProperty(
        name="Count", description="Default count for repeated elements "
        "(vent lines, slats…)", default=5, min=1, max=40)
    hs_detail_scale: bpy.props.FloatProperty(
        name="Detail Scale", description="Uniform scale factor applied to the "
        "geometry of new mechanical details (the object scale stays 1)",
        default=1.0, min=0.1, soft_max=5.0)
    hs_create_materials: bpy.props.BoolProperty(
        name="Assign HS Materials",
        description="Assign a simple hard-surface material to new objects",
        default=True)
    hs_align_to_floor: bpy.props.BoolProperty(
        name="Align to Floor",
        description="Place new hard-surface objects with their base at Z = 0 "
                    "instead of the 3D cursor height",
        default=False)
    hs_use_weighted_normals: bpy.props.BoolProperty(
        name="Weighted Normals on Create",
        description="Add a Weighted Normal modifier to every new hard-surface "
                    "object",
        default=False)

    # ── v0.1.5 — Character / Organic / Retopo Pro ────────────────
    organic_smooth_strength: bpy.props.FloatProperty(
        name="Smooth Strength", default=0.5, min=0.0, max=1.0)
    organic_relax_iterations: bpy.props.IntProperty(
        name="Iterations", default=3, min=1, max=50)
    organic_merge_distance: bpy.props.FloatProperty(
        name="Merge Distance", default=0.0005, min=0.00001, max=0.05,
        precision=5)
    organic_inflate_amount: bpy.props.FloatProperty(
        name="Inflate Amount", default=0.01, soft_min=-0.5, soft_max=0.5,
        precision=4)
    organic_backup_before_cleanup: bpy.props.BoolProperty(
        name="Backup Before Cleanup",
        description="Store a hidden backup before destructive cleanups",
        default=True)
    organic_preserve_uvs: bpy.props.BoolProperty(
        name="Preserve UVs",
        description="Cleanup tools never touch UV maps (atlas-safe)",
        default=True)

    ai_cleanup_threshold: bpy.props.IntProperty(
        name="Tiny Part Threshold",
        description="Islands below this vertex count are considered debris",
        default=30, min=3, max=10000)
    ai_cleanup_create_backup: bpy.props.BoolProperty(
        name="Backup AI Source", default=True)

    symmetry_axis: bpy.props.EnumProperty(
        name="Axis",
        items=[('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")],
        default='X')
    symmetry_tolerance: bpy.props.FloatProperty(
        name="Tolerance", default=0.001, min=0.00001, max=0.5, precision=5)
    symmetry_snap_distance: bpy.props.FloatProperty(
        name="Snap Distance", default=0.005, min=0.0001, max=0.5, precision=4)
    symmetry_use_modifier: bpy.props.BoolProperty(
        name="Prefer Modifier (non-destructive)", default=True)

    retopo_target_object: bpy.props.PointerProperty(
        name="Retopo Target", type=bpy.types.Object,
        description="Source mesh the retopo tools project onto",
        poll=lambda self, obj: obj.type == 'MESH')
    retopo_shrinkwrap_offset: bpy.props.FloatProperty(
        name="Shrinkwrap Offset", default=0.002, min=0.0, max=0.5,
        precision=4)
    retopo_patch_size: bpy.props.FloatProperty(
        name="Patch Size", default=0.1, min=0.005, soft_max=2.0,
        unit='LENGTH')
    retopo_relax_strength: bpy.props.FloatProperty(
        name="Relax Strength", default=0.5, min=0.0, max=1.0)
    retopo_project_offset: bpy.props.FloatProperty(
        name="Project Offset", default=0.002, min=0.0, max=0.5, precision=4)
    retopo_use_mirror: bpy.props.BoolProperty(
        name="Use Mirror X", default=True)
    retopo_display_xray: bpy.props.BoolProperty(
        name="Source X-Ray Material",
        description="Assign the X-Ray material to the source on setup "
                    "(your materials are saved and restorable)",
        default=False)

    topology_dense_threshold: bpy.props.FloatProperty(
        name="Dense Threshold",
        description="Verts whose edges are shorter than this fraction of the "
                    "mesh average count as dense (estimated)",
        default=0.35, min=0.05, max=0.9)
    topology_tiny_face_threshold: bpy.props.FloatProperty(
        name="Tiny Face Threshold",
        description="Faces below this fraction of the average area count as "
                    "tiny (estimated)",
        default=0.02, min=0.001, max=0.5, precision=3)

    curve_bevel_depth: bpy.props.FloatProperty(
        name="Curve Bevel", default=0.04, min=0.001, soft_max=0.5,
        unit='LENGTH')
    curve_resolution: bpy.props.IntProperty(
        name="Curve Resolution", default=12, min=2, max=64)
    curve_taper_ends: bpy.props.BoolProperty(
        name="Taper Ends", default=True)

    sculpt_voxel_size: bpy.props.FloatProperty(
        name="Voxel Size", default=0.02, min=0.0005, soft_max=0.5,
        precision=4, unit='LENGTH')
    sculpt_create_backup: bpy.props.BoolProperty(
        name="Backup Before Sculpt Prep", default=True)

    character_target_height: bpy.props.FloatProperty(
        name="Target Height", default=1.78, min=0.1, soft_max=10.0,
        unit='LENGTH')
    character_tri_budget: bpy.props.IntProperty(
        name="Tri Budget", default=50000, min=100, max=5000000)

    # v0.1.5.1 - Boolean Target system
    hs_boolean_target_object: bpy.props.PointerProperty(
        name="Boolean Target", type=bpy.types.Object,
        description="The object that receives every boolean modifier",
        poll=lambda self, obj: obj.type == 'MESH')
    hs_last_created_cutter: bpy.props.PointerProperty(
        name="Last Cutter", type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH')
    hs_boolean_operation: bpy.props.EnumProperty(
        name="Operation",
        items=[('DIFFERENCE', "Difference", "Subtract the cutter"),
               ('UNION', "Union", "Merge the cutter"),
               ('INTERSECT', "Intersect", "Keep the overlap")],
        default='DIFFERENCE')
    hs_boolean_use_exact_solver: bpy.props.BoolProperty(
        name="Exact Solver",
        description="Use the EXACT boolean solver when available",
        default=True)
    hs_boolean_keep_cutter: bpy.props.BoolProperty(
        name="Keep Cutters After Apply",
        description="Cutters are hidden (never deleted) after applying",
        default=True)
    hs_boolean_hide_cutter_after_add: bpy.props.BoolProperty(
        name="Hide Cutter After Add",
        description="Hide the cutter right after adding the boolean",
        default=False)
    hs_boolean_apply_safely: bpy.props.BoolProperty(
        name="Safe Apply",
        description="Apply always goes through backup + checks",
        default=True)
    hs_boolean_create_backup: bpy.props.BoolProperty(
        name="Backup on Apply",
        description="Store a hidden backup before applying booleans",
        default=True)

    # v0.1.5.1 - Mechanical Panels / Grilles / Covers
    hs_panel_rows: bpy.props.IntProperty(
        name="Rows", default=4, min=1, max=40)
    hs_panel_columns: bpy.props.IntProperty(
        name="Columns", default=6, min=1, max=40)
    hs_panel_hole_radius: bpy.props.FloatProperty(
        name="Hole Radius", default=0.012, min=0.001, soft_max=0.2,
        unit='LENGTH')
    hs_panel_slot_width: bpy.props.FloatProperty(
        name="Slot Width", default=0.08, min=0.002, soft_max=1.0,
        unit='LENGTH')
    hs_panel_slot_height: bpy.props.FloatProperty(
        name="Slot Height", default=0.012, min=0.002, soft_max=0.5,
        unit='LENGTH')
    hs_panel_thickness: bpy.props.FloatProperty(
        name="Plate Thickness", default=0.015, min=0.002, soft_max=0.3,
        unit='LENGTH')
    hs_panel_bevel_amount: bpy.props.FloatProperty(
        name="Bevel Amount", default=0.002, min=0.0, soft_max=0.05,
        unit='LENGTH')
    hs_panel_use_weighted_normals: bpy.props.BoolProperty(
        name="Weighted Normals", default=True)
    hs_panel_create_as_cutter: bpy.props.BoolProperty(
        name="Create as Cutter",
        description="Build only the pattern volumes (full depth, wire, "
                    "CUT_ prefix) ready to subtract for REAL holes",
        default=False)
    hs_panel_pattern_type: bpy.props.EnumProperty(
        name="Pattern",
        items=[('CIRCULAR', "Circular Holes", ""),
               ('RECT_SLOTS', "Rectangular Slots", ""),
               ('LONG_SLOTS', "Long Slots", ""),
               ('HEX', "Hex Pattern", ""),
               ('LOUVER_H', "Horizontal Louvers", ""),
               ('LOUVER_V', "Vertical Louvers", ""),
               ('GRID_BARS', "Grid Bars", ""),
               ('MESH_LINES', "Mesh Lines", "")],
        default='CIRCULAR')

    # ════════════════════════════════════════════════════════════════
    # v0.1.6 — Material / Texture / Baking Pro Suite
    # ════════════════════════════════════════════════════════════════

    # ── Material Audit / Cleanup ─────────────────────────────────
    mat_audit_scope: bpy.props.EnumProperty(
        name="Scope",
        items=[('SELECTED', "Selected", "Audit selected objects only"),
               ('SCENE', "Scene", "Audit the whole scene")],
        default='SCENE')
    mat_cleanup_create_backup: bpy.props.BoolProperty(
        name="Backup Before Cleanup",
        description="Create _MATBAK fake-user copies before hard cleanups",
        default=True)
    mat_merge_by_color_tolerance: bpy.props.FloatProperty(
        name="Color Tolerance", default=0.02, min=0.0, max=0.5,
        description="Max per-channel difference for Merge by Color")
    mat_name_prefix: bpy.props.StringProperty(
        name="Prefix", default="MAT_",
        description="Prefix for Add Prefix / pipeline naming")
    # audit summary (read-only display)
    mat_audit_done: bpy.props.BoolProperty(default=False)
    mat_audit_total: bpy.props.IntProperty(default=0)
    mat_audit_scoped: bpy.props.IntProperty(default=0)
    mat_audit_unused: bpy.props.IntProperty(default=0)
    mat_audit_duplicates: bpy.props.IntProperty(default=0)
    mat_audit_missing_tex: bpy.props.IntProperty(default=0)
    mat_audit_abs_paths: bpy.props.IntProperty(default=0)
    mat_audit_non_pbr: bpy.props.IntProperty(default=0)
    mat_audit_heavy: bpy.props.IntProperty(default=0)
    mat_audit_empty_slots: bpy.props.IntProperty(default=0)
    mat_audit_images: bpy.props.IntProperty(default=0)

    # ── Texture Manager ──────────────────────────────────────────
    texture_relink_folder: bpy.props.StringProperty(
        name="Relink Folder", subtype='DIR_PATH', default="",
        description="Folder searched (recursively) by Relink From Folder")
    texture_max_size_warning: bpy.props.IntProperty(
        name="Max Size Warning", default=4096, min=64, max=32768,
        description="Textures above this size are flagged")
    texture_make_relative: bpy.props.BoolProperty(
        name="Make Relative on Relink", default=True)
    texture_pack_after_relink: bpy.props.BoolProperty(
        name="Pack After Relink", default=False)
    texture_report_missing_only: bpy.props.BoolProperty(
        name="Report Missing Only", default=False,
        description="Texture report lists only the missing files")
    texture_missing_count: bpy.props.IntProperty(default=-1)
    texture_atlas_risks: bpy.props.IntProperty(default=-1)

    # ── PBR Builder ──────────────────────────────────────────────
    pbr_base_color: bpy.props.FloatVectorProperty(
        name="Base Color", subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.8, 0.8, 0.8, 1.0))
    pbr_roughness: bpy.props.FloatProperty(
        name="Roughness", default=0.5, min=0.0, max=1.0)
    pbr_metallic: bpy.props.FloatProperty(
        name="Metallic", default=0.0, min=0.0, max=1.0)
    pbr_alpha: bpy.props.FloatProperty(
        name="Alpha", default=1.0, min=0.0, max=1.0)
    pbr_create_copy: bpy.props.BoolProperty(
        name="Put Copy in Slot",
        description="Convert to PBR Safe also swaps the slot to the "
                    "PBR_ copy (original always kept with fake user)",
        default=True)

    # ── Procedural Materials ─────────────────────────────────────
    procedural_material_preset: bpy.props.EnumProperty(
        name="Preset", items=ops_procedural_materials.PRESET_ENUM,
        default='PRO_Mat_Plastic_Black')
    procedural_replace_slots: bpy.props.BoolProperty(
        name="Replace Slots",
        description="Apply replaces every slot (originals keep a fake "
                    "user); off = appended as a new slot",
        default=True)

    # ── Baking ───────────────────────────────────────────────────
    bake_resolution: bpy.props.IntProperty(
        name="Resolution", default=2048, min=64, max=16384)
    bake_margin: bpy.props.IntProperty(
        name="Margin (px)", default=16, min=0, max=256)
    bake_use_cage: bpy.props.BoolProperty(
        name="Use Cage", default=False)
    bake_cage_extrusion: bpy.props.FloatProperty(
        name="Cage Extrusion", default=0.03, min=0.0, soft_max=1.0,
        unit='LENGTH')
    bake_selected_to_active: bpy.props.BoolProperty(
        name="Selected to Active (High→Low)", default=False)
    bake_image_prefix: bpy.props.StringProperty(
        name="Image Prefix", default="BAKE_")
    bake_output_folder: bpy.props.StringProperty(
        name="Output Folder", subtype='DIR_PATH', default="",
        description="If set, baked images are saved here as PNG")
    bake_map_type: bpy.props.EnumProperty(
        name="Map",
        items=[('NORMAL', "Normal", ""), ('AO', "AO", ""),
               ('DIFFUSE', "Diffuse", ""), ('ROUGHNESS', "Roughness", ""),
               ('EMIT', "Emission", ""), ('COLOR_ID', "Color ID", ""),
               ('COMBINED', "Combined", "")],
        default='NORMAL')
    bake_low_object: bpy.props.PointerProperty(
        name="Low", type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH')
    bake_high_object: bpy.props.PointerProperty(
        name="High", type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH')
    bake_cage_object: bpy.props.PointerProperty(
        name="Cage", type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH')

    # ── Unity / Game Prep ────────────────────────────────────────
    unity_max_texture_size: bpy.props.IntProperty(
        name="Max Texture Size", default=2048, min=64, max=16384)
    unity_max_materials_per_object: bpy.props.IntProperty(
        name="Max Materials / Object", default=4, min=1, max=64)
    unity_require_pbr: bpy.props.BoolProperty(
        name="Require PBR", default=True)
    unity_audit_done: bpy.props.BoolProperty(default=False)
    unity_audit_issues: bpy.props.IntProperty(default=0)


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _matches_search(context, *keywords):
    """Return True if search_query is empty or matches any keyword."""
    props = context.scene.pro_toolkit
    q = props.search_query.strip().lower()
    if not q:
        return True
    return any(q in kw.lower() for kw in keywords)


def _draw_edit_mode_warning(layout):
    row = layout.row()
    row.alert = True
    row.label(text="Enter Edit Mode to use tools", icon='ERROR')


def _draw_object_mode_warning(layout):
    row = layout.row()
    row.alert = True
    row.label(text="Enter Object Mode to use tools", icon='ERROR')


# ═══════════════════════════════════════════════════════════════════════
#  UTILITY – Clear Search
# ═══════════════════════════════════════════════════════════════════════

class PRO_TOOLKIT_OT_clear_search(bpy.types.Operator):
    """Clear the search filter"""
    bl_idname = "pro_toolkit.clear_search"
    bl_label = "Clear Search"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        context.scene.pro_toolkit.search_query = ""
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  MAIN PANEL (Root)
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_main(bpy.types.Panel):
    bl_label = "Pro Toolkit"
    bl_idname = "VIEW3D_PT_pro_toolkit_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit

        # ── Search bar ───────────────────────────────────────────
        row = layout.row(align=True)
        row.prop(props, "search_query", text="", icon='VIEWZOOM')
        if props.search_query:
            row.operator("pro_toolkit.clear_search", text="", icon='X')

        # ── Active object info ───────────────────────────────────
        obj = context.active_object
        if obj:
            col = layout.column(align=True)
            col.label(text=f"Active: {obj.name}", icon='OBJECT_DATA')
            col.label(
                text=f"Mode: {obj.mode}",
                icon='EDITMODE_HLT' if obj.mode == 'EDIT' else 'OBJECT_DATAMODE')
        else:
            layout.label(text="No active object", icon='INFO')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 0 — Quick Tools
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_quick_tools(bpy.types.Panel):
    bl_label = "Quick Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_quick_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        layout = self.layout
        in_edit = (context.mode == 'EDIT_MESH')

        grid = layout.grid_flow(row_major=True, columns=2,
                                even_columns=True, even_rows=False, align=True)

        sub = grid.column(align=True)
        sub.enabled = in_edit
        sub.operator("mesh.pro_push_pull", icon='NORMALS_VERTEX_FACE')

        sub = grid.column(align=True)
        sub.enabled = in_edit
        sub.operator("mesh.pro_bevel", icon='MOD_BEVEL')

        sub = grid.column(align=True)
        sub.enabled = in_edit
        sub.operator("mesh.pro_extrude", icon='ORIENTATION_NORMAL')

        sub = grid.column(align=True)
        sub.enabled = in_edit
        sub.operator("mesh.pro_inset", icon='FULLSCREEN_ENTER')

        sub = grid.column(align=True)
        sub.enabled = in_edit
        sub.operator("mesh.pro_circularize", icon='MESH_CIRCLE')

        grid.operator("object.pro_toolkit_run_audit", icon='VIEWZOOM')

        if not in_edit:
            row = layout.row()
            row.scale_y = 0.7
            row.label(text="Mesh tools need Edit Mode", icon='INFO')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 1 — Selection Tools
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_selection(bpy.types.Panel):
    bl_label = "Selection Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_selection"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return

        col = layout.column(align=True)
        if _matches_search(context, "select", "ngon"):
            col.operator("mesh.pro_select_ngons", icon='MESH_CIRCLE')
        if _matches_search(context, "select", "tris", "triangle"):
            col.operator("mesh.pro_select_tris", icon='MESH_TORUS')
        if _matches_search(context, "select", "non-manifold", "manifold"):
            col.operator("mesh.pro_select_non_manifold", icon='OUTLINER_DATA_MESH')
        if _matches_search(context, "select", "boundary", "border", "open"):
            col.operator("mesh.pro_select_boundary", icon='MOD_EDGESPLIT')
        if _matches_search(context, "select", "loose", "isolated"):
            col.operator("mesh.pro_select_loose", icon='STICKY_UVS_DISABLE')
        if _matches_search(context, "select", "sharp", "angle"):
            col.operator("mesh.pro_select_sharp_edges", icon='SHARPCURVE')
        if _matches_search(context, "select", "seam", "uv"):
            col.operator("mesh.pro_select_seams", icon='UV_EDGESEL')

        if _matches_search(context, "select", "grow", "shrink", "more", "less", "invert"):
            layout.separator()
            row = layout.row(align=True)
            row.operator("mesh.pro_grow_selection", text="Grow", icon='ADD')
            row.operator("mesh.pro_shrink_selection", text="Shrink", icon='REMOVE')
            layout.operator("mesh.pro_invert_selection", icon='ARROW_LEFTRIGHT')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 2 — Vertex Tools
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_vertices(bpy.types.Panel):
    bl_label = "Vertex Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_vertices"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return

        if _matches_search(context, "push", "pull"):
            layout.operator("mesh.pro_push_pull", icon='NORMALS_VERTEX_FACE')
        if _matches_search(context, "relax", "smooth"):
            layout.operator("mesh.pro_relax", icon='MOD_SMOOTH')
        if _matches_search(context, "flatten"):
            layout.operator("mesh.pro_flatten", icon='ORIENTATION_NORMAL')
        if _matches_search(context, "merge", "distance", "doubles"):
            layout.operator("mesh.pro_merge_distance", icon='AUTOMERGE_OFF')

        # Align buttons (compact row)
        if _matches_search(context, "align"):
            layout.label(text="Align:")
            row = layout.row(align=True)
            op = row.operator("mesh.pro_align", text="X")
            op.axis = 'X'
            op = row.operator("mesh.pro_align", text="Y")
            op.axis = 'Y'
            op = row.operator("mesh.pro_align", text="Z")
            op.axis = 'Z'


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 3 — Edge Tools
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_edges(bpy.types.Panel):
    bl_label = "Edge Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_edges"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return

        if _matches_search(context, "slide", "edge"):
            layout.operator("mesh.edge_slide", icon='MOD_EDGESPLIT')
        if _matches_search(context, "bridge", "loop"):
            layout.operator("mesh.bridge_edge_loops", icon='MESH_GRID')
        if _matches_search(context, "subdivide"):
            layout.operator("mesh.subdivide", icon='MOD_SUBSURF')
        if _matches_search(context, "bevel", "chamfer"):
            layout.operator("mesh.pro_bevel", icon='MOD_BEVEL')

        # Mark Sharp / Seam row
        if _matches_search(context, "sharp", "seam", "mark"):
            layout.separator()
            layout.label(text="Marks:")
            row = layout.row(align=True)
            row.operator("mesh.mark_sharp", text="Sharp", icon='SHARPCURVE')
            op_clear_sharp = row.operator("mesh.mark_sharp", text="Clear")
            op_clear_sharp.clear = True

            row = layout.row(align=True)
            row.operator("mesh.mark_seam", text="Seam", icon='UV_EDGESEL')
            op_clear_seam = row.operator("mesh.mark_seam", text="Clear")
            op_clear_seam.clear = True


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 4 — Face Tools
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_faces(bpy.types.Panel):
    bl_label = "Face Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_faces"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return

        if _matches_search(context, "extrude", "normal"):
            layout.operator("mesh.pro_extrude", icon='ORIENTATION_NORMAL')
        if _matches_search(context, "inset"):
            layout.operator("mesh.pro_inset", icon='FULLSCREEN_ENTER')
        if _matches_search(context, "solidify"):
            layout.operator("mesh.pro_solidify", icon='MOD_SOLIDIFY')
        if _matches_search(context, "grid", "fill"):
            layout.operator("mesh.fill_grid", icon='MESH_GRID')
        if _matches_search(context, "flip", "normals"):
            layout.operator("mesh.flip_normals", icon='NORMALS_FACE')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 5 — Shape Tools
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_shapes(bpy.types.Panel):
    bl_label = "Shape Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_shapes"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        in_edit = (context.mode == 'EDIT_MESH')
        in_object = (context.mode == 'OBJECT')

        # ── Edit Mode shape edits ────────────────────────────────
        col = layout.column(align=True)
        col.enabled = in_edit
        if _matches_search(context, "circularize", "circle", "loop"):
            col.operator("mesh.pro_circularize", icon='MESH_CIRCLE')
        if _matches_search(context, "sphere", "spherize"):
            col.operator("transform.tosphere", text="To Sphere", icon='MESH_UVSPHERE')
        if _matches_search(context, "hole", "recess"):
            col.operator("mesh.pro_make_hole_basic", icon='MESH_CYLINDER')
        if _matches_search(context, "slot", "groove"):
            col.operator("mesh.pro_make_slot_basic", icon='MOD_BOOLEAN')
        if _matches_search(context, "frame", "border"):
            col.operator("mesh.pro_make_frame_basic", icon='MOD_LATTICE')

        # ── Object Mode shape generators ─────────────────────────
        layout.separator()
        layout.label(text="Create:")
        col = layout.column(align=True)
        col.enabled = in_object
        if _matches_search(context, "rounded", "box", "cube"):
            col.operator("object.pro_make_rounded_box", icon='META_CUBE')
        if _matches_search(context, "pipe", "tube"):
            col.operator("object.pro_add_pipe_curve", icon='MESH_CYLINDER')
        if _matches_search(context, "cable", "wire", "rope"):
            col.operator("object.pro_add_cable_curve", icon='CURVE_BEZCURVE')

        if not (in_edit or in_object):
            _draw_edit_mode_warning(layout)


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 6 — Pivot / Origin
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_pivot_origin(bpy.types.Panel):
    bl_label = "Pivot / Origin"
    bl_idname = "VIEW3D_PT_pro_toolkit_pivot_origin"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        col = layout.column(align=True)
        if _matches_search(context, "origin", "bottom", "base", "pivot"):
            col.operator("object.pro_origin_to_bottom", icon='TRIA_DOWN_BAR')
        if _matches_search(context, "origin", "center", "pivot"):
            col.operator("object.pro_origin_to_center", icon='SNAP_FACE_CENTER')
        if _matches_search(context, "origin", "cursor", "pivot"):
            col.operator("object.pro_origin_to_cursor", icon='PIVOT_CURSOR')
        if _matches_search(context, "floor", "ground", "drop"):
            col.operator("object.pro_center_on_floor", icon='IMPORT')

        if _matches_search(context, "apply", "scale", "rotation", "transform"):
            layout.separator()
            layout.label(text="Apply Transforms:")
            row = layout.row(align=True)
            row.operator("object.pro_apply_scale_safe", text="Scale", icon='FULLSCREEN_ENTER')
            row.operator("object.pro_apply_rotation_safe", text="Rotation", icon='ORIENTATION_GIMBAL')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 7 — Architecture / Blockout
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_architecture(bpy.types.Panel):
    bl_label = "Architecture / Blockout"
    bl_idname = "VIEW3D_PT_pro_toolkit_architecture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        col = layout.column(align=True)
        if _matches_search(context, "wall", "architecture"):
            col.operator("object.pro_add_wall_cube", icon='MOD_BUILD')
        if _matches_search(context, "floor", "ground", "architecture"):
            col.operator("object.pro_add_floor_plane", icon='MESH_PLANE')
        if _matches_search(context, "door", "architecture"):
            col.operator("object.pro_add_door_blockout", icon='SNAP_VOLUME')
        if _matches_search(context, "window", "architecture"):
            col.operator("object.pro_add_window_blockout", icon='MOD_WIREFRAME')
        if _matches_search(context, "roof", "architecture"):
            col.operator("object.pro_add_roof_blockout", icon='HOME')

        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Reference volumes - no booleans", icon='INFO')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 8 — Character / Organic
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_character(bpy.types.Panel):
    bl_label = "Character / Organic"
    bl_idname = "VIEW3D_PT_pro_toolkit_character"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        in_edit = (context.mode == 'EDIT_MESH')

        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return

        # ── Modifier presets (any mode) ──────────────────────────
        layout.label(text="Setup:")
        col = layout.column(align=True)
        if _matches_search(context, "mirror", "character", "symmetry"):
            col.operator("object.pro_add_character_mirror", icon='MOD_MIRROR')
        if _matches_search(context, "subdivision", "smooth", "preview"):
            col.operator("object.pro_add_subdivision_preview", icon='MOD_SUBSURF')
        if _matches_search(context, "shrinkwrap", "wrap", "retopo"):
            col.operator("object.pro_add_shrinkwrap", icon='MOD_SHRINKWRAP')

        # ── Edit Mode organic tools ──────────────────────────────
        layout.separator()
        layout.label(text="Sculpt-like (Edit Mode):")
        col = layout.column(align=True)
        col.enabled = in_edit
        if _matches_search(context, "smooth", "organic"):
            col.operator("mesh.pro_smooth_selection", icon='MOD_SMOOTH')
        if _matches_search(context, "inflate", "deflate", "fatten"):
            col.operator("mesh.pro_inflate_deflate", icon='PROP_ON')
        if _matches_search(context, "symmetrize", "symmetry", "mirror"):
            col.operator("mesh.pro_symmetrize_x", icon='MOD_MIRROR')
        if _matches_search(context, "snap", "symmetry"):
            col.operator("mesh.pro_snap_to_symmetry_x", icon='SNAP_ON')


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 9 — Modifiers Quick Add
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_modifiers(bpy.types.Panel):
    bl_label = "Modifiers Quick Add"
    bl_idname = "VIEW3D_PT_pro_toolkit_modifiers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return

        if _matches_search(context, "mirror"):
            op = layout.operator("object.pro_toolkit_add_modifier", text="Mirror", icon='MOD_MIRROR')
            op.mod_type = 'MIRROR'
        if _matches_search(context, "solidify"):
            op = layout.operator("object.pro_toolkit_add_modifier", text="Solidify", icon='MOD_SOLIDIFY')
            op.mod_type = 'SOLIDIFY'
        if _matches_search(context, "bevel"):
            op = layout.operator("object.pro_toolkit_add_modifier", text="Bevel", icon='MOD_BEVEL')
            op.mod_type = 'BEVEL'
        if _matches_search(context, "weighted", "normal"):
            op = layout.operator("object.pro_toolkit_add_modifier", text="Weighted Normal", icon='MOD_NORMALEDIT')
            op.mod_type = 'WEIGHTED_NORMAL'


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 10 — Cleanup & Repair
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_cleanup(bpy.types.Panel):
    bl_label = "Cleanup & Repair"
    bl_idname = "VIEW3D_PT_pro_toolkit_cleanup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit

        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return

        if _matches_search(context, "audit", "scan", "health"):
            layout.operator("object.pro_toolkit_run_audit", icon='VIEWZOOM')
        if _matches_search(context, "cleanup", "clean", "one-click"):
            layout.operator("object.pro_toolkit_one_click_cleanup", icon='BRUSH_DATA')
        if _matches_search(context, "face", "orientation"):
            layout.operator("object.pro_face_orientation_toggle", icon='FACESEL')

        # Backups
        n_backups = core_toolkit.backup_count()
        if n_backups > 0 and _matches_search(context, "backup", "purge"):
            layout.operator("object.pro_toolkit_purge_backups",
                            text=f"Purge Backups ({n_backups})", icon='TRASH')

        # Show audit results if available
        if props.audit_done:
            layout.separator()
            box = layout.box()
            box.label(text="Mesh Health Report", icon='INFO')
            if props.audit_object_name:
                row = box.row()
                stale = (obj.name != props.audit_object_name)
                row.alert = stale
                suffix = "  (outdated)" if stale else ""
                row.label(text=f"Object: {props.audit_object_name}{suffix}")
            col = box.column(align=True)
            col.label(text=f"Verts: {props.audit_total_verts}")
            col.label(text=f"Edges: {props.audit_total_edges}")
            col.label(text=f"Faces: {props.audit_total_faces}")
            col.separator()
            _health_row(col, "N-Gons", props.audit_ngons)
            _health_row(col, "Tris", props.audit_tris)
            _health_row(col, "Non-Manifold", props.audit_non_manifold)
            _health_row(col, "Doubles", props.audit_doubles)
            _health_row(col, "Loose Verts", props.audit_loose)


def _health_row(layout, label, count):
    """Draw a health metric row with color coding."""
    row = layout.row()
    icon = 'CHECKMARK' if count == 0 else 'ERROR'
    row.alert = (count > 0)
    row.label(text=f"{label}: {count}", icon=icon)


# ═══════════════════════════════════════════════════════════════════════
#  SUBPANEL 11 — About / Credits
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_footer(bpy.types.Panel):
    bl_label = "About / Credits"
    bl_idname = "VIEW3D_PT_pro_toolkit_footer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Blender Pro Modeling Toolkit", icon='TOOL_SETTINGS')
        col.label(text="Made by Diarka Studio")
        col.label(text="Created by Saúl")
        col.label(text=f"Version {ADDON_VERSION_STR}")


# ═══════════════════════════════════════════════════════════════════════
#  v0.1.2 — PRO UV SUITE
# ═══════════════════════════════════════════════════════════════════════

class _ProSubPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Pro Toolkit'
    bl_options = {'DEFAULT_CLOSED'}


class VIEW3D_PT_pro_toolkit_uv_suite(_ProSubPanel, bpy.types.Panel):
    bl_label = "Pro UV Suite"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_suite"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.layout.label(text="Select a Mesh object", icon='INFO')
            return
        me = obj.data
        row = self.layout.row()
        row.scale_y = 0.8
        if me.uv_layers:
            row.label(text=f"Active UV: {me.uv_layers.active.name}", icon='UV')
        else:
            row.alert = True
            row.label(text="Object has NO UV map", icon='ERROR')


class VIEW3D_PT_pro_toolkit_uv_maps(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Map Manager"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_maps"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        me = obj.data

        col = layout.column(align=True)
        if me.uv_layers:
            col.label(text=f"Active UV: {me.uv_layers.active.name}")
        else:
            row = col.row()
            row.alert = True
            row.label(text="Active UV: (none)", icon='ERROR')
        col.label(text=f"UV Maps count: {len(me.uv_layers)}")

        col = layout.column(align=True)
        col.operator("object.pro_uv_create_map", icon='ADD')
        col.operator("object.pro_uv_create_lightmap", icon='LIGHT_SUN')
        col.operator("object.pro_uv_create_second_channel", icon='DUPLICATE')
        col = layout.column(align=True)
        col.operator("object.pro_uv_duplicate_map", icon='COPYDOWN')
        col.operator("object.pro_uv_rename_map", icon='FONT_DATA')
        col.operator("object.pro_uv_set_active_map", icon='FILE_REFRESH')
        row = col.row()
        row.alert = True
        row.operator("object.pro_uv_delete_map", icon='TRASH')


class VIEW3D_PT_pro_toolkit_uv_seams(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Seam Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_seams"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return
        row = layout.row(align=True)
        row.operator("mesh.pro_uv_mark_seam", text="Mark", icon='UV_EDGESEL')
        row.operator("mesh.pro_uv_clear_seam", text="Clear")
        col = layout.column(align=True)
        col.operator("mesh.pro_uv_clear_all_seams", icon='X')
        col.operator("mesh.pro_uv_select_seams", icon='RESTRICT_SELECT_OFF')
        col.operator("mesh.pro_uv_mark_sharp_as_seam", icon='SHARPCURVE')
        layout.separator()
        layout.label(text="Auto Seams:")
        col = layout.column(align=True)
        col.operator("mesh.pro_uv_auto_seams_by_angle", icon='DRIVER_ROTATIONAL_DIFFERENCE')
        row = col.row(align=True)
        row.operator("mesh.pro_uv_auto_seams_hard_surface", text="Hard Surface")
        row.operator("mesh.pro_uv_auto_seams_organic", text="Organic")
        layout.separator()
        row = layout.row(align=True)
        row.operator("mesh.pro_uv_select_boundary_edges", text="Boundary")
        row.operator("mesh.pro_uv_select_open_edges", text="Open Edges")


class VIEW3D_PT_pro_toolkit_uv_unwrap(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Unwrap Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_unwrap"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return
        layout.label(text="Presets:")
        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
        for preset, label in (('HARD_SURFACE', "Hard Surface"),
                              ('ORGANIC', "Organic"),
                              ('CHARACTER', "Character"),
                              ('ARCHITECTURE', "Architecture"),
                              ('PROP', "Prop"),
                              ('LIGHTMAP', "Lightmap")):
            op = grid.operator("mesh.pro_uv_unwrap_preset", text=label)
            op.preset = preset
        layout.separator()
        col = layout.column(align=True)
        col.operator("mesh.pro_uv_smart_project", icon='MOD_UVPROJECT')
        col.operator("mesh.pro_uv_unwrap_from_seams", icon='UV')
        row = col.row(align=True)
        row.operator("mesh.pro_uv_cube_project", text="Cube")
        row.operator("mesh.pro_uv_cylinder_project", text="Cylinder")
        row.operator("mesh.pro_uv_sphere_project", text="Sphere")
        col.operator("mesh.pro_uv_project_from_view", icon='VIEW_CAMERA')
        col.operator("mesh.pro_uv_lightmap_pack", icon='LIGHT_SUN')
        col.operator("mesh.pro_uv_follow_active_quads", icon='MESH_GRID')
        col.operator("mesh.pro_uv_reset_uvs", icon='LOOP_BACK')


class VIEW3D_PT_pro_toolkit_uv_islands(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Island Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_islands"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return
        col = layout.column(align=True)
        col.operator("mesh.pro_uv_pack_islands", icon='PACKAGE')
        col.operator("mesh.pro_uv_average_island_scale", icon='FULLSCREEN_EXIT')
        col.operator("mesh.pro_uv_minimize_stretch", icon='MOD_SMOOTH')
        layout.separator()
        row = layout.row(align=True)
        row.operator("mesh.pro_uv_rotate_islands_90", text="Rot 90°")
        row.operator("mesh.pro_uv_flip_islands_x", text="Flip X")
        row.operator("mesh.pro_uv_flip_islands_y", text="Flip Y")
        layout.operator("mesh.pro_uv_fit_to_0_1", icon='FULLSCREEN_ENTER')
        layout.label(text="Align Islands:")
        row = layout.row(align=True)
        row.operator("mesh.pro_uv_align_left", text="Left")
        row.operator("mesh.pro_uv_align_horizontal", text="Center H")
        row.operator("mesh.pro_uv_align_right", text="Right")
        row = layout.row(align=True)
        row.operator("mesh.pro_uv_align_top", text="Top")
        row.operator("mesh.pro_uv_align_vertical", text="Center V")
        row.operator("mesh.pro_uv_align_bottom", text="Bottom")
        layout.separator()
        col = layout.column(align=True)
        col.operator("mesh.pro_uv_straighten_selection", icon='IPO_LINEAR')
        col.operator("mesh.pro_uv_rectify_island", icon='MESH_GRID')
        col.operator("mesh.pro_uv_square_island", icon='MESH_PLANE')


class VIEW3D_PT_pro_toolkit_uv_density(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Texel Density"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_density"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        col = layout.column(align=True)
        col.prop(props, "uv_texture_size")
        col.prop(props, "uv_target_density")
        if props.uv_density_result > 0:
            layout.label(text=f"Current: {props.uv_density_result:.1f} px/m",
                         icon='INFO')
        col = layout.column(align=True)
        col.operator("object.pro_uv_calculate_texel_density", icon='VIEWZOOM')
        col.operator("object.pro_uv_set_texel_density", icon='UV_SYNC_SELECT')
        col.operator("object.pro_uv_match_texel_density", icon='LINKED')
        col.operator("object.pro_uv_normalize_texel_density", icon='ALIGN_FLUSH')
        col.operator("object.pro_uv_show_density_report", icon='TEXT')


class VIEW3D_PT_pro_toolkit_uv_checker(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Checker / Preview"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_checker"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        layout.prop(props, "uv_checker_scale")
        col = layout.column(align=True)
        col.operator("object.pro_uv_add_checker_material", icon='TEXTURE')
        col.operator("object.pro_uv_add_colored_checker_material", icon='COLOR')
        col.operator("object.pro_uv_add_distortion_checker_material", icon='MOD_WARP')
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_uv_toggle_checker_preview", icon='HIDE_OFF')
        col.operator("object.pro_uv_restore_previous_materials", icon='RECOVER_LAST')
        col.operator("object.pro_uv_remove_checker_material", icon='X')


class VIEW3D_PT_pro_toolkit_uv_audit(_ProSubPanel, bpy.types.Panel):
    bl_label = "UV Audit / Repair"
    bl_idname = "VIEW3D_PT_pro_toolkit_uv_audit"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_uv_suite"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return

        layout.operator("object.pro_uv_audit", icon='VIEWZOOM')

        if props.uv_audit_done:
            box = layout.box()
            stale = (props.uv_audit_object != obj.name)
            row = box.row()
            row.alert = stale
            row.label(text=f"Report: {props.uv_audit_object}"
                           + ("  (outdated)" if stale else ""),
                      icon='INFO')
            col = box.column(align=True)
            col.label(text=f"Has UV Map: {'Yes' if props.uv_audit_has_uv else 'No'}")
            col.label(text=f"Active UV Map: {props.uv_audit_active_map}")
            col.label(text=f"UV Maps: {props.uv_audit_map_count}   "
                           f"Faces: {props.uv_audit_faces}   "
                           f"Mats: {props.uv_audit_materials}")
            col.label(text=f"UV Islands: {props.uv_audit_islands}")
            _health_row(col, "Overlaps (estimated)", props.uv_audit_overlaps)
            _health_row(col, "Outside 0-1", props.uv_audit_outside)
            _health_row(col, "Zero Area UVs", props.uv_audit_zero_area)
            _health_row(col, "Flipped UVs", props.uv_audit_flipped)
            col.label(text=f"Avg Density: {props.uv_audit_density:.1f} px/m")
            col.label(text=f"Density Variation: x{props.uv_audit_density_var:.2f}")
            for w in props.uv_audit_warnings.split(" | "):
                if w:
                    row = col.row()
                    row.scale_y = 0.75
                    row.label(text=w, icon='DOT')

        layout.separator()
        layout.label(text="Select Issues (Edit Mode):")
        col = layout.column(align=True)
        col.enabled = (context.mode == 'EDIT_MESH')
        col.operator("mesh.pro_uv_select_overlaps")
        col.operator("mesh.pro_uv_select_outside_0_1")
        col.operator("mesh.pro_uv_select_flipped_uvs")
        col.operator("mesh.pro_uv_select_zero_area_uvs")
        layout.label(text="Repair (Edit Mode):")
        col = layout.column(align=True)
        col.enabled = (context.mode == 'EDIT_MESH')
        col.operator("mesh.pro_uv_fix_outside_0_1", icon='SNAP_GRID')
        col.operator("mesh.pro_uv_fix_zero_area_uvs", icon='TOOL_SETTINGS')
        layout.operator("object.pro_uv_export_report", icon='FILE_TEXT')


# ═══════════════════════════════════════════════════════════════════════
#  v0.1.2 — PRO CEL SHADING SUITE
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_cel_suite(_ProSubPanel, bpy.types.Panel):
    bl_label = "Pro Cel Shading Suite"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_suite"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        row = self.layout.row()
        row.scale_y = 0.8
        engine = context.scene.render.engine
        row.label(text=f"Engine: {engine.replace('BLENDER_', '').title()}",
                  icon='SHADING_RENDERED')


class VIEW3D_PT_pro_toolkit_cel_presets(_ProSubPanel, bpy.types.Panel):
    bl_label = "Cel Shader Presets"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_presets"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_cel_suite"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return

        # ── Application Mode (v0.1.2.1) ──────────────────────────
        box = layout.box()
        mode = ("Flat Toon Replace" if props.cel_replace_material
                else "Preserve Texture Toon")
        box.label(text=f"Mode: {mode}", icon='MATERIAL')
        col = box.column(align=True)
        col.prop(props, "cel_preserve_existing_texture")
        col.prop(props, "cel_duplicate_original_material")
        col.prop(props, "cel_apply_to_all_material_slots")
        col.prop(props, "cel_replace_material")
        if props.cel_replace_material:
            row = box.row()
            row.alert = True
            row.label(text="Replace removes the texture setup!", icon='ERROR')
        else:
            row = box.row()
            row.scale_y = 0.7
            row.label(text="Keeps textures, builds toon on top",
                      icon='INFO')

        grid = layout.grid_flow(row_major=True, columns=2,
                                even_columns=True, align=True)
        for suffix, (_mat, label, _params) in ops_toon_presets.PRESETS.items():
            grid.operator(f"object.pro_cel_apply_{suffix}", text=label)
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Applies to active + selected objects", icon='INFO')


class VIEW3D_PT_pro_toolkit_cel_controls(_ProSubPanel, bpy.types.Panel):
    bl_label = "Cel Shader Controls"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_controls"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_cel_suite"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        layout.prop(props, "cel_material_preset")
        layout.operator("object.pro_cel_apply_selected_preset", icon='MATERIAL')
        layout.separator()
        col = layout.column(align=True)
        col.prop(props, "cel_base_color")
        col.prop(props, "cel_shadow_color")
        col.prop(props, "cel_highlight_color")
        col.prop(props, "cel_rim_color")
        col = layout.column(align=True)
        col.prop(props, "cel_ramp_threshold")
        col.prop(props, "cel_ramp_hardness")
        col.prop(props, "cel_rim_strength")
        layout.operator("object.pro_cel_apply_custom_settings", icon='FILE_REFRESH')


class VIEW3D_PT_pro_toolkit_cel_outlines(_ProSubPanel, bpy.types.Panel):
    bl_label = "Outlines"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_outlines"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_cel_suite"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "cel_outline_thickness")
        col.prop(props, "cel_outline_color")
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_outline_add_inverted_hull", icon='MOD_SOLIDIFY')
        col.operator("object.pro_outline_remove_inverted_hull", icon='X')
        col.operator("object.pro_outline_add_solidify_outline", icon='MOD_THICKNESS')
        layout.separator()
        row = layout.row(align=True)
        row.operator("object.pro_outline_set_thickness", text="Thickness")
        row.operator("object.pro_outline_set_color", text="Color")


class VIEW3D_PT_pro_toolkit_cel_freestyle(_ProSubPanel, bpy.types.Panel):
    bl_label = "Freestyle / Line Art"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_freestyle"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_cel_suite"

    def draw(self, context):
        layout = self.layout
        fs_on = context.scene.render.use_freestyle
        layout.label(text=f"Freestyle: {'ON' if fs_on else 'OFF'}",
                     icon='STROKE' if fs_on else 'BLANK1')
        col = layout.column(align=True)
        col.operator("object.pro_outline_setup_freestyle_preset", icon='LINE_DATA')
        row = col.row(align=True)
        row.operator("object.pro_outline_enable_freestyle", text="Enable")
        row.operator("object.pro_outline_disable_freestyle", text="Disable")
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Freestyle shows in renders (F12) only", icon='INFO')
        layout.separator()
        layout.operator("object.pro_outline_add_line_art_setup", icon='EXPERIMENTAL')


class VIEW3D_PT_pro_toolkit_cel_convert(_ProSubPanel, bpy.types.Panel):
    bl_label = "Material Conversion"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_convert"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_cel_suite"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        if obj.active_material:
            layout.label(text=f"Active: {obj.active_material.name}",
                         icon='MATERIAL')
        col = layout.column(align=True)
        col.operator("object.pro_cel_convert_active_material", icon='SHADING_RENDERED')
        col.operator("object.pro_cel_convert_selected_materials", icon='OUTLINER_OB_GROUP_INSTANCE')
        col.operator("object.pro_cel_duplicate_as_toon", icon='DUPLICATE')
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Originals are kept in the file", icon='INFO')


class VIEW3D_PT_pro_toolkit_cel_lighting(_ProSubPanel, bpy.types.Panel):
    bl_label = "Lighting Helpers"
    bl_idname = "VIEW3D_PT_pro_toolkit_cel_lighting"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_cel_suite"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("object.pro_cel_add_toon_key_light", icon='LIGHT_SUN')
        col.operator("object.pro_cel_add_rim_light", icon='LIGHT_HEMI')
        col.operator("object.pro_cel_add_flat_lighting_setup", icon='WORLD')
        layout.separator()
        layout.operator("object.pro_cel_set_eevee_toon_settings", icon='SCENE')


# ═══════════════════════════════════════════════════════════════════════
#  v0.1.3 — PRO MODELING CREATION SUITE
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_creation(_ProSubPanel, bpy.types.Panel):
    bl_label = "Pro Modeling Creation"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit

        box = layout.box()
        box.label(text="Creation Settings", icon='TOOL_SETTINGS')
        col = box.column(align=True)
        col.prop(props, "creation_collection_mode", text="")
        col.prop(props, "creation_align_to_floor")
        col.prop(props, "creation_create_material")
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)


class VIEW3D_PT_pro_toolkit_creation_arch(_ProSubPanel, bpy.types.Panel):
    bl_label = "Architecture / Blockout"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_arch"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        layout.label(text="Structure:")
        col = layout.column(align=True)
        if _matches_search(context, "wall", "module", "architecture"):
            col.operator("object.pro_create_wall_module", icon='MOD_BUILD')
        if _matches_search(context, "floor", "module", "architecture"):
            col.operator("object.pro_create_floor_module", icon='MESH_PLANE')
        if _matches_search(context, "room", "blockout"):
            col.operator("object.pro_create_room_blockout", icon='HOME')
        if _matches_search(context, "pillar", "column"):
            col.operator("object.pro_create_pillar", icon='MESH_CYLINDER')
        if _matches_search(context, "beam"):
            col.operator("object.pro_create_beam", icon='FIXED_SIZE')
        if _matches_search(context, "stair", "steps"):
            col.operator("object.pro_create_stair_blockout", icon='NLA_PUSHDOWN')

        layout.label(text="Openings:")
        col = layout.column(align=True)
        if _matches_search(context, "door", "frame"):
            col.operator("object.pro_create_door_frame", icon='SNAP_VOLUME')
        if _matches_search(context, "window", "frame"):
            col.operator("object.pro_create_window_frame", icon='MOD_WIREFRAME')
        if _matches_search(context, "door", "opening", "cut"):
            col.operator("object.pro_create_door_opening_block", icon='SELECT_SUBTRACT')
        if _matches_search(context, "window", "opening", "cut"):
            col.operator("object.pro_create_window_opening_block", icon='SELECT_INTERSECT')

        layout.label(text="Store Furniture:")
        col = layout.column(align=True)
        if _matches_search(context, "counter", "checkout"):
            col.operator("object.pro_create_counter_blockout", icon='SNAP_FACE')
        if _matches_search(context, "shelf", "shelving"):
            col.operator("object.pro_create_shelf_blockout", icon='ALIGN_JUSTIFY')
        if _matches_search(context, "aisle", "supermarket"):
            col.operator("object.pro_create_aisle_blockout", icon='CENTER_ONLY')


class VIEW3D_PT_pro_toolkit_creation_products(_ProSubPanel, bpy.types.Panel):
    bl_label = "Product & Prop Base"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_products"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        layout.label(text="Products:")
        col = layout.column(align=True)
        if _matches_search(context, "product", "box"):
            col.operator("object.pro_create_product_box", icon='MESH_CUBE')
        if _matches_search(context, "product", "can"):
            col.operator("object.pro_create_product_can", icon='MESH_CYLINDER')
        if _matches_search(context, "product", "bottle"):
            col.operator("object.pro_create_product_bottle", icon='MESH_CAPSULE')
        if _matches_search(context, "snack", "bag"):
            col.operator("object.pro_create_snack_bag", icon='OUTLINER_OB_SURFACE')
        if _matches_search(context, "milk", "carton"):
            col.operator("object.pro_create_milk_carton", icon='META_CUBE')

        layout.label(text="Labels / Signs:")
        col = layout.column(align=True)
        if _matches_search(context, "label", "plane"):
            col.operator("object.pro_create_label_plane", icon='IMAGE_PLANE')
        if _matches_search(context, "price", "tag"):
            col.operator("object.pro_create_price_tag", icon='TAG')
        if _matches_search(context, "sign"):
            col.operator("object.pro_create_simple_sign", icon='ALIGN_TOP')

        layout.label(text="Store Equipment:")
        col = layout.column(align=True)
        if _matches_search(context, "cash", "register", "checkout"):
            col.operator("object.pro_create_cash_register", icon='DESKTOP')
        if _matches_search(context, "fridge", "cooler"):
            col.operator("object.pro_create_fridge_blockout", icon='SNAP_VOLUME')
        if _matches_search(context, "freezer", "chest"):
            col.operator("object.pro_create_freezer_chest", icon='UGLYPACKAGE')
        if _matches_search(context, "basket", "shopping"):
            col.operator("object.pro_create_shopping_basket", icon='MOD_LATTICE')
        if _matches_search(context, "cart", "trolley", "shopping"):
            col.operator("object.pro_create_shopping_cart", icon='AUTO')


class VIEW3D_PT_pro_toolkit_creation_shapes(_ProSubPanel, bpy.types.Panel):
    bl_label = "Shape Creation"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_shapes"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        col = layout.column(align=True)
        if _matches_search(context, "rounded", "box"):
            col.operator("object.pro_make_rounded_box", icon='META_CUBE')
        if _matches_search(context, "pipe", "tube"):
            col.operator("object.pro_add_pipe_curve", icon='MESH_CYLINDER')
        if _matches_search(context, "cable", "wire"):
            col.operator("object.pro_add_cable_curve", icon='CURVE_BEZCURVE')
        if _matches_search(context, "handle", "grip"):
            col.operator("object.pro_create_handle", icon='ARROW_LEFTRIGHT')
        if _matches_search(context, "rail", "guard"):
            col.operator("object.pro_create_rail", icon='IPO_LINEAR')
        if _matches_search(context, "vent", "louver"):
            col.operator("object.pro_create_vent", icon='ALIGN_JUSTIFY')
        if _matches_search(context, "panel", "plate"):
            col.operator("object.pro_create_panel", icon='MESH_PLANE')
        if _matches_search(context, "frame", "border"):
            col.operator("object.pro_create_frame_shape", icon='MOD_LATTICE')
        if _matches_search(context, "slot", "groove"):
            col.operator("object.pro_create_slot_block", icon='REMOVE')
        if _matches_search(context, "arch"):
            col.operator("object.pro_create_simple_arch", icon='SPHERECURVE')
        if _matches_search(context, "hole", "cutter", "boolean"):
            col.operator("object.pro_create_hole_cutter", icon='MESH_CYLINDER')

        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Editable bases - no auto booleans", icon='INFO')


class VIEW3D_PT_pro_toolkit_creation_lathe(_ProSubPanel, bpy.types.Panel):
    bl_label = "Profile Revolve / Lathe Pro"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_lathe"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        box = layout.box()
        box.label(text="Draw / Trace Mode", icon='GREASEPENCIL')
        col = box.column(align=True)
        col.prop(props, "lathe_draw_mode")
        row = col.row(align=True)
        row.prop(props, "lathe_auto_front_view", text="Front View")
        row.prop(props, "lathe_create_axis_guide", text="Axis")
        col.prop(props, "lathe_axis_height")
        col.prop(props, "lathe_axis_color")
        col.prop(props, "lathe_draw_profile_name")
        row = col.row(align=True)
        row.prop(props, "lathe_use_tablet_friendly_mode", text="Tablet")
        row.prop(props, "lathe_gp_stroke_thickness", text="GP Thickness")
        col.prop(props, "lathe_curve_resolution")
        col.prop(props, "lathe_trace_simplify_amount")
        col.separator()
        col.operator("object.pro_lathe_create_axis_guide",
                     text="Create Axis Guide", icon='EMPTY_AXIS')
        col.operator("object.pro_lathe_center_reference_image_to_axis",
                     text="Center Reference Image to Axis", icon='IMAGE_DATA')
        col.separator()
        col.operator("object.pro_lathe_start_curve_profile_draw_mode",
                     text="Start Curve Profile Draw Mode", icon='CURVE_DATA')
        col.operator("object.pro_lathe_start_grease_pencil_sketch_mode",
                     text="Start Grease Pencil Sketch Mode",
                     icon='GREASEPENCIL')
        col.operator("object.pro_lathe_start_vertex_trace_mode",
                     text="Start Vertex Trace Mode", icon='VERTEXSEL')
        col.operator("object.pro_lathe_start_bezier_profile_mode",
                     text="Start Bezier Profile Mode", icon='CURVE_BEZCURVE')
        col.separator()
        col.operator("object.pro_lathe_convert_grease_pencil_to_profile_curve",
                     text="Convert Grease Pencil to Profile Curve",
                     icon='OUTLINER_OB_CURVE')
        col.operator("object.pro_lathe_finish_profile_draw_mode",
                     text="Finish Draw Mode", icon='CHECKMARK')
        col.operator("object.pro_lathe_prepare_selected_profile_for_revolve",
                     text="Prepare Selected Profile for Revolve",
                     icon='MOD_SCREW')
        col.operator("object.pro_lathe_trace_mode_help",
                     text="Help: How to Trace for Lathe", icon='HELP')

        box = layout.box()
        box.label(text="Profile Creation", icon='CURVE_DATA')
        col = box.column(align=True)
        col.prop(props, "lathe_profile_preset", text="")
        op = col.operator("object.pro_create_revolve_profile_curve",
                          text="Create Profile Curve", icon='CURVE_DATA')
        op.preset = props.lathe_profile_preset
        op = col.operator("object.pro_create_revolve_profile_mesh",
                          text="Create Profile Mesh", icon='MESH_DATA')
        op.preset = props.lathe_profile_preset
        col.operator("object.pro_center_profile_to_axis", icon='PIVOT_MEDIAN')
        col.operator("object.pro_mirror_profile_to_axis", icon='MOD_MIRROR')

        box = layout.box()
        box.label(text="Revolve / Screw", icon='MOD_SCREW')
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "lathe_axis", expand=True)
        row = col.row(align=True)
        row.operator("object.pro_set_revolve_axis_x", text="Set Axis X")
        row.operator("object.pro_set_revolve_axis_y", text="Set Axis Y")
        row.operator("object.pro_set_revolve_axis_z", text="Set Axis Z")
        col.prop(props, "lathe_angle")
        col.prop(props, "lathe_segments")
        col.prop(props, "lathe_merge_center")
        col.prop(props, "lathe_merge_distance")
        col.prop(props, "lathe_use_smooth")
        col.operator("object.pro_add_screw_modifier_to_profile",
                     text="Add Screw / Revolve 360", icon='MOD_SCREW')
        col.operator("object.pro_revolve_profile_360",
                     text="Revolve Profile 360", icon='FILE_REFRESH')

        box = layout.box()
        box.label(text="Profile Presets", icon='PRESET')
        grid = box.grid_flow(row_major=True, columns=2, align=True,
                             even_columns=True)
        preset_buttons = (
            ('SIMPLE_BOTTLE', "Bottle Profile"),
            ('CAN', "Can Profile"),
            ('JAR', "Jar Profile"),
            ('CAP', "Cap Profile"),
            ('KNOB', "Knob Profile"),
            ('COLUMN', "Column Profile"),
            ('VASE', "Vase Profile"),
            ('SMALL_CONTAINER', "Small Product Container Profile"),
            ('CLEANING_BOTTLE', "Cleaning Bottle Profile"),
            ('PAWN_TEST', "Pawn-like Test Profile"),
        )
        for preset_id, label in preset_buttons:
            op = grid.operator("object.pro_create_revolve_profile_mesh",
                               text=label)
            op.preset = preset_id

        box = layout.box()
        box.label(text="Cleanup / Convert", icon='MODIFIER')
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "lathe_cap_bottom", text="Cap Bottom")
        row.prop(props, "lathe_cap_top", text="Cap Top")
        col.operator("object.pro_lathe_shade_smooth",
                     text="Shade Smooth", icon='SHADING_RENDERED')
        col.prop(props, "lathe_add_bevel")
        col.prop(props, "lathe_bevel_amount")
        col.operator("object.pro_add_lathe_bevel",
                     text="Add Lathe Bevel", icon='MOD_BEVEL')
        col.prop(props, "lathe_use_weighted_normals")
        col.operator("object.pro_add_lathe_weighted_normals",
                     text="Add Weighted Normals", icon='MOD_NORMALEDIT')
        col.prop(props, "lathe_add_subdivision")
        col.operator("object.pro_close_revolve_caps",
                     text="Close Revolve Caps", icon='SNAP_FACE')
        col.separator()
        col.prop(props, "lathe_non_destructive")
        col.prop(props, "lathe_apply_safely")
        col.operator("object.pro_convert_revolve_to_mesh_safe",
                     text="Convert Revolve to Mesh Safe", icon='MESH_DATA')
        col.operator("object.pro_apply_revolve_safely",
                     text="Apply Revolve Safely", icon='CHECKMARK')

        box = layout.box()
        box.label(text="Validation", icon='VIEWZOOM')
        box.operator("object.pro_lathe_audit_profile",
                     text="Audit Profile", icon='TEXT')
        if props.lathe_audit_done:
            row = box.row()
            row.scale_y = 0.8
            if props.lathe_audit_warnings:
                row.alert = True
                row.label(text=f"{props.lathe_audit_warnings} warning(s)",
                          icon='ERROR')
            else:
                row.label(text="Profile audit OK", icon='CHECKMARK')


class VIEW3D_PT_pro_toolkit_creation_pivot(_ProSubPanel, bpy.types.Panel):
    bl_label = "Pivot / Origin / Transform"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_pivot"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        layout.label(text="Origin:")
        col = layout.column(align=True)
        if _matches_search(context, "origin", "bottom"):
            col.operator("object.pro_origin_to_bottom", icon='TRIA_DOWN_BAR')
        if _matches_search(context, "origin", "center"):
            col.operator("object.pro_origin_to_center", icon='SNAP_FACE_CENTER')
        if _matches_search(context, "origin", "cursor"):
            col.operator("object.pro_origin_to_cursor", icon='PIVOT_CURSOR')

        layout.label(text="Placement:")
        col = layout.column(align=True)
        if _matches_search(context, "floor", "move", "drop"):
            col.operator("object.pro_center_on_floor",
                         text="Move Object to Floor", icon='IMPORT')
        if _matches_search(context, "floor", "align", "level"):
            col.operator("object.pro_align_to_floor", icon='ORIENTATION_NORMAL')
        if _matches_search(context, "center", "origin", "world"):
            col.operator("object.pro_center_on_origin", icon='OBJECT_ORIGIN')
        if _matches_search(context, "grid", "align", "snap"):
            col.operator("object.pro_align_to_world_grid", icon='SNAP_GRID')

        layout.label(text="Apply (Safe):")
        row = layout.row(align=True)
        row.operator("object.pro_apply_scale_safe", text="Scale")
        row.operator("object.pro_apply_rotation_safe", text="Rotation")
        layout.operator("object.pro_apply_all_transforms_safe", icon='CHECKMARK')

        if _matches_search(context, "dimensions", "size", "set"):
            layout.label(text="Set Dimensions:")
            col = layout.column(align=True)
            col.prop(props, "creation_width")
            col.prop(props, "creation_depth")
            col.prop(props, "creation_height")
            col.prop(props, "creation_apply_scale")
            col.operator("object.pro_set_dimensions", icon='FULLSCREEN_ENTER')


class VIEW3D_PT_pro_toolkit_creation_measure(_ProSubPanel, bpy.types.Panel):
    bl_label = "Snap / Measure / Scale"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_measure"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        layout.label(text="Measure:")
        col = layout.column(align=True)
        if _matches_search(context, "measure"):
            col.operator("object.pro_measure_object", icon='DRIVER_DISTANCE')
        if _matches_search(context, "report", "dimensions"):
            col.operator("object.pro_report_dimensions", icon='TEXT')
        if _matches_search(context, "real", "world", "scale"):
            col.operator("object.pro_set_real_world_scale", icon='WORLD')
        if _matches_search(context, "snap", "grid"):
            col.operator("object.pro_snap_selection_to_grid", icon='SNAP_GRID')

        layout.label(text="Helpers:")
        col = layout.column(align=True)
        if _matches_search(context, "grid", "helper"):
            op = col.operator("object.pro_create_grid_helper",
                              text="1m Grid Helper", icon='GRID')
            op.spacing = 'M1'
            op = col.operator("object.pro_create_grid_helper",
                              text="10cm Grid Helper", icon='VIEW_ORTHO')
            op.spacing = 'CM10'
        if _matches_search(context, "ruler", "measure"):
            col.operator("object.pro_create_ruler", icon='ARROW_LEFTRIGHT')

        layout.label(text="Scale References:")
        col = layout.column(align=True)
        if _matches_search(context, "player", "human", "scale"):
            col.operator("object.pro_create_player_reference", icon='OUTLINER_OB_ARMATURE')
        if _matches_search(context, "door", "reference", "scale"):
            col.operator("object.pro_create_door_reference", icon='SNAP_VOLUME')
        if _matches_search(context, "shelf", "reference", "scale"):
            col.operator("object.pro_create_shelf_reference", icon='ALIGN_JUSTIFY')


class VIEW3D_PT_pro_toolkit_creation_sf(_ProSubPanel, bpy.types.Panel):
    bl_label = "Supermarket Flower Presets"
    bl_idname = "VIEW3D_PT_pro_toolkit_creation_sf"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_creation"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        from .ops_creation_sf_presets import SF_PRESETS

        def sf_button(col, preset_id, icon='NONE'):
            op = col.operator("object.pro_sf_preset",
                              text=SF_PRESETS[preset_id][0], icon=icon)
            op.preset = preset_id

        layout.label(text="Structure:")
        col = layout.column(align=True)
        for pid, icon in (('SF_WALL', 'MOD_BUILD'),
                          ('SF_FLOOR', 'MESH_PLANE'),
                          ('SF_DOOR_FRAME', 'SNAP_VOLUME'),
                          ('SF_WINDOW_FRAME', 'MOD_WIREFRAME'),
                          ('SF_ENTRANCE', 'HOME')):
            sf_button(col, pid, icon)

        layout.label(text="Store Furniture:")
        col = layout.column(align=True)
        for pid, icon in (('SF_SHELF', 'ALIGN_JUSTIFY'),
                          ('SF_CHECKOUT', 'SNAP_FACE'),
                          ('SF_FRIDGE', 'SNAP_VOLUME'),
                          ('SF_FREEZER', 'UGLYPACKAGE')):
            sf_button(col, pid, icon)

        layout.label(text="Products:")
        col = layout.column(align=True)
        for pid, icon in (('SF_PRODUCT_BOX', 'MESH_CUBE'),
                          ('SF_PRODUCT_CAN', 'MESH_CYLINDER'),
                          ('SF_PRODUCT_BOTTLE', 'MESH_CAPSULE'),
                          ('SF_PRICE_TAG', 'TAG')):
            sf_button(col, pid, icon)

        layout.label(text="Helpers:")
        col = layout.column(align=True)
        for pid, icon in (('SF_AISLE_HELPER', 'CENTER_ONLY'),
                          ('SF_PLAYER_REF', 'OUTLINER_OB_ARMATURE'),
                          ('SF_PARKING_LINE', 'IPO_LINEAR')):
            sf_button(col, pid, icon)

        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Real-world scale - clean bases", icon='INFO')


# ═══════════════════════════════════════════════════════════════════════
#  v0.1.4 — HARD SURFACE PRO SUITE
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_hardsurface(_ProSubPanel, bpy.types.Panel):
    bl_label = "Hard Surface Pro"
    bl_idname = "VIEW3D_PT_pro_toolkit_hardsurface"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit

        box = layout.box()
        box.label(text="Hard Surface Settings", icon='TOOL_SETTINGS')
        col = box.column(align=True)
        col.prop(props, "hs_non_destructive")
        col.prop(props, "hs_create_materials")
        col.prop(props, "hs_align_to_floor")
        col.prop(props, "hs_use_weighted_normals")
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)


class VIEW3D_PT_pro_toolkit_hs_bevel(_ProSubPanel, bpy.types.Panel):
    bl_label = "Bevel / Normals"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_bevel"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit

        col = layout.column(align=True)
        col.prop(props, "hs_bevel_amount")
        row = col.row(align=True)
        row.prop(props, "hs_bevel_segments")
        row.prop(props, "hs_bevel_profile")
        col.prop(props, "hs_auto_weighted_normals")
        col.prop(props, "hs_apply_scale_if_needed")

        if context.mode == 'OBJECT':
            col = layout.column(align=True)
            if _matches_search(context, "smart", "bevel"):
                col.operator("object.pro_hs_smart_bevel", icon='MOD_BEVEL')
            if _matches_search(context, "weighted", "normal"):
                col.operator("object.pro_hs_weighted_normal", icon='NORMALS_FACE')
            if _matches_search(context, "smooth", "angle", "auto"):
                col.operator("object.pro_hs_auto_smooth", icon='MOD_SMOOTH')

            layout.label(text="Modifiers:")
            col = layout.column(align=True)
            if _matches_search(context, "bevel", "non destructive"):
                col.operator("object.pro_hs_bevel_object_nd", icon='MODIFIER')
            if _matches_search(context, "bevel", "modifier"):
                col.operator("object.pro_hs_add_bevel_modifier", icon='MOD_BEVEL')
            if _matches_search(context, "weighted", "normal", "modifier"):
                col.operator("object.pro_hs_add_wn_modifier", icon='NORMALS_VERTEX_FACE')
            if _matches_search(context, "apply", "bevel", "stack"):
                col.operator("object.pro_hs_apply_bevel_stack", icon='CHECKMARK')
        elif context.mode == 'EDIT_MESH':
            layout.label(text="Edges (Edit Mode):")
            col = layout.column(align=True)
            if _matches_search(context, "mark", "sharp"):
                col.operator("mesh.pro_hs_mark_sharp", icon='SHARPCURVE')
            if _matches_search(context, "clear", "sharp"):
                col.operator("mesh.pro_hs_clear_sharp", icon='SMOOTHCURVE')
            if _matches_search(context, "bevel", "edges"):
                col.operator("mesh.pro_hs_bevel_edges", icon='MOD_BEVEL')
        else:
            _draw_object_mode_warning(layout)


class VIEW3D_PT_pro_toolkit_hs_booleans(_ProSubPanel, bpy.types.Panel):
    bl_label = "Boolean Cutters"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_booleans"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        # ── Boolean Target (v0.1.5.1 workflow) ───────────────────
        box = layout.box()
        box.label(text="Boolean Target:", icon='OBJECT_DATA')
        tgt = props.hs_boolean_target_object
        row = box.row()
        row.alert = tgt is None
        row.label(text=f"Target: {tgt.name if tgt else 'None'}")
        row = box.row(align=True)
        row.operator("object.pro_hs_set_boolean_target", text="Set Active as Target")
        row.operator("object.pro_hs_clear_boolean_target", text="Clear")

        box.label(text="Cutter:")
        last = props.hs_last_created_cutter
        box.label(text=f"Last Cutter: {last.name if last else 'None'}")
        box.operator("object.pro_hs_use_selected_as_cutter", icon='MOD_BOOLEAN')

        box.label(text="Operations:")
        col = box.column(align=True)
        col.operator("object.pro_hs_add_boolean_difference_to_target",
                     icon='SELECT_SUBTRACT')
        row = col.row(align=True)
        row.operator("object.pro_hs_add_boolean_union_to_target", text="Union")
        row.operator("object.pro_hs_add_boolean_intersect_to_target",
                     text="Intersect")
        row = col.row(align=True)
        row.prop(props, "hs_boolean_operation", text="")
        row.operator("object.pro_hs_add_boolean_from_last_cutter",
                     text="From Last Cutter")

        box.label(text="Safe Apply:")
        col = box.column(align=True)
        row = col.row(align=True)
        row.operator("object.pro_hs_preview_boolean_toggle", icon='HIDE_OFF')
        col.operator("object.pro_hs_apply_target_boolean_safely", icon='CHECKMARK')
        row = box.row(align=True)
        row.prop(props, "hs_boolean_use_exact_solver", text="Exact")
        row.prop(props, "hs_boolean_hide_cutter_after_add", text="Hide on Add")
        row = box.row(align=True)
        row.prop(props, "hs_boolean_keep_cutter", text="Keep Cutters")
        row.prop(props, "hs_boolean_create_backup", text="Backup")

        # ── Create cutters ───────────────────────────────────────
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(props, "hs_cutter_width")
        row.prop(props, "hs_cutter_depth")
        row = col.row(align=True)
        row.prop(props, "hs_cutter_height")
        row.prop(props, "hs_cutter_radius")
        col.prop(props, "hs_cutter_segments")

        layout.label(text="Create Cutters:")
        grid = layout.grid_flow(row_major=True, columns=2,
                                even_columns=True, align=True)
        grid.operator("object.pro_hs_create_box_cutter", text="Box")
        grid.operator("object.pro_hs_create_cylinder_cutter", text="Cylinder")
        grid.operator("object.pro_hs_create_slot_cutter", text="Slot")
        grid.operator("object.pro_hs_create_round_hole_cutter", text="Round Hole")
        grid.operator("object.pro_hs_create_panel_cutter", text="Panel")
        grid.operator("object.pro_hs_create_line_cutter", text="Line")
        grid.operator("object.pro_hs_create_ring_cutter", text="Ring")
        grid.operator("object.pro_hs_create_corner_cutter", text="Corner")

        layout.label(text="Quick Boolean (selection-based):")
        col = layout.column(align=True)
        if _matches_search(context, "boolean", "difference", "subtract"):
            col.operator("object.pro_hs_boolean_difference", icon='SELECT_SUBTRACT')
        if _matches_search(context, "boolean", "union"):
            col.operator("object.pro_hs_boolean_union", icon='SELECT_EXTEND')
        if _matches_search(context, "boolean", "intersect"):
            col.operator("object.pro_hs_boolean_intersect", icon='SELECT_INTERSECT')
        if _matches_search(context, "apply", "boolean", "safe"):
            col.operator("object.pro_hs_apply_boolean", icon='CHECKMARK')

        layout.label(text="Cutter Management:")
        col = layout.column(align=True)
        if _matches_search(context, "hide", "cutters"):
            col.operator("object.pro_hs_hide_cutters", icon='HIDE_ON')
        if _matches_search(context, "show", "cutters"):
            col.operator("object.pro_hs_show_cutters", icon='HIDE_OFF')
        if _matches_search(context, "wire", "cutters"):
            col.operator("object.pro_hs_cutters_to_wire", icon='SHADING_WIRE')
        if _matches_search(context, "collection", "cutters"):
            col.operator("object.pro_hs_cutters_to_collection", icon='OUTLINER_COLLECTION')
        if _matches_search(context, "delete", "unused", "cutters"):
            col.operator("object.pro_hs_delete_unused_cutters", icon='TRASH')


class VIEW3D_PT_pro_toolkit_hs_mech_panels(_ProSubPanel, bpy.types.Panel):
    bl_label = "Mechanical Panels / Grilles / Covers"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_mech_panels"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(props, "hs_panel_rows")
        row.prop(props, "hs_panel_columns")
        row = col.row(align=True)
        row.prop(props, "hs_panel_hole_radius")
        row.prop(props, "hs_panel_thickness")
        row = col.row(align=True)
        row.prop(props, "hs_panel_slot_width")
        row.prop(props, "hs_panel_slot_height")
        col.prop(props, "hs_panel_pattern_type")
        row = col.row(align=True)
        row.prop(props, "hs_panel_bevel_amount")
        row = col.row(align=True)
        row.prop(props, "hs_panel_use_weighted_normals", text="W. Normals")
        row.prop(props, "hs_panel_create_as_cutter", text="As Cutter")
        if props.hs_panel_create_as_cutter:
            r = layout.row()
            r.scale_y = 0.7
            r.label(text="Solo el patrón, listo para Boolean", icon='INFO')

        grid = layout.grid_flow(row_major=True, columns=2,
                                even_columns=True, align=True)
        for suffix, text in (("vent_grille", "Vent Grille"),
                             ("louvered_vent", "Louvered Vent"),
                             ("perforated_panel", "Perforated Panel"),
                             ("access_cover", "Access Cover"),
                             ("maintenance_hatch", "Maint. Hatch"),
                             ("screw_plate", "Screw Plate"),
                             ("bolt_pattern", "Bolt Pattern"),
                             ("circular_vent", "Circular Vent"),
                             ("speaker_grille", "Speaker Grille"),
                             ("filter_panel", "Filter Panel"),
                             ("metal_mesh_panel", "Metal Mesh"),
                             ("technical_door_panel", "Tech Door"),
                             ("corner_screws", "Corner Screws"),
                             ("handle_plate", "Handle Plate"),
                             ("hinge_plate", "Hinge Plate"),
                             ("recessed_cover", "Recessed Cover"),
                             ("slot_pattern", "Slot Pattern"),
                             ("grid_pattern", "Grid Pattern"),
                             ("hex_hole_pattern", "Hex Holes"),
                             ("rounded_rect_plate", "Rounded Plate")):
            grid.operator(f"object.pro_hs_mech_{suffix}", text=text)


class VIEW3D_PT_pro_toolkit_hs_panels(_ProSubPanel, bpy.types.Panel):
    bl_label = "Panel / Inset Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_panels"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(props, "hs_panel_width")
        row.prop(props, "hs_panel_height")
        row = col.row(align=True)
        row.prop(props, "hs_panel_depth")
        row.prop(props, "hs_panel_margin")
        row = col.row(align=True)
        row.prop(props, "hs_panel_spacing")
        row.prop(props, "hs_panel_count")

        layout.label(text="Panels:")
        col = layout.column(align=True)
        if _matches_search(context, "panel", "inset"):
            col.operator("object.pro_hs_create_panel_inset", icon='MOD_SOLIDIFY')
        if _matches_search(context, "panel", "border"):
            col.operator("object.pro_hs_create_panel_border", icon='MESH_PLANE')
        if _matches_search(context, "raised", "panel"):
            col.operator("object.pro_hs_create_raised_panel", icon='EXPORT')
        if _matches_search(context, "recessed", "panel"):
            col.operator("object.pro_hs_create_recessed_panel", icon='IMPORT')

        layout.label(text="Surface Details:")
        col = layout.column(align=True)
        if _matches_search(context, "groove"):
            col.operator("object.pro_hs_create_groove", icon='IPO_LINEAR')
        if _matches_search(context, "slot"):
            col.operator("object.pro_hs_create_slot", icon='REMOVE')
        if _matches_search(context, "vent", "lines"):
            col.operator("object.pro_hs_create_vent_lines", icon='ALIGN_JUSTIFY')
        if _matches_search(context, "grille"):
            col.operator("object.pro_hs_create_grille", icon='VIEW_ORTHO')

        layout.label(text="Equipment Panels:")
        col = layout.column(align=True)
        if _matches_search(context, "door", "panel"):
            col.operator("object.pro_hs_create_door_panel", icon='SNAP_VOLUME')
        if _matches_search(context, "machine", "panel"):
            col.operator("object.pro_hs_create_machine_panel", icon='DESKTOP')
        if _matches_search(context, "fridge", "door", "panel"):
            col.operator("object.pro_hs_create_fridge_door_panel", icon='SNAP_FACE')
        if _matches_search(context, "register", "panel"):
            col.operator("object.pro_hs_create_register_panel", icon='MOD_SIMPLIFY')


class VIEW3D_PT_pro_toolkit_hs_details(_ProSubPanel, bpy.types.Panel):
    bl_label = "Mechanical Details"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_details"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        layout.prop(props, "hs_detail_scale")

        layout.label(text="Fasteners:")
        col = layout.column(align=True)
        if _matches_search(context, "screw", "bolt"):
            col.operator("object.pro_hs_create_screw", icon='RADIOBUT_ON')
        if _matches_search(context, "washer"):
            col.operator("object.pro_hs_create_washer", icon='CURVE_NCIRCLE')
        if _matches_search(context, "hinge"):
            col.operator("object.pro_hs_create_hinge", icon='ORIENTATION_VIEW')
        if _matches_search(context, "handle"):
            col.operator("object.pro_hs_create_handle", icon='ARROW_LEFTRIGHT')

        layout.label(text="Controls:")
        col = layout.column(align=True)
        if _matches_search(context, "button"):
            col.operator("object.pro_hs_create_small_button", icon='RADIOBUT_OFF')
        if _matches_search(context, "switch"):
            col.operator("object.pro_hs_create_switch", icon='CHECKBOX_HLT')
        if _matches_search(context, "knob"):
            col.operator("object.pro_hs_create_knob", icon='MESH_CIRCLE')

        layout.label(text="Hardware:")
        col = layout.column(align=True)
        if _matches_search(context, "rubber", "foot"):
            col.operator("object.pro_hs_create_rubber_foot", icon='MESH_CYLINDER')
        if _matches_search(context, "vent", "grille"):
            col.operator("object.pro_hs_create_vent_grille", icon='ALIGN_JUSTIFY')
        if _matches_search(context, "cable", "clamp"):
            col.operator("object.pro_hs_create_cable_clamp", icon='CONSTRAINT')
        if _matches_search(context, "metal", "plate"):
            col.operator("object.pro_hs_create_metal_plate", icon='MESH_PLANE')
        if _matches_search(context, "corner", "protector"):
            col.operator("object.pro_hs_create_corner_protector", icon='MOD_EDGESPLIT')


class VIEW3D_PT_pro_toolkit_hs_supermarket(_ProSubPanel, bpy.types.Panel):
    bl_label = "Legacy / Optional Supermarket Details"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_supermarket"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        from .ops_hardsurface_supermarket import SF_HS_PRESETS

        def hs_button(col, preset_id, icon='NONE'):
            op = col.operator("object.pro_hs_sf_preset",
                              text=SF_HS_PRESETS[preset_id][0], icon=icon)
            op.preset = preset_id

        layout.label(text="Fridge / Freezer:")
        col = layout.column(align=True)
        for pid, icon in (('FRIDGE_DOOR_DETAIL', 'SNAP_FACE'),
                          ('FRIDGE_HANDLE', 'ARROW_LEFTRIGHT'),
                          ('FRIDGE_RUBBER_SEAL', 'MOD_WIREFRAME'),
                          ('FREEZER_GLASS_LID_FRAME', 'VIEW_ORTHO')):
            hs_button(col, pid, icon)

        layout.label(text="Checkout:")
        col = layout.column(align=True)
        for pid, icon in (('CHECKOUT_CONVEYOR_BELT', 'SEQ_STRIP_DUPLICATE'),
                          ('CASH_REGISTER_BUTTONS', 'SNAP_GRID'),
                          ('CASH_REGISTER_SCREEN', 'DESKTOP'),
                          ('SHOPPING_CART_METAL_BAR', 'ARROW_LEFTRIGHT')):
            hs_button(col, pid, icon)

        layout.label(text="Shelving:")
        col = layout.column(align=True)
        for pid, icon in (('SHELF_PRICE_RAIL', 'TAG'),
                          ('METAL_SHELF_SIDE_PANEL', 'MESH_PLANE')):
            hs_button(col, pid, icon)

        layout.label(text="Store Shell:")
        col = layout.column(align=True)
        for pid, icon in (('SLIDING_DOOR_FRAME', 'MOD_WIREFRAME'),
                          ('STORE_ENTRANCE_METAL_FRAME', 'HOME'),
                          ('ELECTRICAL_BOX', 'PLUGIN'),
                          ('SECURITY_CAMERA_BLOCKOUT', 'CAMERA_DATA'),
                          ('CEILING_LIGHT_PANEL', 'LIGHT_AREA'),
                          ('VENTILATION_GRILLE', 'ALIGN_JUSTIFY')):
            hs_button(col, pid, icon)

        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Bases to detail the v0.1.3 blockouts", icon='INFO')


class VIEW3D_PT_pro_toolkit_hs_cleanup(_ProSubPanel, bpy.types.Panel):
    bl_label = "Hard Surface Cleanup"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_cleanup"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout

        if context.mode == 'OBJECT':
            layout.label(text="Audit:")
            col = layout.column(align=True)
            if _matches_search(context, "audit", "hard surface"):
                col.operator("object.pro_hs_audit_selected", icon='VIEWZOOM')
            if _matches_search(context, "unapplied", "scale", "select"):
                col.operator("object.pro_hs_select_unapplied_scale", icon='CON_SIZELIMIT')

            layout.label(text="Fix:")
            col = layout.column(align=True)
            if _matches_search(context, "fix", "normals"):
                col.operator("object.pro_hs_fix_normals", icon='NORMALS_FACE')
            if _matches_search(context, "loose", "geometry"):
                col.operator("object.pro_hs_remove_loose", icon='X')
            if _matches_search(context, "merge", "distance"):
                col.operator("object.pro_hs_merge_by_distance", icon='AUTOMERGE_ON')
            if _matches_search(context, "weighted", "normals", "selected"):
                col.operator("object.pro_hs_add_wn_modifier",
                             text="Add Weighted Normals to Selected",
                             icon='NORMALS_VERTEX_FACE')
            if _matches_search(context, "clean", "cutters"):
                col.operator("object.pro_hs_clean_cutters", icon='BRUSH_DATA')
        elif context.mode == 'EDIT_MESH':
            layout.label(text="Select (Edit Mode):")
            col = layout.column(align=True)
            if _matches_search(context, "ngon", "select"):
                col.operator("mesh.pro_select_ngons", icon='MESH_GRID')
            if _matches_search(context, "thin", "faces"):
                col.operator("mesh.pro_hs_select_thin_faces", icon='IPO_LINEAR')
            if _matches_search(context, "non manifold"):
                col.operator("mesh.pro_select_non_manifold", icon='ERROR')
            layout.label(text="Fix (Edit Mode):")
            col = layout.column(align=True)
            if _matches_search(context, "recalculate", "outside"):
                col.operator("mesh.pro_hs_recalc_outside", icon='NORMALS_FACE')
        else:
            _draw_object_mode_warning(layout)


class VIEW3D_PT_pro_toolkit_hs_alignment(_ProSubPanel, bpy.types.Panel):
    bl_label = "Cutter Alignment"
    bl_idname = "VIEW3D_PT_pro_toolkit_hs_alignment"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_hardsurface"

    def draw(self, context):
        layout = self.layout

        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return

        if _matches_search(context, "align", "cutter", "center", "cursor", "view"):
            layout.label(text="Align:")
            col = layout.column(align=True)
            col.operator("object.pro_hs_align_cutter_to_active_center",
                         icon='SNAP_FACE_CENTER')
            row = col.row(align=True)
            row.operator("object.pro_hs_align_cutter_to_active_bounds_x",
                         text="Center X")
            row.operator("object.pro_hs_align_cutter_to_active_bounds_y",
                         text="Center Y")
            row.operator("object.pro_hs_align_cutter_to_active_bounds_z",
                         text="Center Z")
            row = col.row(align=True)
            row.operator("object.pro_hs_align_cutter_to_cursor",
                         icon='PIVOT_CURSOR')
            row.operator("object.pro_hs_align_cutter_to_view",
                         icon='VIEW_CAMERA')

        if _matches_search(context, "rotate", "cutter", "90"):
            layout.label(text="Transform:")
            row = layout.row(align=True)
            row.operator("object.pro_hs_rotate_cutter_90_x", text="Rot 90 X")
            row.operator("object.pro_hs_rotate_cutter_90_y", text="Rot 90 Y")
            row.operator("object.pro_hs_rotate_cutter_90_z", text="Rot 90 Z")

        if _matches_search(context, "mirror", "duplicate", "cutter"):
            layout.label(text="Mirror / Duplicate:")
            col = layout.column(align=True)
            row = col.row(align=True)
            row.operator("object.pro_hs_mirror_cutter_x", text="Mirror X")
            row.operator("object.pro_hs_mirror_cutter_y", text="Mirror Y")
            row.operator("object.pro_hs_mirror_cutter_z", text="Mirror Z")
            col.operator("object.pro_hs_duplicate_cutter", icon='DUPLICATE')

        if _matches_search(context, "snap", "surface", "cutter"):
            layout.label(text="Snap:")
            layout.operator("object.pro_hs_snap_cutter_to_surface_basic",
                            icon='SNAP_ON')

        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Select cutters, target object active", icon='INFO')


# ═══════════════════════════════════════════════════════════════════════
#  v0.1.5 — CHARACTER / ORGANIC / RETOPO PRO
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_charpro(_ProSubPanel, bpy.types.Panel):
    bl_label = "Character / Organic / Retopo Pro"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        props = context.scene.pro_toolkit
        row = self.layout.row()
        row.scale_y = 0.8
        tgt = props.retopo_target_object
        row.label(text=f"Retopo target: {tgt.name if tgt else '(none)'}",
                  icon='MOD_SHRINKWRAP')


class VIEW3D_PT_pro_toolkit_charpro_cleanup(_ProSubPanel, bpy.types.Panel):
    bl_label = "Organic Mesh Cleanup"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_cleanup"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "organic_smooth_strength")
        col.prop(props, "organic_relax_iterations")
        col.prop(props, "organic_inflate_amount")
        col.prop(props, "organic_merge_distance")
        row = layout.row(align=True)
        row.prop(props, "organic_backup_before_cleanup", text="Backup")
        row.prop(props, "organic_preserve_uvs", text="Keep UVs")

        if context.mode == 'EDIT_MESH':
            col = layout.column(align=True)
            col.operator("mesh.pro_char_organic_smooth", icon='MOD_SMOOTH')
            col.operator("mesh.pro_char_organic_relax", icon='SMOOTHCURVE')
            col.operator("mesh.pro_char_inflate_deflate", icon='PROP_ON')
            col.operator("mesh.pro_char_smooth_by_surface", icon='MOD_SHRINKWRAP')
            col.operator("mesh.pro_char_merge_close_verts_safe", icon='AUTOMERGE_ON')
        elif context.mode == 'OBJECT':
            col = layout.column(align=True)
            col.operator("object.pro_char_remove_tiny_loose_parts", icon='X')
            col.operator("object.pro_char_recalc_organic_normals", icon='NORMALS_FACE')
            col.operator("object.pro_char_fix_inside_out", icon='ORIENTATION_NORMAL')
            col.operator("object.pro_char_smooth_shading_organic", icon='SHADING_RENDERED')
            col.operator("object.pro_char_add_corrective_smooth", icon='MOD_SMOOTH')
            col.operator("object.pro_char_add_smooth_by_angle", icon='NORMALS_VERTEX_FACE')
        else:
            _draw_object_mode_warning(layout)


class VIEW3D_PT_pro_toolkit_charpro_ai(_ProSubPanel, bpy.types.Panel):
    bl_label = "AI Model Cleanup"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_ai"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return

        layout.operator("object.pro_char_ai_audit", icon='VIEWZOOM')
        col = layout.column(align=True)
        col.label(text="Detect:")
        col.operator("mesh.pro_char_select_dense_areas",
                     text="Detect Dense Areas (est.)")
        op = col.operator("mesh.pro_char_select_loose_parts",
                          text="Detect Tiny Islands")
        op.only_tiny = True
        col.operator("mesh.pro_char_detect_bad_normals")
        op = col.operator("mesh.pro_char_select_loose_parts",
                          text="Detect Floating Parts")
        op.only_tiny = False
        col.operator("object.pro_char_detect_atlas_risk", icon='TEXTURE')
        col.operator("mesh.pro_select_non_manifold",
                     text="Detect Non-Manifold")

        layout.separator()
        col = layout.column(align=True)
        col.prop(props, "ai_cleanup_threshold")
        col.prop(props, "ai_cleanup_create_backup")
        col.operator("object.pro_char_remove_tiny_loose_parts",
                     text="Clean Small Loose Parts", icon='BRUSH_DATA')
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_char_ai_prepare_for_retopo", icon='MOD_REMESH')
        col.operator("object.pro_char_ai_create_retopo_duplicate", icon='DUPLICATE')
        row = col.row(align=True)
        row.operator("object.pro_char_ai_low_visibility_material", text="Ghost Mat")
        row.operator("object.pro_char_ai_xray_material", text="X-Ray Mat")
        col.operator("object.pro_char_ai_restore_materials", icon='RECOVER_LAST')
        col.operator("object.pro_char_ai_freeze_source", icon='FREEZE')


class VIEW3D_PT_pro_toolkit_charpro_symmetry(_ProSubPanel, bpy.types.Panel):
    bl_label = "Symmetry Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_symmetry"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        row = layout.row(align=True)
        row.prop(props, "symmetry_axis", expand=True)
        col = layout.column(align=True)
        col.prop(props, "symmetry_tolerance")
        col.prop(props, "symmetry_snap_distance")

        layout.label(text="Check:")
        row = layout.row(align=True)
        row.operator("object.pro_char_check_symmetry_x", text="X")
        row.operator("object.pro_char_check_symmetry_y", text="Y")
        row.operator("object.pro_char_check_symmetry_z", text="Z")
        col = layout.column(align=True)
        col.operator("mesh.pro_char_select_asymmetrical", icon='RESTRICT_SELECT_OFF')
        col.operator("object.pro_char_report_symmetry", icon='TEXT')

        layout.label(text="Fix:")
        col = layout.column(align=True)
        col.operator("object.pro_char_symmetrize_positive_x")
        col.operator("object.pro_char_symmetrize_negative_x")
        col.operator("mesh.pro_char_snap_to_symmetry_plane", icon='SNAP_ON')
        col.operator("object.pro_char_add_mirror_safe", icon='MOD_MIRROR')
        col.operator("object.pro_char_apply_mirror_safe", icon='CHECKMARK')
        col.operator("object.pro_char_create_symmetry_plane", icon='MESH_PLANE')


class VIEW3D_PT_pro_toolkit_charpro_retopo(_ProSubPanel, bpy.types.Panel):
    bl_label = "Retopo Setup"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_retopo"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        layout.prop(props, "retopo_target_object")
        col = layout.column(align=True)
        col.prop(props, "retopo_shrinkwrap_offset")
        col.prop(props, "retopo_patch_size")
        row = col.row(align=True)
        row.prop(props, "retopo_use_mirror", text="Mirror X")
        row.prop(props, "retopo_display_xray", text="Src X-Ray")

        layout.operator("object.pro_retopo_create_setup", icon='MOD_SHRINKWRAP')
        col = layout.column(align=True)
        row = col.row(align=True)
        row.operator("object.pro_retopo_create_plane", text="Plane")
        row.operator("object.pro_retopo_create_strip", text="Strip")
        row.operator("object.pro_retopo_create_patch", text="Patch")
        col.operator("object.pro_retopo_create_mesh")
        col.operator("object.pro_retopo_add_shrinkwrap", icon='MOD_SHRINKWRAP')
        col.operator("object.pro_retopo_add_mirror_stack", icon='MOD_MIRROR')
        col.operator("object.pro_retopo_create_material", icon='MATERIAL')
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_retopo_xray_view", icon='XRAY')
        col.operator("object.pro_retopo_toggle_in_front", icon='FACESEL')
        row = col.row(align=True)
        row.operator("object.pro_retopo_set_retopo_display", text="Retopo Disp.")
        row.operator("object.pro_retopo_set_source_display", text="Source Disp.")
        row = col.row(align=True)
        row.operator("object.pro_retopo_lock_source", text="Lock Source")
        row.operator("object.pro_retopo_unlock_source", text="Unlock")


class VIEW3D_PT_pro_toolkit_charpro_retopo_draw(_ProSubPanel, bpy.types.Panel):
    bl_label = "Retopo Drawing Helpers"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_retopo_draw"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        if context.mode != 'EDIT_MESH':
            _draw_edit_mode_warning(layout)
            return
        col = layout.column(align=True)
        col.prop(props, "retopo_relax_strength")
        col.prop(props, "retopo_project_offset")

        col = layout.column(align=True)
        row = col.row(align=True)
        row.operator("mesh.pro_retopo_add_quad_patch", text="Quad Patch")
        row.operator("mesh.pro_retopo_add_edge_strip", text="Edge Strip")
        col.operator("mesh.pro_retopo_extrude_strip", icon='MOD_ARRAY')
        row = col.row(align=True)
        row.operator("mesh.pro_retopo_bridge_edges", text="Bridge")
        row.operator("mesh.pro_retopo_fill_quad", text="Fill Quad")
        layout.separator()
        col = layout.column(align=True)
        col.operator("mesh.pro_retopo_project_to_surface", icon='IMPORT')
        col.operator("mesh.pro_retopo_relax", icon='MOD_SMOOTH')
        col.operator("transform.vert_slide", text="Slide Retopo Vertices",
                     icon='MOD_EDGESPLIT')
        col.operator("mesh.pro_retopo_shrinkwrap_selected", icon='SNAP_ON')
        col.operator("mesh.pro_retopo_snap_all", icon='SNAP_FACE')
        layout.label(text="Loop Guides:")
        col = layout.column(align=True)
        col.operator("mesh.pro_retopo_limb_loop_guide", text="Limb Loop")
        row = col.row(align=True)
        row.operator("mesh.pro_retopo_face_loop_guide", text="Face Loop")
        row.operator("mesh.pro_retopo_joint_loop_guide", text="Joint Loop")


class VIEW3D_PT_pro_toolkit_charpro_audit(_ProSubPanel, bpy.types.Panel):
    bl_label = "Topology Audit"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_audit"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        layout.operator("object.pro_char_topology_audit", icon='VIEWZOOM')
        layout.operator("object.pro_char_check_retopo_readiness", icon='CHECKMARK')
        layout.operator("object.pro_char_check_edge_flow", icon='IPO_EASE_IN_OUT')
        col = layout.column(align=True)
        col.prop(props, "topology_dense_threshold")
        col.prop(props, "topology_tiny_face_threshold")
        layout.label(text="Select Issues:")
        col = layout.column(align=True)
        col.operator("mesh.pro_select_ngons", text="N-Gons")
        col.operator("mesh.pro_select_tris", text="Tris")
        col.operator("mesh.pro_char_select_poles5")
        col.operator("mesh.pro_char_select_high_valence")
        col.operator("mesh.pro_select_non_manifold", text="Non-Manifold")
        col.operator("mesh.pro_char_select_dense_areas")
        col.operator("mesh.pro_char_select_thin_faces")
        col.operator("mesh.pro_char_select_tiny_faces")
        col.operator("mesh.pro_char_select_boundary_holes")
        col.operator("mesh.pro_char_select_loose_parts")


class VIEW3D_PT_pro_toolkit_charpro_shapes(_ProSubPanel, bpy.types.Panel):
    bl_label = "Organic Shape Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_shapes"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return
        grid = layout.grid_flow(row_major=True, columns=2,
                                even_columns=True, align=True)
        for suffix, text in (("organic_blob", "Organic Blob"),
                             ("limb_guide", "Limb Guide"),
                             ("joint_guide", "Joint Guide"),
                             ("eye_socket", "Eye Socket"),
                             ("mouth_opening", "Mouth Opening"),
                             ("root_base", "Root / Vine"),
                             ("tentacle_base", "Tentacle"),
                             ("claw_base", "Claw"),
                             ("leaf_base", "Leaf"),
                             ("petal_base", "Petal")):
            grid.operator(f"object.pro_char_{suffix}", text=text)
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Bases editables, no assets finales", icon='INFO')


class VIEW3D_PT_pro_toolkit_charpro_curves(_ProSubPanel, bpy.types.Panel):
    bl_label = "Curve / Tentacle / Root Tools"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_curves"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "curve_bevel_depth")
        col.prop(props, "curve_resolution")
        col.prop(props, "curve_taper_ends")
        col = layout.column(align=True)
        for suffix, text in (("organic_curve", "Organic Curve"),
                             ("tentacle_curve", "Tentacle Curve"),
                             ("root_curve", "Root Curve"),
                             ("vine_curve", "Vine Curve"),
                             ("cable_organic_curve", "Organic Cable")):
            col.operator(f"object.pro_char_{suffix}", text=text)
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_char_convert_curve_safe", icon='MESH_DATA')
        col.operator("object.pro_char_set_curve_bevel")
        col.operator("object.pro_char_taper_curve_ends")
        col.operator("object.pro_char_curve_resolution_preset")
        if context.mode == 'EDIT_MESH':
            col.operator("mesh.pro_char_curve_along_selection", icon='CURVE_BEZCURVE')


class VIEW3D_PT_pro_toolkit_charpro_guides(_ProSubPanel, bpy.types.Panel):
    bl_label = "Character Scale & Guides"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_guides"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        layout.prop(props, "character_target_height")
        if context.mode != 'OBJECT':
            _draw_object_mode_warning(layout)
            return
        col = layout.column(align=True)
        col.operator("object.pro_char_human_guide", icon='ARMATURE_DATA')
        col.operator("object.pro_char_bounding_box_guide", icon='SHADING_BBOX')
        grid = layout.grid_flow(row_major=True, columns=2,
                                even_columns=True, align=True)
        for suffix, text in (("head_guide", "Head"),
                             ("shoulder_guide", "Shoulders"),
                             ("hand_guide", "Hand"),
                             ("foot_guide", "Foot"),
                             ("tpose_guide", "T-Pose"),
                             ("apose_guide", "A-Pose"),
                             ("limb_cylinder", "Limb Cyl."),
                             ("joint_marker", "Joint Mark")):
            grid.operator(f"object.pro_char_{suffix}", text=text)


class VIEW3D_PT_pro_toolkit_charpro_sculpt(_ProSubPanel, bpy.types.Panel):
    bl_label = "Sculpt Prep"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_sculpt"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        col = layout.column(align=True)
        col.prop(props, "sculpt_voxel_size")
        col.prop(props, "sculpt_create_backup")
        col = layout.column(align=True)
        col.operator("object.pro_char_prepare_sculpt_object", icon='SCULPTMODE_HLT')
        col.operator("object.pro_char_voxel_remesh_helper", icon='MOD_REMESH')
        col.operator("object.pro_char_add_multires_safe", icon='MOD_MULTIRES')
        col.operator("object.pro_char_add_corrective_smooth", icon='MOD_SMOOTH')
        col.operator("object.pro_char_smooth_shading_organic",
                     text="Apply Shade Smooth Organic")
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_char_create_sculpt_backup", icon='FILE_BACKUP')
        col.operator("object.pro_char_create_sculpt_collection", icon='OUTLINER_COLLECTION')
        col.operator("object.pro_char_set_clay_material", icon='MATERIAL')
        col.operator("object.pro_char_set_matcap_view", icon='SHADING_SOLID')


class VIEW3D_PT_pro_toolkit_charpro_gameready(_ProSubPanel, bpy.types.Panel):
    bl_label = "Game Ready Character Prep"
    bl_idname = "VIEW3D_PT_pro_toolkit_charpro_gameready"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_charpro"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a Mesh object", icon='INFO')
            return
        col = layout.column(align=True)
        col.prop(props, "character_tri_budget")
        layout.operator("object.pro_char_gameready_audit", icon='VIEWZOOM')
        col = layout.column(align=True)
        col.operator("object.pro_char_create_export_duplicate", icon='EXPORT')
        col.operator("object.pro_char_name_for_export", icon='FONT_DATA')
        col.operator("object.pro_char_create_lod_placeholders", icon='MOD_DECIM')
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="El audit escribe el informe Game Ready", icon='INFO')


# ═══════════════════════════════════════════════════════════════════════
#  v0.1.6 — MATERIAL / TEXTURE / BAKING PRO SUITE
# ═══════════════════════════════════════════════════════════════════════

class VIEW3D_PT_pro_toolkit_mtb(_ProSubPanel, bpy.types.Panel):
    bl_label = "Material / Texture / Baking Pro"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_main"

    def draw(self, context):
        props = context.scene.pro_toolkit
        row = self.layout.row()
        row.scale_y = 0.8
        low = props.bake_low_object
        high = props.bake_high_object
        row.label(text=f"Bake pair: {high.name if high else '—'} → "
                       f"{low.name if low else '—'}", icon='RENDER_STILL')


class VIEW3D_PT_pro_toolkit_mtb_audit(_ProSubPanel, bpy.types.Panel):
    bl_label = "Material Audit"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_audit"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        row = layout.row(align=True)
        row.prop(props, "mat_audit_scope", expand=True)
        col = layout.column(align=True)
        col.operator("object.pro_mat_audit", text="Audit Materials",
                     icon='VIEWZOOM').scope = props.mat_audit_scope
        if props.mat_audit_done:
            box = layout.box()
            col = box.column(align=True)
            col.scale_y = 0.8
            col.label(text=f"Total: {props.mat_audit_total} · "
                           f"Ámbito: {props.mat_audit_scoped} · "
                           f"Imágenes: {props.mat_audit_images}")
            col.label(text=f"Sin uso: {props.mat_audit_unused} · "
                           f"Duplicados: {props.mat_audit_duplicates} · "
                           f"Slots vacíos: {props.mat_audit_empty_slots}")
            col.label(text=f"Tex perdidas: {props.mat_audit_missing_tex} · "
                           f"Rutas abs: {props.mat_audit_abs_paths}")
            col.label(text=f"No-PBR: {props.mat_audit_non_pbr} · "
                           f"Pesados: {props.mat_audit_heavy}")
        layout.label(text="Find issues (selecciona afectados):")
        grid = layout.grid_flow(row_major=True, columns=2, align=True,
                                even_columns=True)
        for issue, txt in (
                ('MISSING_MATERIALS', "Missing Mats"),
                ('UNUSED', "Unused"),
                ('DUPLICATES', "Duplicates"),
                ('EMPTY_SLOTS', "Empty Slots"),
                ('NO_NODES', "No Nodes"),
                ('NO_PRINCIPLED', "No Principled"),
                ('TOO_MANY_TEXTURES', "Many Textures"),
                ('ABS_PATHS', "Abs Paths"),
                ('MISSING_IMAGES', "Missing Images"),
                ('NON_PBR', "Non-PBR"),
                ('HEAVY', "Heavy"),
                ('TEX_SIZE', "Tex Size")):
            grid.operator("object.pro_mat_find_issue", text=txt).issue = issue


class VIEW3D_PT_pro_toolkit_mtb_cleanup(_ProSubPanel, bpy.types.Panel):
    bl_label = "Material Cleanup"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_cleanup"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "mat_cleanup_create_backup")
        col.operator("object.pro_mat_backup", icon='FILE_BACKUP')
        col = layout.column(align=True)
        col.operator("object.pro_mat_remove_empty_slots", icon='X')
        col.operator("object.pro_mat_remove_unused_from_selected",
                     icon='TRASH')
        col = layout.column(align=True)
        col.operator("object.pro_mat_merge_by_name", icon='AUTOMERGE_ON')
        col.operator("object.pro_mat_merge_by_color", icon='COLOR')
        col.prop(props, "mat_merge_by_color_tolerance")
        col = layout.column(align=True)
        col.prop(props, "mat_name_prefix")
        col.operator("object.pro_mat_rename_clean", icon='FONT_DATA')
        col.operator("object.pro_mat_add_prefix")
        col.operator("object.pro_mat_pipeline_names")
        layout.separator()
        col = layout.column(align=True)
        col.operator("object.pro_mat_purge_orphans", icon='ORPHAN_DATA')
        col.operator("object.pro_mat_assign_debug", icon='ERROR')
        col.operator("object.pro_mat_assign_random_ids",
                     icon='COLORSET_02_VEC')


class VIEW3D_PT_pro_toolkit_mtb_textures(_ProSubPanel, bpy.types.Panel):
    bl_label = "Texture Manager"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_textures"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.operator("image.pro_tex_find_missing", icon='VIEWZOOM')
        if props.texture_missing_count >= 0:
            row = layout.row()
            row.scale_y = 0.8
            if props.texture_missing_count:
                row.alert = True
                row.label(text=f"{props.texture_missing_count} textura(s) "
                               "perdidas", icon='ERROR')
            else:
                row.label(text="Sin texturas perdidas", icon='CHECKMARK')
        col = layout.column(align=True)
        col.prop(props, "texture_relink_folder", text="")
        col.prop(props, "texture_make_relative")
        col.prop(props, "texture_pack_after_relink")
        col.operator("image.pro_tex_relink_folder", icon='FILE_REFRESH')
        col = layout.column(align=True)
        col.operator("image.pro_tex_make_relative", icon='FILE_FOLDER')
        col.operator("image.pro_tex_make_absolute")
        col.operator("image.pro_tex_pack_all", icon='PACKAGE')
        col.operator("image.pro_tex_unpack_all", icon='UGLYPACKAGE')
        col.operator("image.pro_tex_delete_unused", icon='TRASH')
        layout.separator()
        col = layout.column(align=True)
        col.prop(props, "texture_max_size_warning")
        col.prop(props, "texture_report_missing_only")
        col.operator("image.pro_tex_report", icon='TEXT')


class VIEW3D_PT_pro_toolkit_mtb_pbr(_ProSubPanel, bpy.types.Panel):
    bl_label = "PBR Material Builder"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_pbr"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "pbr_base_color")
        col.prop(props, "pbr_roughness")
        col.prop(props, "pbr_metallic")
        col.prop(props, "pbr_alpha")
        col = layout.column(align=True)
        col.operator("material.pro_pbr_create", icon='MATERIAL')
        col.operator("material.pro_pbr_from_folder", icon='FILE_FOLDER')
        layout.separator()
        col = layout.column(align=True)
        col.prop(props, "pbr_create_copy")
        col.operator("material.pro_pbr_convert_active", icon='SHADERFX')
        col.operator("material.pro_pbr_convert_selected")
        col = layout.column(align=True)
        col.operator("material.pro_pbr_connect_maps", icon='NODETREE')
        col.operator("material.pro_pbr_create_missing_inputs", icon='ADD')


class VIEW3D_PT_pro_toolkit_mtb_procedural(_ProSubPanel, bpy.types.Panel):
    bl_label = "Procedural Materials"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_procedural"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "procedural_material_preset", text="")
        col.prop(props, "procedural_replace_slots")
        col = layout.column(align=True)
        op = col.operator("material.pro_proc_create", icon='NODE_MATERIAL')
        op.preset = props.procedural_material_preset
        col.operator("material.pro_proc_apply", icon='CHECKMARK')
        layout.separator()
        layout.operator("material.pro_proc_create_all_sf",
                        icon='OUTLINER_COLLECTION')


class VIEW3D_PT_pro_toolkit_mtb_atlas(_ProSubPanel, bpy.types.Panel):
    bl_label = "Texture Atlas / UV Check"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_atlas"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.operator("object.pro_tex_atlas_check", icon='VIEWZOOM')
        if props.texture_atlas_risks >= 0:
            row = layout.row()
            row.scale_y = 0.8
            if props.texture_atlas_risks:
                row.alert = True
                row.label(text=f"{props.texture_atlas_risks} riesgo(s) "
                               "de atlas", icon='ERROR')
            else:
                row.label(text="Atlas check OK", icon='CHECKMARK')
        col = layout.column(align=True)
        col.operator("object.pro_tex_atlas_report", icon='TEXT')
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="UV Suite tiene el audit UV completo", icon='INFO')


class VIEW3D_PT_pro_toolkit_mtb_bake_setup(_ProSubPanel, bpy.types.Panel):
    bl_label = "Baking Setup"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_bake_setup"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "bake_resolution")
        col.prop(props, "bake_margin")
        col.prop(props, "bake_image_prefix")
        col.prop(props, "bake_output_folder", text="")
        col = layout.column(align=True)
        col.operator("object.pro_bake_create_collections",
                     icon='OUTLINER_COLLECTION')
        row = col.row(align=True)
        row.operator("object.pro_bake_set_high", text="Set High")
        row.operator("object.pro_bake_set_low", text="Set Low")
        col = layout.column(align=True)
        col.prop(props, "bake_use_cage")
        col.prop(props, "bake_cage_extrusion")
        col.operator("object.pro_bake_create_cage", icon='MESH_GRID')
        col = layout.column(align=True)
        col.prop(props, "bake_map_type")
        col.operator("object.pro_bake_create_target_image", icon='IMAGE_DATA')
        col.operator("object.pro_bake_create_image_set")
        col.operator("object.pro_bake_assign_images", icon='NODETREE')
        col = layout.column(align=True)
        col.operator("object.pro_bake_prepare_selected", icon='CHECKMARK')
        col.operator("object.pro_bake_clear_setup", icon='X')


class VIEW3D_PT_pro_toolkit_mtb_bake_maps(_ProSubPanel, bpy.types.Panel):
    bl_label = "Bake Maps"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_bake_maps"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "bake_selected_to_active")
        grid = layout.grid_flow(row_major=True, columns=2, align=True,
                                even_columns=True)
        grid.operator("object.pro_bake_normal", text="Normal")
        grid.operator("object.pro_bake_ao", text="AO")
        grid.operator("object.pro_bake_diffuse", text="Diffuse")
        grid.operator("object.pro_bake_roughness", text="Roughness")
        grid.operator("object.pro_bake_emission", text="Emission")
        grid.operator("object.pro_bake_color_id", text="Color ID")
        grid.operator("object.pro_bake_combined", text="Combined")
        layout.operator("object.pro_bake_selected_maps",
                        icon='RENDERLAYERS')
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Cycles se activa y restaura solo", icon='INFO')


class VIEW3D_PT_pro_toolkit_mtb_highlow(_ProSubPanel, bpy.types.Panel):
    bl_label = "High to Low Bake"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_highlow"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "bake_low_object")
        col.prop(props, "bake_high_object")
        col.prop(props, "bake_cage_object")
        col = layout.column(align=True)
        col.operator("object.pro_hl_create_setup", icon='OUTLINER')
        col.operator("object.pro_hl_pair_by_name", icon='LINKED')
        col.operator("object.pro_hl_pair_selected_to_active")
        col.operator("object.pro_hl_validate", icon='CHECKMARK')
        col = layout.column(align=True)
        col.operator("object.pro_hl_transfer_material_ids",
                     icon='COLORSET_02_VEC')
        col.operator("object.pro_bake_create_image_set", icon='IMAGE_DATA')
        col = layout.column(align=True)
        col.operator("object.pro_hl_bake_normal", icon='NORMALS_FACE')
        col.operator("object.pro_hl_bake_ao")
        col.operator("object.pro_hl_bake_color_id")
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Convención: Obj_high / Obj_low / Obj_cage",
                  icon='INFO')


class VIEW3D_PT_pro_toolkit_mtb_unity(_ProSubPanel, bpy.types.Panel):
    bl_label = "Unity / Game Material Prep"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_unity"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        props = context.scene.pro_toolkit
        col = layout.column(align=True)
        col.prop(props, "unity_max_texture_size")
        col.prop(props, "unity_max_materials_per_object")
        col.prop(props, "unity_require_pbr")
        col = layout.column(align=True)
        col.operator("object.pro_unity_audit", icon='VIEWZOOM')
        col.operator("object.pro_unity_readiness", icon='CHECKMARK')
        if props.unity_audit_done:
            row = layout.row()
            row.scale_y = 0.8
            if props.unity_audit_issues:
                row.alert = True
                row.label(text=f"{props.unity_audit_issues} problema(s)",
                          icon='ERROR')
            else:
                row.label(text="Sin problemas", icon='CHECKMARK')
        col = layout.column(align=True)
        col.operator("object.pro_unity_convert_game_friendly",
                     icon='SHADERFX')
        col.operator("object.pro_unity_export_duplicate", icon='DUPLICATE')
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Export real a Unity: v0.1.8", icon='INFO')


class VIEW3D_PT_pro_toolkit_mtb_reports(_ProSubPanel, bpy.types.Panel):
    bl_label = "Material Reports"
    bl_idname = "VIEW3D_PT_pro_toolkit_mtb_reports"
    bl_parent_id = "VIEW3D_PT_pro_toolkit_mtb"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("object.pro_mat_audit_report", icon='TEXT',
                     text="Material Audit Report")
        col.operator("image.pro_tex_report", text="Texture Report")
        col.operator("object.pro_tex_atlas_report",
                     text="Atlas / UV Report")
        col.operator("object.pro_bake_report", text="Bake Report")
        col.operator("object.pro_colorid_report", text="Material ID Report")
        col.operator("object.pro_unity_report", text="Unity Report")
        row = layout.row()
        row.scale_y = 0.7
        row.label(text="Los .md se escriben junto al .blend", icon='INFO')
