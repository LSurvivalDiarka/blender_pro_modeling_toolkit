# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  character_utils.py
# v0.1.5 Character / Organic / Retopo Pro Suite: shared helpers.
# Collections, simple viewport materials, safety backups, organic
# topology statistics (poles, density, islands, tiny faces) and the
# report writer used by all character/retopo audits.
# ──────────────────────────────────────────────────────────────────────

import os
import tempfile

import bpy
import bmesh
from mathutils import Vector

from . import creation_utils as cu

# ═══════════════════════════════════════════════════════════════════════
#  COLLECTIONS
# ═══════════════════════════════════════════════════════════════════════

COLL_CHARACTER = "PRO_Character"
COLL_ORGANIC = "PRO_Organic"
COLL_RETOPO = "PRO_Retopo"
COLL_AI_SOURCE = "PRO_AI_Source"
COLL_CURVES = "PRO_Organic_Curves"
COLL_GUIDES = "PRO_Character_Guides"
COLL_SCULPT_BACKUPS = "PRO_Sculpt_Backups"
COLL_GAMEREADY = "PRO_GameReady_Character"


def get_coll(context, name):
    """Get-or-create a top-level character suite collection."""
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
    if name not in context.scene.collection.children:
        try:
            context.scene.collection.children.link(coll)
        except RuntimeError:
            pass
    return coll


def link_to_coll(context, obj, name):
    coll = get_coll(context, name)
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)
    return coll


# ═══════════════════════════════════════════════════════════════════════
#  SIMPLE MATERIALS (no textures, light shaders, never touch user mats)
# ═══════════════════════════════════════════════════════════════════════

# name: (RGBA, roughness, alpha)
CHAR_MATERIALS = {
    "PRO_Retopo_Blue":    ((0.10, 0.35, 0.90, 1.0), 0.6, 0.55),
    "PRO_Retopo_Green":   ((0.10, 0.80, 0.35, 1.0), 0.6, 0.55),
    "PRO_Source_XRay":    ((0.70, 0.70, 0.72, 1.0), 0.8, 0.30),
    "PRO_Source_Ghost":   ((0.55, 0.58, 0.65, 1.0), 0.9, 0.15),
    "PRO_Organic_Clay":   ((0.60, 0.42, 0.34, 1.0), 0.85, 1.0),
    "PRO_Symmetry_Red":   ((0.90, 0.12, 0.12, 1.0), 0.7, 0.35),
    "PRO_Symmetry_Blue":  ((0.12, 0.30, 0.90, 1.0), 0.7, 0.35),
    "PRO_Guide_Yellow":   ((0.95, 0.80, 0.10, 1.0), 0.7, 1.0),
    "PRO_Curve_Root":     ((0.35, 0.24, 0.15, 1.0), 0.85, 1.0),
    "PRO_Curve_Tentacle": ((0.45, 0.20, 0.45, 1.0), 0.65, 1.0),
}


def get_char_material(name):
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    color, rough, alpha = CHAR_MATERIALS.get(
        name, ((0.7, 0.7, 0.7, 1.0), 0.7, 1.0))
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Roughness"].default_value = rough
        if alpha < 1.0:
            bsdf.inputs["Alpha"].default_value = alpha
    mat.diffuse_color = (color[0], color[1], color[2], alpha)
    if alpha < 1.0:
        if hasattr(mat, "blend_method"):
            mat.blend_method = 'BLEND'
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = 'BLENDED'
        mat.show_transparent_back = False
    return mat


def assign_char_material(obj, mat_name):
    """Replace slot 0 (or append) — only used on objects this suite creates
    or when the user explicitly clicks a material button."""
    mat = get_char_material(mat_name)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    return mat


def save_materials(obj):
    """Remember object's material names once (for X-Ray override restore)."""
    import json
    if "pro_char_saved_mats" not in obj:
        obj["pro_char_saved_mats"] = json.dumps(
            [s.material.name if s.material else "" for s in obj.material_slots])


def restore_materials(obj):
    import json
    if "pro_char_saved_mats" not in obj:
        return False
    names = json.loads(obj["pro_char_saved_mats"])
    obj.data.materials.clear()
    for n in names:
        obj.data.materials.append(bpy.data.materials.get(n) if n else None)
    del obj["pro_char_saved_mats"]
    return True


# ═══════════════════════════════════════════════════════════════════════
#  BACKUPS
# ═══════════════════════════════════════════════════════════════════════

def backup_object(context, obj, suffix="_backup"):
    """Hidden copy of obj (+mesh) inside PRO_Sculpt_Backups. Returns copy."""
    coll = get_coll(context, COLL_SCULPT_BACKUPS)
    dup = obj.copy()
    dup.data = obj.data.copy()
    dup.name = f"{obj.name}{suffix}"
    coll.objects.link(dup)
    dup.hide_set(True)
    dup.hide_render = True
    coll.hide_viewport = True
    coll.hide_render = True
    return dup


# ═══════════════════════════════════════════════════════════════════════
#  ORGANIC TOPOLOGY STATISTICS
# ═══════════════════════════════════════════════════════════════════════

def open_bm(obj):
    """(bm, owned). Edit-mode aware."""
    if obj.mode == 'EDIT':
        return bmesh.from_edit_mesh(obj.data), False
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    return bm, True


def close_bm(obj, bm, owned, write=False):
    if owned:
        if write:
            bm.to_mesh(obj.data)
            obj.data.update()
        bm.free()
    else:
        bmesh.update_edit_mesh(obj.data)


def vert_islands(bm):
    """Connected components of verts. Returns list of sets of vert indices."""
    bm.verts.ensure_lookup_table()
    seen = set()
    islands = []
    for v in bm.verts:
        if v.index in seen:
            continue
        stack = [v]
        seen.add(v.index)
        comp = {v.index}
        while stack:
            cur = stack.pop()
            for e in cur.link_edges:
                o = e.other_vert(cur)
                if o.index not in seen:
                    seen.add(o.index)
                    comp.add(o.index)
                    stack.append(o)
        islands.append(comp)
    return islands


def mesh_stats(obj, dense_factor=0.35, tiny_factor=0.02):
    """Full organic-topology stats dict for *obj* (object or edit mode).
    'dense_verts' and 'tiny_faces' are threshold-based approximations
    relative to the mesh's own averages (documented as estimated)."""
    bm, owned = open_bm(obj)
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        n_tris = sum(1 for f in bm.faces if len(f.verts) == 3)
        n_quads = sum(1 for f in bm.faces if len(f.verts) == 4)
        n_ngons = sum(1 for f in bm.faces if len(f.verts) > 4)
        poles5 = sum(1 for v in bm.verts if len(v.link_edges) >= 5)
        high_valence = sum(1 for v in bm.verts if len(v.link_edges) >= 6)
        non_manifold = sum(1 for e in bm.edges if not e.is_manifold)
        boundary = sum(1 for e in bm.edges if e.is_boundary)
        loose_verts = sum(1 for v in bm.verts if not v.link_edges)

        areas = [f.calc_area() for f in bm.faces]
        avg_area = (sum(areas) / len(areas)) if areas else 0.0
        tiny_faces = (sum(1 for a in areas if a < avg_area * tiny_factor)
                      if avg_area > 0 else 0)

        edge_lens = [e.calc_length() for e in bm.edges]
        avg_edge = (sum(edge_lens) / len(edge_lens)) if edge_lens else 0.0
        dense_verts = 0
        if avg_edge > 0:
            thr = avg_edge * dense_factor
            for v in bm.verts:
                if v.link_edges and (sum(e.calc_length() for e in v.link_edges)
                                     / len(v.link_edges)) < thr:
                    dense_verts += 1

        islands = vert_islands(bm)
        biggest = max((len(i) for i in islands), default=0)
        tiny_islands = sum(1 for i in islands
                           if len(i) < max(8, biggest * 0.005))

        return {
            "verts": len(bm.verts), "edges": len(bm.edges),
            "faces": len(bm.faces),
            "tris": n_tris, "quads": n_quads, "ngons": n_ngons,
            "poles5": poles5, "high_valence": high_valence,
            "non_manifold": non_manifold, "boundary_edges": boundary,
            "loose_verts": loose_verts,
            "islands": len(islands), "tiny_islands": tiny_islands,
            "avg_face_area": avg_area, "tiny_faces": tiny_faces,
            "avg_edge_len": avg_edge, "dense_verts": dense_verts,
        }
    finally:
        if owned:
            bm.free()
        # edit-mode bmesh stays owned by Blender — nothing to free


def approx_tri_count(obj):
    return sum(max(len(p.vertices) - 2, 0) for p in obj.data.polygons)


# ═══════════════════════════════════════════════════════════════════════
#  REPORT WRITER
# ═══════════════════════════════════════════════════════════════════════

def write_report(filename, lines):
    """Write a markdown report next to the .blend (or temp dir).
    Returns the path."""
    base = bpy.path.abspath("//") if bpy.data.is_saved else tempfile.gettempdir()
    path = os.path.join(base, filename)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def object_mode_poll(context):
    return (context.mode == 'OBJECT'
            and context.active_object is not None
            and context.active_object.type == 'MESH')


def edit_mesh_poll(context):
    return context.mode == 'EDIT_MESH' and context.edit_object is not None
