# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_creation_sf_presets.py
# v0.1.3 Pro Modeling Creation Suite: Supermarket Flower presets.
# One-click real-scale bases for building the supermarket fast. Each
# preset reuses a generic creation operator (or a small custom build),
# then renames the result, files it into PRO_Supermarket_Flower and
# assigns the matching SF blockout material.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu
from . import ops_creation_transform


# preset id: (button label, SF object name, SF material)
SF_PRESETS = {
    'SF_WALL':         ("SF Wall Module", "SF_Wall_Module_3m", "SF_Blockout_Wall"),
    'SF_FLOOR':        ("SF Floor Module", "SF_Floor_Module_4m", "SF_Blockout_Floor"),
    'SF_DOOR_FRAME':   ("SF Door Frame", "SF_Door_Frame", "SF_Blockout_Wall"),
    'SF_WINDOW_FRAME': ("SF Window Frame", "SF_Window_Frame", "SF_Blockout_Glass"),
    'SF_SHELF':        ("SF Shelf Blockout", "SF_Shelf_Blockout", "SF_Blockout_Prop"),
    'SF_CHECKOUT':     ("SF Checkout Counter", "SF_Checkout_Counter", "SF_Blockout_Prop"),
    'SF_FRIDGE':       ("SF Fridge Blockout", "SF_Fridge_Blockout", "SF_Blockout_Metal"),
    'SF_FREEZER':      ("SF Freezer Chest", "SF_Freezer_Chest", "SF_Blockout_Metal"),
    'SF_PRODUCT_BOX':  ("SF Product Box", "SF_Product_Box", "SF_Blockout_Product"),
    'SF_PRODUCT_CAN':  ("SF Product Can", "SF_Product_Can", "SF_Blockout_Product"),
    'SF_PRODUCT_BOTTLE': ("SF Product Bottle", "SF_Product_Bottle", "SF_Blockout_Product"),
    'SF_PRICE_TAG':    ("SF Price Tag", "SF_Price_Tag", "SF_Blockout_Product"),
    'SF_AISLE_HELPER': ("SF Aisle Width Helper", "SF_Aisle_Width_Helper", "PRO_Blockout_Yellow"),
    'SF_PLAYER_REF':   ("SF Player Scale Reference", "SF_Player_Reference", "PRO_Blockout_Green"),
    'SF_PARKING_LINE': ("SF Parking Line Helper", "SF_Parking_Line_Helper", "PRO_Blockout_Yellow"),
    'SF_ENTRANCE':     ("SF Store Entrance Blockout", "SF_Store_Entrance_Blockout", "SF_Blockout_Wall"),
}

_ENUM_ITEMS = [(k, v[0], "") for k, v in SF_PRESETS.items()]


class OBJECT_OT_pro_sf_preset(bpy.types.Operator):
    """Create a Supermarket Flower blockout preset at real-world scale"""
    bl_idname = "object.pro_sf_preset"
    bl_label = "SF Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(name="Preset", items=_ENUM_ITEMS,
                                   default='SF_WALL')

    @classmethod
    def poll(cls, context):
        return cu.object_mode_poll(context)

    # ── custom builds for SF-only helpers ────────────────────────────
    def _build_custom(self, context, bm):
        p = self.preset
        if p == 'SF_AISLE_HELPER':
            # 1.20 m minimum walkway footprint, slightly above the floor
            cu.add_plane(bm, 1.2, 4.0, z=0.002)
        elif p == 'SF_PARKING_LINE':
            cu.add_plane(bm, 0.12, 5.0, z=0.002)
        elif p == 'SF_PLAYER_REF':
            ops_creation_transform.build_player_reference(bm, 1.78)
        elif p == 'SF_ENTRANCE':
            # Wide double-door entrance: 2.40 m opening, side posts + header
            w, h, d, f = 2.4, 2.4, 0.2, 0.15
            cu.add_box(bm, f, d, h, cx=-(w + f) / 2.0)
            cu.add_box(bm, f, d, h, cx=(w + f) / 2.0)
            cu.add_box(bm, w + 2 * f, d, f, z0=h)
            # Sliding door leaves (thin panels inside the opening)
            cu.add_box(bm, w / 2.0 - 0.02, 0.04, h - 0.05, cx=-w / 4.0)
            cu.add_box(bm, w / 2.0 - 0.02, 0.04, h - 0.05, cx=w / 4.0)
        else:
            return False
        return True

    def execute(self, context):
        label, sf_name, sf_mat = SF_PRESETS[self.preset]

        # 1. Custom SF-only geometry
        bm = bmesh.new()
        if self._build_custom(context, bm):
            obj = cu.finalize_new_object(context, self, sf_name, bm,
                                         cu.COLL_SUPERMARKET, sf_mat)
            if self.preset in {'SF_AISLE_HELPER', 'SF_PARKING_LINE',
                               'SF_PLAYER_REF'}:
                obj.hide_render = True
            return {'FINISHED'}
        bm.free()

        # 2. Reuse the generic creation operators with SF dimensions
        ops = bpy.ops.object
        call = {
            'SF_WALL':           lambda: ops.pro_create_wall_module(),
            'SF_FLOOR':          lambda: ops.pro_create_floor_module(),
            'SF_DOOR_FRAME':     lambda: ops.pro_create_door_frame(),
            'SF_WINDOW_FRAME':   lambda: ops.pro_create_window_frame(),
            'SF_SHELF':          lambda: ops.pro_create_shelf_blockout(),
            'SF_CHECKOUT':       lambda: ops.pro_create_counter_blockout(),
            'SF_FRIDGE':         lambda: ops.pro_create_fridge_blockout(),
            'SF_FREEZER':        lambda: ops.pro_create_freezer_chest(),
            'SF_PRODUCT_BOX':    lambda: ops.pro_create_product_box(size='MEDIUM'),
            'SF_PRODUCT_CAN':    lambda: ops.pro_create_product_can(),
            'SF_PRODUCT_BOTTLE': lambda: ops.pro_create_product_bottle(),
            'SF_PRICE_TAG':      lambda: ops.pro_create_price_tag(),
        }[self.preset]
        result = call()
        if 'FINISHED' not in result:
            self.report({'ERROR'}, f"Preset '{label}' could not be created")
            return {'CANCELLED'}

        # 3. Re-brand the new active object as a Supermarket Flower asset
        obj = context.view_layer.objects.active
        obj.name = sf_name
        obj.data.name = sf_name
        cu.link_to_collection(context, obj, cu.COLL_SUPERMARKET)
        if context.scene.pro_toolkit.creation_create_material:
            cu.assign_material(obj, sf_mat)
        d = obj.dimensions
        self.report({'INFO'},
                    f"{sf_name} created ({d.x:.2f} x {d.y:.2f} x {d.z:.2f} m) "
                    f"in '{cu.COLL_SUPERMARKET}'")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_sf_preset,
)
