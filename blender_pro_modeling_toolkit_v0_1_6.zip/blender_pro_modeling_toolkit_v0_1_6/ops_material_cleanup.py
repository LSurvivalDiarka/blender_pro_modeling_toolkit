# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_material_cleanup.py
# v0.1.6 — Material Cleanup: slots, unused, duplicates, renaming,
# safe purge, debug / random ID assignment.
#
# RULES:
#   - used materials are never deleted without confirmation,
#   - hard cleanups create _MATBAK backups first (option),
#   - face assignments are never changed except by explicit operators.
# ──────────────────────────────────────────────────────────────────────

import random

import bpy

from . import material_utils as mu


def _maybe_backup(context, mats):
    if not context.scene.pro_toolkit.mat_cleanup_create_backup:
        return 0
    n = 0
    for m in mats:
        if not mu.is_backup_material(m):
            mu.backup_material(m)
            n += 1
    return n


class OBJECT_OT_pro_mat_backup(bpy.types.Operator):
    """Create _MATBAK fake-user copies of every material on the selected
    objects (survives saving; restore manually from the blend data)"""
    bl_idname = "object.pro_mat_backup"
    bl_label = "Backup Materials"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        mats = {s.material for o in mu.scope_objects(context, 'SELECTED')
                for s in o.material_slots if s.material}
        n = 0
        for m in mats:
            if not mu.is_backup_material(m):
                mu.backup_material(m)
                n += 1
        self.report({'INFO'}, f"{n} backup(s) de material creados (_MATBAK).")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_remove_empty_slots(bpy.types.Operator):
    """Remove empty material slots from the selected objects
    (face assignments of remaining slots are preserved by Blender)"""
    bl_idname = "object.pro_mat_remove_empty_slots"
    bl_label = "Remove Empty Material Slots"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        removed = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            if obj.data.users > 1:
                self.report({'WARNING'},
                            f"'{obj.name}': malla multiusuario — omitido.")
                continue
            with context.temp_override(object=obj, active_object=obj):
                for i in range(len(obj.material_slots) - 1, -1, -1):
                    if obj.material_slots[i].material is None:
                        obj.active_material_index = i
                        bpy.ops.object.material_slot_remove()
                        removed += 1
        self.report({'INFO'}, f"{removed} slot(s) vacíos eliminados.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_remove_unused_from_selected(bpy.types.Operator):
    """Remove material slots whose material is not assigned to any face
    of the selected objects (uses Blender's safe slot remove)"""
    bl_idname = "object.pro_mat_remove_unused_from_selected"
    bl_label = "Remove Unused Slots From Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        before = sum(len(o.material_slots)
                     for o in mu.scope_objects(context, 'SELECTED'))
        with context.temp_override(
                selected_objects=mu.scope_objects(context, 'SELECTED')):
            bpy.ops.object.material_slot_remove_unused()
        after = sum(len(o.material_slots)
                    for o in mu.scope_objects(context, 'SELECTED'))
        self.report({'INFO'}, f"{before - after} slot(s) sin uso eliminados.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_merge_by_name(bpy.types.Operator):
    """Merge Mat / Mat.001 / Mat.002 duplicates: every slot is repointed
    to the base material; the duplicates are NOT deleted (purge after)"""
    bl_idname = "object.pro_mat_merge_by_name"
    bl_label = "Merge Duplicates by Name"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        groups = mu.duplicate_groups_by_name()
        if not groups:
            self.report({'INFO'}, "No hay duplicados por nombre.")
            return {'CANCELLED'}
        _maybe_backup(context, [m for g in groups.values() for m in g[:1]])
        slots = merged = 0
        for _base, mats in groups.items():
            keep = mats[0]
            for dup in mats[1:]:
                slots += mu.remap_material(dup, keep)
                merged += 1
        self.report({'INFO'},
                    f"{merged} duplicado(s) fusionados en {len(groups)} "
                    f"grupo(s); {slots} slot(s) reasignados. Los duplicados "
                    "siguen en el archivo (usa Purge Orphan Materials).")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_merge_by_color(bpy.types.Operator):
    """Merge materials whose base color matches within the tolerance and
    that use the same image set (conservative); slots are repointed"""
    bl_idname = "object.pro_mat_merge_by_color"
    bl_label = "Merge Duplicates by Color"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        tol = context.scene.pro_toolkit.mat_merge_by_color_tolerance
        groups = mu.duplicate_groups_by_color(tol)
        if not groups:
            self.report({'INFO'}, f"No hay duplicados por color (tol {tol}).")
            return {'CANCELLED'}
        _maybe_backup(context, [g[0] for g in groups])
        slots = merged = 0
        for mats in groups:
            keep = sorted(mats, key=lambda m: m.name)[0]
            for dup in mats:
                if dup is keep:
                    continue
                slots += mu.remap_material(dup, keep)
                merged += 1
        self.report({'INFO'},
                    f"{merged} material(es) fusionados por color en "
                    f"{len(groups)} grupo(s); {slots} slot(s) reasignados.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_rename_clean(bpy.types.Operator):
    """Clean the names of the materials on the selected objects:
    spaces/symbols to underscores, numeric suffixes dropped"""
    bl_idname = "object.pro_mat_rename_clean"
    bl_label = "Rename Materials Clean"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        mats = {s.material for o in mu.scope_objects(context, 'SELECTED')
                for s in o.material_slots if s.material}
        n = 0
        for m in mats:
            if mu.is_backup_material(m):
                continue
            new = mu.clean_name_token(m.name)
            if new != m.name and bpy.data.materials.get(new) is None:
                m.name = new
                n += 1
        self.report({'INFO'}, f"{n} material(es) renombrados.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_add_prefix(bpy.types.Operator):
    """Add the panel prefix to the materials of the selected objects
    (skips materials that already have it)"""
    bl_idname = "object.pro_mat_add_prefix"
    bl_label = "Add Prefix to Materials"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        prefix = context.scene.pro_toolkit.mat_name_prefix
        mats = {s.material for o in mu.scope_objects(context, 'SELECTED')
                for s in o.material_slots if s.material}
        n = 0
        for m in mats:
            if mu.is_backup_material(m) or m.name.startswith(prefix):
                continue
            m.name = f"{prefix}{m.name}"
            n += 1
        self.report({'INFO'}, f"{n} material(es) con prefijo '{prefix}'.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_pipeline_names(bpy.types.Operator):
    """Convert material names to pipeline format: MAT_Token_Token_A"""
    bl_idname = "object.pro_mat_pipeline_names"
    bl_label = "Convert Names to Pipeline Format"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        prefix = context.scene.pro_toolkit.mat_name_prefix or "MAT_"
        mats = {s.material for o in mu.scope_objects(context, 'SELECTED')
                for s in o.material_slots if s.material}
        n = 0
        for m in sorted(mats, key=lambda m: m.name):
            if mu.is_backup_material(m):
                continue
            target = mu.pipeline_name(m.name, prefix)
            if m.name == target:
                continue
            variant = "A"
            while bpy.data.materials.get(target) is not None:
                variant = chr(ord(variant) + 1)
                if variant > "Z":
                    break
                target = mu.pipeline_name(m.name, prefix, variant)
            if bpy.data.materials.get(target) is None:
                m.name = target
                n += 1
        self.report({'INFO'}, f"{n} material(es) en formato pipeline.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_purge_orphans(bpy.types.Operator):
    """Delete materials with zero users and no fake user (asks for
    confirmation; backups _MATBAK are never purged)"""
    bl_idname = "object.pro_mat_purge_orphans"
    bl_label = "Purge Orphan Materials Safe"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        self._victims = [m for m in bpy.data.materials
                         if m.users == 0 and not m.use_fake_user
                         and not mu.is_backup_material(m)]
        if not self._victims:
            self.report({'INFO'}, "No hay materiales huérfanos.")
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        victims = getattr(self, "_victims", None)
        if victims is None:
            victims = [m for m in bpy.data.materials
                       if m.users == 0 and not m.use_fake_user
                       and not mu.is_backup_material(m)]
        n = len(victims)
        for m in victims:
            bpy.data.materials.remove(m)
        self.report({'INFO'}, f"{n} material(es) huérfanos eliminados.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_assign_debug(bpy.types.Operator):
    """Assign the magenta PRO_Bake_Debug material to the selected objects
    (originals are backed up as _MATBAK and restorable via Color ID Restore)"""
    bl_idname = "object.pro_mat_assign_debug"
    bl_label = "Assign Debug Material"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        from . import ops_baking
        ops_baking.store_original_assignments(
            context, mu.scope_objects(context, 'SELECTED'))
        mat = mu.build_id_material("PRO_Bake_Debug", (1.0, 0.0, 0.8, 1.0))
        n = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            obj.data.materials.clear()
            obj.data.materials.append(mat)
            n += 1
        self.report({'INFO'},
                    f"Debug material asignado a {n} objeto(s). Restaurable "
                    "con Restore Original Materials.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_assign_random_ids(bpy.types.Operator):
    """Assign a random flat ID material per selected object (originals
    stored; restorable with Restore Original Materials)"""
    bl_idname = "object.pro_mat_assign_random_ids"
    bl_label = "Assign Random ID Materials"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        from . import ops_baking
        objs = mu.scope_objects(context, 'SELECTED')
        ops_baking.store_original_assignments(context, objs)
        rng = random.Random(4711)
        order = list(range(len(objs)))
        rng.shuffle(order)
        for obj, idx in zip(objs, order):
            color = mu.distinct_color(idx)
            mat = mu.build_id_material(f"PRO_ID_{obj.name}", color)
            obj.data.materials.clear()
            obj.data.materials.append(mat)
        self.report({'INFO'},
                    f"ID aleatorio asignado a {len(objs)} objeto(s). "
                    "Restaurable con Restore Original Materials.")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_mat_backup,
    OBJECT_OT_pro_mat_remove_empty_slots,
    OBJECT_OT_pro_mat_remove_unused_from_selected,
    OBJECT_OT_pro_mat_merge_by_name,
    OBJECT_OT_pro_mat_merge_by_color,
    OBJECT_OT_pro_mat_rename_clean,
    OBJECT_OT_pro_mat_add_prefix,
    OBJECT_OT_pro_mat_pipeline_names,
    OBJECT_OT_pro_mat_purge_orphans,
    OBJECT_OT_pro_mat_assign_debug,
    OBJECT_OT_pro_mat_assign_random_ids,
)
