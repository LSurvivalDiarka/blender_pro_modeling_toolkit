# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_uv_audit.py
# Pro UV Suite: Texel Density, UV Audit / Repair, UV Checker materials
#
# Honesty rule: overlap detection is approximate (island bounding boxes)
# and is labelled "estimated" everywhere. Flipped and zero-area counts
# are exact (signed UV area per face).
# ──────────────────────────────────────────────────────────────────────

import json
import math
import os
import tempfile

import bpy
import bmesh
from mathutils import Vector

from . import uv_utils
from . import node_utils

SAVED_MATS_PROP = "pro_uv_saved_mats"


# ═══════════════════════════════════════════════════════════════════════
#  POLL MIXINS / HELPERS
# ═══════════════════════════════════════════════════════════════════════

class _MeshObjectOp:
    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')


class _EditMeshOp:
    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and context.edit_object is not None


def _open_bm(obj):
    """Return (bm, owned). owned=True means caller must free / write back."""
    if obj.mode == 'EDIT':
        return bmesh.from_edit_mesh(obj.data), False
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    return bm, True


def _close_bm(obj, bm, owned, write=False):
    if owned:
        if write:
            bm.to_mesh(obj.data)
            obj.data.update()
        bm.free()
    else:
        bmesh.update_edit_mesh(obj.data)


# ═══════════════════════════════════════════════════════════════════════
#  TEXEL DENSITY
# ═══════════════════════════════════════════════════════════════════════

def _density_faces(context, obj, bm):
    """Faces to operate on: selected in edit mode, all otherwise."""
    if obj.mode == 'EDIT':
        faces = [f for f in bm.faces if f.select]
        return faces if faces else list(bm.faces)
    return list(bm.faces)


class OBJECT_OT_pro_uv_calculate_texel_density(_MeshObjectOp, bpy.types.Operator):
    """Calculate the texel density (px/m) of the active object"""
    bl_idname = "object.pro_uv_calculate_texel_density"
    bl_label = "Calculate"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        bm, owned = _open_bm(obj)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            _close_bm(obj, bm, owned)
            self.report({'WARNING'}, "Object has no UV map.")
            return {'CANCELLED'}
        faces = _density_faces(context, obj, bm)
        density, uv_area, w_area = uv_utils.texel_density(
            faces, uv_layer, obj.matrix_world, props.uv_texture_size)
        _close_bm(obj, bm, owned)
        props.uv_density_result = density
        self.report({'INFO'},
                    f"Texel density: {density:.1f} px/m  "
                    f"(UV area {uv_area:.4f}, 3D area {w_area:.3f} m², "
                    f"texture {props.uv_texture_size}px)")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_set_texel_density(_MeshObjectOp, bpy.types.Operator):
    """Scale UV islands to reach the target texel density"""
    bl_idname = "object.pro_uv_set_texel_density"
    bl_label = "Set Density"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        target = props.uv_target_density
        bm, owned = _open_bm(obj)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            _close_bm(obj, bm, owned)
            self.report({'WARNING'}, "Object has no UV map.")
            return {'CANCELLED'}
        faces = _density_faces(context, obj, bm)
        islands = uv_utils.uv_islands(bm, uv_layer, faces)
        done = skipped = 0
        for island in islands:
            prev = uv_utils.scale_island_density(
                island, uv_layer, obj.matrix_world, target, props.uv_texture_size)
            if prev is None:
                skipped += 1
            else:
                done += 1
        _close_bm(obj, bm, owned, write=True)
        props.uv_density_result = target
        msg = f"Set {done} islands to {target:.0f} px/m"
        if skipped:
            msg += f" ({skipped} degenerate islands skipped)"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class OBJECT_OT_pro_uv_match_texel_density(bpy.types.Operator):
    """Match selected objects' texel density to the ACTIVE object's density"""
    bl_idname = "object.pro_uv_match_texel_density"
    bl_label = "Match Active"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and context.active_object is not None
                and context.active_object.type == 'MESH'
                and len([o for o in context.selected_objects
                         if o.type == 'MESH']) >= 2)

    def execute(self, context):
        props = context.scene.pro_toolkit
        active = context.active_object

        bm, owned = _open_bm(active)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            _close_bm(active, bm, owned)
            self.report({'WARNING'}, "Active object has no UV map.")
            return {'CANCELLED'}
        target, _, _ = uv_utils.texel_density(
            list(bm.faces), uv_layer, active.matrix_world, props.uv_texture_size)
        _close_bm(active, bm, owned)
        if target <= 1e-9:
            self.report({'WARNING'}, "Active object has degenerate UVs.")
            return {'CANCELLED'}

        done = 0
        for obj in context.selected_objects:
            if obj is active or obj.type != 'MESH':
                continue
            bm, owned = _open_bm(obj)
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                _close_bm(obj, bm, owned)
                continue
            for island in uv_utils.uv_islands(bm, uv_layer, list(bm.faces)):
                uv_utils.scale_island_density(
                    island, uv_layer, obj.matrix_world, target,
                    props.uv_texture_size)
            _close_bm(obj, bm, owned, write=True)
            done += 1
        self.report({'INFO'},
                    f"Matched {done} object(s) to {target:.1f} px/m (active: {active.name})")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_normalize_texel_density(_MeshObjectOp, bpy.types.Operator):
    """Scale every island to the mesh's average density (uniform texels)"""
    bl_idname = "object.pro_uv_normalize_texel_density"
    bl_label = "Normalize"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        bm, owned = _open_bm(obj)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            _close_bm(obj, bm, owned)
            self.report({'WARNING'}, "Object has no UV map.")
            return {'CANCELLED'}
        faces = _density_faces(context, obj, bm)
        avg, _, _ = uv_utils.texel_density(
            faces, uv_layer, obj.matrix_world, props.uv_texture_size)
        if avg <= 1e-9:
            _close_bm(obj, bm, owned)
            self.report({'WARNING'}, "Mesh has degenerate UVs.")
            return {'CANCELLED'}
        islands = uv_utils.uv_islands(bm, uv_layer, faces)
        for island in islands:
            uv_utils.scale_island_density(
                island, uv_layer, obj.matrix_world, avg, props.uv_texture_size)
        _close_bm(obj, bm, owned, write=True)
        self.report({'INFO'},
                    f"Normalized {len(islands)} islands to {avg:.1f} px/m")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_show_density_report(_MeshObjectOp, bpy.types.Operator):
    """Show per-island texel density statistics"""
    bl_idname = "object.pro_uv_show_density_report"
    bl_label = "Density Report"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        bm, owned = _open_bm(obj)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            _close_bm(obj, bm, owned)
            self.report({'WARNING'}, "Object has no UV map.")
            return {'CANCELLED'}
        islands = uv_utils.uv_islands(bm, uv_layer, list(bm.faces))
        densities = []
        for island in islands:
            d, _, _ = uv_utils.texel_density(
                island, uv_layer, obj.matrix_world, props.uv_texture_size)
            if d > 1e-9:
                densities.append(d)
        _close_bm(obj, bm, owned)
        if not densities:
            self.report({'WARNING'}, "No valid islands found.")
            return {'CANCELLED'}
        avg = sum(densities) / len(densities)
        dmin, dmax = min(densities), max(densities)
        variation = (dmax / dmin) if dmin > 1e-9 else float('inf')

        lines = [f"Islands: {len(densities)}",
                 f"Average: {avg:.1f} px/m",
                 f"Min: {dmin:.1f}   Max: {dmax:.1f}",
                 f"Variation: x{variation:.2f}"]
        if variation > 1.5:
            lines.append("WARNING: density varies a lot between islands "
                         "- consider Normalize")

        if not bpy.app.background and context.window is not None:  # popup crashes headless
            def draw(menu, _context):
                for line in lines:
                    menu.layout.label(text=line)
            context.window_manager.popup_menu(draw, title="Texel Density Report",
                                              icon='INFO')
        self.report({'INFO'},
                    f"Density avg {avg:.1f} px/m, variation x{variation:.2f}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  UV AUDIT
# ═══════════════════════════════════════════════════════════════════════

def compute_uv_audit(obj, texture_size=1024):
    """Full UV audit of *obj*. Returns a dict (counts + warnings list).
    'overlaps' is ESTIMATED (island bbox intersections); flipped and
    zero-area are exact (signed face UV areas)."""
    me = obj.data
    data = {
        "object": obj.name,
        "has_uv": bool(me.uv_layers),
        "active_map": me.uv_layers.active.name if me.uv_layers else "-",
        "map_count": len(me.uv_layers),
        "faces": len(me.polygons),
        "materials": len([m for m in me.materials if m is not None]),
        "islands": 0, "overlaps_est": 0, "outside": 0,
        "zero_area": 0, "flipped": 0,
        "density": 0.0, "density_var": 0.0,
        "warnings": [],
    }
    if not me.uv_layers:
        data["warnings"].append("Object has NO UV map.")
        return data

    bm, owned = _open_bm(obj)
    uv_layer = bm.loops.layers.uv.active
    faces = list(bm.faces)

    flipped = zero = outside = 0
    eps = 1e-5
    for f in faces:
        area = uv_utils.face_uv_area_signed(f, uv_layer)
        if abs(area) < 1e-10:
            zero += 1
        elif area < 0:
            flipped += 1
        if any(l[uv_layer].uv.x < -eps or l[uv_layer].uv.x > 1 + eps
               or l[uv_layer].uv.y < -eps or l[uv_layer].uv.y > 1 + eps
               for l in f.loops):
            outside += 1

    islands = uv_utils.uv_islands(bm, uv_layer, faces)
    data["islands"] = len(islands)

    # Estimated overlap: island bounding-box intersections
    bboxes = [uv_utils.island_bbox(isl, uv_layer) for isl in islands]
    overlap_pairs = 0
    for i in range(len(bboxes)):
        amin, amax = bboxes[i]
        for j in range(i + 1, len(bboxes)):
            bmin, bmax = bboxes[j]
            if (amin.x < bmax.x - eps and amax.x > bmin.x + eps
                    and amin.y < bmax.y - eps and amax.y > bmin.y + eps):
                overlap_pairs += 1
    data["overlaps_est"] = overlap_pairs

    densities = []
    for isl in islands:
        d, _, _ = uv_utils.texel_density(isl, uv_layer, obj.matrix_world,
                                         texture_size)
        if d > 1e-9:
            densities.append(d)
    if densities:
        data["density"] = sum(densities) / len(densities)
        dmin, dmax = min(densities), max(densities)
        data["density_var"] = (dmax / dmin) if dmin > 1e-9 else 0.0

    _close_bm(obj, bm, owned)

    data["zero_area"] = zero
    data["flipped"] = flipped
    data["outside"] = outside
    w = data["warnings"]
    if flipped:
        w.append(f"{flipped} flipped UV faces (mirrored islands).")
    if zero:
        w.append(f"{zero} zero-area UV faces (unmapped or collapsed).")
    if outside:
        w.append(f"{outside} faces outside the 0-1 UV space.")
    if overlap_pairs:
        w.append(f"~{overlap_pairs} island pairs may overlap (estimated, bbox test).")
    if data["density_var"] > 1.5:
        w.append(f"Texel density varies x{data['density_var']:.2f} between islands.")
    if not w:
        w.append("No UV issues detected.")
    return data


class OBJECT_OT_pro_uv_audit(_MeshObjectOp, bpy.types.Operator):
    """Run the full UV audit on the active object"""
    bl_idname = "object.pro_uv_audit"
    bl_label = "Run UV Audit"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        data = compute_uv_audit(obj, props.uv_texture_size)

        props.uv_audit_done = True
        props.uv_audit_object = data["object"]
        props.uv_audit_has_uv = data["has_uv"]
        props.uv_audit_active_map = data["active_map"]
        props.uv_audit_map_count = data["map_count"]
        props.uv_audit_faces = data["faces"]
        props.uv_audit_materials = data["materials"]
        props.uv_audit_islands = data["islands"]
        props.uv_audit_overlaps = data["overlaps_est"]
        props.uv_audit_outside = data["outside"]
        props.uv_audit_zero_area = data["zero_area"]
        props.uv_audit_flipped = data["flipped"]
        props.uv_audit_density = data["density"]
        props.uv_audit_density_var = data["density_var"]
        props.uv_audit_warnings = " | ".join(data["warnings"])

        self.report({'INFO'},
                    f"UV audit: {data['islands']} islands, "
                    f"{data['flipped']} flipped, {data['zero_area']} zero-area, "
                    f"{data['outside']} outside 0-1, "
                    f"~{data['overlaps_est']} overlaps (estimated)")
        return {'FINISHED'}


class _UVSelectAuditOp(_EditMeshOp):
    """Base: select faces matching a UV predicate."""
    _msg = "Selected"

    def execute(self, context):
        context.tool_settings.mesh_select_mode = (False, False, True)
        bpy.ops.mesh.select_all(action='DESELECT')
        bm, me, uv_layer = uv_utils.get_uv_bmesh(context)
        count = self._select(bm, uv_layer)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"{self._msg}: {count} faces")
        return {'FINISHED'}


class MESH_OT_pro_uv_select_overlaps(_UVSelectAuditOp, bpy.types.Operator):
    """Select faces of islands whose bounds overlap (ESTIMATED, bbox test)"""
    bl_idname = "mesh.pro_uv_select_overlaps"
    bl_label = "Select Overlaps (est.)"
    bl_options = {'REGISTER', 'UNDO'}
    _msg = "Selected estimated-overlapping"

    def _select(self, bm, uv_layer):
        faces = list(bm.faces)
        islands = uv_utils.uv_islands(bm, uv_layer, faces)
        bboxes = [uv_utils.island_bbox(isl, uv_layer) for isl in islands]
        eps = 1e-5
        flagged = set()
        for i in range(len(bboxes)):
            amin, amax = bboxes[i]
            for j in range(i + 1, len(bboxes)):
                bmin, bmax = bboxes[j]
                if (amin.x < bmax.x - eps and amax.x > bmin.x + eps
                        and amin.y < bmax.y - eps and amax.y > bmin.y + eps):
                    flagged.add(i)
                    flagged.add(j)
        count = 0
        for idx in flagged:
            for f in islands[idx]:
                f.select = True
                count += 1
        return count


class MESH_OT_pro_uv_select_outside_0_1(_UVSelectAuditOp, bpy.types.Operator):
    """Select faces with UVs outside the 0-1 space"""
    bl_idname = "mesh.pro_uv_select_outside_0_1"
    bl_label = "Select Outside 0-1"
    bl_options = {'REGISTER', 'UNDO'}
    _msg = "Selected outside-0-1"

    def _select(self, bm, uv_layer):
        eps = 1e-5
        count = 0
        for f in bm.faces:
            if any(l[uv_layer].uv.x < -eps or l[uv_layer].uv.x > 1 + eps
                   or l[uv_layer].uv.y < -eps or l[uv_layer].uv.y > 1 + eps
                   for l in f.loops):
                f.select = True
                count += 1
        return count


class MESH_OT_pro_uv_select_flipped_uvs(_UVSelectAuditOp, bpy.types.Operator):
    """Select faces with flipped (mirrored) UVs — exact, signed-area test"""
    bl_idname = "mesh.pro_uv_select_flipped_uvs"
    bl_label = "Select Flipped"
    bl_options = {'REGISTER', 'UNDO'}
    _msg = "Selected flipped"

    def _select(self, bm, uv_layer):
        count = 0
        for f in bm.faces:
            if uv_utils.face_uv_area_signed(f, uv_layer) < -1e-10:
                f.select = True
                count += 1
        return count


class MESH_OT_pro_uv_select_zero_area_uvs(_UVSelectAuditOp, bpy.types.Operator):
    """Select faces whose UV area is zero (unmapped/collapsed)"""
    bl_idname = "mesh.pro_uv_select_zero_area_uvs"
    bl_label = "Select Zero Area"
    bl_options = {'REGISTER', 'UNDO'}
    _msg = "Selected zero-area"

    def _select(self, bm, uv_layer):
        count = 0
        for f in bm.faces:
            if abs(uv_utils.face_uv_area_signed(f, uv_layer)) < 1e-10:
                f.select = True
                count += 1
        return count


class MESH_OT_pro_uv_fix_outside_0_1(_EditMeshOp, bpy.types.Operator):
    """Move islands fully back into the 0-1 space (UDIM-style wrap)"""
    bl_idname = "mesh.pro_uv_fix_outside_0_1"
    bl_label = "Fix Outside 0-1"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bm, me, uv_layer = uv_utils.get_uv_bmesh(context)
        faces = list(bm.faces)
        islands = uv_utils.uv_islands(bm, uv_layer, faces)
        moved = 0
        for island in islands:
            umin, umax = uv_utils.island_bbox(island, uv_layer)
            center = (umin + umax) * 0.5
            off = Vector((math.floor(center.x), math.floor(center.y)))
            if off.length > 1e-9:
                uv_utils.transform_island(island, uv_layer,
                                          lambda uv, o=off: uv - o)
                moved += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"Moved {moved} islands back into 0-1 "
                    "(islands larger than the tile are not rescaled)")
        return {'FINISHED'}


class MESH_OT_pro_uv_fix_zero_area_uvs(_EditMeshOp, bpy.types.Operator):
    """Give zero-area UV faces a tiny valid footprint (basic repair)"""
    bl_idname = "mesh.pro_uv_fix_zero_area_uvs"
    bl_label = "Fix Zero Area"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bm, me, uv_layer = uv_utils.get_uv_bmesh(context)
        fixed = 0
        for f in bm.faces:
            if abs(uv_utils.face_uv_area_signed(f, uv_layer)) >= 1e-10:
                continue
            center = Vector((0.0, 0.0))
            for l in f.loops:
                center += l[uv_layer].uv
            center /= len(f.loops)
            n = len(f.loops)
            r = 0.002
            for i, l in enumerate(f.loops):
                ang = 2.0 * math.pi * i / n
                l[uv_layer].uv = center + Vector(
                    (r * math.cos(ang), r * math.sin(ang)))
            fixed += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"Repaired {fixed} zero-area UV faces (tiny footprint - "
                    "re-unwrap those areas for real UVs)")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_export_report(_MeshObjectOp, bpy.types.Operator):
    """Write the UV audit report to a text file next to the .blend"""
    bl_idname = "object.pro_uv_export_report"
    bl_label = "Export Report"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        data = compute_uv_audit(obj, props.uv_texture_size)

        lines = [
            f"# PRO UV Report — {data['object']}",
            "",
            f"Has UV Map: {'Yes' if data['has_uv'] else 'No'}",
            f"Active UV Map: {data['active_map']}",
            f"UV Maps Count: {data['map_count']}",
            f"Faces Count: {data['faces']}",
            f"Materials Count: {data['materials']}",
            f"UV Islands Count: {data['islands']}",
            f"Overlapping UVs: {data['overlaps_est']} island pairs (estimated)",
            f"Outside 0-1: {data['outside']} faces",
            f"Zero Area UVs: {data['zero_area']} faces",
            f"Flipped UVs: {data['flipped']} faces",
            f"Average Texel Density: {data['density']:.1f} px/m "
            f"(texture {props.uv_texture_size}px)",
            f"Density Variation: x{data['density_var']:.2f}",
            "",
            "Warnings:",
        ] + [f"- {w}" for w in data["warnings"]]

        base = bpy.path.abspath("//") if bpy.data.is_saved else tempfile.gettempdir()
        path = os.path.join(base, f"PRO_UV_Report_{obj.name}.md")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        self.report({'INFO'}, f"Report written: {path}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  UV CHECKER / PREVIEW
# ═══════════════════════════════════════════════════════════════════════

def _target_objects(context):
    objs = [o for o in context.selected_objects if o.type == 'MESH']
    active = context.active_object
    if active and active.type == 'MESH' and active not in objs:
        objs.append(active)
    return objs


def _save_materials(obj):
    """Remember the object's material names once (don't overwrite)."""
    if SAVED_MATS_PROP not in obj:
        names = [slot.material.name if slot.material else ""
                 for slot in obj.material_slots]
        obj[SAVED_MATS_PROP] = json.dumps(names)


def _apply_checker(context, kind, scale):
    mat = node_utils.build_checker_material(kind, scale)
    count = 0
    for obj in _target_objects(context):
        _save_materials(obj)
        node_utils.assign_material(obj, mat)
        count += 1
    return mat, count


class _CheckerAddOp(_MeshObjectOp):
    _kind = 'GRID'

    def execute(self, context):
        props = context.scene.pro_toolkit
        mat, count = _apply_checker(context, self._kind, props.uv_checker_scale)
        self.report({'INFO'},
                    f"Applied {mat.name} to {count} object(s) "
                    "(previous materials saved)")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_add_checker_material(_CheckerAddOp, bpy.types.Operator):
    """Apply the grid checker (saves your materials for restore)"""
    bl_idname = "object.pro_uv_add_checker_material"
    bl_label = "Checker: Grid"
    bl_options = {'REGISTER', 'UNDO'}
    _kind = 'GRID'


class OBJECT_OT_pro_uv_add_colored_checker_material(_CheckerAddOp, bpy.types.Operator):
    """Apply the colored checker (orientation + tiling readability)"""
    bl_idname = "object.pro_uv_add_colored_checker_material"
    bl_label = "Checker: Color"
    bl_options = {'REGISTER', 'UNDO'}
    _kind = 'COLOR'


class OBJECT_OT_pro_uv_add_distortion_checker_material(_CheckerAddOp, bpy.types.Operator):
    """Apply the distortion checker (diagonal stripes reveal stretching)"""
    bl_idname = "object.pro_uv_add_distortion_checker_material"
    bl_label = "Checker: Distortion"
    bl_options = {'REGISTER', 'UNDO'}
    _kind = 'DISTORTION'


class OBJECT_OT_pro_uv_remove_checker_material(_MeshObjectOp, bpy.types.Operator):
    """Remove PRO checker materials from selected objects (slots left empty)"""
    bl_idname = "object.pro_uv_remove_checker_material"
    bl_label = "Remove Checker"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        checker_names = set(node_utils.CHECKER_MATERIALS.values())
        count = 0
        for obj in _target_objects(context):
            if any(slot.material and slot.material.name in checker_names
                   for slot in obj.material_slots):
                obj.data.materials.clear()
                count += 1
        self.report({'INFO'}, f"Removed checker from {count} object(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_restore_previous_materials(_MeshObjectOp, bpy.types.Operator):
    """Restore the materials saved before the checker was applied"""
    bl_idname = "object.pro_uv_restore_previous_materials"
    bl_label = "Restore Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        restored = missing = 0
        for obj in _target_objects(context):
            if SAVED_MATS_PROP not in obj:
                continue
            names = json.loads(obj[SAVED_MATS_PROP])
            obj.data.materials.clear()
            for name in names:
                mat = bpy.data.materials.get(name) if name else None
                if name and mat is None:
                    missing += 1
                obj.data.materials.append(mat)
            del obj[SAVED_MATS_PROP]
            restored += 1
        msg = f"Restored materials on {restored} object(s)"
        if missing:
            msg += f" ({missing} original materials no longer exist)"
        self.report({'INFO'} if restored else {'WARNING'},
                    msg if restored else "Nothing to restore (no saved materials).")
        return {'FINISHED' if restored else 'CANCELLED'}


class OBJECT_OT_pro_uv_toggle_checker_preview(_MeshObjectOp, bpy.types.Operator):
    """Toggle the grid checker on/off (restores saved materials)"""
    bl_idname = "object.pro_uv_toggle_checker_preview"
    bl_label = "Toggle Checker"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        checker_names = set(node_utils.CHECKER_MATERIALS.values())
        has_checker = any(slot.material and slot.material.name in checker_names
                          for slot in obj.material_slots)
        if has_checker:
            return bpy.ops.object.pro_uv_restore_previous_materials()
        props = context.scene.pro_toolkit
        _apply_checker(context, 'GRID', props.uv_checker_scale)
        self.report({'INFO'}, "Checker ON")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_uv_calculate_texel_density,
    OBJECT_OT_pro_uv_set_texel_density,
    OBJECT_OT_pro_uv_match_texel_density,
    OBJECT_OT_pro_uv_normalize_texel_density,
    OBJECT_OT_pro_uv_show_density_report,
    OBJECT_OT_pro_uv_audit,
    MESH_OT_pro_uv_select_overlaps,
    MESH_OT_pro_uv_select_outside_0_1,
    MESH_OT_pro_uv_select_flipped_uvs,
    MESH_OT_pro_uv_select_zero_area_uvs,
    MESH_OT_pro_uv_fix_outside_0_1,
    MESH_OT_pro_uv_fix_zero_area_uvs,
    OBJECT_OT_pro_uv_export_report,
    OBJECT_OT_pro_uv_add_checker_material,
    OBJECT_OT_pro_uv_add_colored_checker_material,
    OBJECT_OT_pro_uv_add_distortion_checker_material,
    OBJECT_OT_pro_uv_remove_checker_material,
    OBJECT_OT_pro_uv_restore_previous_materials,
    OBJECT_OT_pro_uv_toggle_checker_preview,
)
