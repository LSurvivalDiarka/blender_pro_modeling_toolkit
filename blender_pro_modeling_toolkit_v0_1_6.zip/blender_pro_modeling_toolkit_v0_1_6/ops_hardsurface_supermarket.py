# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_supermarket.py
# v0.1.4 Hard Surface Pro Suite: Supermarket Flower hard-surface presets.
# One-click bases meant to be snapped onto the v0.1.3 SF blockouts
# (fridges, freezers, registers, shelves, entrance). They are simple,
# low-poly and editable — not final hero assets.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu
from . import hardsurface_utils as hs


# ═══════════════════════════════════════════════════════════════════════
#  BUILD FUNCTIONS (each fills a bmesh and returns nothing)
# ═══════════════════════════════════════════════════════════════════════

def _fridge_door_detail(bm):
    # frame + recessed glass field sized for the SF fridge (1.20 x 2.10)
    hs.add_panel_with_field(bm, 0.55, 1.5, 0.04, 0.06, 0.02)


def _fridge_handle(bm):
    # vertical bar handle: two standoffs + long grip
    r, s, length = 0.012, 0.05, 0.60
    half = length / 2.0 - 0.04
    for z in (-half, half):
        ret = bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False,
                                    segments=10, radius1=r, radius2=r, depth=s)
        for v in ret["verts"]:
            v.co.z, v.co.y = v.co.y + z + length / 2.0, v.co.z + s / 2.0
    grip = bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False,
                                 segments=10, radius1=r, radius2=r, depth=length)
    for v in grip["verts"]:
        v.co.z += length / 2.0
        v.co.y += s + r
    # base at z = 0 already (handle spans 0..length vertically)


def _fridge_rubber_seal(bm):
    # rectangular gasket frame matching the fridge door (0.55 x 1.50)
    w, h, t, d = 0.55, 1.50, 0.015, 0.012
    cu.add_box(bm, w, d, t)
    cu.add_box(bm, w, d, t, z0=h - t)
    cu.add_box(bm, t, d, h - 2 * t, cx=-(w - t) / 2.0, z0=t)
    cu.add_box(bm, t, d, h - 2 * t, cx=(w - t) / 2.0, z0=t)


def _freezer_glass_lid_frame(bm):
    # sliding-lid frame for the SF freezer chest (1.50 x 0.75 top)
    w, d, f, t = 1.40, 0.65, 0.05, 0.04
    cu.add_box(bm, w, f, t, cy=-(d - f) / 2.0)
    cu.add_box(bm, w, f, t, cy=(d - f) / 2.0)
    cu.add_box(bm, f, d - 2 * f, t, cx=-(w - f) / 2.0)
    cu.add_box(bm, f, d - 2 * f, t, cx=(w - f) / 2.0)
    cu.add_box(bm, f, d - 2 * f, t * 1.2)          # center mullion


def _checkout_conveyor_belt(bm):
    # belt bed + side rails + end rollers
    w, d, t = 1.50, 0.50, 0.04
    cu.add_box(bm, w, d, t)                                  # belt bed
    cu.add_box(bm, w, 0.04, 0.06, cy=-(d + 0.04) / 2.0)      # side rail
    cu.add_box(bm, w, 0.04, 0.06, cy=(d + 0.04) / 2.0)       # side rail
    for sx in (-1, 1):
        hs.add_cylinder_y(bm, 0.03, d, 12, cx=sx * (w / 2.0 + 0.015),
                          cz=t / 2.0)


def _cash_register_buttons(bm):
    # keypad plate with a 4 x 4 grid of small buttons
    base, bh = 0.18, 0.012
    cu.add_box(bm, base, base, bh)
    cell = base / 4.0
    for i in range(4):
        for j in range(4):
            x = -base / 2.0 + cell * (i + 0.5)
            y = -base / 2.0 + cell * (j + 0.5)
            cu.add_box(bm, cell * 0.6, cell * 0.6, 0.012,
                       cx=x, cy=y, z0=bh)


def _cash_register_screen(bm):
    # display panel on a short stand
    cu.add_cylinder(bm, 0.03, 0.05, 10)                      # stand post
    cu.add_box(bm, 0.12, 0.06, 0.02, z0=0.0)                 # foot
    cu.add_box(bm, 0.30, 0.02, 0.22, z0=0.05)                # screen body
    cu.add_box(bm, 0.27, 0.005, 0.19, cy=-0.012, z0=0.065)   # screen face


def _shopping_cart_metal_bar(bm):
    # push bar: two uprights + cross grip
    r, h, w = 0.012, 0.25, 0.55
    half = (w - 2 * r) / 2.0
    cu.add_cylinder(bm, r, h, 10, cx=-half)
    cu.add_cylinder(bm, r, h, 10, cx=half)
    ret = bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False,
                                segments=10, radius1=r * 1.3, radius2=r * 1.3,
                                depth=w)
    for v in ret["verts"]:
        x, y, z = v.co.x, v.co.y, v.co.z
        v.co.x, v.co.z = z, x + h
        v.co.y = y


def _shelf_price_rail(bm):
    # tilted price-label rail clipped to a shelf edge (1.00 m long)
    w = 1.00
    cu.add_box(bm, w, 0.012, 0.008)                          # clip base
    hs.add_wedge(bm, w, 0.006, 0.04, 0.035, cy=-0.009, z0=0.008)


def _metal_shelf_side_panel(bm):
    # vertical side panel with raised stiffener ribs (0.55 x 2.00)
    w, h, t = 0.55, 2.00, 0.015
    cu.add_box(bm, w, t, h)
    for i in range(4):
        z = 0.25 + i * 0.5
        cu.add_box(bm, w * 0.8, 0.008, 0.05, cy=-(t + 0.008) / 2.0, z0=z)


def _sliding_door_frame(bm):
    # double sliding-door frame with center mullion and floor track
    w, h, f, d = 2.00, 2.20, 0.08, 0.10
    cu.add_box(bm, f, d, h, cx=-(w - f) / 2.0)
    cu.add_box(bm, f, d, h, cx=(w - f) / 2.0)
    cu.add_box(bm, w - 2 * f, d, f, z0=h - f)                # header
    cu.add_box(bm, 0.05, d, h - f)                           # center mullion
    cu.add_box(bm, w, d * 1.2, 0.015)                        # floor track


def _store_entrance_metal_frame(bm):
    # big entrance portal with deep header
    w, h, f, d = 2.40, 2.40, 0.12, 0.15
    cu.add_box(bm, f, d, h, cx=-(w - f) / 2.0)
    cu.add_box(bm, f, d, h, cx=(w - f) / 2.0)
    cu.add_box(bm, w, d, 0.25, z0=h - 0.25)                  # header band
    cu.add_box(bm, w - 2 * f, d * 0.5, 0.06, z0=h - 0.31)    # header trim


def _electrical_box(bm):
    # wall-mounted electrical box with door seam and latch
    w, d, h = 0.30, 0.15, 0.40
    cu.add_box(bm, w, d, h)
    cu.add_box(bm, w * 0.85, 0.006, h * 0.85,
               cy=-(d + 0.006) / 2.0, z0=h * 0.075)          # door face
    cu.add_box(bm, 0.02, 0.01, 0.04, cx=w * 0.32,
               cy=-(d + 0.02) / 2.0, z0=h * 0.45)            # latch
    cu.add_box(bm, w * 0.5, 0.008, 0.03,
               cy=-(d + 0.01) / 2.0, z0=h * 0.12)            # vent slot hint


def _security_camera_blockout(bm):
    # wall arm + camera body + lens
    cu.add_box(bm, 0.10, 0.10, 0.015)                        # wall plate
    cu.add_box(bm, 0.03, 0.12, 0.03, cy=0.05, z0=0.015)      # arm
    cu.add_box(bm, 0.10, 0.18, 0.09, cy=0.14, z0=0.0)        # body
    hs.add_cylinder_y(bm, 0.032, 0.03, 12, cz=0.045, y0=0.23)


def _ceiling_light_panel(bm):
    # framed diffuser panel (1.20 x 0.30)
    w, d, f, t = 1.20, 0.30, 0.03, 0.06
    cu.add_box(bm, w, f, t, cy=-(d - f) / 2.0)
    cu.add_box(bm, w, f, t, cy=(d - f) / 2.0)
    cu.add_box(bm, f, d - 2 * f, t, cx=-(w - f) / 2.0)
    cu.add_box(bm, f, d - 2 * f, t, cx=(w - f) / 2.0)
    cu.add_box(bm, w - 2 * f, d - 2 * f, 0.015, z0=0.01)     # diffuser pane


def _ventilation_grille(bm):
    # ceiling/wall ventilation grille (0.60 x 0.30)
    w, h, d, f = 0.60, 0.30, 0.02, 0.025
    cu.add_box(bm, f, d, h, cx=-(w - f) / 2.0)
    cu.add_box(bm, f, d, h, cx=(w - f) / 2.0)
    cu.add_box(bm, w - 2 * f, d, f)
    cu.add_box(bm, w - 2 * f, d, f, z0=h - f)
    for i in range(1, 7):
        z = f + (h - 2 * f) * i / 7.0
        cu.add_box(bm, w - 2 * f, d * 0.5, 0.008, z0=z - 0.004)


# ═══════════════════════════════════════════════════════════════════════
#  PRESET TABLE  id: (label, object name, material, build fn, at_floor)
# ═══════════════════════════════════════════════════════════════════════

SF_HS_PRESETS = {
    "FRIDGE_DOOR_DETAIL": ("SF Fridge Door Detail", "SF_Fridge_Door_Detail",
                           "HS_Metal_Light", _fridge_door_detail, False),
    "FRIDGE_HANDLE": ("SF Fridge Handle", "SF_Fridge_Handle",
                      "HS_Metal_Light", _fridge_handle, False),
    "FRIDGE_RUBBER_SEAL": ("SF Fridge Rubber Seal", "SF_Fridge_Rubber_Seal",
                           "HS_Rubber_Dark", _fridge_rubber_seal, False),
    "FREEZER_GLASS_LID_FRAME": ("SF Freezer Glass Lid Frame",
                                "SF_Freezer_Glass_Lid_Frame",
                                "HS_Metal_Light", _freezer_glass_lid_frame, False),
    "CHECKOUT_CONVEYOR_BELT": ("SF Checkout Conveyor Belt",
                               "SF_Checkout_Conveyor_Belt",
                               "HS_Rubber_Dark", _checkout_conveyor_belt, False),
    "CASH_REGISTER_BUTTONS": ("SF Cash Register Buttons",
                              "SF_Cash_Register_Buttons",
                              "HS_Button_Dark", _cash_register_buttons, False),
    "CASH_REGISTER_SCREEN": ("SF Cash Register Screen",
                             "SF_Cash_Register_Screen",
                             "HS_Screen_Black", _cash_register_screen, False),
    "SHOPPING_CART_METAL_BAR": ("SF Shopping Cart Metal Bar",
                                "SF_Shopping_Cart_Metal_Bar",
                                "HS_Metal_Light", _shopping_cart_metal_bar, False),
    "SHELF_PRICE_RAIL": ("SF Shelf Price Rail", "SF_Shelf_Price_Rail",
                         "HS_Plastic_White", _shelf_price_rail, False),
    "METAL_SHELF_SIDE_PANEL": ("SF Metal Shelf Side Panel",
                               "SF_Metal_Shelf_Side_Panel",
                               "HS_Metal_Light", _metal_shelf_side_panel, True),
    "SLIDING_DOOR_FRAME": ("SF Sliding Door Frame", "SF_Sliding_Door_Frame",
                           "HS_Metal_Dark", _sliding_door_frame, True),
    "STORE_ENTRANCE_METAL_FRAME": ("SF Store Entrance Metal Frame",
                                   "SF_Store_Entrance_Metal_Frame",
                                   "HS_Metal_Dark", _store_entrance_metal_frame, True),
    "ELECTRICAL_BOX": ("SF Electrical Box", "SF_Electrical_Box",
                       "HS_Metal_Light", _electrical_box, False),
    "SECURITY_CAMERA_BLOCKOUT": ("SF Security Camera Blockout",
                                 "SF_Security_Camera_Blockout",
                                 "HS_Plastic_White", _security_camera_blockout, False),
    "CEILING_LIGHT_PANEL": ("SF Ceiling Light Panel", "SF_Ceiling_Light_Panel",
                            "HS_Plastic_White", _ceiling_light_panel, False),
    "VENTILATION_GRILLE": ("SF Ventilation Grille", "SF_Ventilation_Grille",
                           "HS_Metal_Light", _ventilation_grille, False),
}


class OBJECT_OT_pro_hs_sf_preset(bpy.types.Operator):
    """Create a Supermarket Flower hard-surface base at the 3D cursor"""
    bl_idname = "object.pro_hs_sf_preset"
    bl_label = "SF Hard Surface Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Preset",
        items=[(k, v[0], f"Create {v[0]}") for k, v in SF_HS_PRESETS.items()])

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        label, obj_name, mat, build, at_floor = SF_HS_PRESETS[self.preset]
        bm = bmesh.new()
        build(bm)
        hs.finalize_hs_object(context, self, obj_name, bm,
                              hs.COLL_HS_SUPERMARKET, mat, at_floor=at_floor)
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_hs_sf_preset,
)
