# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_texture_tools.py
# v0.1.6 — Texture Manager (missing/relink/paths/pack/lists/duplicates)
# + Texture Atlas / UV Check (pre-bake, pre-export validation).
#
# RULES:
#   - paths never change without a report (the relink op logs every file),
#   - images are never deleted without confirmation,
#   - UV checks reuse the UV Suite logic where it exists.
# ──────────────────────────────────────────────────────────────────────

import os

import bmesh
import bpy

from . import material_utils as mu
from . import texture_utils as tu


# ═══════════════════════════════════════════════════════════════════════
#  TEXTURE MANAGER
# ═══════════════════════════════════════════════════════════════════════

class IMAGE_OT_pro_tex_find_missing(bpy.types.Operator):
    """List every image whose file is missing on disk (read-only)"""
    bl_idname = "image.pro_tex_find_missing"
    bl_label = "Find Missing Textures"
    bl_options = {'REGISTER'}

    def execute(self, context):
        missing = tu.missing_images()
        props = context.scene.pro_toolkit
        props.texture_missing_count = len(missing)
        if not missing:
            self.report({'INFO'}, "Sin texturas perdidas. ✅")
        else:
            names = ", ".join(i.name for i in missing[:6])
            if len(missing) > 6:
                names += ", …"
            self.report({'WARNING'},
                        f"{len(missing)} textura(s) perdidas: {names}")
        return {'FINISHED'}


class IMAGE_OT_pro_tex_relink_folder(bpy.types.Operator):
    """Relink missing images by filename searching the relink folder
    recursively; every relinked file is logged in the texture report"""
    bl_idname = "image.pro_tex_relink_folder"
    bl_label = "Relink Textures From Folder"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        folder = bpy.path.abspath(props.texture_relink_folder)
        if not folder or not os.path.isdir(folder):
            self.report({'ERROR'},
                        "Configura una carpeta de relink válida primero.")
            return {'CANCELLED'}
        relinked, not_found = tu.relink_from_folder(
            folder,
            make_relative=props.texture_make_relative,
            missing_only=True)
        if props.texture_pack_after_relink:
            for name, _p in relinked:
                img = bpy.data.images.get(name)
                if img is not None and img.packed_file is None:
                    try:
                        img.pack()
                    except RuntimeError:
                        pass
        # persist the relink log for the report
        global _LAST_RELINK
        _LAST_RELINK = {"folder": folder, "relinked": relinked,
                        "not_found": not_found}
        msg = f"{len(relinked)} relinkadas"
        if not_found:
            msg += f", {len(not_found)} NO encontradas: " \
                   + ", ".join(not_found[:5])
        self.report({'WARNING' if not_found else 'INFO'}, msg)
        return {'FINISHED'}


_LAST_RELINK = None


class IMAGE_OT_pro_tex_make_relative(bpy.types.Operator):
    """Convert absolute image paths to //relative (needs a saved .blend)"""
    bl_idname = "image.pro_tex_make_relative"
    bl_label = "Make Texture Paths Relative"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        changed = tu.make_paths_relative()
        if changed is None:
            self.report({'ERROR'},
                        "Guarda el .blend primero — sin archivo no hay "
                        "rutas relativas.")
            return {'CANCELLED'}
        self.report({'INFO'}, f"{len(changed)} ruta(s) convertidas a relativas.")
        return {'FINISHED'}


class IMAGE_OT_pro_tex_make_absolute(bpy.types.Operator):
    """Convert //relative image paths to absolute"""
    bl_idname = "image.pro_tex_make_absolute"
    bl_label = "Make Texture Paths Absolute"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        changed = tu.make_paths_absolute()
        self.report({'INFO'}, f"{len(changed)} ruta(s) convertidas a absolutas.")
        return {'FINISHED'}


class IMAGE_OT_pro_tex_pack_all(bpy.types.Operator):
    """Pack every external image into the .blend file"""
    bl_idname = "image.pro_tex_pack_all"
    bl_label = "Pack All Images"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = err = 0
        for img in tu.packable_images():
            try:
                img.pack()
                n += 1
            except RuntimeError:
                err += 1
        msg = f"{n} imagen(es) empaquetadas."
        if err:
            msg += f" {err} fallaron (¿archivo inexistente?)."
        self.report({'WARNING' if err else 'INFO'}, msg)
        return {'FINISHED'}


class IMAGE_OT_pro_tex_unpack_all(bpy.types.Operator):
    """Unpack embedded images to //textures (uses Blender's
    USE_LOCAL unpack; needs a saved .blend)"""
    bl_idname = "image.pro_tex_unpack_all"
    bl_label = "Unpack Images To Folder"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not bpy.data.is_saved:
            self.report({'ERROR'}, "Guarda el .blend primero.")
            return {'CANCELLED'}
        n = 0
        for img in tu.embedded_images():
            try:
                img.unpack(method='USE_LOCAL')
                n += 1
            except RuntimeError:
                pass
        self.report({'INFO'},
                    f"{n} imagen(es) desempaquetadas a //textures.")
        return {'FINISHED'}


class IMAGE_OT_pro_tex_delete_unused(bpy.types.Operator):
    """Delete images with zero users (confirmation; packed and fake-user
    images are kept)"""
    bl_idname = "image.pro_tex_delete_unused"
    bl_label = "Delete Unused Images"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        self._victims = [i for i in tu.real_images()
                         if i.users == 0 and not i.use_fake_user
                         and i.packed_file is None]
        if not self._victims:
            self.report({'INFO'}, "No hay imágenes sin uso.")
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        victims = getattr(self, "_victims", []) or \
            [i for i in tu.real_images()
             if i.users == 0 and not i.use_fake_user and i.packed_file is None]
        n = len(victims)
        for i in victims:
            bpy.data.images.remove(i)
        self.report({'INFO'}, f"{n} imagen(es) eliminadas.")
        return {'FINISHED'}


class IMAGE_OT_pro_tex_report(bpy.types.Operator):
    """Write V016_TEXTURE_REPORT.md: used/unused/missing/duplicate images,
    sizes, paths and the last relink log"""
    bl_idname = "image.pro_tex_report"
    bl_label = "Create Texture Report"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        used = tu.used_image_set()
        users = tu.image_users()
        imgs = tu.real_images()
        missing = tu.missing_images()
        large = tu.find_large_images(props.texture_max_size_warning)
        dups = tu.duplicate_image_groups()
        missing_only = props.texture_report_missing_only

        lines = ["# V016 TEXTURE REPORT", "",
                 "## Resumen",
                 f"- Imágenes en el archivo: **{len(imgs)}**",
                 f"- Usadas en materiales: **{len([i for i in imgs if i in used])}**",
                 f"- Sin uso: **{len([i for i in imgs if i not in used])}**",
                 f"- Perdidas: **{len(missing)}**",
                 f"- Empaquetadas: **{len(tu.embedded_images())}**",
                 f"- Externas: **{len(tu.external_images())}**",
                 f"- Grandes (> {props.texture_max_size_warning}px): "
                 f"**{len(large)}**",
                 f"- Grupos duplicados: **{len(dups)}**",
                 "",
                 "## Texturas perdidas"]
        lines += [f"- `{i.name}` — {i.filepath}" for i in missing] \
            or ["- (ninguna)"]
        if not missing_only:
            lines += ["", "## Inventario"]
            for img in sorted(imgs, key=lambda i: i.name):
                w, h = tu.image_size(img)
                kind = ("PACKED" if img.packed_file else
                        "MISSING" if tu.image_is_missing(img) else
                        "ABS" if tu.is_path_absolute(img) else "REL")
                mats = ", ".join(users.get(img, [])) or "(sin uso)"
                lines.append(f"- `{img.name}` {w}x{h} [{kind}] → {mats}")
            lines += ["", "## Duplicados"]
            for key, group in dups.items():
                lines.append(f"- `{key}`: " + ", ".join(i.name for i in group))
            if not dups:
                lines.append("- (ninguno)")
            lines += ["", f"## Grandes (> {props.texture_max_size_warning}px)"]
            lines += [f"- {i.name} ({w}x{h})" for i, (w, h) in large] \
                or ["- (ninguna)"]
        if _LAST_RELINK is not None:
            lines += ["", "## Último relink",
                      f"Carpeta: `{_LAST_RELINK['folder']}`"]
            lines += [f"- ✅ {n} → `{p}`"
                      for n, p in _LAST_RELINK["relinked"]] or ["- (nada)"]
            lines += [f"- ❌ no encontrada: {n}"
                      for n in _LAST_RELINK["not_found"]]
        path = mu.write_report("V016_TEXTURE_REPORT.md", lines)
        self.report({'INFO'}, f"Informe escrito: {path}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  TEXTURE ATLAS / UV CHECK
# ═══════════════════════════════════════════════════════════════════════

def _uv_stats(obj):
    """outside01 / zero-area face counts for the active UV map."""
    me = obj.data
    if not me.uv_layers:
        return None
    bm = bmesh.new()
    bm.from_mesh(me)
    uv = bm.loops.layers.uv.active
    outside = zero = 0
    eps = 1e-9
    for f in bm.faces:
        coords = [l[uv].uv for l in f.loops]
        if any(c.x < -1e-5 or c.x > 1.00001 or c.y < -1e-5 or c.y > 1.00001
               for c in coords):
            outside += 1
        area = 0.0
        for i in range(1, len(coords) - 1):
            a, b, c = coords[0], coords[i], coords[i + 1]
            area += abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y))
        if area * 0.5 < eps:
            zero += 1
    bm.free()
    return {"outside": outside, "zero": zero, "faces": len(me.polygons)}


def _atlas_check(context, objs, props):
    """All atlas/UV pre-bake checks; returns (rows, risk_msgs)."""
    rows, risks = [], []
    sizes_seen = set()
    for obj in objs:
        me = obj.data
        row = {"object": obj.name,
               "uv_maps": len(me.uv_layers),
               "active_uv": me.uv_layers.active.name if me.uv_layers else "-",
               "materials": len([s for s in obj.material_slots if s.material]),
               "outside": 0, "zero": 0, "images": [], "warnings": []}
        if not me.uv_layers:
            row["warnings"].append("SIN UVs")
            risks.append(f"'{obj.name}' no tiene UVs — imprescindible antes "
                         "de bake.")
        else:
            st = _uv_stats(obj)
            row["outside"] = st["outside"]
            row["zero"] = st["zero"]
            if st["outside"]:
                row["warnings"].append(f"{st['outside']} caras fuera de 0-1")
                risks.append(f"'{obj.name}': {st['outside']} caras UV fuera "
                             "de 0-1 (atlas/bake se repetirá).")
            if st["zero"]:
                row["warnings"].append(f"{st['zero']} caras con área UV cero")
                risks.append(f"'{obj.name}': {st['zero']} caras con área UV "
                             "cero (bake con artefactos).")
        if len(me.uv_layers) > 1:
            row["warnings"].append(f"{len(me.uv_layers)} UV maps")
        for slot in obj.material_slots:
            if slot.material is None:
                continue
            for img in mu.material_images(slot.material):
                w, h = tu.image_size(img)
                row["images"].append((img.name, w, h))
                if w and h:
                    sizes_seen.add((w, h))
                if w != h:
                    row["warnings"].append(f"{img.name} no cuadrada {w}x{h}")
        rows.append(row)
    if len(sizes_seen) > 1:
        risks.append("Resoluciones de textura inconsistentes entre objetos: "
                     + ", ".join(f"{w}x{h}" for w, h in sorted(sizes_seen)))
    return rows, risks


class OBJECT_OT_pro_tex_atlas_check(bpy.types.Operator):
    """Check Texture Atlas Risk: UVs present, 0-1 bounds, zero-area faces,
    UV map count, material/UV consistency, image sizes and aspect"""
    bl_idname = "object.pro_tex_atlas_check"
    bl_label = "Check Texture Atlas Risk"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == 'MESH'] \
            or mu.scope_objects(context, 'SCENE')
        if not objs:
            self.report({'ERROR'}, "No hay objetos mesh que comprobar.")
            return {'CANCELLED'}
        _rows, risks = _atlas_check(context, objs, context.scene.pro_toolkit)
        props = context.scene.pro_toolkit
        props.texture_atlas_risks = len(risks)
        if not risks:
            self.report({'INFO'},
                        f"Atlas check OK en {len(objs)} objeto(s). ✅")
        else:
            self.report({'WARNING'},
                        f"{len(risks)} riesgo(s): " + " | ".join(risks[:3])
                        + (" …" if len(risks) > 3 else ""))
        return {'FINISHED'}


class OBJECT_OT_pro_tex_atlas_report(bpy.types.Operator):
    """Write V016_TEXTURE_ATLAS_UV_REPORT.md with the full per-object
    UV/atlas analysis (reuses the UV Suite checks)"""
    bl_idname = "object.pro_tex_atlas_report"
    bl_label = "Create Atlas / UV Report"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == 'MESH'] \
            or mu.scope_objects(context, 'SCENE')
        if not objs:
            self.report({'ERROR'}, "No hay objetos mesh que comprobar.")
            return {'CANCELLED'}
        rows, risks = _atlas_check(context, objs, context.scene.pro_toolkit)
        lines = ["# V016 TEXTURE ATLAS / UV REPORT", "",
                 f"Objetos analizados: {len(rows)}", "",
                 "## Riesgos"]
        lines += [f"- ⚠️ {r}" for r in risks] or ["- Sin riesgos. ✅"]
        lines += ["", "## Detalle por objeto"]
        for r in rows:
            lines += [f"### {r['object']}",
                      f"- UV maps: {r['uv_maps']} (activo: {r['active_uv']})",
                      f"- Materiales: {r['materials']}",
                      f"- Caras fuera de 0-1: {r['outside']}",
                      f"- Caras con área UV cero: {r['zero']}"]
            if r["images"]:
                lines += ["- Imágenes: "
                          + ", ".join(f"{n} ({w}x{h})"
                                      for n, w, h in r["images"])]
            if r["warnings"]:
                lines += [f"- ⚠️ {w}" for w in r["warnings"]]
            lines.append("")
        path = mu.write_report("V016_TEXTURE_ATLAS_UV_REPORT.md", lines)
        self.report({'INFO'}, f"Informe escrito: {path}")
        return {'FINISHED'}


classes = (
    IMAGE_OT_pro_tex_find_missing,
    IMAGE_OT_pro_tex_relink_folder,
    IMAGE_OT_pro_tex_make_relative,
    IMAGE_OT_pro_tex_make_absolute,
    IMAGE_OT_pro_tex_pack_all,
    IMAGE_OT_pro_tex_unpack_all,
    IMAGE_OT_pro_tex_delete_unused,
    IMAGE_OT_pro_tex_report,
    OBJECT_OT_pro_tex_atlas_check,
    OBJECT_OT_pro_tex_atlas_report,
)
