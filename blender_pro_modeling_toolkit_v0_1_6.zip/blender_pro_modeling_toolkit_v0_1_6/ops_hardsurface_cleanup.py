# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_cleanup.py
# v0.1.4 Hard Surface Pro Suite: cleanup, selection helpers and the
# hard-surface mesh audit. The audit prints to the console and writes
# V014_HARDSURFACE_AUDIT_REPORT.md next to the .blend (or to the temp
# dir when the file is unsaved).
# ──────────────────────────────────────────────────────────────────────

import os
import bpy
import bmesh

from . import hardsurface_utils as hs
from .ops_hardsurface_booleans import _all_cutters, _used_cutters, _setup_cutter


class _HSCleanObjectOp:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))


class _HSCleanEditOp:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and context.active_object is not None


# ═══════════════════════════════════════════════════════════════════════
#  AUDIT
# ═══════════════════════════════════════════════════════════════════════

def _approx_tri_count(obj):
    return sum((len(p.vertices) - 2) for p in obj.data.polygons)


def _audit_object(obj):
    """Collect hard-surface health stats for one mesh object."""
    me = obj.data
    ngons = sum(1 for p in me.polygons if len(p.vertices) > 4)
    tris = sum(1 for p in me.polygons if len(p.vertices) == 3)

    bm = bmesh.new()
    try:
        bm.from_mesh(me)
        non_manifold = sum(1 for e in bm.edges if not e.is_manifold)
        loose_verts = sum(1 for v in bm.verts if not v.link_edges)
    finally:
        bm.free()

    mods = [m.type for m in obj.modifiers]
    return {
        "name": obj.name,
        "polys": len(me.polygons),
        "tri_count": _approx_tri_count(obj),
        "ngons": ngons,
        "tris": tris,
        "non_manifold": non_manifold,
        "loose_verts": loose_verts,
        "unapplied_scale": hs.has_unapplied_scale(obj),
        "scale": tuple(round(s, 4) for s in obj.scale),
        "booleans": mods.count('BOOLEAN'),
        "bevels": mods.count('BEVEL'),
        "weighted_normals": mods.count('WEIGHTED_NORMAL'),
        "materials": len([m for m in me.materials if m]),
        "auto_smooth": all(p.use_smooth for p in me.polygons) if me.polygons else False,
    }


class OBJECT_OT_pro_hs_audit_selected(bpy.types.Operator):
    """Audit the selected objects for hard-surface health (n-gons, normals,
    scale, boolean/bevel stack, tri count) and write a markdown report"""
    bl_idname = "object.pro_hs_audit_selected"
    bl_label = "Hard Surface Mesh Audit"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        rows = [_audit_object(o) for o in hs.selected_mesh_objects(context)]
        unused = _all_cutters() - _used_cutters()

        lines = ["# V014 — Hard Surface Audit Report", ""]
        lines.append(f"**Objetos auditados:** {len(rows)}")
        lines.append(f"**Cutters sin usar en el archivo:** {len(unused)}"
                     + (f" ({', '.join(o.name for o in sorted(unused, key=lambda x: x.name))})"
                        if unused else ""))
        lines.append("")
        lines.append("| Objeto | Polys | ~Tris | N-gons | Triángulos | Non-manifold | "
                     "Vértices sueltos | Escala | Booleans | Bevels | W.Normals | "
                     "Materiales | Smooth |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
        issues = 0
        for r in rows:
            scale_txt = "OK" if not r["unapplied_scale"] else f"⚠ {r['scale']}"
            if r["unapplied_scale"] or r["ngons"] or r["non_manifold"] or r["loose_verts"]:
                issues += 1
            lines.append(
                f"| {r['name']} | {r['polys']} | {r['tri_count']} | {r['ngons']} | "
                f"{r['tris']} | {r['non_manifold']} | {r['loose_verts']} | {scale_txt} | "
                f"{r['booleans']} | {r['bevels']} | {r['weighted_normals']} | "
                f"{r['materials']} | {'sí' if r['auto_smooth'] else 'no'} |")
        lines.append("")
        lines.append(f"**Objetos con avisos:** {issues} de {len(rows)}")
        text = "\n".join(lines)

        print("\n" + "═" * 70)
        print("PRO TOOLKIT — HARD SURFACE MESH AUDIT")
        print("═" * 70)
        print(text)
        print("═" * 70 + "\n")

        base = bpy.path.abspath("//") or bpy.app.tempdir
        path = os.path.join(base, "V014_HARDSURFACE_AUDIT_REPORT.md")
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text + "\n")
            self.report({'INFO'},
                        f"Audit done: {len(rows)} object(s), {issues} with "
                        f"warnings. Report: {path}")
        except OSError:
            self.report({'WARNING'},
                        f"Audit done ({len(rows)} object(s)) — console only, "
                        "could not write the report file.")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  SELECTION HELPERS
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_hs_select_thin_faces(_HSCleanEditOp, bpy.types.Operator):
    """Select long, thin faces (aspect ratio above the threshold) —
    they catch light badly on hard surfaces"""
    bl_idname = "mesh.pro_hs_select_thin_faces"
    bl_label = "Select Long Thin Faces"

    ratio: bpy.props.FloatProperty(
        name="Aspect Ratio", description="Select faces longer than this "
        "many times their width", default=8.0, min=2.0, soft_max=50.0)

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        n = 0
        for f in bm.faces:
            f.select_set(False)
        for f in bm.faces:
            lengths = [e.calc_length() for e in f.edges]
            if min(lengths) > 1e-9 and max(lengths) / min(lengths) >= self.ratio:
                f.select_set(True)
                n += 1
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, f"{n} thin face(s) selected (ratio ≥ {self.ratio:.0f}).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_select_unapplied_scale(bpy.types.Operator):
    """Select every visible mesh object whose scale is not (1, 1, 1)"""
    bl_idname = "object.pro_hs_select_unapplied_scale"
    bl_label = "Select Unapplied Scale Objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        n = 0
        for o in context.visible_objects:
            sel = o.type == 'MESH' and hs.has_unapplied_scale(o)
            o.select_set(sel)
            if sel:
                context.view_layer.objects.active = o
                n += 1
        self.report({'INFO'}, f"{n} object(s) with unapplied scale selected.")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  FIXERS
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_hs_fix_normals(_HSCleanObjectOp, bpy.types.Operator):
    """Recalculate the normals of every selected object to point outside"""
    bl_idname = "object.pro_hs_fix_normals"
    bl_label = "Fix Normals"

    def execute(self, context):
        done = 0
        for obj in hs.selected_mesh_objects(context):
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()
            done += 1
        self.report({'INFO'}, f"Normals recalculated on {done} object(s).")
        return {'FINISHED'}


class MESH_OT_pro_hs_recalc_outside(_HSCleanEditOp, bpy.types.Operator):
    """Recalculate the selected faces' normals to point outside (Edit Mode)"""
    bl_idname = "mesh.pro_hs_recalc_outside"
    bl_label = "Recalculate Outside"

    def execute(self, context):
        bpy.ops.mesh.normals_make_consistent(inside=False)
        self.report({'INFO'}, "Normals recalculated outside.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_remove_loose(_HSCleanObjectOp, bpy.types.Operator):
    """Remove loose vertices and edges (no faces) from the selected objects"""
    bl_idname = "object.pro_hs_remove_loose"
    bl_label = "Remove Loose Geometry"

    def execute(self, context):
        total = 0
        for obj in hs.selected_mesh_objects(context):
            if obj.data.users > 1:
                self.report({'WARNING'},
                            f"'{obj.name}': shared mesh data — skipped.")
                continue
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            loose_e = [e for e in bm.edges if not e.link_faces]
            loose_v = [v for v in bm.verts if not v.link_edges]
            n = len(loose_e) + len(loose_v)
            if loose_e:
                bmesh.ops.delete(bm, geom=loose_e, context='EDGES')
            loose_v = [v for v in bm.verts if not v.link_edges]
            if loose_v:
                bmesh.ops.delete(bm, geom=loose_v, context='VERTS')
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()
            total += n
        self.report({'INFO'}, f"{total} loose element(s) removed.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_merge_by_distance(_HSCleanObjectOp, bpy.types.Operator):
    """Merge vertices closer than the threshold (safe default 0.1 mm,
    reports how many were merged; shared meshes are skipped)"""
    bl_idname = "object.pro_hs_merge_by_distance"
    bl_label = "Merge by Distance Safe"

    distance: bpy.props.FloatProperty(
        name="Distance", default=0.0001, min=0.00001, soft_max=0.01,
        precision=5, unit='LENGTH')

    def execute(self, context):
        total = 0
        for obj in hs.selected_mesh_objects(context):
            if obj.data.users > 1:
                self.report({'WARNING'},
                            f"'{obj.name}': shared mesh data — skipped.")
                continue
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            before = len(bm.verts)
            bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=self.distance)
            merged = before - len(bm.verts)
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()
            total += merged
        self.report({'INFO'}, f"{total} vertex(es) merged "
                    f"(distance {self.distance:.5f} m).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_clean_cutters(bpy.types.Operator):
    """Tidy the boolean cutters: wire display, filed in the cutters
    collection, drop Boolean modifiers whose cutter object is missing,
    and report unused cutters (nothing is deleted)"""
    bl_idname = "object.pro_hs_clean_cutters"
    bl_label = "Clean Boolean Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        tidied = 0
        for o in _all_cutters():
            _setup_cutter(o)
            hs.link_to_hs_collection(context, o, hs.COLL_HS_CUTTERS)
            tidied += 1
        dropped = 0
        for o in bpy.data.objects:
            for m in list(o.modifiers):
                if m.type == 'BOOLEAN' and m.object is None:
                    o.modifiers.remove(m)
                    dropped += 1
        unused = _all_cutters() - _used_cutters()
        msg = (f"{tidied} cutter(s) tidied, {dropped} empty boolean "
               f"modifier(s) removed, {len(unused)} unused cutter(s)")
        if unused:
            msg += " — use 'Delete Unused Cutters' to remove them"
        self.report({'INFO'}, msg + ".")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_hs_audit_selected,
    MESH_OT_pro_hs_select_thin_faces,
    OBJECT_OT_pro_hs_select_unapplied_scale,
    OBJECT_OT_pro_hs_fix_normals,
    MESH_OT_pro_hs_recalc_outside,
    OBJECT_OT_pro_hs_remove_loose,
    OBJECT_OT_pro_hs_merge_by_distance,
    OBJECT_OT_pro_hs_clean_cutters,
)
