# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  uv_utils.py
# UV helpers: islands, bboxes, transforms, areas, texel density,
# UV-editor context override. Pure helpers, no operators here.
# ──────────────────────────────────────────────────────────────────────

import bmesh
from mathutils import Vector

UV_EPS = 1e-6


# ═══════════════════════════════════════════════════════════════════════
#  BASIC ACCESS
# ═══════════════════════════════════════════════════════════════════════

def get_uv_bmesh(context):
    """Return (bm, mesh, uv_layer) for the edited mesh.
    Creates the UV layer if the mesh has none (bmesh verify is edit-safe)."""
    obj = context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.verify()
    return bm, me, uv_layer


def selected_faces(bm):
    return [f for f in bm.faces if f.select]


# ═══════════════════════════════════════════════════════════════════════
#  ISLAND DETECTION
# ═══════════════════════════════════════════════════════════════════════

def _edge_uv_continuous(edge, f_a, f_b, uv_layer):
    """True if faces f_a/f_b share *edge* with matching UVs (same island)."""
    def uvs_for(face):
        out = {}
        for loop in face.loops:
            if loop.edge == edge or loop.link_loop_prev.edge == edge:
                out[loop.vert.index] = loop[uv_layer].uv.copy()
        return out

    uvs_a = uvs_for(f_a)
    uvs_b = uvs_for(f_b)
    for vidx, uv_a in uvs_a.items():
        uv_b = uvs_b.get(vidx)
        if uv_b is None or (uv_a - uv_b).length > 1e-5:
            return False
    return True


def uv_islands(bm, uv_layer, faces=None):
    """Group *faces* (default: selected) into UV islands.
    Returns a list of lists of BMFace."""
    if faces is None:
        faces = selected_faces(bm)
    face_set = set(faces)
    seen = set()
    islands = []

    for start in faces:
        if start in seen:
            continue
        stack = [start]
        seen.add(start)
        island = []
        while stack:
            f = stack.pop()
            island.append(f)
            for edge in f.edges:
                if edge.seam:
                    continue
                for nf in edge.link_faces:
                    if nf is f or nf not in face_set or nf in seen:
                        continue
                    if _edge_uv_continuous(edge, f, nf, uv_layer):
                        seen.add(nf)
                        stack.append(nf)
        islands.append(island)
    return islands


def island_loops(island):
    for f in island:
        for loop in f.loops:
            yield loop


def island_bbox(island, uv_layer):
    """Return (min_uv, max_uv) Vectors of the island."""
    umin = Vector((1e30, 1e30))
    umax = Vector((-1e30, -1e30))
    for loop in island_loops(island):
        uv = loop[uv_layer].uv
        umin.x = min(umin.x, uv.x)
        umin.y = min(umin.y, uv.y)
        umax.x = max(umax.x, uv.x)
        umax.y = max(umax.y, uv.y)
    return umin, umax


def transform_island(island, uv_layer, fn):
    """Apply fn(uv: Vector) -> Vector to every unique loop UV of the island."""
    done = set()
    for loop in island_loops(island):
        key = (loop.vert.index, loop.face.index)
        if key in done:
            continue
        done.add(key)
        luv = loop[uv_layer]
        luv.uv = fn(luv.uv.copy())


# ═══════════════════════════════════════════════════════════════════════
#  AREAS & TEXEL DENSITY
# ═══════════════════════════════════════════════════════════════════════

def face_uv_area_signed(face, uv_layer):
    """Signed UV area of a face (shoelace). Negative = flipped island."""
    uvs = [loop[uv_layer].uv for loop in face.loops]
    area = 0.0
    n = len(uvs)
    for i in range(n):
        a = uvs[i]
        b = uvs[(i + 1) % n]
        area += a.x * b.y - b.x * a.y
    return area * 0.5


def face_world_area(face, matrix_world):
    """World-space area of a face (fan triangulation, fine for convex faces)."""
    verts = [matrix_world @ v.co for v in face.verts]
    area = 0.0
    for i in range(1, len(verts) - 1):
        area += ((verts[i] - verts[0]).cross(verts[i + 1] - verts[0])).length * 0.5
    return area


def texel_density(faces, uv_layer, matrix_world, texture_size=1024):
    """Approximate texel density in px/m for *faces*.
    Returns (density, uv_area, world_area). Density 0 if degenerate."""
    uv_area = sum(abs(face_uv_area_signed(f, uv_layer)) for f in faces)
    world_area = sum(face_world_area(f, matrix_world) for f in faces)
    if world_area < 1e-12 or uv_area < 1e-12:
        return 0.0, uv_area, world_area
    return (uv_area / world_area) ** 0.5 * texture_size, uv_area, world_area


def scale_island_density(island, uv_layer, matrix_world, target_density,
                         texture_size=1024):
    """Scale one island around its center so it reaches target density.
    Returns the density it had before, or None if degenerate."""
    density, _, _ = texel_density(island, uv_layer, matrix_world, texture_size)
    if density <= 1e-9:
        return None
    factor = target_density / density
    umin, umax = island_bbox(island, uv_layer)
    center = (umin + umax) * 0.5
    transform_island(island, uv_layer,
                     lambda uv: center + (uv - center) * factor)
    return density


# ═══════════════════════════════════════════════════════════════════════
#  UV-EDITOR CONTEXT OVERRIDE
# ═══════════════════════════════════════════════════════════════════════

def run_in_uv_editor(context, fn):
    """Run *fn()* with the context overridden to a UV/Image editor area.

    Several native uv operators (pack_islands, average_islands_scale,
    minimize_stretch, ...) poll for an Image Editor in UV mode. From the
    3D-View N-Panel we temporarily convert an area, run, and restore.
    UV select sync is enabled so the 3D selection drives the operator.
    Returns fn()'s result.
    """
    window = context.window
    screen = window.screen
    tool_settings = context.scene.tool_settings

    prev_sync = tool_settings.use_uv_select_sync
    tool_settings.use_uv_select_sync = True

    target = None
    temp_converted = None
    prev_ui_type = None
    for area in screen.areas:
        if area.ui_type == 'UV':
            target = area
            break
    if target is None:
        # Temporarily convert the largest non-active area (or the active one)
        candidates = [a for a in screen.areas if a != context.area]
        area = max(candidates or screen.areas, key=lambda a: a.width * a.height)
        prev_ui_type = area.ui_type
        area.ui_type = 'UV'
        target = area
        temp_converted = area

    region = next(r for r in target.regions if r.type == 'WINDOW')
    try:
        with context.temp_override(window=window, area=target, region=region):
            return fn()
    finally:
        if temp_converted is not None:
            temp_converted.ui_type = prev_ui_type
        tool_settings.use_uv_select_sync = prev_sync
