# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_toon_presets.py
# Pro Cel Shading Suite: 20 professional presets + material conversion.
#
# v0.1.2.1 — TEXTURE PRESERVING APPLY MODES:
#   Default behavior now PRESERVES existing materials and textures:
#   each slot's material is converted to "TOON_<name>" keeping its base
#   texture / normal map / roughness, the original material stays in the
#   file (with fake user), and material slots are never collapsed.
#   The old replace-everything behavior is only used when the user
#   explicitly enables "Replace Material" or the object has no materials.
# ──────────────────────────────────────────────────────────────────────

import bpy

from . import node_utils


# ═══════════════════════════════════════════════════════════════════════
#  PRESET TABLE
#  suffix -> (material name, UI label, params for the cel builder)
# ═══════════════════════════════════════════════════════════════════════

PRESETS = {
    "basic_2tone": ("PRO_CEL_Basic_2Tone", "Basic 2-Tone", dict(
        base_color=(0.75, 0.75, 0.78, 1), shadow_color=(0.25, 0.25, 0.32, 1),
        bands=2, threshold=0.5)),
    "basic_3tone": ("PRO_CEL_Basic_3Tone", "Basic 3-Tone", dict(
        base_color=(0.75, 0.75, 0.78, 1), shadow_color=(0.22, 0.22, 0.30, 1),
        bands=3, threshold=0.55)),
    "anime_clean": ("PRO_CEL_Anime_Clean", "Anime Clean", dict(
        base_color=(0.82, 0.80, 0.86, 1), shadow_color=(0.46, 0.46, 0.64, 1),
        highlight_color=(0.97, 0.96, 1.0, 1), highlight_threshold=0.86,
        bands=3, threshold=0.45)),
    "anime_skin": ("PRO_CEL_Anime_Skin", "Anime Skin", dict(
        base_color=(0.95, 0.76, 0.62, 1), shadow_color=(0.82, 0.45, 0.38, 1),
        highlight_color=(1.0, 0.93, 0.85, 1), highlight_threshold=0.88,
        bands=2, threshold=0.42, softness=0.06)),
    "manga_ink": ("PRO_CEL_Manga_Ink", "Manga Ink", dict(
        base_color=(0.95, 0.95, 0.95, 1), shadow_color=(0.02, 0.02, 0.02, 1),
        bands=3, threshold=0.55)),
    "dark_comic": ("PRO_CEL_Dark_Comic", "Dark Comic", dict(
        base_color=(0.45, 0.42, 0.50, 1), shadow_color=(0.015, 0.015, 0.03, 1),
        bands=2, threshold=0.62,
        rim=True, rim_color=(0.9, 0.9, 0.95, 1), rim_strength=0.8, rim_size=0.22)),
    "pixar_toon": ("PRO_CEL_Pixar_Toon", "Pixar Toon", dict(
        base_color=(0.80, 0.60, 0.45, 1), shadow_color=(0.42, 0.30, 0.28, 1),
        highlight_color=(1.0, 0.92, 0.80, 1), highlight_threshold=0.82,
        bands=3, threshold=0.48, softness=0.12,
        specular=True, specular_size=0.3, toon_smooth=0.2)),
    "plastic_toy": ("PRO_CEL_Plastic_Toy", "Plastic Toy", dict(
        base_color=(0.90, 0.15, 0.12, 1), shadow_color=(0.45, 0.05, 0.06, 1),
        bands=2, threshold=0.5,
        specular=True, specular_size=0.08, specular_color=(1, 1, 1, 1))),
    "clay_toon": ("PRO_CEL_Clay_Toon", "Clay Toon", dict(
        base_color=(0.72, 0.45, 0.35, 1), shadow_color=(0.40, 0.24, 0.20, 1),
        bands=3, threshold=0.5, softness=0.2, toon_smooth=0.3)),
    "pastel_toon": ("PRO_CEL_Pastel_Toon", "Pastel Toon", dict(
        base_color=(0.85, 0.78, 0.92, 1), shadow_color=(0.62, 0.58, 0.78, 1),
        highlight_color=(0.98, 0.95, 1.0, 1), highlight_threshold=0.85,
        bands=2, threshold=0.4, softness=0.08)),
    "horror_flower": ("PRO_CEL_Horror_Flower", "Horror Flower", dict(
        base_color=(0.13, 0.22, 0.10, 1), shadow_color=(0.01, 0.03, 0.01, 1),
        bands=2, threshold=0.68,
        rim=True, rim_color=(0.55, 0.75, 0.45, 1), rim_strength=0.35, rim_size=0.18)),
    "supermarket_flower_style": ("PRO_CEL_Supermarket_Flower", "Supermarket Flower", dict(
        base_color=(0.70, 0.64, 0.50, 1), shadow_color=(0.32, 0.33, 0.42, 1),
        highlight_color=(0.88, 0.85, 0.75, 1), highlight_threshold=0.84,
        bands=3, threshold=0.5, softness=0.04)),
    "game_prop_toon": ("PRO_CEL_Game_Prop", "Game Prop", dict(
        base_color=(0.62, 0.62, 0.65, 1), shadow_color=(0.30, 0.30, 0.36, 1),
        bands=2, threshold=0.5,
        specular=True, specular_size=0.2)),
    "lowpoly_toon": ("PRO_CEL_Lowpoly", "Lowpoly Toon", dict(
        base_color=(0.55, 0.75, 0.55, 1), shadow_color=(0.28, 0.42, 0.30, 1),
        bands=2, threshold=0.5)),
    "ink_shadow": ("PRO_CEL_Ink_Shadow", "Ink Shadow", dict(
        base_color=(0.92, 0.90, 0.86, 1), shadow_color=(0.0, 0.0, 0.0, 1),
        bands=2, threshold=0.6)),
    "soft_cel": ("PRO_CEL_Soft", "Soft Cel", dict(
        base_color=(0.75, 0.70, 0.68, 1), shadow_color=(0.45, 0.42, 0.45, 1),
        bands=3, threshold=0.5, softness=0.25, toon_smooth=0.35)),
    "hard_cel": ("PRO_CEL_Hard", "Hard Cel", dict(
        base_color=(0.80, 0.75, 0.70, 1), shadow_color=(0.30, 0.28, 0.30, 1),
        bands=2, threshold=0.5, softness=0.0)),
    "rimlight_toon": ("PRO_CEL_Rim_Light", "Rim Light Toon", dict(
        base_color=(0.35, 0.38, 0.55, 1), shadow_color=(0.12, 0.13, 0.25, 1),
        bands=2, threshold=0.52,
        rim=True, rim_color=(0.95, 0.85, 0.60, 1), rim_strength=1.0, rim_size=0.35)),
    "halftone_comic": ("PRO_CEL_Halftone", "Halftone Comic", dict(
        base_color=(0.90, 0.87, 0.80, 1), shadow_color=(0.10, 0.08, 0.08, 1),
        bands=2, threshold=0.55, halftone=True, halftone_scale=90.0)),
    "posterized_shader": ("PRO_CEL_Posterized", "Posterized", dict(
        base_color=(0.85, 0.55, 0.30, 1), shadow_color=(0.15, 0.10, 0.25, 1),
        posterize_levels=5)),

    # ── v0.1.2.1 — showcase / stylized-PBR presets ───────────────
    "deluxe": ("PRO_CEL_Deluxe", "Deluxe", dict(
        base_color=(0.78, 0.70, 0.62, 1), shadow_color=(0.30, 0.26, 0.40, 1),
        highlight_color=(0.32, 0.27, 0.20, 1), highlight_threshold=0.80,
        bands=3, threshold=0.5, softness=0.05, shadow_density=0.88,
        specular=True, specular_size=0.18,
        rim=True, rim_color=(0.90, 0.85, 0.72, 1), rim_strength=0.5, rim_size=0.30,
        saturation=1.10, pbr_mix=0.25, toon_smooth=0.15)),
    "silent_saints": ("PRO_CEL_Silent_Saints", "Silent Saints", dict(
        base_color=(0.35, 0.36, 0.42, 1), shadow_color=(0.04, 0.05, 0.10, 1),
        bands=2, threshold=0.62, shadow_density=0.95, saturation=0.92,
        rim=True, rim_color=(0.50, 0.72, 0.85, 1), rim_strength=0.85, rim_size=0.24,
        pbr_mix=0.12)),
    "stylized_pbr_hero_prop": ("PRO_CEL_Stylized_Hero_Prop", "PBR Hero Prop", dict(
        base_color=(0.70, 0.62, 0.52, 1), shadow_color=(0.28, 0.27, 0.38, 1),
        highlight_color=(0.28, 0.25, 0.18, 1), highlight_threshold=0.82,
        bands=3, threshold=0.5, softness=0.08, shadow_density=0.85,
        saturation=1.15, specular=True, specular_size=0.25,
        pbr_mix=0.35, pbr_roughness=0.4, toon_smooth=0.2)),
    "stylized_pbr_vehicle": ("PRO_CEL_Stylized_Vehicle", "PBR Vehicle", dict(
        base_color=(0.55, 0.58, 0.65, 1), shadow_color=(0.18, 0.20, 0.30, 1),
        bands=2, threshold=0.52, softness=0.04, shadow_density=0.88,
        saturation=1.08, specular=True, specular_size=0.08,
        rim=True, rim_color=(0.95, 0.97, 1.0, 1), rim_strength=0.4, rim_size=0.2,
        pbr_mix=0.40, pbr_roughness=0.25, toon_smooth=0.1)),
    "stylized_pbr_product_box": ("PRO_CEL_Stylized_Product_Box", "PBR Product Box", dict(
        base_color=(0.80, 0.74, 0.62, 1), shadow_color=(0.38, 0.38, 0.50, 1),
        bands=2, threshold=0.45, softness=0.06, shadow_density=0.78,
        saturation=1.10, pbr_mix=0.30, pbr_roughness=0.55)),
    "stylized_pbr_environment": ("PRO_CEL_Stylized_Environment", "PBR Environment", dict(
        base_color=(0.62, 0.62, 0.56, 1), shadow_color=(0.30, 0.33, 0.44, 1),
        bands=3, threshold=0.55, softness=0.15, shadow_density=0.72,
        saturation=1.05, pbr_mix=0.30, pbr_roughness=0.65, toon_smooth=0.3)),
    "trailer_look": ("PRO_CEL_Trailer_Look", "Trailer Look", dict(
        base_color=(0.60, 0.55, 0.50, 1), shadow_color=(0.05, 0.09, 0.14, 1),
        highlight_color=(0.35, 0.22, 0.10, 1), highlight_threshold=0.84,
        bands=2, threshold=0.58, shadow_density=0.95, saturation=1.12,
        rim=True, rim_color=(1.0, 0.75, 0.45, 1), rim_strength=0.9, rim_size=0.28,
        pbr_mix=0.15)),
}

PRESET_ENUM_ITEMS = [
    (suffix.upper(), label, f"Apply the {label} cel material")
    for suffix, (_mat, label, _p) in PRESETS.items()
]


def _target_objects(context):
    objs = [o for o in context.selected_objects if o.type == 'MESH']
    active = context.active_object
    if active and active.type == 'MESH' and active not in objs:
        objs.append(active)
    return objs


def _toon_name(orig_name):
    return orig_name if orig_name.startswith("TOON_") else f"TOON_{orig_name}"


def apply_preset(context, suffix):
    """Apply a cel preset honoring the Application Mode settings.

    Returns (label_message, stats dict).
    Modes (scene.pro_toolkit):
      cel_replace_material         -> old behavior: one flat preset material
      cel_preserve_existing_texture-> convert each slot keeping textures
      cel_duplicate_original_material -> originals kept (slot gets TOON_ copy)
      cel_keep_original_material_slot -> originals protected with fake user
      cel_apply_to_all_material_slots -> every slot vs active slot only
    """
    props = context.scene.pro_toolkit
    mat_name, label, params = PRESETS[suffix]
    stats = {"objects": 0, "converted_slots": 0, "plain": 0,
             "textures_kept": 0, "normals_kept": 0}

    plain_mat = None

    def get_plain():
        nonlocal plain_mat
        if plain_mat is None:
            plain_mat = node_utils.build_cel_material(mat_name, params)
        return plain_mat

    toon_cache = {}

    def get_toon_for(orig):
        key = orig.name
        if key in toon_cache:
            return toon_cache[key]
        name = _toon_name(orig.name)
        if props.cel_preserve_existing_texture:
            toon, info = node_utils.build_texture_preserving_toon_material(
                orig, name, params, preserve_texture=True)
            if info["kept_base_texture"]:
                stats["textures_kept"] += 1
            if info["kept_normal_map"]:
                stats["normals_kept"] += 1
        else:
            src = node_utils.detect_base_color_source(orig)
            p2 = dict(params)
            p2["base_color"] = src["base_color"]
            toon = node_utils.build_cel_material(name, p2)
        if props.cel_keep_original_material_slot and not orig.name.startswith("TOON_"):
            orig.use_fake_user = True
        toon_cache[key] = toon
        return toon

    for obj in _target_objects(context):
        stats["objects"] += 1
        has_real_mat = any(s.material is not None for s in obj.material_slots)

        # Case A (no materials) or explicit Replace mode: flat preset
        if props.cel_replace_material or not has_real_mat:
            node_utils.assign_material(obj, get_plain())
            stats["plain"] += 1
            continue

        # Case B: preserve — convert per slot, keep slot count/assignments
        if props.cel_apply_to_all_material_slots:
            slots = list(obj.material_slots)
        else:
            slots = [obj.material_slots[obj.active_material_index]]
        for slot in slots:
            if slot.material is None:
                slot.material = get_plain()
                stats["plain"] += 1
                continue
            if not props.cel_duplicate_original_material:
                # in-place: rebuild this material's nodes as toon (Undo-able)
                orig = slot.material
                if props.cel_preserve_existing_texture:
                    toon, _info = node_utils.build_texture_preserving_toon_material(
                        orig, orig.name, params, preserve_texture=True)
                else:
                    src = node_utils.detect_base_color_source(orig)
                    p2 = dict(params)
                    p2["base_color"] = src["base_color"]
                    node_utils.build_cel_material(orig.name, p2)
            else:
                slot.material = get_toon_for(slot.material)
            stats["converted_slots"] += 1

    msg = (f"{label}: {stats['converted_slots']} slot(s) converted, "
           f"{stats['textures_kept']} texture(s) kept, "
           f"{stats['plain']} flat apply")
    return msg, stats


# ═══════════════════════════════════════════════════════════════════════
#  20 PRESET OPERATORS (factory — one stable bl_idname per preset)
# ═══════════════════════════════════════════════════════════════════════

def _make_preset_op(suffix):
    mat_name, label, _params = PRESETS[suffix]

    class _Op(bpy.types.Operator):
        bl_idname = f"object.pro_cel_apply_{suffix}"
        bl_label = label
        bl_description = (f"Apply the {label} cel material ({mat_name}). "
                          "Preserves existing textures by default")
        bl_options = {'REGISTER', 'UNDO'}

        @classmethod
        def poll(cls, context):
            return (context.active_object is not None
                    and context.active_object.type == 'MESH')

        def execute(self, context):
            # *suffix* is captured from the enclosing factory scope
            msg, _stats = apply_preset(context, suffix)
            self.report({'INFO'}, msg)
            return {'FINISHED'}

    _Op.__name__ = f"OBJECT_OT_pro_cel_apply_{suffix}"
    return _Op


_preset_op_classes = tuple(_make_preset_op(suffix) for suffix in PRESETS)


class OBJECT_OT_pro_cel_apply_selected_preset(bpy.types.Operator):
    """Apply the preset chosen in the Cel Shader Controls panel"""
    bl_idname = "object.pro_cel_apply_selected_preset"
    bl_label = "Apply Selected Preset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        suffix = context.scene.pro_toolkit.cel_material_preset.lower()
        if suffix not in PRESETS:
            self.report({'WARNING'}, f"Unknown preset: {suffix}")
            return {'CANCELLED'}
        msg, _stats = apply_preset(context, suffix)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  MATERIAL CONVERSION  (original material is never destroyed)
# ═══════════════════════════════════════════════════════════════════════

def _toon_params_from_color(base):
    """Derive pleasant toon params from an existing base color."""
    r, g, b = base[0], base[1], base[2]
    shadow = (max(0.05, r * 0.45), max(0.05, g * 0.45),
              max(0.08, b * 0.6), 1.0)            # darker, cool-shifted tint
    highlight = (min(1.0, r * 0.25 + 0.15),
                 min(1.0, g * 0.25 + 0.15),
                 min(1.0, b * 0.25 + 0.15), 1.0)  # additive highlight
    return dict(base_color=(r, g, b, 1.0), shadow_color=shadow,
                highlight_color=highlight, highlight_threshold=0.85,
                bands=3, threshold=0.5)


def _convert_material_to_toon(mat, preserve_texture=True):
    """Create TOON_<name> from *mat* keeping its textures.
    Returns (new material, info dict)."""
    src_name = mat.name if mat else "Material"
    base = node_utils.get_base_color(mat)
    params = _toon_params_from_color(base)
    if mat is None:
        return node_utils.build_cel_material(f"TOON_{src_name}", params), {}
    return node_utils.build_texture_preserving_toon_material(
        mat, _toon_name(src_name), params, preserve_texture=preserve_texture)


class OBJECT_OT_pro_cel_convert_active_material(bpy.types.Operator):
    """Convert the active material slot to a toon version (original + textures kept)"""
    bl_idname = "object.pro_cel_convert_active_material"
    bl_label = "Convert Active Material"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        props = context.scene.pro_toolkit
        if not obj.material_slots:
            self.report({'WARNING'}, "Object has no materials. "
                                     "Use a cel preset instead.")
            return {'CANCELLED'}
        slot = obj.material_slots[obj.active_material_index]
        toon, info = _convert_material_to_toon(
            slot.material, preserve_texture=props.cel_preserve_existing_texture)
        if slot.material is not None and props.cel_keep_original_material_slot:
            slot.material.use_fake_user = True
        slot.material = toon
        kept = " (base texture kept)" if info.get("kept_base_texture") else ""
        self.report({'INFO'},
                    f"Converted to {toon.name}{kept} - original kept in file")
        return {'FINISHED'}


class OBJECT_OT_pro_cel_convert_selected_materials(bpy.types.Operator):
    """Convert every material of the selected objects to toon versions"""
    bl_idname = "object.pro_cel_convert_selected_materials"
    bl_label = "Convert Selected Objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        props = context.scene.pro_toolkit
        converted = textures = 0
        cache = {}
        for obj in _target_objects(context):
            for slot in obj.material_slots:
                if slot.material is None:
                    continue
                key = slot.material.name
                if key not in cache:
                    toon, info = _convert_material_to_toon(
                        slot.material,
                        preserve_texture=props.cel_preserve_existing_texture)
                    if info.get("kept_base_texture"):
                        textures += 1
                    if props.cel_keep_original_material_slot:
                        slot.material.use_fake_user = True
                    cache[key] = toon
                slot.material = cache[key]
                converted += 1
        self.report({'INFO'},
                    f"Converted {converted} slot(s) "
                    f"({len(cache)} toon materials, {textures} with texture, "
                    "originals kept)")
        return {'FINISHED'}


class OBJECT_OT_pro_cel_duplicate_as_toon(bpy.types.Operator):
    """Create TOON_<name> from the active material WITHOUT assigning it"""
    bl_idname = "object.pro_cel_duplicate_as_toon"
    bl_label = "Duplicate as Toon"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH'
                and obj.active_material is not None)

    def execute(self, context):
        toon, info = _convert_material_to_toon(
            context.active_object.active_material)
        kept = " (base texture kept)" if info.get("kept_base_texture") else ""
        self.report({'INFO'},
                    f"Created {toon.name}{kept} - not assigned, pick it in "
                    "the material slot when ready")
        return {'FINISHED'}


classes = _preset_op_classes + (
    OBJECT_OT_pro_cel_apply_selected_preset,
    OBJECT_OT_pro_cel_convert_active_material,
    OBJECT_OT_pro_cel_convert_selected_materials,
    OBJECT_OT_pro_cel_duplicate_as_toon,
)
