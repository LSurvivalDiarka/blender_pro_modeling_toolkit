# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_panels.py
# v0.1.4 Hard Surface Pro Suite: panel and surface-detail generators.
# Everything here creates clean quad-based standalone geometry (no
# destructive booleans, no n-gons). Panels stand in the XZ plane with
# their thickness along Y, base at Z = 0, ready to snap onto a surface.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu
from . import hardsurface_utils as hs


class _PanelOp:
    bl_options = {'REGISTER', 'UNDO'}
    pro_collection = hs.COLL_HS_PANELS
    pro_material = "HS_Panel_Grey"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        bm = bmesh.new()
        name = self.build(context, bm)
        hs.finalize_hs_object(context, self, name, bm,
                              self.pro_collection, self.pro_material)
        return {'FINISHED'}


class OBJECT_OT_pro_hs_create_panel_inset(_PanelOp, bpy.types.Operator):
    """Create a panel with a recessed inner field (classic inset panel)"""
    bl_idname = "object.pro_hs_create_panel_inset"
    bl_label = "Create Panel Inset"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.width, self.height = p.hs_panel_width, p.hs_panel_height
        self.depth, self.margin = p.hs_panel_depth, p.hs_panel_margin
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.05, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.05, soft_max=4.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.02, min=0.004, soft_max=0.3, unit='LENGTH')
    margin: bpy.props.FloatProperty(name="Margin", default=0.03, min=0.005, soft_max=0.5, unit='LENGTH')

    def build(self, context, bm):
        m = min(self.margin, self.width / 3.0, self.height / 3.0)
        hs.add_panel_with_field(bm, self.width, self.height, self.depth,
                                m, self.depth * 0.4)
        return "HS_Panel_Inset"


class OBJECT_OT_pro_hs_create_panel_border(_PanelOp, bpy.types.Operator):
    """Create a flat border frame to trim around an existing panel"""
    bl_idname = "object.pro_hs_create_panel_border"
    bl_label = "Create Panel Border"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.width, self.height = p.hs_panel_width, p.hs_panel_height
        self.margin = p.hs_panel_margin
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.05, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.05, soft_max=4.0, unit='LENGTH')
    margin: bpy.props.FloatProperty(name="Border Width", default=0.03, min=0.005, soft_max=0.5, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.01, min=0.002, soft_max=0.2, unit='LENGTH')

    def build(self, context, bm):
        w, h, b, d = self.width, self.height, self.margin, self.depth
        ih = h - 2 * b
        cu.add_box(bm, w, d, b)                              # bottom
        cu.add_box(bm, w, d, b, z0=h - b)                    # top
        cu.add_box(bm, b, d, ih, cx=-(w - b) / 2.0, z0=b)    # left
        cu.add_box(bm, b, d, ih, cx=(w - b) / 2.0, z0=b)     # right
        return "HS_Panel_Border"


class OBJECT_OT_pro_hs_create_groove(_PanelOp, bpy.types.Operator):
    """Create a groove strip: two raised rails leaving a recessed channel"""
    bl_idname = "object.pro_hs_create_groove"
    bl_label = "Create Groove"

    length: bpy.props.FloatProperty(name="Length", default=0.6, min=0.02, soft_max=4.0, unit='LENGTH')
    groove_width: bpy.props.FloatProperty(name="Groove Width", default=0.01, min=0.002, soft_max=0.2, unit='LENGTH')
    rail_width: bpy.props.FloatProperty(name="Rail Width", default=0.02, min=0.004, soft_max=0.3, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.008, min=0.002, soft_max=0.1, unit='LENGTH')

    def build(self, context, bm):
        g, r = self.groove_width, self.rail_width
        cu.add_box(bm, self.length, r, self.depth, cy=-(g + r) / 2.0)
        cu.add_box(bm, self.length, r, self.depth, cy=(g + r) / 2.0)
        cu.add_box(bm, self.length, g, self.depth * 0.35)    # channel floor
        return "HS_Groove"


class OBJECT_OT_pro_hs_create_slot(_PanelOp, bpy.types.Operator):
    """Create a slot plate: a thin plate with a rectangular opening"""
    bl_idname = "object.pro_hs_create_slot"
    bl_label = "Create Slot"

    width: bpy.props.FloatProperty(name="Plate Width", default=0.25, min=0.02, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Plate Height", default=0.1, min=0.02, soft_max=2.0, unit='LENGTH')
    slot_length: bpy.props.FloatProperty(name="Slot Length", default=0.15, min=0.01, soft_max=2.0, unit='LENGTH')
    slot_height: bpy.props.FloatProperty(name="Slot Height", default=0.02, min=0.004, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.01, min=0.002, soft_max=0.2, unit='LENGTH')

    def build(self, context, bm):
        w, h, d = self.width, self.height, self.depth
        sl = min(self.slot_length, w * 0.9)
        sh = min(self.slot_height, h * 0.6)
        side = (w - sl) / 2.0
        band = (h - sh) / 2.0
        cu.add_box(bm, w, d, band)                            # below slot
        cu.add_box(bm, w, d, band, z0=h - band)               # above slot
        cu.add_box(bm, side, d, sh, cx=-(w - side) / 2.0, z0=band)
        cu.add_box(bm, side, d, sh, cx=(w - side) / 2.0, z0=band)
        return "HS_Slot_Plate"


class OBJECT_OT_pro_hs_create_vent_lines(_PanelOp, bpy.types.Operator):
    """Create a strip of parallel vent slats (no frame)"""
    bl_idname = "object.pro_hs_create_vent_lines"
    bl_label = "Create Vent Lines"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.count = p.hs_panel_count
        self.spacing = p.hs_panel_spacing
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.4, min=0.02, soft_max=2.0, unit='LENGTH')
    count: bpy.props.IntProperty(name="Lines", default=5, min=1, max=40)
    spacing: bpy.props.FloatProperty(name="Spacing", default=0.02, min=0.004, soft_max=0.2, unit='LENGTH')
    slat_height: bpy.props.FloatProperty(name="Slat Height", default=0.01, min=0.002, soft_max=0.1, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.008, min=0.002, soft_max=0.1, unit='LENGTH')

    def build(self, context, bm):
        for i in range(self.count):
            cu.add_box(bm, self.width, self.depth, self.slat_height,
                       z0=i * (self.slat_height + self.spacing))
        return "HS_Vent_Lines"


class OBJECT_OT_pro_hs_create_grille(_PanelOp, bpy.types.Operator):
    """Create a grille: frame with crossing horizontal and vertical bars"""
    bl_idname = "object.pro_hs_create_grille"
    bl_label = "Create Grille"

    width: bpy.props.FloatProperty(name="Width", default=0.4, min=0.05, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.3, min=0.05, soft_max=2.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.015, min=0.004, soft_max=0.2, unit='LENGTH')
    bars_h: bpy.props.IntProperty(name="Horizontal Bars", default=4, min=0, max=20)
    bars_v: bpy.props.IntProperty(name="Vertical Bars", default=6, min=0, max=20)

    def build(self, context, bm):
        w, h, d, f, b = self.width, self.height, self.depth, 0.02, 0.006
        cu.add_box(bm, f, d, h, cx=-(w - f) / 2.0)
        cu.add_box(bm, f, d, h, cx=(w - f) / 2.0)
        cu.add_box(bm, w - 2 * f, d, f)
        cu.add_box(bm, w - 2 * f, d, f, z0=h - f)
        iw, ih = w - 2 * f, h - 2 * f
        for i in range(1, self.bars_h + 1):
            z = f + ih * i / (self.bars_h + 1)
            cu.add_box(bm, iw, d * 0.6, b, z0=z - b / 2.0)
        for i in range(1, self.bars_v + 1):
            x = -iw / 2.0 + iw * i / (self.bars_v + 1)
            cu.add_box(bm, b, d * 0.6, ih, cx=x, z0=f)
        return "HS_Grille"


class OBJECT_OT_pro_hs_create_door_panel(_PanelOp, bpy.types.Operator):
    """Create a metal door leaf with a recessed center panel"""
    bl_idname = "object.pro_hs_create_door_panel"
    bl_label = "Create Door Panel"
    pro_material = "HS_Metal_Light"

    width: bpy.props.FloatProperty(name="Width", default=0.9, min=0.3, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.0, min=0.5, soft_max=3.5, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.05, min=0.02, soft_max=0.2, unit='LENGTH')
    margin: bpy.props.FloatProperty(name="Margin", default=0.1, min=0.02, soft_max=0.5, unit='LENGTH')

    def build(self, context, bm):
        m = min(self.margin, self.width / 3.0, self.height / 3.0)
        hs.add_panel_with_field(bm, self.width, self.height, self.depth,
                                m, self.depth * 0.3)
        return "HS_Door_Panel"


class OBJECT_OT_pro_hs_create_machine_panel(_PanelOp, bpy.types.Operator):
    """Create a machine front panel: recessed field with a row of raised
    control blocks"""
    bl_idname = "object.pro_hs_create_machine_panel"
    bl_label = "Create Machine Panel"
    pro_material = "HS_Metal_Dark"

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.1, soft_max=3.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.1, soft_max=3.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.03, min=0.01, soft_max=0.2, unit='LENGTH')
    controls: bpy.props.IntProperty(name="Control Blocks", default=3, min=0, max=8)

    def build(self, context, bm):
        w, h, d = self.width, self.height, self.depth
        m = min(0.04, w / 4.0, h / 4.0)
        hs.add_panel_with_field(bm, w, h, d, m, d * 0.3)
        # raised control blocks on the lower strip of the field
        if self.controls:
            bw = 0.05
            span = (w - 2 * m) / self.controls
            for i in range(self.controls):
                x = -(w - 2 * m) / 2.0 + span * (i + 0.5)
                cu.add_box(bm, min(bw, span * 0.6), d * 0.5, 0.03,
                           cx=x, cy=d * 0.35, z0=m + 0.03)
        return "HS_Machine_Panel"


class OBJECT_OT_pro_hs_create_fridge_door_panel(_PanelOp, bpy.types.Operator):
    """Create a fridge door panel sized for the SF fridge blockout:
    frame with recessed glass-window field"""
    bl_idname = "object.pro_hs_create_fridge_door_panel"
    bl_label = "Create Fridge Door Panel"
    pro_material = "HS_Metal_Light"
    pro_collection = hs.COLL_HS_SUPERMARKET

    width: bpy.props.FloatProperty(name="Width", default=0.55, min=0.3, soft_max=1.2, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=1.5, min=0.6, soft_max=2.2, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.04, min=0.02, soft_max=0.12, unit='LENGTH')
    margin: bpy.props.FloatProperty(name="Frame Width", default=0.06, min=0.02, soft_max=0.2, unit='LENGTH')

    def build(self, context, bm):
        m = min(self.margin, self.width / 3.0, self.height / 3.0)
        hs.add_panel_with_field(bm, self.width, self.height, self.depth,
                                m, self.depth * 0.5)
        return "HS_Fridge_Door_Panel"


class OBJECT_OT_pro_hs_create_register_panel(_PanelOp, bpy.types.Operator):
    """Create a sloped register keypad panel (wedge)"""
    bl_idname = "object.pro_hs_create_register_panel"
    bl_label = "Create Register Panel"
    pro_material = "HS_Plastic_Black"

    width: bpy.props.FloatProperty(name="Width", default=0.3, min=0.1, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.25, min=0.1, soft_max=1.0, unit='LENGTH')
    height_back: bpy.props.FloatProperty(name="Back Height", default=0.08, min=0.02, soft_max=0.4, unit='LENGTH')
    height_front: bpy.props.FloatProperty(name="Front Height", default=0.03, min=0.01, soft_max=0.4, unit='LENGTH')

    def build(self, context, bm):
        hs.add_wedge(bm, self.width, self.depth,
                     self.height_back, self.height_front)
        return "HS_Register_Panel"


class OBJECT_OT_pro_hs_create_raised_panel(_PanelOp, bpy.types.Operator):
    """Create a panel with a raised center field"""
    bl_idname = "object.pro_hs_create_raised_panel"
    bl_label = "Create Raised Panel"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.width, self.height = p.hs_panel_width, p.hs_panel_height
        self.depth, self.margin = p.hs_panel_depth, p.hs_panel_margin
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.05, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.05, soft_max=4.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.02, min=0.004, soft_max=0.3, unit='LENGTH')
    margin: bpy.props.FloatProperty(name="Margin", default=0.03, min=0.005, soft_max=0.5, unit='LENGTH')

    def build(self, context, bm):
        m = min(self.margin, self.width / 3.0, self.height / 3.0)
        hs.add_panel_with_field(bm, self.width, self.height, self.depth,
                                m, -self.depth * 0.4)
        return "HS_Raised_Panel"


class OBJECT_OT_pro_hs_create_recessed_panel(_PanelOp, bpy.types.Operator):
    """Create a panel with a recessed center field"""
    bl_idname = "object.pro_hs_create_recessed_panel"
    bl_label = "Create Recessed Panel"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.width, self.height = p.hs_panel_width, p.hs_panel_height
        self.depth, self.margin = p.hs_panel_depth, p.hs_panel_margin
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.05, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.05, soft_max=4.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Thickness", default=0.02, min=0.004, soft_max=0.3, unit='LENGTH')
    margin: bpy.props.FloatProperty(name="Margin", default=0.03, min=0.005, soft_max=0.5, unit='LENGTH')

    def build(self, context, bm):
        m = min(self.margin, self.width / 3.0, self.height / 3.0)
        hs.add_panel_with_field(bm, self.width, self.height, self.depth,
                                m, self.depth * 0.5)
        return "HS_Recessed_Panel"


classes = (
    OBJECT_OT_pro_hs_create_panel_inset,
    OBJECT_OT_pro_hs_create_panel_border,
    OBJECT_OT_pro_hs_create_groove,
    OBJECT_OT_pro_hs_create_slot,
    OBJECT_OT_pro_hs_create_vent_lines,
    OBJECT_OT_pro_hs_create_grille,
    OBJECT_OT_pro_hs_create_door_panel,
    OBJECT_OT_pro_hs_create_machine_panel,
    OBJECT_OT_pro_hs_create_fridge_door_panel,
    OBJECT_OT_pro_hs_create_register_panel,
    OBJECT_OT_pro_hs_create_raised_panel,
    OBJECT_OT_pro_hs_create_recessed_panel,
)
