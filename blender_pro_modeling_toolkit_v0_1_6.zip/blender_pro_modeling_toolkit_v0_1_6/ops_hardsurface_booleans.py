# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_booleans.py
# v0.1.5.1 Boolean Workflow repair.
#
# THE RULES (never broken):
#   - the Boolean modifier ALWAYS goes on the TARGET object,
#   - the cutter is ALWAYS the modifier's operand, never the recipient,
#   - DIFFERENCE by default, solver EXACT when available,
#   - nothing is applied automatically; Apply is explicit + backed up.
#
# Cutters: prefix CUT_, collection PRO_Cutters, material CUTTER_Red,
# wire display, no render. The old v0.1.4 convention (HS_Cutter_*,
# PRO_HardSurface_Cutters) is still recognised everywhere for
# compatibility with existing scenes.
# ──────────────────────────────────────────────────────────────────────

from math import cos, sin, pi

import bpy
import bmesh
from mathutils import Vector

from . import core_toolkit
from . import creation_utils as cu
from . import hardsurface_utils as hs

COLL_CUTTERS = "PRO_Cutters"
LEGACY_COLL = hs.COLL_HS_CUTTERS            # PRO_HardSurface_Cutters
CUTTER_PREFIXES = ("CUT_", "HS_Cutter")


def _cutter_material(name="CUTTER_Red"):
    """CUTTER_Red / CUTTER_Orange simple materials (created on demand)."""
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    color = (0.85, 0.10, 0.10, 1.0) if "Red" in name else (0.90, 0.45, 0.05, 1.0)
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Roughness"].default_value = 0.8
    mat.diffuse_color = color
    return mat


def _setup_cutter(obj):
    """Common cutter look: wire display, visible in front, no render."""
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    obj.hide_render = True


def _is_cutter(obj):
    if obj is None or obj.type != 'MESH':
        return False
    if obj.name.startswith(CUTTER_PREFIXES):
        return True
    for coll in obj.users_collection:
        if coll.name in (COLL_CUTTERS, LEGACY_COLL):
            return True
    for slot in obj.material_slots:
        if slot.material and slot.material.name.startswith(("CUTTER_", "HS_Cutter")):
            return True
    return obj.display_type == 'WIRE'


def _all_cutters():
    """Every cutter in either cutter collection plus prefixed strays."""
    objs = set()
    for cname in (COLL_CUTTERS, LEGACY_COLL):
        coll = bpy.data.collections.get(cname)
        if coll:
            objs.update(o for o in coll.objects if o.type == 'MESH')
    for o in bpy.data.objects:
        if o.type == 'MESH' and o.name.startswith(CUTTER_PREFIXES):
            objs.add(o)
    return objs


def _used_cutters():
    used = set()
    for o in bpy.data.objects:
        for m in o.modifiers:
            if m.type == 'BOOLEAN' and m.object is not None:
                used.add(m.object)
    return used


def _link_to_cutters(context, obj):
    coll = bpy.data.collections.get(COLL_CUTTERS)
    if coll is None:
        coll = bpy.data.collections.new(COLL_CUTTERS)
    if COLL_CUTTERS not in context.scene.collection.children:
        try:
            context.scene.collection.children.link(coll)
        except RuntimeError:
            pass
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)


def _bbox_overlap(a, b):
    """World-space AABB overlap test (intersection heuristic)."""
    def box(o):
        cs = [o.matrix_world @ Vector(c) for c in o.bound_box]
        return (Vector((min(c[i] for c in cs) for i in range(3))),
                Vector((max(c[i] for c in cs) for i in range(3))))
    alo, ahi = box(a)
    blo, bhi = box(b)
    return all(alo[i] <= bhi[i] and ahi[i] >= blo[i] for i in range(3))


def _add_boolean(self, context, target, cutters, operation, allow_hide=True):
    """Core: add Boolean modifiers ON THE TARGET, cutters as operands.
    Implements naming, EXACT solver, duplicate/scale/intersection warnings
    and the hide-after-add option. Returns number added."""
    props = context.scene.pro_toolkit
    existing = {m.object for m in target.modifiers
                if m.type == 'BOOLEAN' and m.object is not None}
    if hs.has_unapplied_scale(target):
        self.report({'WARNING'},
                    f"'{target.name}' tiene escala sin aplicar "
                    f"{tuple(round(s, 3) for s in target.scale)} — el corte "
                    "puede deformarse. Considera Apply Scale.")
    added = 0
    short = {'DIFFERENCE': 'DIFF', 'UNION': 'UNION', 'INTERSECT': 'INTERSECT'}
    for cutter in cutters:
        if cutter is target:
            continue
        if cutter in existing:
            self.report({'WARNING'},
                        f"'{target.name}' ya tiene un Boolean con "
                        f"'{cutter.name}' — no se duplica.")
            continue
        if not _bbox_overlap(target, cutter):
            self.report({'WARNING'},
                        f"'{cutter.name}' no parece intersectar a "
                        f"'{target.name}' (bounding boxes separados) — el "
                        "boolean se añade igualmente.")
        mod = target.modifiers.new(
            f"HS_BOOL_{short[operation]}_{cutter.name}", 'BOOLEAN')
        mod.operation = operation
        mod.object = cutter
        if props.hs_boolean_use_exact_solver and hasattr(mod, "solver"):
            try:
                mod.solver = 'EXACT'
            except TypeError:
                pass
        _setup_cutter(cutter)
        if not any(c.name in (COLL_CUTTERS, LEGACY_COLL)
                   for c in cutter.users_collection):
            _link_to_cutters(context, cutter)
        if not cutter.name.startswith(CUTTER_PREFIXES):
            cutter.name = f"CUT_{cutter.name}"
        if allow_hide and props.hs_boolean_hide_cutter_after_add:
            cutter.hide_set(True)
        added += 1
    return added


def _resolve_target_and_cutters(self, context):
    """Cases A–E of the boolean workflow. Returns (target, cutters) or
    (None, None) after reporting a clear error."""
    props = context.scene.pro_toolkit
    stored = props.hs_boolean_target_object
    if stored is not None and stored.name not in context.scene.objects:
        stored = None                       # target was deleted
        props.hs_boolean_target_object = None
    active = context.view_layer.objects.active
    selected = [o for o in context.selected_objects if o.type == 'MESH']

    # who is a cutter among the selection?
    sel_cutters = [o for o in selected if _is_cutter(o) and o is not stored]

    # Case B: target + cutter both selected, no stored target needed
    if stored is None:
        non_cutters = [o for o in selected if not _is_cutter(o)]
        if len(non_cutters) == 1 and sel_cutters:
            return non_cutters[0], sel_cutters

    # Cases A & C: stored target + (selected cutters or active cutter or last)
    target = stored
    if target is None:
        # Case D
        self.report({'ERROR'},
                    "No Boolean Target set. Select the object to cut and "
                    "press Set Boolean Target.")
        return None, None

    cutters = sel_cutters
    if not cutters and active is not None and _is_cutter(active) \
            and active is not target:
        cutters = [active]
    if not cutters:
        last = props.hs_last_created_cutter
        if last is not None and last.name in context.scene.objects \
                and last is not target:
            cutters = [last]
    if not cutters:
        # Case E
        self.report({'ERROR'},
                    "No cutter selected. Select a cutter or create one first.")
        return None, None
    return target, cutters


def _auto_boolean_target(context):
    """Target for the automatic Difference added on cutter creation.
    Priority: active mesh, then first selected mesh, then the stored
    Boolean Target. Cutters are never targets (so creating a second
    cutter while the first is still active falls back correctly)."""
    props = context.scene.pro_toolkit
    active = context.view_layer.objects.active
    if (active is not None and active.type == 'MESH'
            and active.name in context.scene.objects
            and not _is_cutter(active)):
        return active
    for o in context.selected_objects:
        if o.type == 'MESH' and not _is_cutter(o):
            return o
    stored = props.hs_boolean_target_object
    if stored is not None and stored.name in context.scene.objects:
        return stored
    return None


# ═══════════════════════════════════════════════════════════════════════
#  CUTTER CREATION (CUT_ prefix, PRO_Cutters, CUTTER_Red, last-cutter)
# ═══════════════════════════════════════════════════════════════════════

class _CutterCreateOp:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        # resolve the target BEFORE creating the cutter — afterwards the
        # cutter becomes the active object and the selection is gone
        target = _auto_boolean_target(context)
        bm = bmesh.new()
        name = self.build(context, bm)
        if bm.faces:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        me = bpy.data.meshes.new(name)
        bm.to_mesh(me)
        bm.free()

        obj = bpy.data.objects.new(name, me)
        _link_to_cutters(context, obj)
        obj.location = context.scene.cursor.location.copy()
        if obj.data.materials:
            obj.data.materials[0] = _cutter_material()
        else:
            obj.data.materials.append(_cutter_material())
        _setup_cutter(obj)

        # the cutter stays active & selected so the user can move it;
        # the stored boolean target is NOT touched
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        props.hs_last_created_cutter = obj

        # automatic Boolean Difference on the resolved target (the cutter
        # is the operand, never the recipient). allow_hide=False: the user
        # still has to place the freshly created cutter.
        added = 0
        if target is not None:
            # refresh matrix_world of the new cutter so the bbox
            # intersection warning checks its real position
            context.view_layer.update()
            added = _add_boolean(self, context, target, [obj],
                                 'DIFFERENCE', allow_hide=False)

        if added:
            self.report({'INFO'},
                        f"'{obj.name}' creado y cortando '{target.name}' "
                        "(Boolean Difference, no destructivo). Muévelo "
                        "para ajustar el corte.")
        elif target is None:
            self.report({'WARNING'},
                        f"'{obj.name}' creado, pero no hay ningún mesh "
                        "válido seleccionado — no se añadió ningún "
                        "boolean. Selecciona el objeto a cortar y usa "
                        "Add Difference to Target.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_create_box_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create a box cutter at the 3D cursor (wire, PRO_Cutters)"""
    bl_idname = "object.pro_hs_create_box_cutter"
    bl_label = "Create Box Cutter"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.width, self.depth, self.height = p.hs_cutter_width, p.hs_cutter_depth, p.hs_cutter_height
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.depth, self.height,
                   z0=-self.height / 2.0)
        return "CUT_Box"


class OBJECT_OT_pro_hs_create_cylinder_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create a vertical cylinder cutter at the 3D cursor"""
    bl_idname = "object.pro_hs_create_cylinder_cutter"
    bl_label = "Create Cylinder Cutter"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.radius, self.height = p.hs_cutter_radius, p.hs_cutter_height
        self.segments = p.hs_cutter_segments
        return self.execute(context)

    radius: bpy.props.FloatProperty(name="Radius", default=0.05, min=0.001, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.2, min=0.001, soft_max=5.0, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=16, min=6, max=64)

    def build(self, context, bm):
        cu.add_cylinder(bm, self.radius, self.height, self.segments,
                        z0=-self.height / 2.0)
        return "CUT_Cylinder"


class OBJECT_OT_pro_hs_create_slot_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create an elongated slot cutter (rounded ends) at the 3D cursor"""
    bl_idname = "object.pro_hs_create_slot_cutter"
    bl_label = "Create Slot Cutter"

    length: bpy.props.FloatProperty(name="Length", default=0.2, min=0.01, soft_max=2.0, unit='LENGTH')
    width: bpy.props.FloatProperty(name="Width", default=0.03, min=0.002, soft_max=0.5, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Cut Depth", default=0.1, min=0.005, soft_max=2.0, unit='LENGTH')

    def build(self, context, bm):
        r = self.width / 2.0
        body = self.length - self.width
        cu.add_box(bm, max(body, 0.001), self.width, self.depth,
                   z0=-self.depth / 2.0)
        cu.add_cylinder(bm, r, self.depth, 12, cx=-body / 2.0,
                        z0=-self.depth / 2.0)
        cu.add_cylinder(bm, r, self.depth, 12, cx=body / 2.0,
                        z0=-self.depth / 2.0)
        return "CUT_Slot"


class OBJECT_OT_pro_hs_create_round_hole_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create a horizontal hole cutter (cylinder along Y) for punching
    through front panels and doors"""
    bl_idname = "object.pro_hs_create_round_hole_cutter"
    bl_label = "Create Round Hole Cutter"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.radius = p.hs_cutter_radius
        self.segments = p.hs_cutter_segments
        return self.execute(context)

    radius: bpy.props.FloatProperty(name="Radius", default=0.05, min=0.001, soft_max=2.0, unit='LENGTH')
    length: bpy.props.FloatProperty(name="Through Length", default=0.3, min=0.01, soft_max=5.0, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=16, min=6, max=64)

    def build(self, context, bm):
        hs.add_cylinder_y(bm, self.radius, self.length, self.segments)
        return "CUT_RoundHole"


class OBJECT_OT_pro_hs_create_panel_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create a wide flat cutter for recessing panel areas into a surface"""
    bl_idname = "object.pro_hs_create_panel_cutter"
    bl_label = "Create Panel Cutter"

    def invoke(self, context, event):
        p = context.scene.pro_toolkit
        self.width, self.height = p.hs_panel_width, p.hs_panel_height
        return self.execute(context)

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.01, soft_max=5.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.4, min=0.01, soft_max=5.0, unit='LENGTH')
    cut_depth: bpy.props.FloatProperty(name="Cut Depth", default=0.02, min=0.001, soft_max=0.5, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.cut_depth, self.height,
                   z0=-self.height / 2.0)
        return "CUT_Panel"


class OBJECT_OT_pro_hs_create_line_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create a long thin line cutter (panel lines / grooves)"""
    bl_idname = "object.pro_hs_create_line_cutter"
    bl_label = "Create Line Cutter"

    length: bpy.props.FloatProperty(name="Length", default=0.5, min=0.01, soft_max=5.0, unit='LENGTH')
    width: bpy.props.FloatProperty(name="Width", default=0.004, min=0.0005, soft_max=0.1, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Cut Depth", default=0.05, min=0.002, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.length, self.width, self.depth,
                   z0=-self.depth / 2.0)
        return "CUT_Line"


class OBJECT_OT_pro_hs_create_ring_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create an annular ring cutter (circular grooves, port rims)"""
    bl_idname = "object.pro_hs_create_ring_cutter"
    bl_label = "Create Ring Cutter"

    radius_outer: bpy.props.FloatProperty(name="Outer Radius", default=0.08, min=0.002, soft_max=2.0, unit='LENGTH')
    radius_inner: bpy.props.FloatProperty(name="Inner Radius", default=0.06, min=0.001, soft_max=2.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Cut Depth", default=0.05, min=0.002, soft_max=1.0, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=24, min=8, max=96)

    def build(self, context, bm):
        inner = min(self.radius_inner, self.radius_outer * 0.95)
        hs.add_ring(bm, self.radius_outer, inner, self.depth, self.segments,
                    z0=-self.depth / 2.0)
        return "CUT_Ring"


class OBJECT_OT_pro_hs_create_corner_cutter(_CutterCreateOp, bpy.types.Operator):
    """Create an L-shaped corner cutter (notches and corner reliefs)"""
    bl_idname = "object.pro_hs_create_corner_cutter"
    bl_label = "Create Corner Cutter"

    size: bpy.props.FloatProperty(name="Size", default=0.12, min=0.005, soft_max=2.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Arm Thickness", default=0.04, min=0.002, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Cut Depth", default=0.1, min=0.005, soft_max=2.0, unit='LENGTH')

    def build(self, context, bm):
        t = min(self.thickness, self.size)
        cu.add_box(bm, self.size, t, self.depth,
                   cy=-(self.size - t) / 2.0, z0=-self.depth / 2.0)
        cu.add_box(bm, t, self.size, self.depth,
                   cx=-(self.size - t) / 2.0, z0=-self.depth / 2.0)
        return "CUT_Corner"


# ═══════════════════════════════════════════════════════════════════════
#  BOOLEAN TARGET SYSTEM (v0.1.5.1)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_hs_set_boolean_target(bpy.types.Operator):
    """Store the active object as the Boolean Target (the object that
    will receive every boolean cut)"""
    bl_idname = "object.pro_hs_set_boolean_target"
    bl_label = "Set Active as Target"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        if _is_cutter(obj):
            self.report({'WARNING'},
                        f"'{obj.name}' parece un CUTTER — se fija igualmente, "
                        "pero normalmente el target es el objeto a cortar.")
        context.scene.pro_toolkit.hs_boolean_target_object = obj
        self.report({'INFO'}, f"Boolean Target: '{obj.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_use_active_as_boolean_target(bpy.types.Operator):
    """Alias of Set Boolean Target (uses the active object)"""
    bl_idname = "object.pro_hs_use_active_as_boolean_target"
    bl_label = "Use Active as Boolean Target"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        return bpy.ops.object.pro_hs_set_boolean_target()


class OBJECT_OT_pro_hs_clear_boolean_target(bpy.types.Operator):
    """Clear the stored Boolean Target"""
    bl_idname = "object.pro_hs_clear_boolean_target"
    bl_label = "Clear Target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.pro_toolkit.hs_boolean_target_object = None
        self.report({'INFO'}, "Boolean Target limpiado.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_use_selected_as_cutter(bpy.types.Operator):
    """Convert the selected meshes into cutters (CUT_ prefix, wire,
    PRO_Cutters, CUTTER_Red) and remember the last one"""
    bl_idname = "object.pro_hs_use_selected_as_cutter"
    bl_label = "Use Selected as Cutter"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        props = context.scene.pro_toolkit
        target = props.hs_boolean_target_object
        n = 0
        last = None
        for obj in context.selected_objects:
            if obj.type != 'MESH' or obj is target:
                continue
            _setup_cutter(obj)
            _link_to_cutters(context, obj)
            if not obj.name.startswith(CUTTER_PREFIXES):
                obj.name = f"CUT_{obj.name}"
            if not obj.data.materials:
                obj.data.materials.append(_cutter_material())
            last = obj
            n += 1
        if last is not None:
            props.hs_last_created_cutter = last
        if not n:
            self.report({'WARNING'},
                        "Nada convertido (¿solo estaba seleccionado el target?).")
            return {'CANCELLED'}
        self.report({'INFO'}, f"{n} objeto(s) convertidos en cutter.")
        return {'FINISHED'}


class _BooleanToTargetOp:
    bl_options = {'REGISTER', 'UNDO'}
    operation = 'DIFFERENCE'

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        target, cutters = _resolve_target_and_cutters(self, context)
        if target is None:
            return {'CANCELLED'}
        added = _add_boolean(self, context, target, cutters, self.operation)
        if not added:
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Boolean {self.operation.title()} → '{target.name}' "
                    f"con {added} cutter(s). No destructivo (solo modificador).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_add_boolean_difference_to_target(_BooleanToTargetOp, bpy.types.Operator):
    """Add a Difference boolean ON THE STORED TARGET using the selected /
    active / last created cutter (the cutter never receives the modifier)"""
    bl_idname = "object.pro_hs_add_boolean_difference_to_target"
    bl_label = "Add Difference to Target"
    operation = 'DIFFERENCE'


class OBJECT_OT_pro_hs_add_boolean_union_to_target(_BooleanToTargetOp, bpy.types.Operator):
    """Add a Union boolean on the stored target"""
    bl_idname = "object.pro_hs_add_boolean_union_to_target"
    bl_label = "Add Union to Target"
    operation = 'UNION'


class OBJECT_OT_pro_hs_add_boolean_intersect_to_target(_BooleanToTargetOp, bpy.types.Operator):
    """Add an Intersect boolean on the stored target"""
    bl_idname = "object.pro_hs_add_boolean_intersect_to_target"
    bl_label = "Add Intersect to Target"
    operation = 'INTERSECT'


class OBJECT_OT_pro_hs_add_boolean_from_last_cutter(bpy.types.Operator):
    """Add a boolean on the target using the LAST CREATED cutter,
    with the operation chosen in the panel"""
    bl_idname = "object.pro_hs_add_boolean_from_last_cutter"
    bl_label = "Add Boolean from Last Cutter"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        target = props.hs_boolean_target_object
        if target is None or target.name not in context.scene.objects:
            self.report({'ERROR'},
                        "No Boolean Target set. Select the object to cut and "
                        "press Set Boolean Target.")
            return {'CANCELLED'}
        last = props.hs_last_created_cutter
        if last is None or last.name not in context.scene.objects:
            self.report({'ERROR'},
                        "No cutter selected. Select a cutter or create one first.")
            return {'CANCELLED'}
        added = _add_boolean(self, context, target, [last],
                             props.hs_boolean_operation)
        if not added:
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Boolean {props.hs_boolean_operation.title()} → "
                    f"'{target.name}' con '{last.name}'.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_apply_target_boolean_safely(bpy.types.Operator):
    """Apply the booleans of the STORED TARGET with a backup first.
    Cutters are hidden, never deleted"""
    bl_idname = "object.pro_hs_apply_target_boolean_safely"
    bl_label = "Apply Target Boolean Safely"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        target = props.hs_boolean_target_object or context.active_object
        if target is None or target.type != 'MESH':
            self.report({'ERROR'},
                        "No Boolean Target set. Select the object to cut and "
                        "press Set Boolean Target.")
            return {'CANCELLED'}
        mods = [m for m in target.modifiers if m.type == 'BOOLEAN']
        if not mods:
            self.report({'WARNING'}, f"'{target.name}' no tiene booleanos.")
            return {'CANCELLED'}
        if target.data.users > 1:
            self.report({'WARNING'},
                        f"'{target.name}': malla multiusuario — hazla "
                        "single-user antes de aplicar.")
            return {'CANCELLED'}
        backup = None
        if props.hs_boolean_create_backup:
            backup = core_toolkit.backup_object(target)
        cutters = [m.object for m in mods if m.object is not None]
        with context.temp_override(object=target, active_object=target):
            for m in mods:
                bpy.ops.object.modifier_apply(modifier=m.name)
        for cutter in cutters:
            if props.hs_boolean_keep_cutter:
                cutter.hide_set(True)
            else:
                cutter.hide_set(True)       # never auto-delete
        self.report({'INFO'},
                    f"{len(mods)} boolean(s) aplicados en '{target.name}'"
                    + (f" — backup '{backup.name}'" if backup else "")
                    + ". Cutters ocultos, no borrados.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_preview_boolean_toggle(bpy.types.Operator):
    """Toggle the viewport visibility of the target's Boolean modifiers
    (quick before/after preview)"""
    bl_idname = "object.pro_hs_preview_boolean_toggle"
    bl_label = "Preview Toggle"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        target = props.hs_boolean_target_object or context.active_object
        if target is None or target.type != 'MESH':
            self.report({'ERROR'}, "No Boolean Target set.")
            return {'CANCELLED'}
        mods = [m for m in target.modifiers if m.type == 'BOOLEAN']
        if not mods:
            self.report({'WARNING'}, f"'{target.name}' no tiene booleanos.")
            return {'CANCELLED'}
        state = not mods[0].show_viewport
        for m in mods:
            m.show_viewport = state
        self.report({'INFO'},
                    f"Preview booleanos: {'ON' if state else 'OFF'} "
                    f"({len(mods)} en '{target.name}')")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  LEGACY ADD OPS (v0.1.4 ids — now routed through the same core)
# ═══════════════════════════════════════════════════════════════════════

class _BooleanAddOp:
    bl_options = {'REGISTER', 'UNDO'}
    operation = 'DIFFERENCE'

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and context.active_object is not None
                and context.active_object.type == 'MESH'
                and len([o for o in context.selected_objects
                         if o.type == 'MESH']) >= 2)

    def execute(self, context):
        target = context.active_object
        cutters = [o for o in context.selected_objects
                   if o is not target and o.type == 'MESH']
        if not cutters:
            self.report({'WARNING'},
                        "Select cutter(s) first, target object last (active).")
            return {'CANCELLED'}
        added = _add_boolean(self, context, target, cutters, self.operation)
        if not added:
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Boolean {self.operation.title()} added on "
                    f"'{target.name}' with {added} cutter(s) — "
                    "non-destructive (modifier only).")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_boolean_difference(_BooleanAddOp, bpy.types.Operator):
    """Subtract the selected cutters from the active object
    (adds a Boolean modifier — nothing is applied)"""
    bl_idname = "object.pro_hs_boolean_difference"
    bl_label = "Boolean Difference"
    operation = 'DIFFERENCE'


class OBJECT_OT_pro_hs_boolean_union(_BooleanAddOp, bpy.types.Operator):
    """Union the selected objects into the active object"""
    bl_idname = "object.pro_hs_boolean_union"
    bl_label = "Boolean Union"
    operation = 'UNION'


class OBJECT_OT_pro_hs_boolean_intersect(_BooleanAddOp, bpy.types.Operator):
    """Keep only the intersection of the active object and the cutters"""
    bl_idname = "object.pro_hs_boolean_intersect"
    bl_label = "Boolean Intersect"
    operation = 'INTERSECT'


class OBJECT_OT_pro_hs_apply_boolean(bpy.types.Operator):
    """Apply the Boolean modifiers of the active object (backup first).
    Cutters are kept/hidden, UVs and materials preserved"""
    bl_idname = "object.pro_hs_apply_boolean"
    bl_label = "Apply Boolean Safely"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (context.mode == 'OBJECT' and obj is not None
                and obj.type == 'MESH'
                and any(m.type == 'BOOLEAN' for m in obj.modifiers))

    def execute(self, context):
        props = context.scene.pro_toolkit
        obj = context.active_object
        if obj.data.users > 1:
            self.report({'WARNING'},
                        f"'{obj.name}': shared mesh data — make it "
                        "single-user before applying booleans.")
            return {'CANCELLED'}
        mods = [m for m in obj.modifiers if m.type == 'BOOLEAN']
        cutters = [m.object for m in mods if m.object is not None]
        backup = core_toolkit.backup_object(obj)
        with context.temp_override(object=obj, active_object=obj):
            for m in mods:
                bpy.ops.object.modifier_apply(modifier=m.name)
        for cutter in cutters:
            cutter.hide_set(True)
        self.report({'INFO'},
                    f"{len(mods)} boolean(s) applied on '{obj.name}'. "
                    f"Backup: {backup.name}. Cutters hidden, not deleted.")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  CUTTER MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_hs_hide_cutters(bpy.types.Operator):
    """Hide every cutter (PRO_Cutters + legacy collection + strays)"""
    bl_idname = "object.pro_hs_hide_cutters"
    bl_label = "Hide Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = 0
        for o in _all_cutters():
            o.hide_set(True)
            n += 1
        self.report({'INFO'}, f"{n} cutter(s) hidden.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_show_cutters(bpy.types.Operator):
    """Show every cutter"""
    bl_idname = "object.pro_hs_show_cutters"
    bl_label = "Show Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = 0
        for o in _all_cutters():
            o.hide_set(False)
            n += 1
        self.report({'INFO'}, f"{n} cutter(s) shown.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_cutters_to_wire(bpy.types.Operator):
    """Set wire display (and no render) on every cutter"""
    bl_idname = "object.pro_hs_cutters_to_wire"
    bl_label = "Convert Cutters to Wire Display"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = 0
        for o in _all_cutters():
            _setup_cutter(o)
            n += 1
        self.report({'INFO'}, f"{n} cutter(s) set to wire display.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_cutters_to_collection(bpy.types.Operator):
    """Move the selected objects (or every cutter stray) into PRO_Cutters"""
    bl_idname = "object.pro_hs_cutters_to_collection"
    bl_label = "Move Cutters to Collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        objs = sel if sel else [o for o in _all_cutters()]
        n = 0
        for o in objs:
            if any(c.name == COLL_CUTTERS for c in o.users_collection):
                continue
            _link_to_cutters(context, o)
            n += 1
        self.report({'INFO'}, f"{n} object(s) moved to {COLL_CUTTERS}.")
        return {'FINISHED'}


class OBJECT_OT_pro_hs_delete_unused_cutters(bpy.types.Operator):
    """Delete cutters not referenced by any Boolean modifier
    (asks for confirmation first)"""
    bl_idname = "object.pro_hs_delete_unused_cutters"
    bl_label = "Delete Unused Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        unused = _all_cutters() - _used_cutters()
        if not unused:
            self.report({'INFO'}, "No unused cutters found.")
            return {'CANCELLED'}
        self._count = len(unused)
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        props = context.scene.pro_toolkit
        unused = _all_cutters() - _used_cutters()
        n = len(unused)
        for o in unused:
            if props.hs_last_created_cutter is o:
                props.hs_last_created_cutter = None
            bpy.data.objects.remove(o, do_unlink=True)
        self.report({'INFO'}, f"{n} unused cutter(s) deleted.")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_hs_create_box_cutter,
    OBJECT_OT_pro_hs_create_cylinder_cutter,
    OBJECT_OT_pro_hs_create_slot_cutter,
    OBJECT_OT_pro_hs_create_round_hole_cutter,
    OBJECT_OT_pro_hs_create_panel_cutter,
    OBJECT_OT_pro_hs_create_line_cutter,
    OBJECT_OT_pro_hs_create_ring_cutter,
    OBJECT_OT_pro_hs_create_corner_cutter,
    OBJECT_OT_pro_hs_set_boolean_target,
    OBJECT_OT_pro_hs_use_active_as_boolean_target,
    OBJECT_OT_pro_hs_clear_boolean_target,
    OBJECT_OT_pro_hs_use_selected_as_cutter,
    OBJECT_OT_pro_hs_add_boolean_difference_to_target,
    OBJECT_OT_pro_hs_add_boolean_union_to_target,
    OBJECT_OT_pro_hs_add_boolean_intersect_to_target,
    OBJECT_OT_pro_hs_add_boolean_from_last_cutter,
    OBJECT_OT_pro_hs_apply_target_boolean_safely,
    OBJECT_OT_pro_hs_preview_boolean_toggle,
    OBJECT_OT_pro_hs_boolean_difference,
    OBJECT_OT_pro_hs_boolean_union,
    OBJECT_OT_pro_hs_boolean_intersect,
    OBJECT_OT_pro_hs_apply_boolean,
    OBJECT_OT_pro_hs_hide_cutters,
    OBJECT_OT_pro_hs_show_cutters,
    OBJECT_OT_pro_hs_cutters_to_wire,
    OBJECT_OT_pro_hs_cutters_to_collection,
    OBJECT_OT_pro_hs_delete_unused_cutters,
)
