# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_shapes.py
# Shape creation tools: rounded box, pipes, cables, holes, slots, frames.
# Risky mesh edits are implemented as safe recesses (no boolean cuts yet).
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from mathutils import Vector


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _object_mode_poll(context):
    return context.mode == 'OBJECT'


def _edit_mesh_poll(context):
    return context.mode == 'EDIT_MESH' and context.edit_object is not None


def _link_at_cursor(context, obj):
    context.collection.objects.link(obj)
    obj.location = context.scene.cursor.location.copy()
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj


def _new_bezier_curve_object(context, name, points, radius, fill_caps=True):
    """Create a 3D bezier curve object through *points* with round bevel."""
    cu = bpy.data.curves.new(name, type='CURVE')
    cu.dimensions = '3D'
    cu.bevel_depth = radius
    cu.bevel_resolution = 4
    cu.use_fill_caps = fill_caps

    spline = cu.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    for bp, co in zip(spline.bezier_points, points):
        bp.co = co
        bp.handle_left_type = 'AUTO'
        bp.handle_right_type = 'AUTO'

    obj = bpy.data.objects.new(name, cu)
    _link_at_cursor(context, obj)
    return obj


def _selected_faces_and_normal(context):
    """Return (bm, mesh, selected_faces, avg_normal) or (None,)*4 on failure."""
    me = context.edit_object.data
    bm = bmesh.from_edit_mesh(me)
    bm.faces.ensure_lookup_table()
    sel = [f for f in bm.faces if f.select]
    if not sel:
        return None, None, None, None
    normal = Vector()
    for f in sel:
        normal += f.normal
    if normal.length < 1e-8:
        return bm, me, sel, None
    return bm, me, sel, normal.normalized()


# ═══════════════════════════════════════════════════════════════════════
#  Rounded Box  (Object Mode, non-destructive bevel)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_make_rounded_box(bpy.types.Operator):
    """Add a box with a non-destructive Bevel modifier (rounded edges)"""
    bl_idname = "object.pro_make_rounded_box"
    bl_label = "Rounded Box"
    bl_options = {'REGISTER', 'UNDO'}

    size_x: bpy.props.FloatProperty(name="Size X", default=1.0, min=0.01, soft_max=10.0, unit='LENGTH')
    size_y: bpy.props.FloatProperty(name="Size Y", default=1.0, min=0.01, soft_max=10.0, unit='LENGTH')
    size_z: bpy.props.FloatProperty(name="Size Z", default=1.0, min=0.01, soft_max=10.0, unit='LENGTH')
    bevel_width: bpy.props.FloatProperty(name="Bevel Width", default=0.05, min=0.001, soft_max=0.5, unit='LENGTH')
    bevel_segments: bpy.props.IntProperty(name="Bevel Segments", default=3, min=1, max=12)

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        me = bpy.data.meshes.new("Rounded_Box")
        bm = bmesh.new()
        bmesh.ops.create_cube(bm, size=1.0)
        for v in bm.verts:
            v.co.x *= self.size_x
            v.co.y *= self.size_y
            v.co.z *= self.size_z
        bm.to_mesh(me)
        bm.free()

        obj = bpy.data.objects.new("Rounded_Box", me)
        _link_at_cursor(context, obj)

        mod = obj.modifiers.new(name="Pro_Bevel", type='BEVEL')
        mod.width = self.bevel_width
        mod.segments = self.bevel_segments
        mod.limit_method = 'ANGLE'

        self.report({'INFO'}, "Rounded box added (non-destructive bevel)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Pipe Curve  (Object Mode, editable curve)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_pipe_curve(bpy.types.Operator):
    """Add an editable pipe (curve with round profile and caps)"""
    bl_idname = "object.pro_add_pipe_curve"
    bl_label = "Add Pipe"
    bl_options = {'REGISTER', 'UNDO'}

    length: bpy.props.FloatProperty(name="Length", default=2.0, min=0.1, soft_max=20.0, unit='LENGTH')
    radius: bpy.props.FloatProperty(name="Radius", default=0.1, min=0.001, soft_max=1.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        _new_bezier_curve_object(
            context, "Pipe_Curve",
            points=[(0.0, 0.0, 0.0), (self.length, 0.0, 0.0)],
            radius=self.radius,
        )
        self.report({'INFO'},
                    f"Pipe added (length={self.length:.2f}, r={self.radius:.3f}). "
                    "Edit the curve points to route it.")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Cable Curve  (Object Mode, editable curve with sag)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_cable_curve(bpy.types.Operator):
    """Add a hanging cable (curve with natural sag)"""
    bl_idname = "object.pro_add_cable_curve"
    bl_label = "Add Cable"
    bl_options = {'REGISTER', 'UNDO'}

    span: bpy.props.FloatProperty(name="Span", default=2.0, min=0.1, soft_max=20.0, unit='LENGTH')
    sag: bpy.props.FloatProperty(name="Sag", default=0.4, min=0.0, soft_max=5.0, unit='LENGTH')
    radius: bpy.props.FloatProperty(name="Radius", default=0.02, min=0.001, soft_max=0.5, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        half = self.span / 2.0
        _new_bezier_curve_object(
            context, "Cable_Curve",
            points=[
                (-half, 0.0, 0.0),
                (0.0, 0.0, -self.sag),
                (half, 0.0, 0.0),
            ],
            radius=self.radius,
        )
        self.report({'INFO'},
                    f"Cable added (span={self.span:.2f}, sag={self.sag:.2f}). "
                    "Move the end points to attach it.")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Make Hole (Basic)  — safe recess, no boolean cut
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_make_hole_basic(bpy.types.Operator):
    """Create a recessed hole on the selected faces (inset + depth, no boolean)"""
    bl_idname = "mesh.pro_make_hole_basic"
    bl_label = "Make Hole (Basic)"
    bl_options = {'REGISTER', 'UNDO'}

    thickness: bpy.props.FloatProperty(
        name="Border", description="Inset border width",
        default=0.05, min=0.0001, soft_max=1.0, precision=4)
    depth: bpy.props.FloatProperty(
        name="Depth", description="How deep the hole goes",
        default=0.1, min=0.0, soft_max=2.0, precision=4)

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bm, me, sel, normal = _selected_faces_and_normal(context)
        if sel is None:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}

        bmesh.ops.inset_region(
            bm, faces=sel,
            thickness=self.thickness,
            depth=-self.depth,
            use_even_offset=True,
        )
        bmesh.update_edit_mesh(me, loop_triangles=True, destructive=True)
        self.report({'INFO'},
                    f"Recessed hole created (border={self.thickness:.3f}, "
                    f"depth={self.depth:.3f})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Make Slot (Basic)  — elongated recess
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_make_slot_basic(bpy.types.Operator):
    """Create a shallow slot/groove on the selected faces (works best on elongated selections)"""
    bl_idname = "mesh.pro_make_slot_basic"
    bl_label = "Make Slot (Basic)"
    bl_options = {'REGISTER', 'UNDO'}

    thickness: bpy.props.FloatProperty(
        name="Border", description="Inset border width",
        default=0.02, min=0.0001, soft_max=1.0, precision=4)
    depth: bpy.props.FloatProperty(
        name="Depth", description="Groove depth",
        default=0.05, min=0.0, soft_max=2.0, precision=4)

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bm, me, sel, normal = _selected_faces_and_normal(context)
        if sel is None:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}

        bmesh.ops.inset_region(
            bm, faces=sel,
            thickness=self.thickness,
            depth=-self.depth,
            use_even_offset=True,
        )
        bmesh.update_edit_mesh(me, loop_triangles=True, destructive=True)
        self.report({'INFO'},
                    f"Slot created (border={self.thickness:.3f}, depth={self.depth:.3f})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Make Frame (Basic)  — raised border around the selection
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_make_frame_basic(bpy.types.Operator):
    """Create a raised frame/border around the selected faces"""
    bl_idname = "mesh.pro_make_frame_basic"
    bl_label = "Make Frame (Basic)"
    bl_options = {'REGISTER', 'UNDO'}

    thickness: bpy.props.FloatProperty(
        name="Frame Width", description="Width of the frame border",
        default=0.05, min=0.0001, soft_max=1.0, precision=4)
    height: bpy.props.FloatProperty(
        name="Frame Height", description="How much the frame is raised",
        default=0.05, min=0.0, soft_max=2.0, precision=4)

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bm, me, sel, normal = _selected_faces_and_normal(context)
        if sel is None:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}
        if normal is None:
            self.report({'WARNING'},
                        "Selected faces have opposing normals - cannot raise frame.")
            return {'CANCELLED'}

        # 1. Inset to create the border ring
        ret = bmesh.ops.inset_region(
            bm, faces=sel,
            thickness=self.thickness,
            depth=0.0,
            use_even_offset=True,
        )
        ring_faces = ret["faces"]
        if not ring_faces:
            self.report({'WARNING'}, "Inset produced no frame ring.")
            return {'CANCELLED'}

        # 2. Extrude the ring and raise it along the average normal
        ret2 = bmesh.ops.extrude_face_region(bm, geom=ring_faces)
        new_verts = [el for el in ret2["geom"]
                     if isinstance(el, bmesh.types.BMVert)]
        bmesh.ops.translate(bm, verts=new_verts, vec=normal * self.height)

        bmesh.update_edit_mesh(me, loop_triangles=True, destructive=True)
        self.report({'INFO'},
                    f"Frame created (width={self.thickness:.3f}, "
                    f"height={self.height:.3f})")
        return {'FINISHED'}
