# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  core_toolkit.py
# Mesh health audit, one-click cleanup, quick modifiers, overlays, backups
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh


# ═══════════════════════════════════════════════════════════════════════
#  BACKUP SYSTEM
# ═══════════════════════════════════════════════════════════════════════

BACKUP_COLLECTION = "_pro_toolkit_backups"
MAX_BACKUPS = 10


def _get_or_create_backup_collection():
    """Return the hidden backup collection, creating it if needed."""
    col = bpy.data.collections.get(BACKUP_COLLECTION)
    if col is None:
        col = bpy.data.collections.new(BACKUP_COLLECTION)
        bpy.context.scene.collection.children.link(col)
    col.hide_viewport = True
    col.hide_render = True
    return col


def backup_object(obj):
    """Create a hidden copy of the object + mesh data for safety.

    Backups are kept until the user purges them (Cleanup & Repair panel).
    Oldest backups are dropped beyond MAX_BACKUPS to avoid file bloat.
    """
    backup_col = _get_or_create_backup_collection()
    new_obj = obj.copy()
    new_obj.data = obj.data.copy()
    new_obj.name = f"_backup_{obj.name}"
    backup_col.objects.link(new_obj)

    # Rotate old backups beyond the cap (oldest first by name suffix order)
    extra = len(backup_col.objects) - MAX_BACKUPS
    if extra > 0:
        for old in sorted(backup_col.objects, key=lambda o: o.name)[:extra]:
            mesh = old.data
            bpy.data.objects.remove(old, do_unlink=True)
            if mesh and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
    return new_obj


def purge_backups():
    """Remove all objects from the backup collection. Returns count removed."""
    col = bpy.data.collections.get(BACKUP_COLLECTION)
    if col is None:
        return 0
    count = 0
    for obj in list(col.objects):
        mesh = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
        count += 1
    return count


def backup_count():
    """Number of stored backup objects."""
    col = bpy.data.collections.get(BACKUP_COLLECTION)
    return len(col.objects) if col else 0


# ═══════════════════════════════════════════════════════════════════════
#  MESH HEALTH AUDIT
# ═══════════════════════════════════════════════════════════════════════

class MeshHealthReport:
    """Static helper – scans a mesh and returns a metrics dict."""

    @staticmethod
    def scan_mesh(obj):
        """
        Analyse *obj* (must be a MESH) and return a dict with:
            ngons, tris, non_manifold, doubles, loose_verts, total_verts,
            total_edges, total_faces
        Works in Object Mode and Edit Mode (reads live edit data).
        """
        if obj is None or obj.type != 'MESH':
            return None

        in_edit = (obj.mode == 'EDIT')
        if in_edit:
            bm = bmesh.from_edit_mesh(obj.data)
        else:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        ngons = sum(1 for f in bm.faces if len(f.verts) > 4)
        tris = sum(1 for f in bm.faces if len(f.verts) == 3)
        non_manifold = sum(1 for e in bm.edges if not e.is_manifold)
        doubles = bmesh.ops.find_doubles(bm, verts=bm.verts, dist=0.0001)
        loose = sum(1 for v in bm.verts if not v.link_edges)

        result = {
            "ngons": ngons,
            "tris": tris,
            "non_manifold": non_manifold,
            "doubles": len(doubles["targetmap"]),
            "loose_verts": loose,
            "total_verts": len(bm.verts),
            "total_edges": len(bm.edges),
            "total_faces": len(bm.faces),
        }
        if not in_edit:
            bm.free()
        return result


# ═══════════════════════════════════════════════════════════════════════
#  OPERATOR – Scan Mesh Health
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_toolkit_run_audit(bpy.types.Operator):
    """Scan active mesh and report health metrics"""
    bl_idname = "object.pro_toolkit_run_audit"
    bl_label = "Scan Mesh Health"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        obj = context.active_object
        report = MeshHealthReport.scan_mesh(obj)
        if report is None:
            self.report({'WARNING'}, "No valid mesh to scan.")
            return {'CANCELLED'}

        props = context.scene.pro_toolkit
        props.audit_object_name = obj.name
        props.audit_ngons = report["ngons"]
        props.audit_tris = report["tris"]
        props.audit_non_manifold = report["non_manifold"]
        props.audit_doubles = report["doubles"]
        props.audit_loose = report["loose_verts"]
        props.audit_total_verts = report["total_verts"]
        props.audit_total_edges = report["total_edges"]
        props.audit_total_faces = report["total_faces"]
        props.audit_done = True

        self.report({'INFO'},
                    f"Audit: V={report['total_verts']}  E={report['total_edges']}  "
                    f"F={report['total_faces']} | NGons={report['ngons']}  "
                    f"Tris={report['tris']}  NonManifold={report['non_manifold']}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  OPERATOR – One-Click Cleanup
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_toolkit_one_click_cleanup(bpy.types.Operator):
    """Remove doubles, recalculate normals, delete loose geometry (creates a backup)"""
    bl_idname = "object.pro_toolkit_one_click_cleanup"
    bl_label = "One-Click Cleanup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        obj = context.active_object
        prev_mode = obj.mode

        # Flush edit-mode data, then back up before the destructive chain
        if prev_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        backup = backup_object(obj)

        # Run the cleanup chain in Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles(threshold=0.0001)
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.delete_loose(use_verts=True, use_edges=True, use_faces=False)
        bpy.ops.object.mode_set(mode='OBJECT')

        # Post-validation (must run in Object Mode)
        repaired = obj.data.validate(verbose=False)

        # Restore the caller's mode
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')

        if repaired:
            self.report({'WARNING'},
                        f"Cleanup done – mesh required repair (auto-fixed). "
                        f"Backup: {backup.name}")
        else:
            self.report({'INFO'}, f"Cleanup done – mesh is clean. Backup: {backup.name}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  OPERATOR – Purge Backups
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_toolkit_purge_backups(bpy.types.Operator):
    """Delete all backup copies stored by the toolkit"""
    bl_idname = "object.pro_toolkit_purge_backups"
    bl_label = "Purge Backups"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return backup_count() > 0

    def execute(self, context):
        removed = purge_backups()
        self.report({'INFO'}, f"Removed {removed} backup object(s).")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  OPERATOR – Quick Modifier Add
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_toolkit_add_modifier(bpy.types.Operator):
    """Add a preset modifier to the active mesh object"""
    bl_idname = "object.pro_toolkit_add_modifier"
    bl_label = "Add Quick Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    mod_type: bpy.props.EnumProperty(
        name="Modifier",
        items=[
            ('MIRROR', "Mirror", "Add a Mirror modifier"),
            ('SOLIDIFY', "Solidify", "Add a Solidify modifier"),
            ('BEVEL', "Bevel", "Add a Bevel modifier"),
            ('WEIGHTED_NORMAL', "Weighted Normal", "Add a Weighted Normal modifier"),
        ],
        default='MIRROR',
    )

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        obj = context.active_object
        mod_name = f"Pro_{self.mod_type.title()}"

        if self.mod_type == 'MIRROR':
            mod = obj.modifiers.new(name=mod_name, type='MIRROR')
            mod.use_axis[0] = True   # X axis

        elif self.mod_type == 'SOLIDIFY':
            mod = obj.modifiers.new(name=mod_name, type='SOLIDIFY')
            mod.thickness = 0.05
            mod.offset = -1.0

        elif self.mod_type == 'BEVEL':
            mod = obj.modifiers.new(name=mod_name, type='BEVEL')
            mod.width = 0.02
            mod.segments = 2
            mod.limit_method = 'ANGLE'
            mod.angle_limit = 0.523599  # 30 degrees

        elif self.mod_type == 'WEIGHTED_NORMAL':
            if any(m.type == 'WEIGHTED_NORMAL' for m in obj.modifiers):
                self.report({'INFO'}, "Weighted Normal modifier already present.")
                return {'CANCELLED'}
            mod = obj.modifiers.new(name=mod_name, type='WEIGHTED_NORMAL')
            mod.weight = 50
            mod.keep_sharp = True
            # Legacy auto-smooth flag (removed in Blender 4.1+)
            if hasattr(obj.data, 'use_auto_smooth'):
                obj.data.use_auto_smooth = True

        self.report({'INFO'}, f"Added modifier: {self.mod_type}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  OPERATOR – Face Orientation Toggle
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_face_orientation_toggle(bpy.types.Operator):
    """Toggle Face Orientation overlay in the 3D Viewport"""
    bl_idname = "object.pro_face_orientation_toggle"
    bl_label = "Toggle Face Orientation"
    bl_options = {'REGISTER'}

    def execute(self, context):
        space = context.space_data
        if space is None or space.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run this from the 3D Viewport.")
            return {'CANCELLED'}
        overlay = space.overlay
        overlay.show_face_orientation = not overlay.show_face_orientation
        state = "ON" if overlay.show_face_orientation else "OFF"
        self.report({'INFO'}, f"Face Orientation: {state}")
        return {'FINISHED'}
