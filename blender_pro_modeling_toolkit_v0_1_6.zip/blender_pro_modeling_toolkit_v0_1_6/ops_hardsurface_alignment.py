# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_hardsurface_alignment.py
# v0.1.4 Hard Surface Pro Suite: cutter alignment.
# Move, center, orient, rotate, mirror and duplicate boolean cutters
# relative to the active object, the 3D cursor or the current view.
# Never destructive: no booleans applied, no cutters or materials
# deleted, the active (target) object is never moved.
# ──────────────────────────────────────────────────────────────────────

from math import radians

import bpy
from mathutils import Matrix, Vector

from . import hardsurface_utils as hs

# A "cutter" is recognised by any of these signals (covers both the
# v0.1.4 conventions and older/manual naming):
CUTTER_NAME_PREFIXES = ("HS_Cutter", "CUT_")
CUTTER_COLLECTIONS = (hs.COLL_HS_CUTTERS, "PRO_Cutters")
CUTTER_MATERIAL_PREFIXES = ("HS_Cutter", "CUTTER_")


# ═══════════════════════════════════════════════════════════════════════
#  DETECTION / GEOMETRY HELPERS
# ═══════════════════════════════════════════════════════════════════════

def is_cutter(obj):
    """Best-effort cutter detection (name, collection, material, wire)."""
    if obj is None or obj.type != 'MESH':
        return False
    if obj.name.startswith(CUTTER_NAME_PREFIXES):
        return True
    for coll in obj.users_collection:
        if coll.name in CUTTER_COLLECTIONS:
            return True
    for slot in obj.material_slots:
        if slot.material and slot.material.name.startswith(CUTTER_MATERIAL_PREFIXES):
            return True
    if obj.display_type == 'WIRE':
        return True
    return False


def selected_cutters(context, exclude_active=True):
    """Selected cutter objects (optionally without the active object)."""
    active = context.view_layer.objects.active
    out = []
    for obj in context.selected_objects:
        if exclude_active and obj is active:
            continue
        if is_cutter(obj):
            out.append(obj)
    return out


def world_bbox(obj):
    """The 8 bounding-box corners of *obj* in world space."""
    return [obj.matrix_world @ Vector(c) for c in obj.bound_box]


def world_bbox_center(obj):
    corners = world_bbox(obj)
    return sum(corners, Vector()) / 8.0


def move_to_world(obj, world_pos):
    """Place *obj*'s WORLD position at *world_pos* (parent-safe)."""
    mw = obj.matrix_world.copy()
    mw.translation = world_pos
    obj.matrix_world = mw


def _valid_target(context, cutters):
    """The active object as alignment target (must be a mesh and not one
    of the cutters being moved). Returns None if invalid."""
    active = context.view_layer.objects.active
    if active is None or active.type != 'MESH' or active in cutters:
        return None
    return active


# ═══════════════════════════════════════════════════════════════════════
#  BASE OPERATOR
# ═══════════════════════════════════════════════════════════════════════

class _CutterAlignOp:
    bl_options = {'REGISTER', 'UNDO'}

    # subclasses needing the active object as reference set this
    _needs_target = False
    _include_active_cutter = False

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        cutters = selected_cutters(
            context, exclude_active=not self._include_active_cutter)
        if not cutters:
            self.report({'WARNING'},
                        "No cutter selected. Select cutter(s) "
                        "(HS_Cutter_*/CUT_*, wire display or cutter collection)"
                        + (" with the target object active." if self._needs_target else "."))
            return {'CANCELLED'}

        target = None
        if self._needs_target:
            target = _valid_target(context, cutters)
            if target is None:
                self.report({'WARNING'},
                            "No valid target: make the object to align to "
                            "ACTIVE (a mesh that is not one of the cutters).")
                return {'CANCELLED'}

        done = self._apply(context, cutters, target)
        if done is None:        # subclass already reported and cancelled
            return {'CANCELLED'}
        self.report({'INFO'}, done)
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  ALIGN — to active center / bounds axis / cursor / view
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_hs_align_cutter_to_active_center(_CutterAlignOp, bpy.types.Operator):
    """Move selected cutters to the center of the active object"""
    bl_idname = "object.pro_hs_align_cutter_to_active_center"
    bl_label = "To Active Center"
    _needs_target = True

    def _apply(self, context, cutters, target):
        center = world_bbox_center(target)
        for cutter in cutters:
            move_to_world(cutter, center)
        return f"{len(cutters)} cutter(s) centered on '{target.name}'"


def _make_bounds_axis_op(axis_name, index):
    """Factory: center cutters on ONE axis of the active object's bounds,
    keeping the other two coordinates untouched."""

    class _Op(_CutterAlignOp, bpy.types.Operator):
        bl_idname = f"object.pro_hs_align_cutter_to_active_bounds_{axis_name}"
        bl_label = f"Center {axis_name.upper()}"
        bl_description = (f"Center selected cutters on the active object's "
                          f"{axis_name.upper()} axis (other axes unchanged)")
        _needs_target = True

        def _apply(self, context, cutters, target, _i=index):
            center = world_bbox_center(target)
            for cutter in cutters:
                pos = cutter.matrix_world.translation.copy()
                pos[_i] = center[_i]
                move_to_world(cutter, pos)
            return (f"{len(cutters)} cutter(s) centered on "
                    f"{axis_name.upper()} of '{target.name}'")

    _Op.__name__ = f"OBJECT_OT_pro_hs_align_cutter_to_active_bounds_{axis_name}"
    return _Op


OBJECT_OT_pro_hs_align_cutter_to_active_bounds_x = _make_bounds_axis_op("x", 0)
OBJECT_OT_pro_hs_align_cutter_to_active_bounds_y = _make_bounds_axis_op("y", 1)
OBJECT_OT_pro_hs_align_cutter_to_active_bounds_z = _make_bounds_axis_op("z", 2)


class OBJECT_OT_pro_hs_align_cutter_to_cursor(_CutterAlignOp, bpy.types.Operator):
    """Move selected cutters to the 3D cursor"""
    bl_idname = "object.pro_hs_align_cutter_to_cursor"
    bl_label = "To Cursor"
    _include_active_cutter = True

    def _apply(self, context, cutters, target):
        pos = context.scene.cursor.location.copy()
        for cutter in cutters:
            move_to_world(cutter, pos)
        return f"{len(cutters)} cutter(s) moved to the 3D cursor"


class OBJECT_OT_pro_hs_align_cutter_to_view(_CutterAlignOp, bpy.types.Operator):
    """Orient selected cutters to face the current viewport view"""
    bl_idname = "object.pro_hs_align_cutter_to_view"
    bl_label = "To View"
    _include_active_cutter = True

    def _apply(self, context, cutters, target):
        rv3d = context.region_data
        if rv3d is None:
            for area in context.screen.areas if context.screen else []:
                if area.type == 'VIEW_3D':
                    rv3d = area.spaces.active.region_3d
                    break
        if rv3d is None:
            self.report({'WARNING'}, "Align to View requires viewport context.")
            return None

        view_rot = rv3d.view_rotation
        for cutter in cutters:
            loc = cutter.matrix_world.translation.copy()
            scale = cutter.matrix_world.to_scale()
            mw = (Matrix.Translation(loc) @ view_rot.to_matrix().to_4x4()
                  @ Matrix.Diagonal(scale).to_4x4())
            cutter.matrix_world = mw
        return f"{len(cutters)} cutter(s) oriented to the view"


# ═══════════════════════════════════════════════════════════════════════
#  SNAP — basic surface snap (raycast with bbox fallback)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_hs_snap_cutter_to_surface_basic(_CutterAlignOp, bpy.types.Operator):
    """Snap selected cutters onto the active object's surface
    (raycast toward its center; falls back to the bounding box)"""
    bl_idname = "object.pro_hs_snap_cutter_to_surface_basic"
    bl_label = "Snap to Surface (Basic)"
    _needs_target = True

    offset: bpy.props.FloatProperty(
        name="Surface Offset",
        description="Push the cutter along the surface normal after snapping",
        default=0.0, soft_min=-1.0, soft_max=1.0, subtype='DISTANCE')

    def _apply(self, context, cutters, target):
        inv = target.matrix_world.inverted()
        center_w = world_bbox_center(target)
        snapped = boxed = 0

        for cutter in cutters:
            origin_w = cutter.matrix_world.translation.copy()
            direction_w = center_w - origin_w
            if direction_w.length < 1e-9:
                direction_w = Vector((0.0, 0.0, -1.0))

            origin_l = inv @ origin_w
            direction_l = (inv.to_3x3() @ direction_w).normalized()
            try:
                hit, loc_l, normal_l, _idx = target.ray_cast(origin_l, direction_l)
            except RuntimeError:
                hit = False

            if hit:
                loc_w = target.matrix_world @ loc_l
                normal_w = (target.matrix_world.to_3x3() @ normal_l).normalized()
                move_to_world(cutter, loc_w + normal_w * self.offset)
                snapped += 1
            else:
                # safe fallback: clamp onto the target's world bounding box
                corners = world_bbox(target)
                lo = Vector((min(c[i] for c in corners) for i in range(3)))
                hi = Vector((max(c[i] for c in corners) for i in range(3)))
                pos = Vector((min(max(origin_w[i], lo[i]), hi[i]) for i in range(3)))
                move_to_world(cutter, pos)
                boxed += 1

        msg = f"{snapped} cutter(s) snapped to '{target.name}' surface"
        if boxed:
            msg += f", {boxed} clamped to its bounding box (no surface hit)"
        return msg


# ═══════════════════════════════════════════════════════════════════════
#  TRANSFORM — rotate 90° on world axes
# ═══════════════════════════════════════════════════════════════════════

def _make_rotate_op(axis_name, axis_vec):
    class _Op(_CutterAlignOp, bpy.types.Operator):
        bl_idname = f"object.pro_hs_rotate_cutter_90_{axis_name}"
        bl_label = f"Rotate 90 {axis_name.upper()}"
        bl_description = (f"Rotate selected cutters 90° around the world "
                          f"{axis_name.upper()} axis (around their own origin)")
        _include_active_cutter = True

        def _apply(self, context, cutters, target, _axis=Vector(axis_vec)):
            rot = Matrix.Rotation(radians(90.0), 4, _axis)
            for cutter in cutters:
                loc = cutter.matrix_world.translation.copy()
                cutter.matrix_world = (Matrix.Translation(loc) @ rot
                                       @ Matrix.Translation(-loc)
                                       @ cutter.matrix_world)
            return f"{len(cutters)} cutter(s) rotated 90° on {axis_name.upper()}"

    _Op.__name__ = f"OBJECT_OT_pro_hs_rotate_cutter_90_{axis_name}"
    return _Op


OBJECT_OT_pro_hs_rotate_cutter_90_x = _make_rotate_op("x", (1, 0, 0))
OBJECT_OT_pro_hs_rotate_cutter_90_y = _make_rotate_op("y", (0, 1, 0))
OBJECT_OT_pro_hs_rotate_cutter_90_z = _make_rotate_op("z", (0, 0, 1))


# ═══════════════════════════════════════════════════════════════════════
#  MIRROR / DUPLICATE
# ═══════════════════════════════════════════════════════════════════════

def _clone_cutter(context, src):
    """Duplicate *src* keeping mesh (own copy), materials, wire display and
    collections (falls back to the HS cutter collection)."""
    new = src.copy()
    new.data = src.data.copy()
    new.data.name = new.name
    linked = False
    for coll in src.users_collection:
        coll.objects.link(new)
        linked = True
    if not linked:
        hs.get_or_create_hs_collection(context, hs.COLL_HS_CUTTERS).objects.link(new)
    return new


def _make_mirror_op(axis_name, index):
    class _Op(_CutterAlignOp, bpy.types.Operator):
        bl_idname = f"object.pro_hs_mirror_cutter_{axis_name}"
        bl_label = f"Mirror {axis_name.upper()}"
        bl_description = (
            f"Create a mirrored copy of the selected cutters across the "
            f"active object's center (or the world origin) on {axis_name.upper()}")
        _include_active_cutter = True

        def _apply(self, context, cutters, target, _i=index):
            # pivot: active mesh (if it is not one of the cutters), else world
            active = context.view_layer.objects.active
            if (active is not None and active.type == 'MESH'
                    and active not in cutters):
                pivot = world_bbox_center(active)
                ref = f"'{active.name}'"
            else:
                pivot = Vector((0.0, 0.0, 0.0))
                ref = "world origin"

            axis = Vector((0.0, 0.0, 0.0))
            axis[_i] = 1.0
            mirror = (Matrix.Translation(pivot)
                      @ Matrix.Scale(-1.0, 4, axis)
                      @ Matrix.Translation(-pivot))

            new_names = []
            for cutter in cutters:
                new = _clone_cutter(context, cutter)
                new.matrix_world = mirror @ cutter.matrix_world
                new_names.append(new.name)
            return (f"Mirrored {len(new_names)} cutter(s) on "
                    f"{axis_name.upper()} across {ref}")

    _Op.__name__ = f"OBJECT_OT_pro_hs_mirror_cutter_{axis_name}"
    return _Op


OBJECT_OT_pro_hs_mirror_cutter_x = _make_mirror_op("x", 0)
OBJECT_OT_pro_hs_mirror_cutter_y = _make_mirror_op("y", 1)
OBJECT_OT_pro_hs_mirror_cutter_z = _make_mirror_op("z", 2)


class OBJECT_OT_pro_hs_duplicate_cutter(_CutterAlignOp, bpy.types.Operator):
    """Duplicate selected cutters (keeps material, wire display and collection)"""
    bl_idname = "object.pro_hs_duplicate_cutter"
    bl_label = "Duplicate Cutter"
    _include_active_cutter = True

    def _apply(self, context, cutters, target):
        new_objs = []
        for cutter in cutters:
            new = _clone_cutter(context, cutter)
            step = max(cutter.dimensions.x, 0.1) + 0.05
            mw = cutter.matrix_world.copy()
            mw.translation = mw.translation + Vector((step, 0.0, 0.0))
            new.matrix_world = mw
            new_objs.append(new)

        for o in context.selected_objects:
            o.select_set(False)
        for o in new_objs:
            o.select_set(True)
        context.view_layer.objects.active = new_objs[-1]
        return (f"Duplicated {len(new_objs)} cutter(s): "
                + ", ".join(o.name for o in new_objs))


classes = (
    OBJECT_OT_pro_hs_align_cutter_to_active_center,
    OBJECT_OT_pro_hs_align_cutter_to_active_bounds_x,
    OBJECT_OT_pro_hs_align_cutter_to_active_bounds_y,
    OBJECT_OT_pro_hs_align_cutter_to_active_bounds_z,
    OBJECT_OT_pro_hs_align_cutter_to_cursor,
    OBJECT_OT_pro_hs_align_cutter_to_view,
    OBJECT_OT_pro_hs_snap_cutter_to_surface_basic,
    OBJECT_OT_pro_hs_rotate_cutter_90_x,
    OBJECT_OT_pro_hs_rotate_cutter_90_y,
    OBJECT_OT_pro_hs_rotate_cutter_90_z,
    OBJECT_OT_pro_hs_mirror_cutter_x,
    OBJECT_OT_pro_hs_mirror_cutter_y,
    OBJECT_OT_pro_hs_mirror_cutter_z,
    OBJECT_OT_pro_hs_duplicate_cutter,
)
