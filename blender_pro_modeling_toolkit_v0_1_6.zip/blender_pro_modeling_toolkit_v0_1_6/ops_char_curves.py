# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_curves.py
# v0.1.5: organic curve tools — roots, tentacles, vines, organic cables.
# Editable bezier curves with controlled resolution, taper and bevel,
# filed in PRO_Organic_Curves. Conversion to mesh always works on a
# duplicate (the curve is kept).
# ──────────────────────────────────────────────────────────────────────

import bpy
from mathutils import Vector

from . import character_utils as ch


def _new_curve(context, name, points, radius, mat, taper=0.0, resolution=12):
    """Bezier curve through *points* [(co, tilt_radius), ...] with AUTO
    handles, round bevel and per-point radius taper."""
    cu = bpy.data.curves.new(name, type='CURVE')
    cu.dimensions = '3D'
    cu.bevel_depth = radius
    cu.bevel_resolution = 3
    cu.resolution_u = resolution
    cu.use_fill_caps = True

    spline = cu.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    n = len(points)
    for i, (bp, co) in enumerate(zip(spline.bezier_points, points)):
        bp.co = co
        bp.handle_left_type = 'AUTO'
        bp.handle_right_type = 'AUTO'
        t = i / max(n - 1, 1)
        bp.radius = max(1.0 - taper * t, 0.02)

    obj = bpy.data.objects.new(name, cu)
    ch.get_coll(context, ch.COLL_CURVES).objects.link(obj)
    obj.location = context.scene.cursor.location.copy()
    if obj.data.materials:
        obj.data.materials[0] = ch.get_char_material(mat)
    else:
        obj.data.materials.append(ch.get_char_material(mat))
    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    return obj


# table: suffix -> (label, points, taper, material)
CURVES = {
    "organic_curve": ("Create Organic Curve",
                      [(0, 0, 0), (0.25, 0.15, 0.35), (0.15, -0.1, 0.75),
                       (0.3, 0.05, 1.1)], 0.55, "PRO_Curve_Tentacle"),
    "tentacle_curve": ("Create Tentacle Curve",
                       [(0, 0, 0), (0.1, 0.2, 0.45), (-0.15, 0.1, 0.85),
                        (0.2, -0.15, 1.25), (0.05, 0.1, 1.5)],
                       0.92, "PRO_Curve_Tentacle"),
    "root_curve": ("Create Root Curve",
                   [(0, 0, 0), (0.2, 0.1, -0.3), (0.45, -0.05, -0.55),
                    (0.8, 0.15, -0.7)], 0.85, "PRO_Curve_Root"),
    "vine_curve": ("Create Vine Curve",
                   [(0, 0, 0), (0.3, 0.25, 0.4), (0.15, -0.25, 0.9),
                    (0.45, 0.2, 1.4), (0.3, -0.1, 1.9)],
                   0.7, "PRO_Curve_Root"),
    "cable_organic_curve": ("Create Cable Organic Curve",
                            [(-0.8, 0, 0.9), (-0.25, 0.1, 0.45),
                             (0.35, -0.1, 0.5), (0.8, 0, 1.0)],
                            0.0, "PRO_Curve_Tentacle"),
}


def _make_curve_op(suffix):
    label, pts, taper, mat = CURVES[suffix]

    class _Op(bpy.types.Operator):
        bl_idname = f"object.pro_char_{suffix}"
        bl_label = label
        bl_description = (f"{label} en el cursor — curva editable con taper, "
                          "archivada en PRO_Organic_Curves")
        bl_options = {'REGISTER', 'UNDO'}

        @classmethod
        def poll(cls, context):
            return context.mode == 'OBJECT'

        def execute(self, context):
            p = context.scene.pro_toolkit
            obj = _new_curve(context, f"PRO_{suffix}",
                             [Vector(c) for c in pts],
                             p.curve_bevel_depth, mat,
                             taper=taper if p.curve_taper_ends else 0.0,
                             resolution=p.curve_resolution)
            self.report({'INFO'},
                        f"{label} → '{obj.name}' (edita los puntos en Edit Mode)")
            return {'FINISHED'}

    _Op.__name__ = f"OBJECT_OT_pro_char_{suffix}"
    return _Op


_curve_classes = tuple(_make_curve_op(s) for s in CURVES)


def _active_curve(context):
    obj = context.active_object
    return obj if obj is not None and obj.type == 'CURVE' else None


class OBJECT_OT_pro_char_convert_curve_safe(bpy.types.Operator):
    """Convert a DUPLICATE of the active curve to mesh (the curve is kept)"""
    bl_idname = "object.pro_char_convert_curve_safe"
    bl_label = "Convert Curve to Mesh Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_curve(context) is not None

    def execute(self, context):
        src = _active_curve(context)
        dup = src.copy()
        dup.data = src.data.copy()
        dup.name = f"{src.name}_Mesh"
        for coll in src.users_collection:
            coll.objects.link(dup)
        for o in context.selected_objects:
            o.select_set(False)
        dup.select_set(True)
        context.view_layer.objects.active = dup
        bpy.ops.object.convert(target='MESH')
        self.report({'INFO'},
                    f"'{dup.name}' convertido a malla — la curva original se conserva")
        return {'FINISHED'}


class OBJECT_OT_pro_char_set_curve_bevel(bpy.types.Operator):
    """Apply the panel's bevel depth to the selected curves"""
    bl_idname = "object.pro_char_set_curve_bevel"
    bl_label = "Set Curve Bevel Depth"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'CURVE' for o in context.selected_objects)

    def execute(self, context):
        p = context.scene.pro_toolkit
        n = 0
        for obj in context.selected_objects:
            if obj.type == 'CURVE':
                obj.data.bevel_depth = p.curve_bevel_depth
                obj.data.use_fill_caps = True
                n += 1
        self.report({'INFO'},
                    f"Bevel {p.curve_bevel_depth:.3f} aplicado a {n} curva(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_taper_curve_ends(bpy.types.Operator):
    """Taper the selected curves toward their tips (point radius ramp)"""
    bl_idname = "object.pro_char_taper_curve_ends"
    bl_label = "Taper Curve Ends"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'CURVE' for o in context.selected_objects)

    def execute(self, context):
        n = 0
        for obj in context.selected_objects:
            if obj.type != 'CURVE':
                continue
            for spline in obj.data.splines:
                pts = (spline.bezier_points if spline.type == 'BEZIER'
                       else spline.points)
                count = len(pts)
                for i, bp in enumerate(pts):
                    t = i / max(count - 1, 1)
                    bp.radius = max(1.0 - 0.9 * t, 0.05)
            n += 1
        self.report({'INFO'}, f"Taper aplicado a {n} curva(s) (punta al 5%)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_curve_resolution_preset(bpy.types.Operator):
    """Apply a resolution preset to the selected curves"""
    bl_idname = "object.pro_char_curve_resolution_preset"
    bl_label = "Add Curve Resolution Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Preset",
        items=[('LOW', "Low", "u=6, bevel 2 — blockout ligero"),
               ('MEDIUM', "Medium", "u=12, bevel 3 — trabajo normal"),
               ('HIGH', "High", "u=24, bevel 5 — close-ups")],
        default='MEDIUM')

    @classmethod
    def poll(cls, context):
        return any(o.type == 'CURVE' for o in context.selected_objects)

    def execute(self, context):
        res = {'LOW': (6, 2), 'MEDIUM': (12, 3), 'HIGH': (24, 5)}[self.preset]
        n = 0
        for obj in context.selected_objects:
            if obj.type == 'CURVE':
                obj.data.resolution_u = res[0]
                obj.data.bevel_resolution = res[1]
                n += 1
        self.report({'INFO'}, f"Resolución {self.preset} en {n} curva(s)")
        return {'FINISHED'}


class MESH_OT_pro_char_curve_along_selection(bpy.types.Operator):
    """Create an organic curve through the selected vertex chain
    (ordered by edge connectivity)"""
    bl_idname = "mesh.pro_char_curve_along_selection"
    bl_label = "Create Curve Along Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        import bmesh
        p = context.scene.pro_toolkit
        obj = context.edit_object
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [v for v in bm.verts if v.select]
        if len(sel) < 2:
            self.report({'WARNING'}, "Selecciona una cadena de vértices.")
            return {'CANCELLED'}

        sel_set = set(sel)
        # find an endpoint of the chain (vert with 1 selected neighbour)
        def sel_nbrs(v):
            return [e.other_vert(v) for e in v.link_edges
                    if e.other_vert(v) in sel_set]
        start = next((v for v in sel if len(sel_nbrs(v)) == 1), sel[0])

        ordered = [start]
        visited = {start}
        cur = start
        while True:
            nxt = [n for n in sel_nbrs(cur) if n not in visited]
            if not nxt:
                break
            cur = nxt[0]
            ordered.append(cur)
            visited.add(cur)
        if len(ordered) < 2:
            self.report({'WARNING'},
                        "La selección no forma una cadena conectada.")
            return {'CANCELLED'}

        mw = obj.matrix_world
        world_pts = [mw @ v.co for v in ordered]
        bpy.ops.object.mode_set(mode='OBJECT')
        cursor_backup = context.scene.cursor.location.copy()
        context.scene.cursor.location = world_pts[0]
        curve = _new_curve(context, "PRO_curve_along_selection",
                           [pt - world_pts[0] for pt in world_pts],
                           p.curve_bevel_depth, "PRO_Curve_Root",
                           taper=0.6 if p.curve_taper_ends else 0.0,
                           resolution=p.curve_resolution)
        context.scene.cursor.location = cursor_backup
        self.report({'INFO'},
                    f"Curva creada siguiendo {len(ordered)} vértices "
                    f"({len(ordered) - len(sel)} fuera de cadena ignorados)"
                    if len(ordered) != len(sel) else
                    f"Curva creada siguiendo {len(ordered)} vértices")
        return {'FINISHED'}


classes = _curve_classes + (
    OBJECT_OT_pro_char_convert_curve_safe,
    OBJECT_OT_pro_char_set_curve_bevel,
    OBJECT_OT_pro_char_taper_curve_ends,
    OBJECT_OT_pro_char_curve_resolution_preset,
    MESH_OT_pro_char_curve_along_selection,
)
