# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  __init__.py
# Bootstrap, hot-reload, register/unregister
# ──────────────────────────────────────────────────────────────────────

bl_info = {
    "name": "Blender Pro Modeling Toolkit",
    "author": "Saúl / Diarka Studio",
    "version": (0, 1, 7, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Pro Toolkit",
    "description": "A practical modeling toolkit for Blender · Diarka Studio",
    "category": "Mesh",
}

# ── Imports + hot-reload support ────────────────────────────────────
# Import first, reload afterwards: this stays correct even when new
# submodules are added between versions (a plain reload-only branch
# raises NameError for modules the previous version never imported).
_RELOAD = "bpy" in locals()

from . import uv_utils
from . import node_utils
from . import core_toolkit
from . import ops_vertices
from . import ops_edges_faces
from . import ops_selection
from . import ops_pivot_origin
from . import ops_architecture
from . import ops_character
from . import ops_shapes
from . import ops_uv
from . import ops_uv_audit
from . import ops_toon_presets
from . import ops_cel_shading
from . import creation_utils
from . import profile_revolve_utils
from . import ops_creation_architecture
from . import ops_creation_products
from . import ops_creation_shapes
from . import ops_creation_transform
from . import ops_creation_sf_presets
from . import ops_profile_revolve
from . import hardsurface_utils
from . import ops_hardsurface_bevels
from . import ops_hardsurface_booleans
from . import ops_hardsurface_panels
from . import ops_hardsurface_details
from . import ops_hardsurface_supermarket
from . import ops_hardsurface_cleanup
from . import ops_hardsurface_mech_panels
from . import ops_hardsurface_alignment
from . import character_utils
from . import retopo_utils
from . import ops_char_organic
from . import ops_char_ai_cleanup
from . import ops_char_symmetry
from . import ops_char_retopo
from . import ops_char_topology_audit
from . import ops_char_gameready
from . import ops_char_guides
from . import ops_char_curves
from . import material_utils
from . import texture_utils
from . import baking_utils
from . import ops_material_audit
from . import ops_material_cleanup
from . import ops_texture_tools
from . import ops_pbr_builder
from . import ops_procedural_materials
from . import ops_baking
from . import ops_unity_material_prep
from . import ui_panels

if _RELOAD:
    import importlib
    uv_utils = importlib.reload(uv_utils)
    node_utils = importlib.reload(node_utils)
    core_toolkit = importlib.reload(core_toolkit)
    ops_vertices = importlib.reload(ops_vertices)
    ops_edges_faces = importlib.reload(ops_edges_faces)
    ops_selection = importlib.reload(ops_selection)
    ops_pivot_origin = importlib.reload(ops_pivot_origin)
    ops_architecture = importlib.reload(ops_architecture)
    ops_character = importlib.reload(ops_character)
    ops_shapes = importlib.reload(ops_shapes)
    ops_uv = importlib.reload(ops_uv)
    ops_uv_audit = importlib.reload(ops_uv_audit)
    ops_toon_presets = importlib.reload(ops_toon_presets)
    ops_cel_shading = importlib.reload(ops_cel_shading)
    creation_utils = importlib.reload(creation_utils)
    profile_revolve_utils = importlib.reload(profile_revolve_utils)
    ops_creation_architecture = importlib.reload(ops_creation_architecture)
    ops_creation_products = importlib.reload(ops_creation_products)
    ops_creation_shapes = importlib.reload(ops_creation_shapes)
    ops_creation_transform = importlib.reload(ops_creation_transform)
    ops_creation_sf_presets = importlib.reload(ops_creation_sf_presets)
    ops_profile_revolve = importlib.reload(ops_profile_revolve)
    hardsurface_utils = importlib.reload(hardsurface_utils)
    ops_hardsurface_bevels = importlib.reload(ops_hardsurface_bevels)
    ops_hardsurface_booleans = importlib.reload(ops_hardsurface_booleans)
    ops_hardsurface_panels = importlib.reload(ops_hardsurface_panels)
    ops_hardsurface_details = importlib.reload(ops_hardsurface_details)
    ops_hardsurface_supermarket = importlib.reload(ops_hardsurface_supermarket)
    ops_hardsurface_cleanup = importlib.reload(ops_hardsurface_cleanup)
    ops_hardsurface_mech_panels = importlib.reload(ops_hardsurface_mech_panels)
    ops_hardsurface_alignment = importlib.reload(ops_hardsurface_alignment)
    character_utils = importlib.reload(character_utils)
    retopo_utils = importlib.reload(retopo_utils)
    ops_char_organic = importlib.reload(ops_char_organic)
    ops_char_ai_cleanup = importlib.reload(ops_char_ai_cleanup)
    ops_char_symmetry = importlib.reload(ops_char_symmetry)
    ops_char_retopo = importlib.reload(ops_char_retopo)
    ops_char_topology_audit = importlib.reload(ops_char_topology_audit)
    ops_char_gameready = importlib.reload(ops_char_gameready)
    ops_char_guides = importlib.reload(ops_char_guides)
    ops_char_curves = importlib.reload(ops_char_curves)
    material_utils = importlib.reload(material_utils)
    texture_utils = importlib.reload(texture_utils)
    baking_utils = importlib.reload(baking_utils)
    ops_material_audit = importlib.reload(ops_material_audit)
    ops_material_cleanup = importlib.reload(ops_material_cleanup)
    ops_texture_tools = importlib.reload(ops_texture_tools)
    ops_pbr_builder = importlib.reload(ops_pbr_builder)
    ops_procedural_materials = importlib.reload(ops_procedural_materials)
    ops_baking = importlib.reload(ops_baking)
    ops_unity_material_prep = importlib.reload(ops_unity_material_prep)
    ui_panels = importlib.reload(ui_panels)

import bpy


# ── Registration ────────────────────────────────────────────────────
_classes = []


def _gather_classes():
    """Collect every registrable class from submodules in order."""
    global _classes
    _classes = []

    # PropertyGroup first
    _classes.append(ui_panels.ProToolkitProperties)

    # Utility operators
    _classes.append(ui_panels.PRO_TOOLKIT_OT_clear_search)

    # Operators – vertices
    _classes.extend([
        ops_vertices.MESH_OT_pro_push_pull,
        ops_vertices.MESH_OT_pro_relax,
        ops_vertices.MESH_OT_pro_flatten,
        ops_vertices.MESH_OT_pro_align,
        ops_vertices.MESH_OT_pro_merge_distance,
    ])

    # Operators – edges / faces
    _classes.extend([
        ops_edges_faces.MESH_OT_pro_circularize,
        ops_edges_faces.MESH_OT_pro_bevel,
        ops_edges_faces.MESH_OT_pro_extrude,
        ops_edges_faces.MESH_OT_pro_solidify,
        ops_edges_faces.MESH_OT_pro_inset,
        ops_edges_faces.MESH_OT_pro_select_ngons,
        ops_edges_faces.MESH_OT_pro_select_tris,
        ops_edges_faces.MESH_OT_pro_select_non_manifold,
    ])

    # Operators – advanced selection
    _classes.extend([
        ops_selection.MESH_OT_pro_select_boundary,
        ops_selection.MESH_OT_pro_select_loose,
        ops_selection.MESH_OT_pro_select_sharp_edges,
        ops_selection.MESH_OT_pro_select_seams,
        ops_selection.MESH_OT_pro_grow_selection,
        ops_selection.MESH_OT_pro_shrink_selection,
        ops_selection.MESH_OT_pro_invert_selection,
    ])

    # Operators – pivot / origin
    _classes.extend([
        ops_pivot_origin.OBJECT_OT_pro_origin_to_bottom,
        ops_pivot_origin.OBJECT_OT_pro_origin_to_center,
        ops_pivot_origin.OBJECT_OT_pro_origin_to_cursor,
        ops_pivot_origin.OBJECT_OT_pro_center_on_floor,
        ops_pivot_origin.OBJECT_OT_pro_apply_scale_safe,
        ops_pivot_origin.OBJECT_OT_pro_apply_rotation_safe,
    ])

    # Operators – architecture / blockout
    _classes.extend([
        ops_architecture.OBJECT_OT_pro_add_wall_cube,
        ops_architecture.OBJECT_OT_pro_add_floor_plane,
        ops_architecture.OBJECT_OT_pro_add_door_blockout,
        ops_architecture.OBJECT_OT_pro_add_window_blockout,
        ops_architecture.OBJECT_OT_pro_add_roof_blockout,
    ])

    # Operators – character / organic
    _classes.extend([
        ops_character.OBJECT_OT_pro_add_character_mirror,
        ops_character.OBJECT_OT_pro_add_subdivision_preview,
        ops_character.OBJECT_OT_pro_add_shrinkwrap,
        ops_character.MESH_OT_pro_smooth_selection,
        ops_character.MESH_OT_pro_inflate_deflate,
        ops_character.MESH_OT_pro_symmetrize_x,
        ops_character.MESH_OT_pro_snap_to_symmetry_x,
    ])

    # Operators – shape creation
    _classes.extend([
        ops_shapes.OBJECT_OT_pro_make_rounded_box,
        ops_shapes.OBJECT_OT_pro_add_pipe_curve,
        ops_shapes.OBJECT_OT_pro_add_cable_curve,
        ops_shapes.MESH_OT_pro_make_hole_basic,
        ops_shapes.MESH_OT_pro_make_slot_basic,
        ops_shapes.MESH_OT_pro_make_frame_basic,
    ])

    # Operators – object-level (audit, cleanup, modifiers, overlays, backups)
    _classes.extend([
        core_toolkit.OBJECT_OT_pro_toolkit_run_audit,
        core_toolkit.OBJECT_OT_pro_toolkit_one_click_cleanup,
        core_toolkit.OBJECT_OT_pro_toolkit_purge_backups,
        core_toolkit.OBJECT_OT_pro_toolkit_add_modifier,
        core_toolkit.OBJECT_OT_pro_face_orientation_toggle,
    ])

    # v0.1.2 – Pro UV Suite + Pro Cel Shading Suite (module class tuples)
    _classes.extend(ops_uv.classes)
    _classes.extend(ops_uv_audit.classes)
    _classes.extend(ops_toon_presets.classes)
    _classes.extend(ops_cel_shading.classes)

    # v0.1.3 – Pro Modeling Creation Suite (module class tuples)
    _classes.extend(ops_creation_architecture.classes)
    _classes.extend(ops_creation_products.classes)
    _classes.extend(ops_creation_shapes.classes)
    _classes.extend(ops_creation_transform.classes)
    _classes.extend(ops_creation_sf_presets.classes)
    _classes.extend(ops_profile_revolve.classes)

    # v0.1.4 – Hard Surface Pro Suite (module class tuples)
    _classes.extend(ops_hardsurface_bevels.classes)
    _classes.extend(ops_hardsurface_booleans.classes)
    _classes.extend(ops_hardsurface_panels.classes)
    _classes.extend(ops_hardsurface_details.classes)
    _classes.extend(ops_hardsurface_supermarket.classes)
    _classes.extend(ops_hardsurface_cleanup.classes)
    _classes.extend(ops_hardsurface_mech_panels.classes)
    _classes.extend(ops_hardsurface_alignment.classes)
    _classes.extend(ops_char_organic.classes)
    _classes.extend(ops_char_ai_cleanup.classes)
    _classes.extend(ops_char_symmetry.classes)
    _classes.extend(ops_char_retopo.classes)
    _classes.extend(ops_char_topology_audit.classes)
    _classes.extend(ops_char_gameready.classes)
    _classes.extend(ops_char_guides.classes)
    _classes.extend(ops_char_curves.classes)

    # v0.1.6 – Material / Texture / Baking Pro Suite (module class tuples)
    _classes.extend(ops_material_audit.classes)
    _classes.extend(ops_material_cleanup.classes)
    _classes.extend(ops_texture_tools.classes)
    _classes.extend(ops_pbr_builder.classes)
    _classes.extend(ops_procedural_materials.classes)
    _classes.extend(ops_baking.classes)
    _classes.extend(ops_unity_material_prep.classes)

    # Panels (parent first, then children in display order)
    _classes.extend([
        ui_panels.VIEW3D_PT_pro_toolkit_main,
        ui_panels.VIEW3D_PT_pro_toolkit_quick_tools,
        ui_panels.VIEW3D_PT_pro_toolkit_selection,
        ui_panels.VIEW3D_PT_pro_toolkit_vertices,
        ui_panels.VIEW3D_PT_pro_toolkit_edges,
        ui_panels.VIEW3D_PT_pro_toolkit_faces,
        ui_panels.VIEW3D_PT_pro_toolkit_shapes,
        ui_panels.VIEW3D_PT_pro_toolkit_pivot_origin,
        ui_panels.VIEW3D_PT_pro_toolkit_architecture,
        ui_panels.VIEW3D_PT_pro_toolkit_character,
        # Pro UV Suite
        ui_panels.VIEW3D_PT_pro_toolkit_uv_suite,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_maps,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_seams,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_unwrap,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_islands,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_density,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_checker,
        ui_panels.VIEW3D_PT_pro_toolkit_uv_audit,
        # Pro Cel Shading Suite
        ui_panels.VIEW3D_PT_pro_toolkit_cel_suite,
        ui_panels.VIEW3D_PT_pro_toolkit_cel_presets,
        ui_panels.VIEW3D_PT_pro_toolkit_cel_controls,
        ui_panels.VIEW3D_PT_pro_toolkit_cel_outlines,
        ui_panels.VIEW3D_PT_pro_toolkit_cel_freestyle,
        ui_panels.VIEW3D_PT_pro_toolkit_cel_convert,
        ui_panels.VIEW3D_PT_pro_toolkit_cel_lighting,
        # v0.1.3 — Pro Modeling Creation Suite
        ui_panels.VIEW3D_PT_pro_toolkit_creation,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_arch,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_products,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_shapes,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_lathe,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_pivot,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_measure,
        ui_panels.VIEW3D_PT_pro_toolkit_creation_sf,
        # v0.1.4 — Hard Surface Pro Suite
        ui_panels.VIEW3D_PT_pro_toolkit_hardsurface,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_bevel,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_booleans,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_mech_panels,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_panels,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_details,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_cleanup,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_alignment,
        ui_panels.VIEW3D_PT_pro_toolkit_hs_supermarket,
        # Character / Organic / Retopo Pro (v0.1.5)
        ui_panels.VIEW3D_PT_pro_toolkit_charpro,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_cleanup,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_ai,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_symmetry,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_retopo,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_retopo_draw,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_audit,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_shapes,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_curves,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_guides,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_sculpt,
        ui_panels.VIEW3D_PT_pro_toolkit_charpro_gameready,
        # v0.1.6 — Material / Texture / Baking Pro Suite
        ui_panels.VIEW3D_PT_pro_toolkit_mtb,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_audit,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_cleanup,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_textures,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_pbr,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_procedural,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_atlas,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_bake_setup,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_bake_maps,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_highlow,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_unity,
        ui_panels.VIEW3D_PT_pro_toolkit_mtb_reports,
        # Tail panels
        ui_panels.VIEW3D_PT_pro_toolkit_modifiers,
        ui_panels.VIEW3D_PT_pro_toolkit_cleanup,
        ui_panels.VIEW3D_PT_pro_toolkit_footer,
    ])


def register():
    _gather_classes()
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pro_toolkit = bpy.props.PointerProperty(
        type=ui_panels.ProToolkitProperties,
    )


def unregister():
    if hasattr(bpy.types.Scene, "pro_toolkit"):
        del bpy.types.Scene.pro_toolkit
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
