# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_pivot_origin.py
# Pivot / origin placement and safe transform-apply (Object Mode)
# ──────────────────────────────────────────────────────────────────────

import bpy
from mathutils import Vector


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _object_mode_poll(context):
    return (context.mode == 'OBJECT'
            and context.active_object is not None
            and context.active_object.type == 'MESH')


def _selected_mesh_objects(context):
    return [o for o in context.selected_objects if o.type == 'MESH']


def _world_bbox(obj):
    """Return the 8 bounding-box corners of *obj* in world space."""
    return [obj.matrix_world @ Vector(c) for c in obj.bound_box]


def _origin_to_world_point(context, obj, world_point):
    """Move *obj*'s origin to *world_point* using the (well-tested) native
    operator, isolating selection so only this object is affected."""
    cursor = context.scene.cursor
    prev_cursor = cursor.location.copy()
    prev_selected = context.selected_objects[:]
    prev_active = context.view_layer.objects.active

    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    cursor.location = world_point
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

    cursor.location = prev_cursor
    bpy.ops.object.select_all(action='DESELECT')
    for o in prev_selected:
        o.select_set(True)
    context.view_layer.objects.active = prev_active


# ═══════════════════════════════════════════════════════════════════════
#  Origin to Bottom
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_origin_to_bottom(bpy.types.Operator):
    """Place the origin at the bottom center of each selected mesh"""
    bl_idname = "object.pro_origin_to_bottom"
    bl_label = "Origin to Bottom"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        objs = _selected_mesh_objects(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}

        for obj in objs:
            corners = _world_bbox(obj)
            min_z = min(c.z for c in corners)
            cx = sum(c.x for c in corners) / 8.0
            cy = sum(c.y for c in corners) / 8.0
            _origin_to_world_point(context, obj, Vector((cx, cy, min_z)))

        self.report({'INFO'}, f"Origin to bottom: {len(objs)} object(s)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Origin to Center / Cursor
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_origin_to_center(bpy.types.Operator):
    """Place the origin at the geometry center of each selected mesh"""
    bl_idname = "object.pro_origin_to_center"
    bl_label = "Origin to Center"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        objs = _selected_mesh_objects(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        self.report({'INFO'}, f"Origin to center: {len(objs)} object(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_origin_to_cursor(bpy.types.Operator):
    """Place the origin of selected objects at the 3D cursor"""
    bl_idname = "object.pro_origin_to_cursor"
    bl_label = "Origin to Cursor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        objs = _selected_mesh_objects(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        self.report({'INFO'}, f"Origin to cursor: {len(objs)} object(s)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Center on Floor
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_center_on_floor(bpy.types.Operator):
    """Drop each selected mesh so its lowest point sits on Z = 0"""
    bl_idname = "object.pro_center_on_floor"
    bl_label = "Center on Floor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        objs = _selected_mesh_objects(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}

        for obj in objs:
            min_z = min(c.z for c in _world_bbox(obj))
            mw = obj.matrix_world.copy()
            mw.translation.z -= min_z
            obj.matrix_world = mw

        self.report({'INFO'}, f"Placed {len(objs)} object(s) on the floor")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Safe Apply Scale / Rotation
# ═══════════════════════════════════════════════════════════════════════

def _apply_transform_safe(context, scale=False, rotation=False):
    """Apply transforms per object, skipping multi-user meshes.
    Returns (applied_count, skipped_names)."""
    objs = _selected_mesh_objects(context)
    prev_selected = context.selected_objects[:]
    prev_active = context.view_layer.objects.active

    applied = 0
    skipped = []
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objs:
        if obj.data.users > 1:
            skipped.append(obj.name)
            continue
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.transform_apply(location=False, rotation=rotation, scale=scale)
        obj.select_set(False)
        applied += 1

    bpy.ops.object.select_all(action='DESELECT')
    for o in prev_selected:
        o.select_set(True)
    context.view_layer.objects.active = prev_active
    return applied, skipped


class OBJECT_OT_pro_apply_scale_safe(bpy.types.Operator):
    """Apply scale on selected meshes (skips shared/multi-user mesh data)"""
    bl_idname = "object.pro_apply_scale_safe"
    bl_label = "Apply Scale (Safe)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        applied, skipped = _apply_transform_safe(context, scale=True)
        if skipped:
            self.report({'WARNING'},
                        f"Applied scale on {applied} object(s). "
                        f"Skipped multi-user data: {', '.join(skipped)}")
        else:
            self.report({'INFO'}, f"Applied scale on {applied} object(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_apply_rotation_safe(bpy.types.Operator):
    """Apply rotation on selected meshes (skips shared/multi-user mesh data)"""
    bl_idname = "object.pro_apply_rotation_safe"
    bl_label = "Apply Rotation (Safe)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        applied, skipped = _apply_transform_safe(context, rotation=True)
        if skipped:
            self.report({'WARNING'},
                        f"Applied rotation on {applied} object(s). "
                        f"Skipped multi-user data: {', '.join(skipped)}")
        else:
            self.report({'INFO'}, f"Applied rotation on {applied} object(s)")
        return {'FINISHED'}
