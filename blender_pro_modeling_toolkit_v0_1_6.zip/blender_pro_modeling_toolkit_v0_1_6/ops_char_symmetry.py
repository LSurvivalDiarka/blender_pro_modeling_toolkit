# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_symmetry.py
# v0.1.5: premium symmetry tools. KDTree-based symmetry checks per axis,
# safe symmetrize, non-destructive Mirror by default, confirmed+backed-up
# Apply Mirror, snap-to-plane and a symmetry plane helper object.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from mathutils import Vector, kdtree

from . import character_utils as ch


def _axis_index(axis):
    return {'X': 0, 'Y': 1, 'Z': 2}[axis]


def _check_symmetry(obj, axis_i, tolerance):
    """Count vertices without a mirrored partner within *tolerance*.
    Returns (unmatched, total, unmatched_indices)."""
    me = obj.data
    size = len(me.vertices)
    if size == 0:
        return 0, 0, []
    tree = kdtree.KDTree(size)
    for v in me.vertices:
        tree.insert(v.co, v.index)
    tree.balance()

    unmatched = []
    for v in me.vertices:
        mirrored = v.co.copy()
        mirrored[axis_i] = -mirrored[axis_i]
        _, _, dist = tree.find(mirrored)
        if dist is None or dist > tolerance:
            unmatched.append(v.index)
    return len(unmatched), size, unmatched


def _origin_warnings(obj, axis_i):
    msgs = []
    corners = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    center = sum(corners, Vector()) / 8.0
    span = max(obj.dimensions[axis_i], 1e-6)
    if abs(center[axis_i] - obj.matrix_world.translation[axis_i]) > span * 0.05:
        msgs.append("el origen no está centrado en el eje")
    if any(abs(a) > 1e-4 for a in obj.rotation_euler):
        msgs.append("el objeto está rotado respecto al mundo")
    return msgs


def _make_check_op(axis):
    class _Op(bpy.types.Operator):
        bl_idname = f"object.pro_char_check_symmetry_{axis.lower()}"
        bl_label = f"Check Symmetry {axis}"
        bl_description = (f"Check vertex symmetry across the {axis}=0 plane "
                          "(KDTree, tolerance configurable)")
        bl_options = {'REGISTER'}

        @classmethod
        def poll(cls, context):
            return (context.active_object is not None
                    and context.active_object.type == 'MESH')

        def execute(self, context):
            p = context.scene.pro_toolkit
            obj = context.active_object
            unmatched, total, _idx = _check_symmetry(
                obj, _axis_index(axis), p.symmetry_tolerance)
            pct = 100.0 * (total - unmatched) / total if total else 100.0
            warns = _origin_warnings(obj, _axis_index(axis))
            msg = (f"Symmetry {axis}: {pct:.1f}% simétrico "
                   f"({unmatched} de {total} verts sin pareja, "
                   f"tol {p.symmetry_tolerance:.4f})")
            if warns:
                msg += " — AVISO: " + "; ".join(warns)
                self.report({'WARNING'}, msg)
            else:
                self.report({'INFO'}, msg)
            return {'FINISHED'}

    _Op.__name__ = f"OBJECT_OT_pro_char_check_symmetry_{axis.lower()}"
    return _Op


OBJECT_OT_pro_char_check_symmetry_x = _make_check_op('X')
OBJECT_OT_pro_char_check_symmetry_y = _make_check_op('Y')
OBJECT_OT_pro_char_check_symmetry_z = _make_check_op('Z')


def _make_symmetrize_op(direction, label):
    class _Op(bpy.types.Operator):
        bl_idname = f"object.pro_char_symmetrize_{direction.lower()}"
        bl_label = label
        bl_description = f"Symmetrize the whole mesh: {label} (backup first)"
        bl_options = {'REGISTER', 'UNDO'}

        @classmethod
        def poll(cls, context):
            return ch.object_mode_poll(context)

        def execute(self, context):
            p = context.scene.pro_toolkit
            obj = context.active_object
            ch.backup_object(context, obj, "_pre_symmetrize")
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.symmetrize(direction=direction,
                                    threshold=p.symmetry_tolerance)
            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'INFO'}, f"{label} aplicado (backup creado)")
            return {'FINISHED'}

    _Op.__name__ = f"OBJECT_OT_pro_char_symmetrize_{direction.lower()}"
    return _Op


OBJECT_OT_pro_char_symmetrize_positive_x = _make_symmetrize_op(
    'POSITIVE_X', "Symmetrize +X to -X")
OBJECT_OT_pro_char_symmetrize_negative_x = _make_symmetrize_op(
    'NEGATIVE_X', "Symmetrize -X to +X")


class OBJECT_OT_pro_char_add_mirror_safe(bpy.types.Operator):
    """Add a non-destructive Mirror modifier (clip + merge). Warns if the
    origin is off-center or the object is rotated"""
    bl_idname = "object.pro_char_add_mirror_safe"
    bl_label = "Add Mirror Modifier Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        if any(m.type == 'MIRROR' for m in obj.modifiers):
            self.report({'INFO'}, "Mirror ya presente — no se duplica.")
            return {'CANCELLED'}
        axis_i = _axis_index(p.symmetry_axis)
        mod = obj.modifiers.new("PRO_Char_Mirror", 'MIRROR')
        mod.use_axis = tuple(i == axis_i for i in range(3))
        mod.use_clip = True
        mod.use_mirror_merge = True
        mod.merge_threshold = max(p.symmetry_tolerance, 1e-5)
        mod.show_on_cage = True
        warns = _origin_warnings(obj, axis_i)
        if warns:
            self.report({'WARNING'},
                        f"Mirror {p.symmetry_axis} añadido, pero "
                        + "; ".join(warns) + " — el espejo puede salir desplazado.")
        else:
            self.report({'INFO'}, f"Mirror {p.symmetry_axis} añadido (clip+merge)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_apply_mirror_safe(bpy.types.Operator):
    """Apply the Mirror modifier WITH confirmation and a backup first"""
    bl_idname = "object.pro_char_apply_mirror_safe"
    bl_label = "Apply Mirror Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (ch.object_mode_poll(context)
                and any(m.type == 'MIRROR' for m in obj.modifiers))

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.active_object
        if obj.data.users > 1:
            self.report({'WARNING'},
                        f"La malla de '{obj.name}' es multiusuario "
                        f"({obj.data.users}) — hazla single-user antes de aplicar.")
            return {'CANCELLED'}
        ch.backup_object(context, obj, "_pre_mirror_apply")
        mods = [m.name for m in obj.modifiers if m.type == 'MIRROR']
        for name in mods:
            with context.temp_override(object=obj):
                bpy.ops.object.modifier_apply(modifier=name)
        self.report({'INFO'},
                    f"Mirror aplicado ({len(mods)}) — backup creado.")
        return {'FINISHED'}


class MESH_OT_pro_char_snap_to_symmetry_plane(bpy.types.Operator):
    """Snap selected vertices that are near the symmetry plane exactly
    onto it (seals the center seam)"""
    bl_idname = "mesh.pro_char_snap_to_symmetry_plane"
    bl_label = "Snap Vertices to Symmetry Plane"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        axis_i = _axis_index(p.symmetry_axis)
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        pool = sel if sel else list(bm.verts)
        snapped = 0
        for v in pool:
            if abs(v.co[axis_i]) <= p.symmetry_snap_distance and v.co[axis_i] != 0.0:
                v.co[axis_i] = 0.0
                snapped += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"{snapped} verts pegados al plano {p.symmetry_axis}=0 "
                    f"(dist ≤ {p.symmetry_snap_distance:.4f}, "
                    f"{'selección' if sel else 'toda la malla'})")
        return {'FINISHED'}


class OBJECT_OT_pro_char_create_symmetry_plane(bpy.types.Operator):
    """Create a wire symmetry-plane helper sized to the active object"""
    bl_idname = "object.pro_char_create_symmetry_plane"
    bl_label = "Create Symmetry Plane Helper"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        src = context.active_object
        axis_i = _axis_index(p.symmetry_axis)
        d = src.dimensions
        size = max(d.x, d.y, d.z, 0.1) * 1.2

        bm = bmesh.new()
        bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=size / 2.0)
        # grid is XY; orient so its normal lies on the symmetry axis
        for v in bm.verts:
            x, y, z = v.co
            if axis_i == 0:
                v.co = Vector((0.0, x, y))
            elif axis_i == 1:
                v.co = Vector((x, 0.0, y))
        me = bpy.data.meshes.new("PRO_Symmetry_Plane")
        bm.to_mesh(me)
        bm.free()

        obj = bpy.data.objects.new(f"PRO_Symmetry_Plane_{p.symmetry_axis}", me)
        ch.get_coll(context, ch.COLL_GUIDES).objects.link(obj)
        center = sum((src.matrix_world @ Vector(c) for c in src.bound_box),
                     Vector()) / 8.0
        center[axis_i] = src.matrix_world.translation[axis_i]
        obj.location = center
        ch.assign_char_material(obj, "PRO_Symmetry_Red")
        obj.display_type = 'WIRE'
        obj.show_in_front = True
        obj.hide_render = True
        self.report({'INFO'},
                    f"Plano de simetría {p.symmetry_axis} creado en {ch.COLL_GUIDES}")
        return {'FINISHED'}


class MESH_OT_pro_char_select_asymmetrical(bpy.types.Operator):
    """Select vertices without a mirrored partner across the symmetry axis"""
    bl_idname = "mesh.pro_char_select_asymmetrical"
    bl_label = "Select Asymmetrical Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        if obj.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')   # sync mesh data
        unmatched, total, idx = _check_symmetry(
            obj, _axis_index(p.symmetry_axis), p.symmetry_tolerance)
        idx_set = set(idx)
        for v in obj.data.vertices:
            v.select = v.index in idx_set
        for e in obj.data.edges:
            e.select = False
        for f in obj.data.polygons:
            f.select = False
        bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (True, False, False)
        self.report({'INFO'},
                    f"{unmatched} de {total} verts asimétricos seleccionados "
                    f"(eje {p.symmetry_axis})")
        return {'FINISHED'}


class OBJECT_OT_pro_char_report_symmetry(bpy.types.Operator):
    """Run the symmetry check on X, Y and Z and summarize the errors"""
    bl_idname = "object.pro_char_report_symmetry"
    bl_label = "Report Symmetry Errors"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        lines = []
        for axis in ('X', 'Y', 'Z'):
            unmatched, total, _ = _check_symmetry(
                obj, _axis_index(axis), p.symmetry_tolerance)
            pct = 100.0 * (total - unmatched) / total if total else 100.0
            lines.append(f"{axis}: {pct:.1f}% ({unmatched} sin pareja)")

        if not bpy.app.background and context.window is not None:  # popup crashes headless
            def draw(menu, _ctx):
                menu.layout.label(text=f"Simetría de '{obj.name}' "
                                       f"(tol {p.symmetry_tolerance:.4f})")
                for line in lines:
                    menu.layout.label(text=line)
            context.window_manager.popup_menu(draw, title="Symmetry Report",
                                              icon='MOD_MIRROR')
        self.report({'INFO'}, "Simetría — " + " | ".join(lines))
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_char_check_symmetry_x,
    OBJECT_OT_pro_char_check_symmetry_y,
    OBJECT_OT_pro_char_check_symmetry_z,
    OBJECT_OT_pro_char_symmetrize_positive_x,
    OBJECT_OT_pro_char_symmetrize_negative_x,
    OBJECT_OT_pro_char_add_mirror_safe,
    OBJECT_OT_pro_char_apply_mirror_safe,
    MESH_OT_pro_char_snap_to_symmetry_plane,
    OBJECT_OT_pro_char_create_symmetry_plane,
    MESH_OT_pro_char_select_asymmetrical,
    OBJECT_OT_pro_char_report_symmetry,
)
