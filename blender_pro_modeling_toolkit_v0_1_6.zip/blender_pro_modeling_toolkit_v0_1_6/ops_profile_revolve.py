# -----------------------------------------------------------------------------
# Blender Pro Modeling Toolkit - ops_profile_revolve.py
# Profile Revolve / Lathe Pro operators.
#
# Professional profile + Screw/Lathe workflow. No final prefab assets are made:
# preset buttons only create editable side profiles that the artist can modify.
# -----------------------------------------------------------------------------

import bpy

from . import core_toolkit
from . import material_utils as mu
from . import profile_revolve_utils as pru


def _props(context):
    return context.scene.pro_toolkit


def _active_profile(context):
    return pru.active_profile_object(context)


def _profile_selection(context):
    objs = pru.selected_profile_objects(context)
    active = _active_profile(context)
    if active and active not in objs:
        objs.append(active)
    return objs


def _ensure_object_mode(context):
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')


def _make_active(context, obj):
    for other in context.selected_objects:
        other.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


def _make_single_user_mesh(obj):
    if hasattr(obj.data, "users") and obj.data.users > 1:
        obj.data = obj.data.copy()


def _apply_modifier(context, obj, mod_name):
    _make_active(context, obj)
    with context.temp_override(object=obj, active_object=obj):
        bpy.ops.object.modifier_apply(modifier=mod_name)


def _write_audit_report(context, obj, audit):
    lines = [
        "# V PROFILE REVOLVE VALIDATION REPORT",
        "",
        "## Active Profile",
        f"- Object: {obj.name if obj else '-'}",
        f"- Type: {obj.type if obj else '-'}",
        f"- Axis: {_props(context).lathe_axis}",
        f"- Points: {audit.get('point_count', 0)}",
        f"- Modifiers: {audit.get('modifier_count', 0)}",
        f"- Result: {'OK' if audit.get('ok') else 'Needs attention'}",
        "",
        "## Checks",
    ]
    warnings = audit.get("warnings") or []
    if warnings:
        lines.extend(f"- WARNING: {w}" for w in warnings)
    else:
        lines.extend([
            "- Profile has enough editable points.",
            "- Profile is on the revolve plane.",
            "- Radius side is clean.",
            "- Screw modifier is present.",
        ])
    lines.extend([
        "",
        "## Safety",
        "- Destructive apply/convert operators use the toolkit hidden backup system.",
        "- UV Suite, Cel Shading, Hard Surface, Character/Retopo, Material/Baking "
        "and Asset Organizer modules are not modified by this operator.",
    ])
    return mu.write_report("V_PROFILE_REVOLVE_VALIDATION_REPORT.md", lines)


def _safe_mode_set(mode):
    try:
        bpy.ops.object.mode_set(mode=mode)
        return True
    except Exception:
        return False


def _safe_tool_set(tool_ids):
    if bpy.app.background:
        return None
    for tool_id in tool_ids:
        try:
            bpy.ops.wm.tool_set_by_id(name=tool_id)
            return tool_id
        except Exception:
            continue
    return None


def _safe_front_view(context):
    if bpy.app.background:
        return False
    screen = getattr(context, "screen", None)
    if screen is None:
        return False
    for area in screen.areas:
        if area.type != 'VIEW_3D':
            continue
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if region is None:
            continue
        try:
            with context.temp_override(area=area, region=region):
                bpy.ops.view3d.view_axis(type='FRONT', align_active=False)
            return True
        except Exception:
            continue
    return False


def _select_active(context, obj):
    for other in context.selected_objects:
        other.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


def _maybe_axis(context):
    props = _props(context)
    if props.lathe_create_axis_guide:
        color = tuple(props.lathe_axis_color)
        return pru.create_axis_guide(context, props.lathe_axis_height, color)
    return None


def _apply_draw_view_setup(context, obj):
    props = _props(context)
    _select_active(context, obj)
    if props.lathe_auto_front_view:
        _safe_front_view(context)


def _report_tool_fallback(operator, tool_name):
    operator.report(
        {'INFO'},
        f"{tool_name} ready. Native tool activation is best-effort; "
        "select the drawing tool manually if Blender did not switch tools.")


def _selected_reference_image(context):
    for obj in context.selected_objects:
        if obj.type == 'EMPTY' and getattr(obj, "empty_display_type", None) == 'IMAGE':
            return obj
        if obj.type == 'IMAGE':
            return obj
    return None


def _selected_gp_object(context):
    for obj in context.selected_objects:
        if obj.type in {'GREASEPENCIL', 'GPENCIL'}:
            return obj
    return context.active_object if context.active_object and \
        context.active_object.type in {'GREASEPENCIL', 'GPENCIL'} else None


def _profile_side_warnings(obj, axis):
    cfg = pru.axis_config(axis)
    coords = list(pru.iter_editable_points(obj))
    if not coords:
        return ["Profile has no editable points."]
    radii = [co[cfg["radius"]] for co in coords]
    min_r = min(radii)
    max_r = max(radii)
    warnings = []
    if min_r < -1e-5:
        warnings.append("Profile crosses the revolve axis.")
    if min_r < -1e-5 and max_r > 1e-5:
        warnings.append("Profile has points on both sides of the axis.")
    return warnings


class OBJECT_OT_pro_lathe_create_axis_guide(bpy.types.Operator):
    """Create a visible non-rendering vertical axis guide at X=0"""
    bl_idname = "object.pro_lathe_create_axis_guide"
    bl_label = "Create Axis Guide"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = _props(context)
        obj = pru.create_axis_guide(
            context, props.lathe_axis_height, tuple(props.lathe_axis_color))
        _select_active(context, obj)
        self.report({'INFO'}, "LATHE_Axis_Guide created at X=0.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_center_reference_image_to_axis(bpy.types.Operator):
    """Center the selected reference image on the lathe axis"""
    bl_idname = "object.pro_lathe_center_reference_image_to_axis"
    bl_label = "Center Reference Image to Axis"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        obj = _selected_reference_image(context)
        if obj is None:
            self.report({'WARNING'}, "Select a reference image first.")
            return {'CANCELLED'}
        obj.location.x = 0.0
        self.report({'INFO'}, f"'{obj.name}' centered on the lathe axis.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_start_curve_profile_draw_mode(bpy.types.Operator):
    """Prepare an editable curve profile for tablet tracing"""
    bl_idname = "object.pro_lathe_start_curve_profile_draw_mode"
    bl_label = "Start Curve Profile Draw Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = _props(context)
        _maybe_axis(context)
        obj = pru.create_draw_curve(
            context, props.lathe_draw_profile_name, props.lathe_curve_resolution)
        _apply_draw_view_setup(context, obj)
        entered = _safe_mode_set('EDIT')
        tool = _safe_tool_set(('builtin.pen', 'builtin.draw', 'builtin.select_box'))
        if not entered or tool is None:
            _report_tool_fallback(self, "Curve Profile Draw Mode")
        self.report(
            {'INFO'},
            "Curve Profile Draw Mode ready. Draw only half of the bottle "
            "profile on one side of the axis.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_start_grease_pencil_sketch_mode(bpy.types.Operator):
    """Prepare a Grease Pencil object for tablet sketching over a reference"""
    bl_idname = "object.pro_lathe_start_grease_pencil_sketch_mode"
    bl_label = "Start Grease Pencil Sketch Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        _maybe_axis(context)
        try:
            bpy.ops.object.grease_pencil_add(type='EMPTY')
        except Exception:
            try:
                bpy.ops.object.gpencil_add(type='EMPTY')
            except Exception as exc:
                self.report({'WARNING'},
                            f"Could not create Grease Pencil object: {exc}")
                return {'CANCELLED'}
        obj = context.active_object
        obj.name = "LATHE_GP_Sketch"
        obj["pro_lathe_draw_mode"] = "GREASE_PENCIL"
        try:
            pru.cu.link_to_collection(context, obj, pru.COLL_PROFILE_REVOLVE)
        except Exception:
            pass
        _apply_draw_view_setup(context, obj)
        entered = _safe_mode_set('PAINT_GREASE_PENCIL')
        tool = _safe_tool_set(('builtin_brush.Draw', 'builtin.draw',
                               'builtin_brush.Pencil'))
        if not entered or tool is None:
            _report_tool_fallback(self, "Grease Pencil Sketch Mode")
        self.report(
            {'INFO'},
            "Grease Pencil Sketch Mode ready. Sketch the half profile, then "
            "convert/trace to a curve for clean revolve.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_convert_grease_pencil_to_profile_curve(bpy.types.Operator):
    """Try to convert the selected Grease Pencil sketch to a Curve profile"""
    bl_idname = "object.pro_lathe_convert_grease_pencil_to_profile_curve"
    bl_label = "Convert Grease Pencil to Profile Curve"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode in {'OBJECT', 'PAINT_GREASE_PENCIL', 'EDIT_GPENCIL'}

    def execute(self, context):
        _safe_mode_set('OBJECT')
        obj = _selected_gp_object(context)
        if obj is None:
            self.report({'WARNING'}, "Select a Grease Pencil sketch first.")
            return {'CANCELLED'}
        _select_active(context, obj)
        try:
            bpy.ops.object.convert(target='CURVE')
        except Exception as exc:
            self.report({'WARNING'},
                        f"Could not convert Grease Pencil to Curve: {exc}")
            return {'CANCELLED'}
        curve = context.active_object
        curve.name = "LATHE_GP_Profile_Curve"
        curve["pro_lathe_profile"] = True
        pru.assign_lathe_material(curve)
        self.report({'INFO'}, "Grease Pencil converted to profile Curve.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_start_vertex_trace_mode(bpy.types.Operator):
    """Create a minimal mesh profile for point-by-point tracing"""
    bl_idname = "object.pro_lathe_start_vertex_trace_mode"
    bl_label = "Start Vertex Trace Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        _maybe_axis(context)
        obj = pru.create_vertex_trace_mesh(context)
        _apply_draw_view_setup(context, obj)
        _safe_mode_set('EDIT')
        _safe_tool_set(('builtin.select_box', 'builtin.move'))
        self.report(
            {'INFO'},
            "Vertex Trace Mode ready. Use E or Ctrl+Right Click to trace the "
            "profile point by point.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_start_bezier_profile_mode(bpy.types.Operator):
    """Create a simple editable Bezier profile for silhouette tracing"""
    bl_idname = "object.pro_lathe_start_bezier_profile_mode"
    bl_label = "Start Bezier Profile Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = _props(context)
        _maybe_axis(context)
        obj = pru.create_bezier_profile(
            context, "LATHE_Bezier_Profile", props.lathe_curve_resolution)
        _apply_draw_view_setup(context, obj)
        _safe_mode_set('EDIT')
        _safe_tool_set(('builtin.select_box', 'builtin.move'))
        self.report(
            {'INFO'},
            "Bezier Profile Mode ready. Adjust handles to match the bottle "
            "silhouette.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_finish_profile_draw_mode(bpy.types.Operator):
    """Leave draw/edit modes and keep the active profile selected"""
    bl_idname = "object.pro_lathe_finish_profile_draw_mode"
    bl_label = "Finish Draw Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        _safe_mode_set('OBJECT')
        if obj is not None:
            _select_active(context, obj)
        self.report(
            {'INFO'},
            "Draw mode finished. Profile is selected and ready for Add Screw / "
            "Revolve 360.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_prepare_selected_profile_for_revolve(bpy.types.Operator):
    """Check and mark the selected Curve/Mesh profile as ready for Screw"""
    bl_idname = "object.pro_lathe_prepare_selected_profile_for_revolve"
    bl_label = "Prepare Selected Profile for Revolve"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        _safe_mode_set('OBJECT')
        obj = context.active_object
        if obj is None or obj.type not in {'MESH', 'CURVE'}:
            self.report({'WARNING'}, "Select a Mesh or Curve profile first.")
            return {'CANCELLED'}
        obj["pro_lathe_profile"] = True
        obj.location.y = 0.0
        warnings = _profile_side_warnings(obj, _props(context).lathe_axis)
        if warnings:
            self.report({'WARNING'}, " ".join(warnings))
        else:
            self.report({'INFO'}, "Selected profile is ready for Screw/Revolve.")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_trace_mode_help(bpy.types.Operator):
    """Show the basic Lathe tracing workflow"""
    bl_idname = "object.pro_lathe_trace_mode_help"
    bl_label = "Help: How to Trace for Lathe"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        lines = [
            "1. Add an image reference.",
            "2. Center the bottle on the axis.",
            "3. Draw only half of the side profile.",
            "4. Do not draw the full bottle.",
            "5. Use Revolve 360 when finished.",
        ]

        def draw(self, _context):
            col = self.layout.column(align=True)
            for line in lines:
                col.label(text=line)

        if not bpy.app.background and context.window_manager:
            context.window_manager.popup_menu(
                draw, title="Lathe Draw / Trace Mode", icon='INFO')
        self.report({'INFO'}, " ".join(lines))
        return {'FINISHED'}


class OBJECT_OT_pro_create_revolve_profile_mesh(bpy.types.Operator):
    """Create an editable mesh edge profile for Lathe/Screw modeling"""
    bl_idname = "object.pro_create_revolve_profile_mesh"
    bl_label = "Create Mesh Profile"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Profile",
        items=pru.preset_items(),
        default='SIMPLE_BOTTLE',
    )

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        obj = pru.create_profile_mesh(context, self.preset,
                                      _props(context).lathe_axis)
        self.report({'INFO'},
                    f"{pru.profile_label(self.preset)} mesh profile created. "
                    "Edit the side profile, then add Screw/Revolve.")
        return {'FINISHED'}


class OBJECT_OT_pro_create_revolve_profile_curve(bpy.types.Operator):
    """Create an editable curve side profile for drawing Lathe forms"""
    bl_idname = "object.pro_create_revolve_profile_curve"
    bl_label = "Create Curve Profile"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Profile",
        items=pru.preset_items(),
        default='SIMPLE_BOTTLE',
    )

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        pru.create_profile_curve(context, self.preset, _props(context).lathe_axis)
        self.report({'INFO'},
                    f"{pru.profile_label(self.preset)} curve profile created. "
                    "Convert to Mesh Safe if Screw is unavailable for curves.")
        return {'FINISHED'}


class OBJECT_OT_pro_add_screw_modifier_to_profile(bpy.types.Operator):
    """Add or update a non-destructive Screw modifier on selected profiles"""
    bl_idname = "object.pro_add_screw_modifier_to_profile"
    bl_label = "Add Screw / Revolve"
    bl_options = {'REGISTER', 'UNDO'}

    force_360: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_profile(context) is not None

    def execute(self, context):
        props = _props(context)
        done = 0
        for obj in _profile_selection(context):
            try:
                pru.add_or_update_screw_modifier(
                    obj, props, force_angle=360.0 if self.force_360 else None)
            except Exception as exc:
                self.report({'WARNING'},
                            f"'{obj.name}': could not add Screw ({exc}). "
                            "Convert the profile to Mesh Safe and try again.")
                continue
            if props.lathe_add_bevel:
                pru.add_bevel_modifier(obj, props.lathe_bevel_amount)
            if props.lathe_add_subdivision:
                pru.add_subdivision_modifier(obj)
            if props.lathe_use_weighted_normals:
                try:
                    pru.add_weighted_normal_modifier(obj)
                except Exception:
                    pass
            done += 1

        if not done:
            return {'CANCELLED'}
        if not props.lathe_non_destructive and props.lathe_apply_safely:
            bpy.ops.object.pro_apply_revolve_safely()
        self.report({'INFO'}, f"Screw/Revolve set up on {done} profile(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_revolve_profile_360(OBJECT_OT_pro_add_screw_modifier_to_profile):
    """Force the selected profile to a 360 degree Screw/Revolve setup"""
    bl_idname = "object.pro_revolve_profile_360"
    bl_label = "Revolve Profile 360"

    def execute(self, context):
        self.force_360 = True
        return super().execute(context)


class OBJECT_OT_pro_apply_revolve_safely(bpy.types.Operator):
    """Apply the PRO_Lathe modifiers with a hidden backup first"""
    bl_idname = "object.pro_apply_revolve_safely"
    bl_label = "Apply Revolve Safely"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _active_profile(context)
        return context.mode == 'OBJECT' and obj is not None and obj.modifiers

    def execute(self, context):
        _ensure_object_mode(context)
        obj = _active_profile(context)
        names = pru.lathe_modifier_names(obj)
        if not names:
            self.report({'WARNING'}, "No PRO_Lathe modifiers found to apply.")
            return {'CANCELLED'}
        backup = core_toolkit.backup_object(obj)
        _make_single_user_mesh(obj)
        applied = 0
        for name in names:
            if obj.modifiers.get(name) is not None:
                try:
                    _apply_modifier(context, obj, name)
                    applied += 1
                except Exception as exc:
                    self.report({'WARNING'},
                                f"Could not apply '{name}' on '{obj.name}': {exc}")
        self.report({'INFO'},
                    f"Applied {applied} Lathe modifier(s). Backup: {backup.name}")
        return {'FINISHED'}


class OBJECT_OT_pro_convert_revolve_to_mesh_safe(bpy.types.Operator):
    """Convert the active profile/revolve object to Mesh with a backup first"""
    bl_idname = "object.pro_convert_revolve_to_mesh_safe"
    bl_label = "Convert Revolve to Mesh Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_profile(context) is not None

    def execute(self, context):
        _ensure_object_mode(context)
        obj = _active_profile(context)
        backup = core_toolkit.backup_object(obj)
        _make_active(context, obj)
        try:
            with context.temp_override(object=obj, active_object=obj):
                bpy.ops.object.convert(target='MESH')
        except Exception as exc:
            self.report({'ERROR'}, f"Convert failed: {exc}")
            return {'CANCELLED'}
        context.active_object.name = obj.name.replace("_Profile", "_Mesh")
        self.report({'INFO'},
                    f"Converted to Mesh safely. Backup: {backup.name}")
        return {'FINISHED'}


class _SetRevolveAxis(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}
    axis = 'Z'

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = _props(context)
        props.lathe_axis = self.axis
        changed = 0
        for obj in _profile_selection(context):
            changed += pru.update_lathe_axis(obj, self.axis)
        self.report({'INFO'},
                    f"Lathe axis set to {self.axis} "
                    f"({changed} Screw modifier(s) updated).")
        return {'FINISHED'}


class OBJECT_OT_pro_set_revolve_axis_x(_SetRevolveAxis):
    """Set Lathe/Screw axis to X"""
    bl_idname = "object.pro_set_revolve_axis_x"
    bl_label = "Axis X"
    axis = 'X'


class OBJECT_OT_pro_set_revolve_axis_y(_SetRevolveAxis):
    """Set Lathe/Screw axis to Y"""
    bl_idname = "object.pro_set_revolve_axis_y"
    bl_label = "Axis Y"
    axis = 'Y'


class OBJECT_OT_pro_set_revolve_axis_z(_SetRevolveAxis):
    """Set Lathe/Screw axis to Z"""
    bl_idname = "object.pro_set_revolve_axis_z"
    bl_label = "Axis Z"
    axis = 'Z'


class OBJECT_OT_pro_center_profile_to_axis(bpy.types.Operator):
    """Move the profile onto the current revolve plane and axis side"""
    bl_idname = "object.pro_center_profile_to_axis"
    bl_label = "Center Profile to Axis"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_profile(context) is not None

    def execute(self, context):
        axis = _props(context).lathe_axis
        done = 0
        points = 0
        for obj in _profile_selection(context):
            count = pru.center_profile_to_axis(obj, axis)
            done += 1 if count else 0
            points += count
        self.report({'INFO'},
                    f"Centered {points} point(s) on {done} profile(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_mirror_profile_to_axis(bpy.types.Operator):
    """Duplicate a mesh profile mirrored across the current revolve axis"""
    bl_idname = "object.pro_mirror_profile_to_axis"
    bl_label = "Mirror Profile to Axis"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _active_profile(context)
        return context.mode == 'OBJECT' and obj is not None

    def execute(self, context):
        axis = _props(context).lathe_axis
        mirrored = 0
        for obj in _profile_selection(context):
            if obj.type != 'MESH':
                self.report({'WARNING'},
                            f"'{obj.name}': mirror is mesh-only; convert first.")
                continue
            mirrored += pru.mirror_mesh_profile_to_axis(obj, axis)
        self.report({'INFO'}, f"Mirrored {mirrored} profile point(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_close_revolve_caps(bpy.types.Operator):
    """Add axis endpoints to close top/bottom caps after revolution"""
    bl_idname = "object.pro_close_revolve_caps"
    bl_label = "Close Revolve Caps"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _active_profile(context)
        return context.mode == 'OBJECT' and obj is not None

    def execute(self, context):
        props = _props(context)
        added = 0
        for obj in _profile_selection(context):
            if obj.type != 'MESH':
                self.report({'WARNING'},
                            f"'{obj.name}': cap closing is mesh-only; convert first.")
                continue
            added += pru.close_mesh_profile_caps(
                obj, props.lathe_axis, props.lathe_cap_bottom,
                props.lathe_cap_top)
        self.report({'INFO'}, f"Added {added} cap endpoint(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_add_lathe_bevel(bpy.types.Operator):
    """Add a non-destructive bevel modifier for Lathe edges"""
    bl_idname = "object.pro_add_lathe_bevel"
    bl_label = "Add Lathe Bevel"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_profile(context) is not None

    def execute(self, context):
        amount = _props(context).lathe_bevel_amount
        done = 0
        for obj in _profile_selection(context):
            pru.add_bevel_modifier(obj, amount)
            done += 1
        self.report({'INFO'}, f"Lathe bevel added to {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_add_lathe_weighted_normals(bpy.types.Operator):
    """Add Weighted Normals to clean Lathe shading"""
    bl_idname = "object.pro_add_lathe_weighted_normals"
    bl_label = "Add Lathe Weighted Normals"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_profile(context) is not None

    def execute(self, context):
        done = 0
        for obj in _profile_selection(context):
            pru.add_weighted_normal_modifier(obj)
            done += 1
        self.report({'INFO'}, f"Weighted Normals added to {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_shade_smooth(bpy.types.Operator):
    """Enable smooth shading on Lathe mesh faces and Screw modifiers"""
    bl_idname = "object.pro_lathe_shade_smooth"
    bl_label = "Lathe Shade Smooth"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and _active_profile(context) is not None

    def execute(self, context):
        done = 0
        for obj in _profile_selection(context):
            for mod in obj.modifiers:
                if mod.type == 'SCREW':
                    pru.set_screw_property(mod, "use_smooth_shade", True)
            pru.shade_mesh_smooth(obj)
            done += 1
        self.report({'INFO'}, f"Lathe smooth shading set on {done} object(s).")
        return {'FINISHED'}


class OBJECT_OT_pro_lathe_audit_profile(bpy.types.Operator):
    """Audit the active profile and write V_PROFILE_REVOLVE_VALIDATION_REPORT.md"""
    bl_idname = "object.pro_lathe_audit_profile"
    bl_label = "Audit Lathe Profile"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = _props(context)
        obj = _active_profile(context)
        audit = pru.audit_profile_object(obj, props.lathe_axis)
        props.lathe_audit_done = True
        props.lathe_audit_object = obj.name if obj else ""
        props.lathe_audit_warnings = len(audit.get("warnings", []))
        path = _write_audit_report(context, obj, audit)
        if audit.get("ok"):
            self.report({'INFO'}, f"Lathe profile audit OK. Report: {path}")
        else:
            self.report({'WARNING'}, f"Lathe profile needs attention. Report: {path}")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_lathe_create_axis_guide,
    OBJECT_OT_pro_lathe_center_reference_image_to_axis,
    OBJECT_OT_pro_lathe_start_curve_profile_draw_mode,
    OBJECT_OT_pro_lathe_start_grease_pencil_sketch_mode,
    OBJECT_OT_pro_lathe_convert_grease_pencil_to_profile_curve,
    OBJECT_OT_pro_lathe_start_vertex_trace_mode,
    OBJECT_OT_pro_lathe_start_bezier_profile_mode,
    OBJECT_OT_pro_lathe_finish_profile_draw_mode,
    OBJECT_OT_pro_lathe_prepare_selected_profile_for_revolve,
    OBJECT_OT_pro_lathe_trace_mode_help,
    OBJECT_OT_pro_create_revolve_profile_curve,
    OBJECT_OT_pro_create_revolve_profile_mesh,
    OBJECT_OT_pro_revolve_profile_360,
    OBJECT_OT_pro_add_screw_modifier_to_profile,
    OBJECT_OT_pro_apply_revolve_safely,
    OBJECT_OT_pro_convert_revolve_to_mesh_safe,
    OBJECT_OT_pro_set_revolve_axis_x,
    OBJECT_OT_pro_set_revolve_axis_y,
    OBJECT_OT_pro_set_revolve_axis_z,
    OBJECT_OT_pro_center_profile_to_axis,
    OBJECT_OT_pro_mirror_profile_to_axis,
    OBJECT_OT_pro_close_revolve_caps,
    OBJECT_OT_pro_add_lathe_bevel,
    OBJECT_OT_pro_add_lathe_weighted_normals,
    OBJECT_OT_pro_lathe_shade_smooth,
    OBJECT_OT_pro_lathe_audit_profile,
)
