# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_creation_architecture.py
# v0.1.3 Pro Modeling Creation Suite: Architecture / Blockout generators.
# Clean low-poly bases at real-world scale, origin at the base center,
# aligned to the floor and filed into organized collections.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu


class _CreateOp:
    """Mixin: Object Mode poll + bmesh build/finalize skeleton."""
    bl_options = {'REGISTER', 'UNDO'}
    pro_collection = cu.COLL_ARCHITECTURE
    pro_material = "PRO_Blockout_Grey"

    @classmethod
    def poll(cls, context):
        return cu.object_mode_poll(context)

    def execute(self, context):
        bm = bmesh.new()
        name = self.build(context, bm)
        cu.finalize_new_object(context, self, name, bm,
                               self.pro_collection, self.pro_material)
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Wall / Floor / Room
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_wall_module(_CreateOp, bpy.types.Operator):
    """Create a modular wall section (3.00 x 0.20 x 2.70 m by default)"""
    bl_idname = "object.pro_create_wall_module"
    bl_label = "Wall Module"

    length: bpy.props.FloatProperty(name="Length", default=3.0, min=0.1, soft_max=20.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.2, min=0.01, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.7, min=0.1, soft_max=10.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.length, self.thickness, self.height)
        return f"PRO_Wall_Module_{self.length:g}m"


class OBJECT_OT_pro_create_floor_module(_CreateOp, bpy.types.Operator):
    """Create a modular floor slab (4.00 x 4.00 x 0.05 m by default)"""
    bl_idname = "object.pro_create_floor_module"
    bl_label = "Floor Module"

    width: bpy.props.FloatProperty(name="Width", default=4.0, min=0.1, soft_max=50.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=4.0, min=0.1, soft_max=50.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.05, min=0.005, soft_max=0.5, unit='LENGTH')

    def build(self, context, bm):
        # Slab top sits at Z=0 so walls placed on the floor stay correct
        cu.add_box(bm, self.width, self.depth, self.thickness,
                   z0=-self.thickness)
        return f"PRO_Floor_Module_{self.width:g}m"


class OBJECT_OT_pro_create_room_blockout(_CreateOp, bpy.types.Operator):
    """Create a room shell: floor slab + four walls, open top"""
    bl_idname = "object.pro_create_room_blockout"
    bl_label = "Room Blockout"

    width: bpy.props.FloatProperty(name="Width", default=4.0, min=0.5, soft_max=50.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=4.0, min=0.5, soft_max=50.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.7, min=0.5, soft_max=10.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Wall Thickness", default=0.2, min=0.02, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        w, d, h, t = self.width, self.depth, self.height, self.thickness
        cu.add_box(bm, w, d, 0.05, z0=-0.05)                       # floor slab
        cu.add_box(bm, w, t, h, cy=-(d - t) / 2.0)                 # front wall
        cu.add_box(bm, w, t, h, cy=(d - t) / 2.0)                  # back wall
        cu.add_box(bm, t, d - 2 * t, h, cx=-(w - t) / 2.0)         # left wall
        cu.add_box(bm, t, d - 2 * t, h, cx=(w - t) / 2.0)          # right wall
        return "PRO_Room_Blockout"


# ═══════════════════════════════════════════════════════════════════════
#  Door / Window frames and opening markers
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_door_frame(_CreateOp, bpy.types.Operator):
    """Create a door frame (0.90 m wide x 2.10 m tall opening)"""
    bl_idname = "object.pro_create_door_frame"
    bl_label = "Door Frame"

    width: bpy.props.FloatProperty(name="Opening Width", default=0.9, min=0.3, soft_max=3.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Opening Height", default=2.1, min=0.5, soft_max=4.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.15, min=0.02, soft_max=0.6, unit='LENGTH')
    frame_width: bpy.props.FloatProperty(name="Frame Width", default=0.08, min=0.01, soft_max=0.3, unit='LENGTH')

    def build(self, context, bm):
        w, h, d, f = self.width, self.height, self.depth, self.frame_width
        cu.add_box(bm, f, d, h, cx=-(w + f) / 2.0)                  # left jamb
        cu.add_box(bm, f, d, h, cx=(w + f) / 2.0)                   # right jamb
        cu.add_box(bm, w + 2 * f, d, f, z0=h)                       # header
        return "PRO_Door_Frame"


class OBJECT_OT_pro_create_window_frame(_CreateOp, bpy.types.Operator):
    """Create a window frame (1.20 x 1.00 m opening at sill height)"""
    bl_idname = "object.pro_create_window_frame"
    bl_label = "Window Frame"

    width: bpy.props.FloatProperty(name="Opening Width", default=1.2, min=0.2, soft_max=5.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Opening Height", default=1.0, min=0.2, soft_max=3.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.12, min=0.02, soft_max=0.6, unit='LENGTH')
    frame_width: bpy.props.FloatProperty(name="Frame Width", default=0.06, min=0.01, soft_max=0.3, unit='LENGTH')
    sill_height: bpy.props.FloatProperty(name="Sill Height", default=0.9, min=0.0, soft_max=2.0, unit='LENGTH')

    def build(self, context, bm):
        w, h, d, f, s = (self.width, self.height, self.depth,
                         self.frame_width, self.sill_height)
        cu.add_box(bm, f, d, h + 2 * f, cx=-(w + f) / 2.0, z0=s - f)   # left
        cu.add_box(bm, f, d, h + 2 * f, cx=(w + f) / 2.0, z0=s - f)    # right
        cu.add_box(bm, w, d, f, z0=s - f)                              # sill
        cu.add_box(bm, w, d, f, z0=s + h)                              # header
        return "PRO_Window_Frame"


class OBJECT_OT_pro_create_door_opening_block(_CreateOp, bpy.types.Operator):
    """Create a solid door-sized volume to mark/cut wall openings"""
    bl_idname = "object.pro_create_door_opening_block"
    bl_label = "Door Opening Block"
    pro_material = "PRO_Blockout_Red"

    width: bpy.props.FloatProperty(name="Width", default=0.9, min=0.3, soft_max=3.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.1, min=0.5, soft_max=4.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.3, min=0.02, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.thickness, self.height)
        return "PRO_Door_Opening_Block"


class OBJECT_OT_pro_create_window_opening_block(_CreateOp, bpy.types.Operator):
    """Create a solid window-sized volume at sill height to mark openings"""
    bl_idname = "object.pro_create_window_opening_block"
    bl_label = "Window Opening Block"
    pro_material = "PRO_Blockout_Red"

    width: bpy.props.FloatProperty(name="Width", default=1.2, min=0.2, soft_max=5.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=1.0, min=0.2, soft_max=3.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.3, min=0.02, soft_max=1.0, unit='LENGTH')
    sill_height: bpy.props.FloatProperty(name="Sill Height", default=0.9, min=0.0, soft_max=2.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.thickness, self.height,
                   z0=self.sill_height)
        return "PRO_Window_Opening_Block"


# ═══════════════════════════════════════════════════════════════════════
#  Pillar / Beam / Stairs
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_pillar(_CreateOp, bpy.types.Operator):
    """Create a structural pillar (0.30 x 0.30 x 2.70 m)"""
    bl_idname = "object.pro_create_pillar"
    bl_label = "Pillar"

    width: bpy.props.FloatProperty(name="Width", default=0.3, min=0.05, soft_max=2.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.3, min=0.05, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.7, min=0.2, soft_max=10.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.depth, self.height)
        return "PRO_Pillar"


class OBJECT_OT_pro_create_beam(_CreateOp, bpy.types.Operator):
    """Create a horizontal beam (3.00 x 0.25 x 0.25 m, raised to ceiling height)"""
    bl_idname = "object.pro_create_beam"
    bl_label = "Beam"

    length: bpy.props.FloatProperty(name="Length", default=3.0, min=0.2, soft_max=20.0, unit='LENGTH')
    width: bpy.props.FloatProperty(name="Width", default=0.25, min=0.02, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.25, min=0.02, soft_max=1.0, unit='LENGTH')
    elevation: bpy.props.FloatProperty(
        name="Elevation", description="Height of the beam underside above the floor",
        default=2.45, min=0.0, soft_max=10.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.length, self.width, self.height, z0=self.elevation)
        return "PRO_Beam"


class OBJECT_OT_pro_create_stair_blockout(_CreateOp, bpy.types.Operator):
    """Create a simple solid stair blockout (0.18 m rise / 0.28 m run)"""
    bl_idname = "object.pro_create_stair_blockout"
    bl_label = "Stair Blockout"

    steps: bpy.props.IntProperty(name="Steps", default=8, min=2, max=40)
    width: bpy.props.FloatProperty(name="Width", default=1.0, min=0.3, soft_max=5.0, unit='LENGTH')
    rise: bpy.props.FloatProperty(name="Rise", default=0.18, min=0.05, soft_max=0.4, unit='LENGTH')
    run: bpy.props.FloatProperty(name="Run", default=0.28, min=0.1, soft_max=0.6, unit='LENGTH')

    def build(self, context, bm):
        for i in range(self.steps):
            cu.add_box(bm, self.width, self.run, self.rise * (i + 1),
                       cy=self.run * i + self.run / 2.0)
        return "PRO_Stair_Blockout"


# ═══════════════════════════════════════════════════════════════════════
#  Counter / Shelf / Aisle  (supermarket-flavored architecture)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_create_counter_blockout(_CreateOp, bpy.types.Operator):
    """Create a counter blockout (1.60 x 0.70 x 0.90 m)"""
    bl_idname = "object.pro_create_counter_blockout"
    bl_label = "Counter Blockout"
    pro_material = "SF_Blockout_Prop"

    width: bpy.props.FloatProperty(name="Width", default=1.6, min=0.3, soft_max=6.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.7, min=0.2, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.9, min=0.3, soft_max=1.5, unit='LENGTH')

    def build(self, context, bm):
        # Recessed body + flush top board (keeps exact outer dimensions)
        cu.add_box(bm, self.width - 0.06, self.depth - 0.06,
                   self.height - 0.04)
        cu.add_box(bm, self.width, self.depth, 0.04, z0=self.height - 0.04)
        return "PRO_Counter_Blockout"


class OBJECT_OT_pro_create_shelf_blockout(_CreateOp, bpy.types.Operator):
    """Create a supermarket shelf unit (3.00 x 0.55 x 2.10 m, editable boards)"""
    bl_idname = "object.pro_create_shelf_blockout"
    bl_label = "Shelf Blockout"
    pro_material = "SF_Blockout_Prop"

    width: bpy.props.FloatProperty(name="Width", default=3.0, min=0.5, soft_max=12.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.55, min=0.2, soft_max=1.5, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.1, min=0.5, soft_max=4.0, unit='LENGTH')
    shelves: bpy.props.IntProperty(name="Shelf Boards", default=4, min=1, max=10)

    def build(self, context, bm):
        w, d, h = self.width, self.depth, self.height
        t = 0.04                                            # board thickness
        cu.add_box(bm, w, d, 0.15)                          # base plinth
        cu.add_box(bm, w, 0.05, h, cy=(d - 0.05) / 2.0)     # back panel
        cu.add_box(bm, 0.05, d, h, cx=-(w - 0.05) / 2.0)    # left side
        cu.add_box(bm, 0.05, d, h, cx=(w - 0.05) / 2.0)     # right side
        span = (h - 0.15 - t) / (self.shelves + 1)
        for i in range(1, self.shelves + 1):
            cu.add_box(bm, w - 0.10, d - 0.07, t,
                       cy=0.01, z0=0.15 + span * i)
        return "PRO_Shelf_Blockout"


class OBJECT_OT_pro_create_aisle_blockout(_CreateOp, bpy.types.Operator):
    """Create a supermarket aisle: two facing shelf volumes with a 1.20 m walkway"""
    bl_idname = "object.pro_create_aisle_blockout"
    bl_label = "Supermarket Aisle Blockout"
    pro_collection = cu.COLL_SUPERMARKET
    pro_material = "SF_Blockout_Prop"

    length: bpy.props.FloatProperty(name="Aisle Length", default=3.0, min=0.5, soft_max=20.0, unit='LENGTH')
    aisle_width: bpy.props.FloatProperty(
        name="Aisle Width", description="Clear walkway between the shelf fronts (1.20 m minimum)",
        default=1.2, min=1.2, soft_max=4.0, unit='LENGTH')
    shelf_depth: bpy.props.FloatProperty(name="Shelf Depth", default=0.55, min=0.2, soft_max=1.5, unit='LENGTH')
    shelf_height: bpy.props.FloatProperty(name="Shelf Height", default=2.1, min=0.5, soft_max=4.0, unit='LENGTH')

    def build(self, context, bm):
        off = (self.aisle_width + self.shelf_depth) / 2.0
        cu.add_box(bm, self.length, self.shelf_depth, self.shelf_height, cy=-off)
        cu.add_box(bm, self.length, self.shelf_depth, self.shelf_height, cy=off)
        return "PRO_Aisle_Blockout"


classes = (
    OBJECT_OT_pro_create_wall_module,
    OBJECT_OT_pro_create_floor_module,
    OBJECT_OT_pro_create_room_blockout,
    OBJECT_OT_pro_create_door_frame,
    OBJECT_OT_pro_create_window_frame,
    OBJECT_OT_pro_create_door_opening_block,
    OBJECT_OT_pro_create_window_opening_block,
    OBJECT_OT_pro_create_pillar,
    OBJECT_OT_pro_create_beam,
    OBJECT_OT_pro_create_stair_blockout,
    OBJECT_OT_pro_create_counter_blockout,
    OBJECT_OT_pro_create_shelf_blockout,
    OBJECT_OT_pro_create_aisle_blockout,
)
