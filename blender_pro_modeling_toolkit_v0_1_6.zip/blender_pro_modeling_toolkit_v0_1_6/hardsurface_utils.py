# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  hardsurface_utils.py
# v0.1.4 Hard Surface Pro Suite: shared helpers.
# Collections, hard-surface materials and small builders used by the
# ops_hardsurface_* modules. Same philosophy as creation_utils: geometry
# is built at real-world size so new objects start with scale (1, 1, 1).
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from math import cos, sin, pi

from . import creation_utils as cu


# ═══════════════════════════════════════════════════════════════════════
#  COLLECTIONS
# ═══════════════════════════════════════════════════════════════════════

HS_ROOT_COLLECTION = "PRO_HardSurface"

COLL_HS_CUTTERS = "PRO_HardSurface_Cutters"
COLL_HS_DETAILS = "PRO_HardSurface_Details"
COLL_HS_PANELS = "PRO_HardSurface_Panels"
COLL_HS_SUPERMARKET = "PRO_HardSurface_Supermarket"


def get_or_create_hs_collection(context, name):
    """Return collection *name* parented under PRO_HardSurface,
    creating both if needed. PRO_HardSurface itself is also valid."""
    root = bpy.data.collections.get(HS_ROOT_COLLECTION)
    if root is None:
        root = bpy.data.collections.new(HS_ROOT_COLLECTION)
    if HS_ROOT_COLLECTION not in context.scene.collection.children:
        context.scene.collection.children.link(root)
    if name == HS_ROOT_COLLECTION:
        return root

    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
    if name not in root.children:
        try:
            root.children.link(coll)
        except RuntimeError:
            pass  # already linked elsewhere in this scene — keep as is
    return coll


def link_to_hs_collection(context, obj, coll_name):
    """Move *obj* into the given hard-surface collection."""
    coll = get_or_create_hs_collection(context, coll_name)
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)
    return coll


# ═══════════════════════════════════════════════════════════════════════
#  HARD SURFACE MATERIALS (simple Principled setups, no textures)
# ═══════════════════════════════════════════════════════════════════════

# name: (base color RGBA, roughness, metallic, alpha)
HS_MATERIALS = {
    "HS_Metal_Dark":    ((0.18, 0.19, 0.21, 1.0), 0.45, 1.0, 1.0),
    "HS_Metal_Light":   ((0.66, 0.68, 0.70, 1.0), 0.35, 1.0, 1.0),
    "HS_Plastic_Black": ((0.04, 0.04, 0.04, 1.0), 0.55, 0.0, 1.0),
    "HS_Plastic_White": ((0.85, 0.85, 0.84, 1.0), 0.45, 0.0, 1.0),
    "HS_Rubber_Dark":   ((0.05, 0.05, 0.05, 1.0), 0.90, 0.0, 1.0),
    "HS_Glass_Fake":    ((0.60, 0.78, 0.85, 1.0), 0.08, 0.0, 0.25),
    "HS_Cutter_Red":    ((0.85, 0.10, 0.10, 1.0), 0.80, 0.0, 1.0),
    "HS_Panel_Grey":    ((0.45, 0.46, 0.48, 1.0), 0.60, 0.3, 1.0),
    "HS_Button_Dark":   ((0.10, 0.10, 0.11, 1.0), 0.40, 0.0, 1.0),
    "HS_Screen_Black":  ((0.02, 0.02, 0.03, 1.0), 0.15, 0.0, 1.0),
}


def get_hs_material(name):
    """Get or create one of the simple hard-surface materials."""
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    color, rough, metal, alpha = HS_MATERIALS.get(
        name, HS_MATERIALS["HS_Panel_Grey"])

    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Roughness"].default_value = rough
        bsdf.inputs["Metallic"].default_value = metal
        if alpha < 1.0:
            bsdf.inputs["Alpha"].default_value = alpha
    mat.diffuse_color = (color[0], color[1], color[2], alpha)
    if alpha < 1.0:
        if hasattr(mat, "blend_method"):
            mat.blend_method = 'BLEND'
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = 'BLENDED'
    return mat


def assign_hs_material(obj, mat_name):
    """Replace slot 0 (or add it) with the named hard-surface material."""
    mat = get_hs_material(mat_name)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


# ═══════════════════════════════════════════════════════════════════════
#  EXTRA BMESH BUILDERS (the box/cylinder/plane ones live in creation_utils)
# ═══════════════════════════════════════════════════════════════════════

def add_ring(bm, radius_outer, radius_inner, height, segments,
             cx=0.0, cy=0.0, z0=0.0):
    """Add a flat annulus ring (washer): base resting at z0."""
    bot_o, bot_i, top_o, top_i = [], [], [], []
    for i in range(segments):
        a = 2.0 * pi * i / segments
        co, si = cos(a), sin(a)
        bot_o.append(bm.verts.new((cx + co * radius_outer, cy + si * radius_outer, z0)))
        bot_i.append(bm.verts.new((cx + co * radius_inner, cy + si * radius_inner, z0)))
        top_o.append(bm.verts.new((cx + co * radius_outer, cy + si * radius_outer, z0 + height)))
        top_i.append(bm.verts.new((cx + co * radius_inner, cy + si * radius_inner, z0 + height)))
    for i in range(segments):
        j = (i + 1) % segments
        bm.faces.new((bot_o[i], bot_o[j], bot_i[j], bot_i[i]))   # bottom
        bm.faces.new((top_i[i], top_i[j], top_o[j], top_o[i]))   # top
        bm.faces.new((bot_o[i], top_o[i], top_o[j], bot_o[j]))   # outer wall
        bm.faces.new((bot_i[j], top_i[j], top_i[i], bot_i[i]))   # inner wall


def add_cylinder_y(bm, radius, length, segments, cx=0.0, cz=0.0, y0=None):
    """Add a capped cylinder lying along the Y axis (rollers, hinge pins).
    Centered on Y unless *y0* (start) is given; axis passes through (cx, cz)."""
    ret = bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=segments,
        radius1=radius, radius2=radius, depth=length)
    for v in ret["verts"]:
        x, y, z = v.co.x, v.co.y, v.co.z
        # rotate −90° around X: cylinder axis Z → Y
        v.co.x = x + cx
        v.co.y = z + (0.0 if y0 is None else y0 + length / 2.0)
        v.co.z = -y + cz
    return ret["verts"]


def add_wedge(bm, width, depth, height_back, height_front, cx=0.0, cy=0.0, z0=0.0):
    """Add a wedge: a box whose top face slopes from height_back (at -Y)
    down/up to height_front (at +Y). Used for sloped keypads and ramps."""
    hw, hd = width / 2.0, depth / 2.0
    v = [bm.verts.new((cx - hw, cy - hd, z0)),
         bm.verts.new((cx + hw, cy - hd, z0)),
         bm.verts.new((cx + hw, cy + hd, z0)),
         bm.verts.new((cx - hw, cy + hd, z0)),
         bm.verts.new((cx - hw, cy - hd, z0 + height_back)),
         bm.verts.new((cx + hw, cy - hd, z0 + height_back)),
         bm.verts.new((cx + hw, cy + hd, z0 + height_front)),
         bm.verts.new((cx - hw, cy + hd, z0 + height_front))]
    bm.faces.new((v[0], v[1], v[2], v[3]))          # bottom
    bm.faces.new((v[7], v[6], v[5], v[4]))          # top (sloped)
    bm.faces.new((v[0], v[4], v[5], v[1]))          # back
    bm.faces.new((v[2], v[6], v[7], v[3]))          # front
    bm.faces.new((v[1], v[5], v[6], v[2]))          # right
    bm.faces.new((v[3], v[7], v[4], v[0]))          # left
    return v


def add_panel_with_field(bm, width, height, depth, margin, field_offset):
    """Standing panel (XZ plane, thickness in Y) whose front center field is
    raised (field_offset < 0) or recessed (field_offset > 0) by that amount.
    Built from 5 boxes — clean quads, no booleans, no n-gons."""
    m = margin
    iw, ih = width - 2 * m, height - 2 * m
    cu.add_box(bm, width, depth, m)                             # bottom rail
    cu.add_box(bm, width, depth, m, z0=height - m)              # top rail
    cu.add_box(bm, m, depth, ih, cx=-(width - m) / 2.0, z0=m)   # left rail
    cu.add_box(bm, m, depth, ih, cx=(width - m) / 2.0, z0=m)    # right rail
    # center field: back face stays flush with the rails (-Y side), only the
    # front face moves in (recessed) or out (raised)
    if field_offset > 0:
        fd = max(depth - field_offset, depth * 0.25)
        cu.add_box(bm, iw, fd, ih, cy=-(depth - fd) / 2.0, z0=m)
    else:
        fd = depth + abs(field_offset)
        cu.add_box(bm, iw, fd, ih, cy=(fd - depth) / 2.0, z0=m)


# ═══════════════════════════════════════════════════════════════════════
#  SCALE / MODIFIER HELPERS
# ═══════════════════════════════════════════════════════════════════════

def has_unapplied_scale(obj, tol=1e-4):
    return any(abs(s - 1.0) > tol for s in obj.scale)


def warn_or_apply_scale(operator, context, obj):
    """Honour hs_apply_scale_if_needed: warn about unapplied scale, or apply
    it (multi-user safe, with report). Returns True if scale is now clean."""
    if not has_unapplied_scale(obj):
        return True
    props = context.scene.pro_toolkit
    if not props.hs_apply_scale_if_needed:
        operator.report(
            {'WARNING'},
            f"'{obj.name}' has unapplied scale {tuple(round(s, 3) for s in obj.scale)} — "
            "bevel width will look wrong. Apply scale (Ctrl+A) or enable "
            "'Apply Scale if Needed'.")
        return False
    if obj.data.users > 1:
        operator.report(
            {'WARNING'},
            f"'{obj.name}': mesh data is shared by {obj.data.users} objects — "
            "scale NOT applied (make it single-user first).")
        return False
    mw = obj.matrix_world.copy()
    sx, sy, sz = obj.scale
    for v in obj.data.vertices:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    obj.scale = (1.0, 1.0, 1.0)
    operator.report({'INFO'}, f"'{obj.name}': scale applied automatically "
                    f"(was {sx:.3f}, {sy:.3f}, {sz:.3f}).")
    return True


def safe_bevel_width(obj, requested):
    """Clamp the bevel width so small objects never get blown-out bevels.
    Cap at 10% of the smallest non-zero dimension."""
    dims = [d for d in obj.dimensions if d > 1e-6]
    if not dims:
        return requested
    cap = min(dims) * 0.10
    return min(requested, cap)


def add_bevel_modifier(obj, props):
    """Append a Bevel modifier configured from the hs_* properties."""
    mod = obj.modifiers.new("PRO_HS_Bevel", 'BEVEL')
    mod.width = safe_bevel_width(obj, props.hs_bevel_amount)
    mod.segments = props.hs_bevel_segments
    mod.profile = props.hs_bevel_profile
    mod.limit_method = 'ANGLE'
    mod.angle_limit = 0.523599  # 30°
    mod.use_clamp_overlap = True
    mod.miter_outer = 'MITER_ARC'
    return mod


def add_weighted_normal_modifier(obj):
    """Append a Weighted Normal modifier (idempotent) and enable smooth
    shading so it actually has an effect."""
    for m in obj.modifiers:
        if m.type == 'WEIGHTED_NORMAL':
            return m
    mod = obj.modifiers.new("PRO_HS_WeightedNormal", 'WEIGHTED_NORMAL')
    mod.keep_sharp = True
    mod.weight = 50
    for poly in obj.data.polygons:
        poly.use_smooth = True
    return mod


def selected_mesh_objects(context):
    return [o for o in context.selected_objects if o.type == 'MESH']


# ═══════════════════════════════════════════════════════════════════════
#  FINALIZE — mirror of creation_utils.finalize_new_object with hs_* props
# ═══════════════════════════════════════════════════════════════════════

def finalize_hs_object(context, operator, name, bm, coll_name,
                       mat_name=None, wire=False, at_floor=None):
    """Standard tail for hard-surface creation operators."""
    props = context.scene.pro_toolkit

    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()

    obj = bpy.data.objects.new(name, me)
    link_to_hs_collection(context, obj, coll_name)

    loc = context.scene.cursor.location.copy()
    align = (props.hs_align_to_floor if at_floor is None else at_floor)
    if align:
        loc.z = 0.0
    obj.location = loc

    if wire:
        obj.display_type = 'WIRE'
    if mat_name and props.hs_create_materials:
        assign_hs_material(obj, mat_name)
    if props.hs_use_weighted_normals and not wire:
        add_weighted_normal_modifier(obj)

    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj

    d = obj.dimensions
    operator.report(
        {'INFO'},
        f"{name} created ({d.x:.2f} x {d.y:.2f} x {d.z:.2f} m) "
        f"in '{coll_name}' — scale is (1, 1, 1)")
    return obj
