# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_vertices.py
# BMesh-based vertex operators
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from mathutils import Vector


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _get_bmesh(context):
    """Return the active BMesh for the edited mesh."""
    obj = context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    bm.verts.ensure_lookup_table()
    return bm, me


def _finish_bmesh(bm, me):
    """Flush BMesh edits back to the mesh data-block."""
    bmesh.update_edit_mesh(me)


def _selected_verts(bm):
    """Return list of selected BMVerts."""
    return [v for v in bm.verts if v.select]


# ═══════════════════════════════════════════════════════════════════════
#  Push / Pull Vertices
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_push_pull(bpy.types.Operator):
    """Move selected vertices along their normals"""
    bl_idname = "mesh.pro_push_pull"
    bl_label = "Push/Pull Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    distance: bpy.props.FloatProperty(
        name="Distance",
        description="Distance to pull out (+) or push in (–) along vertex normals",
        default=0.05,
        soft_min=-2.0,
        soft_max=2.0,
        step=1,
        precision=4,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel = _selected_verts(bm)
        if not sel:
            self.report({'WARNING'}, "No vertices selected.")
            return {'CANCELLED'}

        for v in sel:
            v.co += v.normal * self.distance

        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Push/Pull {len(sel)} vertices by {self.distance:.4f}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Relax Vertices (Laplacian smooth)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_relax(bpy.types.Operator):
    """Smooth selected vertices toward the average of their neighbours"""
    bl_idname = "mesh.pro_relax"
    bl_label = "Relax Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    factor: bpy.props.FloatProperty(
        name="Factor",
        description="Relaxation strength per iteration",
        default=0.5,
        min=0.0,
        max=1.0,
    )
    iterations: bpy.props.IntProperty(
        name="Iterations",
        description="Number of smoothing passes",
        default=1,
        min=1,
        max=100,
    )
    keep_boundaries: bpy.props.BoolProperty(
        name="Keep Boundaries",
        description="Don't move boundary vertices",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel = _selected_verts(bm)
        if len(sel) < 3:
            self.report({'WARNING'}, "Select at least 3 vertices.")
            return {'CANCELLED'}

        for _ in range(self.iterations):
            new_positions = {}
            for v in sel:
                if self.keep_boundaries and v.is_boundary:
                    continue
                neighbours = [e.other_vert(v) for e in v.link_edges]
                if not neighbours:
                    continue
                avg = sum((n.co for n in neighbours), Vector()) / len(neighbours)
                new_positions[v.index] = v.co.lerp(avg, self.factor)

            for v in sel:
                if v.index in new_positions:
                    v.co = new_positions[v.index]

        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Relaxed {len(sel)} vertices  (iter={self.iterations})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Flatten Vertices
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_flatten(bpy.types.Operator):
    """Project selected vertices onto the average plane"""
    bl_idname = "mesh.pro_flatten"
    bl_label = "Flatten Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    influence: bpy.props.FloatProperty(
        name="Influence",
        description="Strength of the flattening (0 = none, 1 = full)",
        default=1.0,
        min=0.0,
        max=1.0,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel = _selected_verts(bm)
        if len(sel) < 3:
            self.report({'WARNING'}, "Select at least 3 vertices.")
            return {'CANCELLED'}

        # Compute average position and average normal
        center = sum((v.co for v in sel), Vector()) / len(sel)
        avg_normal = sum((v.normal for v in sel), Vector())
        avg_normal_len = avg_normal.length
        if avg_normal_len < 1e-8:
            self.report({'WARNING'}, "Cannot determine a consistent plane.")
            return {'CANCELLED'}
        avg_normal = avg_normal / avg_normal_len

        # Project each vertex onto the plane
        for v in sel:
            offset = v.co - center
            dist_to_plane = offset.dot(avg_normal)
            projected = v.co - avg_normal * dist_to_plane
            v.co = v.co.lerp(projected, self.influence)

        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Flattened {len(sel)} vertices")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Align Vertices
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_align(bpy.types.Operator):
    """Align selected vertices to the average value on chosen axis"""
    bl_idname = "mesh.pro_align"
    bl_label = "Align Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        name="Axis",
        items=[
            ('X', "X", "Align on X axis"),
            ('Y', "Y", "Align on Y axis"),
            ('Z', "Z", "Align on Z axis"),
        ],
        default='X',
    )
    align_to: bpy.props.EnumProperty(
        name="Reference",
        items=[
            ('CENTER', "Average", "Align to average position"),
            ('ACTIVE', "Active Vertex", "Align to the active vertex"),
        ],
        default='CENTER',
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel = _selected_verts(bm)
        if len(sel) < 2:
            self.report({'WARNING'}, "Select at least 2 vertices.")
            return {'CANCELLED'}

        axis_map = {'X': 0, 'Y': 1, 'Z': 2}
        idx = axis_map[self.axis]

        if self.align_to == 'ACTIVE' and bm.select_history:
            active_elem = bm.select_history.active
            if hasattr(active_elem, 'co'):
                target = active_elem.co[idx]
            else:
                target = sum(v.co[idx] for v in sel) / len(sel)
        else:
            target = sum(v.co[idx] for v in sel) / len(sel)

        for v in sel:
            v.co[idx] = target

        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Aligned {len(sel)} verts on {self.axis}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Merge by Distance
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_merge_distance(bpy.types.Operator):
    """Merge selected vertices closer than threshold"""
    bl_idname = "mesh.pro_merge_distance"
    bl_label = "Merge by Distance"
    bl_options = {'REGISTER', 'UNDO'}

    threshold: bpy.props.FloatProperty(
        name="Threshold",
        description="Maximum distance between vertices to merge",
        default=0.0001,
        min=0.0,
        max=1.0,
        precision=5,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel = _selected_verts(bm)
        if len(sel) < 2:
            self.report({'WARNING'}, "Select at least 2 vertices.")
            return {'CANCELLED'}

        before = len(bm.verts)
        bmesh.ops.remove_doubles(bm, verts=sel, dist=self.threshold)
        removed = before - len(bm.verts)

        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Merged {removed} vertices (threshold={self.threshold:.5f})")
        return {'FINISHED'}
