# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  baking_utils.py
# v0.1.6 — bake collections, target images, engine validation,
# high/low pairing, the actual bake runner and the bake report.
#
# RULES:
#   - bakes need Cycles: the runner switches and RESTORES the engine,
#   - the high poly is never modified,
#   - no modifier is applied automatically,
#   - every bake appends an entry to the in-session bake log.
# ──────────────────────────────────────────────────────────────────────

import os
import re
import time

import bpy

from . import material_utils as mu

COLL_BAKE = "PRO_Bake"
COLL_HIGH = "PRO_Bake_High"
COLL_LOW = "PRO_Bake_Low"
COLL_CAGE = "PRO_Bake_Cage"
COLL_OUTPUT = "PRO_Bake_Output"

MAT_CAGE = "PRO_Bake_Cage"
MAT_TARGET = "PRO_Bake_Target"
MAT_DEBUG = "PRO_Bake_Debug"

BAKE_NODE = "PRO Bake Target"

# session bake log: list of dicts (map, object, resolution, seconds, image,
# saved path, selected_to_active, cage, error)
BAKE_LOG = []

_HIGH_RE = re.compile(r"(_high|_hp|high)$", re.IGNORECASE)
_LOW_RE = re.compile(r"(_low|_lp|low)$", re.IGNORECASE)
_CAGE_RE = re.compile(r"(_cage|cage)$", re.IGNORECASE)

# map type -> (cycles bake type, image is non-color data)
MAP_TYPES = {
    'NORMAL': ('NORMAL', True),
    'AO': ('AO', True),
    'DIFFUSE': ('DIFFUSE', False),
    'ROUGHNESS': ('ROUGHNESS', True),
    'EMIT': ('EMIT', False),
    'COLOR_ID': ('EMIT', False),
    'COMBINED': ('COMBINED', False),
}


# ═══════════════════════════════════════════════════════════════════════
#  COLLECTIONS / MATERIALS
# ═══════════════════════════════════════════════════════════════════════

def ensure_collection(name, parent=None):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
    parent = parent or bpy.context.scene.collection
    if coll.name not in parent.children and coll is not parent:
        try:
            parent.children.link(coll)
        except RuntimeError:
            pass
    return coll


def ensure_bake_collections(context):
    root = ensure_collection(COLL_BAKE, context.scene.collection)
    return {
        'root': root,
        'high': ensure_collection(COLL_HIGH, root),
        'low': ensure_collection(COLL_LOW, root),
        'cage': ensure_collection(COLL_CAGE, root),
        'output': ensure_collection(COLL_OUTPUT, root),
    }


def move_to_collection(obj, coll):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)


def cage_material():
    mat = bpy.data.materials.get(MAT_CAGE)
    if mat is not None:
        return mat
    mat = bpy.data.materials.new(MAT_CAGE)
    mat.use_nodes = True
    mat.diffuse_color = (0.1, 0.6, 0.9, 0.25)
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = (0.1, 0.6, 0.9, 1.0)
        if "Alpha" in bsdf.inputs:
            bsdf.inputs["Alpha"].default_value = 0.25
    if hasattr(mat, "blend_method"):
        mat.blend_method = 'BLEND'
    return mat


# ═══════════════════════════════════════════════════════════════════════
#  HIGH / LOW NAMING
# ═══════════════════════════════════════════════════════════════════════

def classify_high_low(name):
    """'high' | 'low' | 'cage' | None from the naming convention."""
    if _CAGE_RE.search(name):
        return 'cage'
    if _HIGH_RE.search(name):
        return 'high'
    if _LOW_RE.search(name):
        return 'low'
    return None


def base_name(name):
    for rx in (_CAGE_RE, _HIGH_RE, _LOW_RE):
        m = rx.search(name)
        if m:
            return name[:m.start()].rstrip("_.")
    return name


def pair_by_name(objects):
    """[(low, high)] pairs among *objects* using the naming convention."""
    lows, highs = {}, {}
    for o in objects:
        if o.type != 'MESH':
            continue
        kind = classify_high_low(o.name)
        if kind == 'low':
            lows[base_name(o.name).lower()] = o
        elif kind == 'high':
            highs[base_name(o.name).lower()] = o
    return [(lows[k], highs[k]) for k in lows if k in highs]


# ═══════════════════════════════════════════════════════════════════════
#  TARGET IMAGES / NODES
# ═══════════════════════════════════════════════════════════════════════

def ensure_bake_image(name, resolution, non_color):
    img = bpy.data.images.get(name)
    if img is not None and tuple(img.size) != (resolution, resolution):
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(name, resolution, resolution, alpha=False)
    img.colorspace_settings.name = 'Non-Color' if non_color else 'sRGB'
    img.use_fake_user = True
    return img


def bake_image_name(prefix, obj_name, map_type):
    return f"{prefix}{obj_name}_{map_type}"


def ensure_target_node(mat, image):
    """Get-or-create the bake target Image Texture node in *mat* and make
    it the ACTIVE node (Cycles bakes into the active image node)."""
    if not mat.use_nodes:
        mat.use_nodes = True
    nt = mat.node_tree
    node = nt.nodes.get(BAKE_NODE)
    if node is None or node.type != 'TEX_IMAGE':
        node = nt.nodes.new('ShaderNodeTexImage')
        node.name = node.label = BAKE_NODE
        node.location = (-1200, -600)
    node.image = image
    for n in nt.nodes:
        n.select = False
    node.select = True
    nt.nodes.active = node
    return node


def ensure_object_has_material(obj):
    """A bake needs at least one material with nodes; create a neutral
    target material when the object has none."""
    if any(s.material for s in obj.material_slots):
        return False
    mat = bpy.data.materials.get(MAT_TARGET)
    if mat is None:
        mat = bpy.data.materials.new(MAT_TARGET)
        mat.use_nodes = True
    obj.data.materials.append(mat)
    return True


# ═══════════════════════════════════════════════════════════════════════
#  VALIDATION / BAKE RUNNER
# ═══════════════════════════════════════════════════════════════════════

def validate_bake(obj, *, needs_uv=True):
    """List of blocking problems for baking *obj* (empty = OK)."""
    problems = []
    if obj is None or obj.type != 'MESH':
        problems.append("No active mesh object.")
        return problems
    if needs_uv and not obj.data.uv_layers:
        problems.append(f"'{obj.name}' has no UV map — unwrap first "
                        "(UV Suite > Smart Unwrap).")
    if obj.mode != 'OBJECT':
        problems.append("Must be in Object Mode.")
    return problems


def run_bake(context, low, map_type, image, *, high=None, use_cage=False,
             cage_object=None, cage_extrusion=0.03, margin=16,
             output_folder="", save=True):
    """Validated Cycles bake. Returns a log entry dict (also appended to
    BAKE_LOG). Never raises: errors land in entry['error']."""
    cycles_type, _non_color = MAP_TYPES[map_type]
    entry = {
        "map": map_type, "object": low.name,
        "resolution": tuple(image.size), "image": image.name,
        "selected_to_active": high is not None,
        "cage": bool(use_cage and cage_object is not None),
        "seconds": None, "saved": "", "error": "",
    }
    scene = context.scene
    prev_engine = scene.render.engine

    try:
        if scene.render.engine != 'CYCLES':
            scene.render.engine = 'CYCLES'

        # selection state: selected-to-active needs high selected + low active
        for o in context.view_layer.objects:
            o.select_set(False)
        if high is not None:
            high.select_set(True)
        low.select_set(True)
        context.view_layer.objects.active = low

        ensure_object_has_material(low)
        for slot in low.material_slots:
            if slot.material is not None:
                ensure_target_node(slot.material, image)

        kwargs = dict(type=cycles_type, margin=margin,
                      use_selected_to_active=high is not None,
                      use_clear=True)
        if high is not None:
            kwargs["cage_extrusion"] = cage_extrusion
            if use_cage and cage_object is not None:
                kwargs["use_cage"] = True
                kwargs["cage_object"] = cage_object.name
        if cycles_type == 'NORMAL':
            kwargs["normal_space"] = 'TANGENT'
        if cycles_type == 'DIFFUSE':
            kwargs["pass_filter"] = {'COLOR'}

        t0 = time.monotonic()
        res = bpy.ops.object.bake(**kwargs)
        entry["seconds"] = round(time.monotonic() - t0, 2)
        if 'FINISHED' not in res:
            entry["error"] = f"bake returned {res}"
        elif save and output_folder:
            folder = bpy.path.abspath(output_folder)
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, f"{image.name}.png")
            image.filepath_raw = path
            image.file_format = 'PNG'
            image.save()
            entry["saved"] = path
    except Exception as exc:                       # noqa: BLE001
        entry["error"] = str(exc)
    finally:
        if scene.render.engine != prev_engine:
            scene.render.engine = prev_engine

    BAKE_LOG.append(entry)
    return entry


def write_bake_report():
    lines = ["# V016 BAKE REPORT", ""]
    if not BAKE_LOG:
        lines.append("No bakes were run in this session.")
    for e in BAKE_LOG:
        lines += [
            f"## {e['map']} — {e['object']}",
            f"- Image: `{e['image']}` ({e['resolution'][0]}x{e['resolution'][1]})",
            f"- Selected to active: {e['selected_to_active']}",
            f"- Cage: {e['cage']}",
            f"- Duration: {e['seconds']} s" if e['seconds'] is not None
            else "- Duration: n/a",
            f"- Saved: `{e['saved']}`" if e['saved'] else "- Saved: (not saved)",
            f"- **ERROR:** {e['error']}" if e['error'] else "- Status: OK",
            "",
        ]
    return mu.write_report("V016_BAKE_REPORT.md", lines)
