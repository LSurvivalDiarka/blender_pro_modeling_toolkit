# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_architecture.py
# Simple blockout generators for houses and structures (Object Mode)
# No destructive booleans — reference volumes only.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _object_mode_poll(context):
    return context.mode == 'OBJECT'


def _link_at_cursor(context, obj):
    """Link *obj* to the active collection at the 3D cursor and activate it."""
    context.collection.objects.link(obj)
    obj.location = context.scene.cursor.location.copy()
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj


def _new_box_object(context, name, width, depth, height, z_offset=0.0):
    """Create a box mesh object. Origin sits at the base center (floor level),
    which makes walls/doors/windows easy to place and snap."""
    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co.x *= width
        v.co.y *= depth
        v.co.z *= height
        v.co.z += height / 2.0 + z_offset
    bm.to_mesh(me)
    bm.free()

    obj = bpy.data.objects.new(name, me)
    _link_at_cursor(context, obj)
    return obj


# ═══════════════════════════════════════════════════════════════════════
#  Wall Cube
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_wall_cube(bpy.types.Operator):
    """Add a simple rectangular wall (origin at base)"""
    bl_idname = "object.pro_add_wall_cube"
    bl_label = "Add Wall"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(name="Width", default=4.0, min=0.1, soft_max=20.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.3, min=0.01, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.7, min=0.1, soft_max=10.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        _new_box_object(context, "Wall_Blockout",
                        self.width, self.thickness, self.height)
        self.report({'INFO'},
                    f"Wall added ({self.width:.2f} x {self.thickness:.2f} x {self.height:.2f} m)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Floor Plane
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_floor_plane(bpy.types.Operator):
    """Add a simple floor plane"""
    bl_idname = "object.pro_add_floor_plane"
    bl_label = "Add Floor"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(name="Width", default=4.0, min=0.1, soft_max=50.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=4.0, min=0.1, soft_max=50.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        me = bpy.data.meshes.new("Floor_Blockout")
        bm = bmesh.new()
        hw, hd = self.width / 2.0, self.depth / 2.0
        v1 = bm.verts.new((-hw, -hd, 0.0))
        v2 = bm.verts.new((hw, -hd, 0.0))
        v3 = bm.verts.new((hw, hd, 0.0))
        v4 = bm.verts.new((-hw, hd, 0.0))
        bm.faces.new((v1, v2, v3, v4))
        bm.to_mesh(me)
        bm.free()

        obj = bpy.data.objects.new("Floor_Blockout", me)
        _link_at_cursor(context, obj)
        self.report({'INFO'}, f"Floor added ({self.width:.2f} x {self.depth:.2f} m)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Door Blockout
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_door_blockout(bpy.types.Operator):
    """Add a door-sized reference block (0.9 x 2.1 m standard)"""
    bl_idname = "object.pro_add_door_blockout"
    bl_label = "Add Door Blockout"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(name="Width", default=0.9, min=0.1, soft_max=3.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.15, min=0.01, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=2.1, min=0.1, soft_max=4.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        _new_box_object(context, "Door_Blockout",
                        self.width, self.thickness, self.height)
        self.report({'INFO'},
                    f"Door blockout added ({self.width:.2f} x {self.height:.2f} m)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Window Blockout
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_window_blockout(bpy.types.Operator):
    """Add a window-sized reference block at sill height"""
    bl_idname = "object.pro_add_window_blockout"
    bl_label = "Add Window Blockout"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(name="Width", default=1.2, min=0.1, soft_max=5.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.15, min=0.01, soft_max=1.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=1.2, min=0.1, soft_max=3.0, unit='LENGTH')
    sill_height: bpy.props.FloatProperty(
        name="Sill Height",
        description="Distance from the floor to the window base",
        default=0.9, min=0.0, soft_max=2.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        _new_box_object(context, "Window_Blockout",
                        self.width, self.thickness, self.height,
                        z_offset=self.sill_height)
        self.report({'INFO'},
                    f"Window blockout added ({self.width:.2f} x {self.height:.2f} m, "
                    f"sill at {self.sill_height:.2f} m)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Roof Blockout (gable)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_roof_blockout(bpy.types.Operator):
    """Add a simple gable roof volume (origin at base)"""
    bl_idname = "object.pro_add_roof_blockout"
    bl_label = "Add Roof Blockout"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(name="Width", default=4.6, min=0.1, soft_max=30.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=4.6, min=0.1, soft_max=30.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Ridge Height", default=1.2, min=0.05, soft_max=10.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_mode_poll(context)

    def execute(self, context):
        me = bpy.data.meshes.new("Roof_Blockout")
        bm = bmesh.new()
        hw, hd, h = self.width / 2.0, self.depth / 2.0, self.height

        # Base corners
        c1 = bm.verts.new((-hw, -hd, 0.0))
        c2 = bm.verts.new((hw, -hd, 0.0))
        c3 = bm.verts.new((hw, hd, 0.0))
        c4 = bm.verts.new((-hw, hd, 0.0))
        # Ridge line along Y
        r1 = bm.verts.new((0.0, -hd, h))
        r2 = bm.verts.new((0.0, hd, h))

        bm.faces.new((c1, c2, c3, c4))      # bottom
        bm.faces.new((c2, c3, r2, r1))      # +X slope
        bm.faces.new((c4, c1, r1, r2))      # -X slope
        bm.faces.new((c1, c2, r1))          # front gable
        bm.faces.new((c3, c4, r2))          # back gable

        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(me)
        bm.free()

        obj = bpy.data.objects.new("Roof_Blockout", me)
        _link_at_cursor(context, obj)
        self.report({'INFO'},
                    f"Roof blockout added ({self.width:.2f} x {self.depth:.2f}, "
                    f"ridge {self.height:.2f} m)")
        return {'FINISHED'}
