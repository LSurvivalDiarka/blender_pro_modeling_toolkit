# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_organic.py
# v0.1.5 Character / Organic / Retopo Pro: organic mesh cleanup + sculpt
# prep. Non-destructive by default; heavy cleanups honour the
# organic_backup_before_cleanup property; materials and UVs are kept.
# ──────────────────────────────────────────────────────────────────────

from math import radians

import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree

from . import character_utils as ch


# ═══════════════════════════════════════════════════════════════════════
#  ORGANIC MESH CLEANUP (Edit Mode tools)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_char_organic_smooth(bpy.types.Operator):
    """Smooth the selected vertices (organic friendly, volume aware)"""
    bl_idname = "mesh.pro_char_organic_smooth"
    bl_label = "Organic Smooth Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        bm = bmesh.from_edit_mesh(context.edit_object.data)
        if not any(v.select for v in bm.verts):
            self.report({'WARNING'}, "No vertices selected.")
            return {'CANCELLED'}
        bpy.ops.mesh.vertices_smooth(
            factor=p.organic_smooth_strength,
            repeat=max(1, int(p.organic_relax_iterations)))
        self.report({'INFO'},
                    f"Organic smooth (factor {p.organic_smooth_strength:.2f}, "
                    f"x{p.organic_relax_iterations})")
        return {'FINISHED'}


class MESH_OT_pro_char_organic_relax(bpy.types.Operator):
    """Relax selected vertices keeping open boundaries pinned"""
    bl_idname = "mesh.pro_char_organic_relax"
    bl_label = "Organic Relax"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        if len(sel) < 3:
            self.report({'WARNING'}, "Select at least 3 vertices.")
            return {'CANCELLED'}
        factor = p.organic_smooth_strength
        for _ in range(max(1, int(p.organic_relax_iterations))):
            new_pos = {}
            for v in sel:
                if v.is_boundary:
                    continue
                nbrs = [e.other_vert(v) for e in v.link_edges]
                if nbrs:
                    avg = sum((n.co for n in nbrs), Vector()) / len(nbrs)
                    new_pos[v] = v.co.lerp(avg, factor)
            for v, co in new_pos.items():
                v.co = co
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Relaxed {len(sel)} verts "
                              f"(x{p.organic_relax_iterations}, boundaries pinned)")
        return {'FINISHED'}


class MESH_OT_pro_char_inflate_deflate(bpy.types.Operator):
    """Inflate (+) or deflate (–) selected vertices along their normals"""
    bl_idname = "mesh.pro_char_inflate_deflate"
    bl_label = "Inflate / Deflate Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        if not sel:
            self.report({'WARNING'}, "No vertices selected.")
            return {'CANCELLED'}
        for v in sel:
            v.co += v.normal * p.organic_inflate_amount
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"{'Inflated' if p.organic_inflate_amount >= 0 else 'Deflated'} "
                    f"{len(sel)} verts by {abs(p.organic_inflate_amount):.4f}")
        return {'FINISHED'}


class MESH_OT_pro_char_smooth_by_surface(bpy.types.Operator):
    """Smooth selection tangentially, re-projecting onto the original
    surface so the volume/silhouette is preserved"""
    bl_idname = "mesh.pro_char_smooth_by_surface"
    bl_label = "Smooth by Surface"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        if len(sel) < 3:
            self.report({'WARNING'}, "Select at least 3 vertices.")
            return {'CANCELLED'}

        snapshot = BVHTree.FromBMesh(bm)        # original surface
        factor = p.organic_smooth_strength
        for _ in range(max(1, int(p.organic_relax_iterations))):
            new_pos = {}
            for v in sel:
                nbrs = [e.other_vert(v) for e in v.link_edges]
                if nbrs:
                    avg = sum((n.co for n in nbrs), Vector()) / len(nbrs)
                    new_pos[v] = v.co.lerp(avg, factor)
            for v, co in new_pos.items():
                hit = snapshot.find_nearest(co)
                v.co = hit[0] if hit and hit[0] is not None else co
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"Surface-smoothed {len(sel)} verts (shape preserved)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_remove_tiny_loose_parts(bpy.types.Operator):
    """Delete tiny disconnected pieces (dust/debris) from the active mesh.
    Creates a backup when 'Backup Before Cleanup' is enabled"""
    bl_idname = "object.pro_char_remove_tiny_loose_parts"
    bl_label = "Remove Tiny Loose Parts"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        if p.organic_backup_before_cleanup:
            ch.backup_object(context, obj, "_pre_loose")

        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            islands = ch.vert_islands(bm)
            if len(islands) <= 1:
                self.report({'INFO'}, "Mesh is a single piece — nothing removed.")
                return {'CANCELLED'}
            biggest = max(len(i) for i in islands)
            thr = max(int(p.ai_cleanup_threshold), 3)
            bm.verts.ensure_lookup_table()
            doomed = [bm.verts[i] for isl in islands
                      if len(isl) < thr and len(isl) < biggest
                      for i in isl]
            removed_islands = sum(1 for isl in islands
                                  if len(isl) < thr and len(isl) < biggest)
            if not doomed:
                self.report({'INFO'},
                            f"No islands under {thr} verts — nothing removed.")
                return {'CANCELLED'}
            bmesh.ops.delete(bm, geom=doomed, context='VERTS')
            bm.to_mesh(obj.data)
            obj.data.update()
        finally:
            bm.free()
        self.report({'INFO'},
                    f"Removed {removed_islands} tiny part(s) (<{thr} verts). "
                    + ("Backup created." if p.organic_backup_before_cleanup else ""))
        return {'FINISHED'}


class MESH_OT_pro_char_merge_close_verts_safe(bpy.types.Operator):
    """Merge selected vertices closer than the merge distance.
    Capped at 10% of the average edge length so shapes never collapse"""
    bl_idname = "mesh.pro_char_merge_close_verts_safe"
    bl_label = "Merge Close Vertices Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.edit_mesh_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        if len(sel) < 2:
            self.report({'WARNING'}, "Select at least 2 vertices.")
            return {'CANCELLED'}
        lens = [e.calc_length() for e in bm.edges]
        cap = (sum(lens) / len(lens)) * 0.1 if lens else p.organic_merge_distance
        dist = min(p.organic_merge_distance, cap)
        before = len(bm.verts)
        bmesh.ops.remove_doubles(bm, verts=sel, dist=dist)
        removed = before - len(bm.verts)
        bmesh.update_edit_mesh(me)
        self.report({'INFO'},
                    f"Merged {removed} verts (dist {dist:.5f}"
                    + (", capped for safety)" if dist < p.organic_merge_distance else ")"))
        return {'FINISHED'}


class OBJECT_OT_pro_char_recalc_organic_normals(bpy.types.Operator):
    """Recalculate all normals outside (UVs and materials untouched)"""
    bl_idname = "object.pro_char_recalc_organic_normals"
    bl_label = "Recalculate Organic Normals"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            bm.to_mesh(obj.data)
            obj.data.update()
        finally:
            bm.free()
        self.report({'INFO'}, f"Normals recalculated on '{obj.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_char_fix_inside_out(bpy.types.Operator):
    """Fix completely inside-out meshes (negative volume): recalculates
    and flips the whole shell if it points inward"""
    bl_idname = "object.pro_char_fix_inside_out"
    bl_label = "Fix Inside-Out Normals"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            flipped = False
            if bm.calc_volume(signed=True) < 0:
                bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
                flipped = True
            bm.to_mesh(obj.data)
            obj.data.update()
        finally:
            bm.free()
        self.report({'INFO'},
                    "Mesh was inside-out — flipped to face outward."
                    if flipped else "Normals were already facing outward.")
        return {'FINISHED'}


class OBJECT_OT_pro_char_smooth_shading_organic(bpy.types.Operator):
    """Shade smooth on selected meshes (organic look, data untouched)"""
    bl_idname = "object.pro_char_smooth_shading_organic"
    bl_label = "Smooth Shading Organic"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        n = 0
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            for poly in obj.data.polygons:
                poly.use_smooth = True
            n += 1
        self.report({'INFO'}, f"Smooth shading on {n} object(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_add_corrective_smooth(bpy.types.Operator):
    """Add a Corrective Smooth modifier (non-destructive organic smoothing)"""
    bl_idname = "object.pro_char_add_corrective_smooth"
    bl_label = "Add Corrective Smooth Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        if any(m.type == 'CORRECTIVE_SMOOTH' for m in obj.modifiers):
            self.report({'INFO'}, "Corrective Smooth already present.")
            return {'CANCELLED'}
        mod = obj.modifiers.new("PRO_Corrective_Smooth", 'CORRECTIVE_SMOOTH')
        mod.factor = 0.5
        mod.iterations = 5
        mod.use_only_smooth = True
        self.report({'INFO'}, "Corrective Smooth added (factor 0.5, 5 iters)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_add_smooth_by_angle(bpy.types.Operator):
    """Smooth shading with hard edges by angle (40°) — modern Smooth by
    Angle setup, with legacy fallback"""
    bl_idname = "object.pro_char_add_smooth_by_angle"
    bl_label = "Add Smooth by Angle Setup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        try:
            bpy.ops.object.shade_auto_smooth(angle=radians(40.0))
            self.report({'INFO'}, "Smooth by Angle set up (40°)")
        except (AttributeError, RuntimeError):
            bpy.ops.object.shade_smooth()
            for obj in context.selected_objects:
                if obj.type == 'MESH' and hasattr(obj.data, "use_auto_smooth"):
                    obj.data.use_auto_smooth = True
                    obj.data.auto_smooth_angle = radians(40.0)
            self.report({'INFO'}, "Smooth shading + auto smooth 40° (legacy)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  SCULPT PREP
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_char_prepare_sculpt_object(bpy.types.Operator):
    """Prepare the active mesh for sculpting: backup, organic collection,
    smooth shading and a polycount sanity report (no remeshing applied)"""
    bl_idname = "object.pro_char_prepare_sculpt_object"
    bl_label = "Prepare Sculpt Object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        msgs = []
        if p.sculpt_create_backup:
            ch.backup_object(context, obj, "_pre_sculpt")
            msgs.append("backup created")
        ch.get_coll(context, ch.COLL_ORGANIC)
        if ch.COLL_ORGANIC not in [c.name for c in obj.users_collection]:
            ch.get_coll(context, ch.COLL_ORGANIC).objects.link(obj)
            msgs.append(f"linked to {ch.COLL_ORGANIC}")
        for poly in obj.data.polygons:
            poly.use_smooth = True
        tris = ch.approx_tri_count(obj)
        if tris > 1_500_000:
            self.report({'WARNING'},
                        f"'{obj.name}' is VERY heavy (~{tris:,} tris) — "
                        "consider voxel remesh before sculpting. " + ", ".join(msgs))
        else:
            self.report({'INFO'},
                        f"Sculpt-ready: ~{tris:,} tris, smooth shading"
                        + (", " + ", ".join(msgs) if msgs else ""))
        return {'FINISHED'}


class OBJECT_OT_pro_char_voxel_remesh_helper(bpy.types.Operator):
    """Configure voxel-remesh settings (size + estimate). Does NOT remesh —
    run Object > Remesh yourself when you are ready"""
    bl_idname = "object.pro_char_voxel_remesh_helper"
    bl_label = "Voxel Remesh Settings Helper"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        size = max(p.sculpt_voxel_size, 0.0005)
        obj.data.remesh_voxel_size = size
        d = obj.dimensions
        est = int((max(d.x, 1e-4) / size) * (max(d.y, 1e-4) / size)
                  * (max(d.z, 1e-4) / size) ** 0.5)
        level = "OK" if est < 3_000_000 else "HEAVY — increase voxel size"
        self.report({'INFO'},
                    f"Voxel size {size:.4f} m set on '{obj.name}' "
                    f"(rough density estimate: {level}). Remesh not applied.")
        return {'FINISHED'}


class OBJECT_OT_pro_char_add_multires_safe(bpy.types.Operator):
    """Add a Multires modifier safely (warns about n-gons, never subdivides
    automatically)"""
    bl_idname = "object.pro_char_add_multires_safe"
    bl_label = "Add Multires Modifier Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        if any(m.type == 'MULTIRES' for m in obj.modifiers):
            self.report({'INFO'}, "Multires already present.")
            return {'CANCELLED'}
        ngons = sum(1 for poly in obj.data.polygons if len(poly.vertices) > 4)
        obj.modifiers.new("PRO_Multires", 'MULTIRES')
        if ngons:
            self.report({'WARNING'},
                        f"Multires added, but the mesh has {ngons} n-gons — "
                        "subdivision quality will suffer. Consider retopo first.")
        else:
            self.report({'INFO'}, "Multires added (subdivide it when ready).")
        return {'FINISHED'}


class OBJECT_OT_pro_char_create_sculpt_backup(bpy.types.Operator):
    """Store a hidden backup copy in PRO_Sculpt_Backups"""
    bl_idname = "object.pro_char_create_sculpt_backup"
    bl_label = "Create Sculpt Backup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        dup = ch.backup_object(context, context.active_object, "_sculpt_backup")
        self.report({'INFO'}, f"Backup '{dup.name}' stored in {ch.COLL_SCULPT_BACKUPS}")
        return {'FINISHED'}


class OBJECT_OT_pro_char_create_sculpt_collection(bpy.types.Operator):
    """File the selected meshes into the PRO_Organic collection"""
    bl_idname = "object.pro_char_create_sculpt_collection"
    bl_label = "Create Sculpt Collection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        n = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                ch.link_to_coll(context, obj, ch.COLL_ORGANIC)
                n += 1
        self.report({'INFO'}, f"{n} object(s) filed in {ch.COLL_ORGANIC}")
        return {'FINISHED'}


class OBJECT_OT_pro_char_set_clay_material(bpy.types.Operator):
    """Assign the PRO_Organic_Clay material (your materials are saved and
    can be restored from the AI Cleanup panel)"""
    bl_idname = "object.pro_char_set_clay_material"
    bl_label = "Set Sculpt Material Clay"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        n = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                ch.save_materials(obj)
                ch.assign_char_material(obj, "PRO_Organic_Clay")
                n += 1
        self.report({'INFO'}, f"Clay material on {n} object(s) (originals saved)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_set_matcap_view(bpy.types.Operator):
    """Switch the 3D viewport to MatCap shading (great for sculpt checks)"""
    bl_idname = "object.pro_char_set_matcap_view"
    bl_label = "Set Matcap Friendly View"
    bl_options = {'REGISTER'}

    def execute(self, context):
        space = context.space_data
        if space is None or space.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run this from the 3D Viewport.")
            return {'CANCELLED'}
        space.shading.type = 'SOLID'
        space.shading.light = 'MATCAP'
        self.report({'INFO'}, "Viewport set to MatCap shading")
        return {'FINISHED'}


classes = (
    MESH_OT_pro_char_organic_smooth,
    MESH_OT_pro_char_organic_relax,
    MESH_OT_pro_char_inflate_deflate,
    MESH_OT_pro_char_smooth_by_surface,
    OBJECT_OT_pro_char_remove_tiny_loose_parts,
    MESH_OT_pro_char_merge_close_verts_safe,
    OBJECT_OT_pro_char_recalc_organic_normals,
    OBJECT_OT_pro_char_fix_inside_out,
    OBJECT_OT_pro_char_smooth_shading_organic,
    OBJECT_OT_pro_char_add_corrective_smooth,
    OBJECT_OT_pro_char_add_smooth_by_angle,
    OBJECT_OT_pro_char_prepare_sculpt_object,
    OBJECT_OT_pro_char_voxel_remesh_helper,
    OBJECT_OT_pro_char_add_multires_safe,
    OBJECT_OT_pro_char_create_sculpt_backup,
    OBJECT_OT_pro_char_create_sculpt_collection,
    OBJECT_OT_pro_char_set_clay_material,
    OBJECT_OT_pro_char_set_matcap_view,
)
