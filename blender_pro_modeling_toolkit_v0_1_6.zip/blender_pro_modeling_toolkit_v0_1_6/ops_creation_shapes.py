# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_creation_shapes.py
# v0.1.3 Pro Modeling Creation Suite: base shape generators.
# Complements ops_shapes.py (Rounded Box / Pipe / Cable stay there).
# No advanced booleans, no Geometry Nodes — editable bases only.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh

from . import creation_utils as cu


class _CreateOp:
    bl_options = {'REGISTER', 'UNDO'}
    pro_collection = cu.COLL_BLOCKOUT
    pro_material = "PRO_Blockout_Grey"

    @classmethod
    def poll(cls, context):
        return cu.object_mode_poll(context)

    def execute(self, context):
        bm = bmesh.new()
        name = self.build(context, bm)
        cu.finalize_new_object(context, self, name, bm,
                               self.pro_collection, self.pro_material)
        return {'FINISHED'}


class OBJECT_OT_pro_create_handle(_CreateOp, bpy.types.Operator):
    """Create a U-shaped handle (two posts + grip bar)"""
    bl_idname = "object.pro_create_handle"
    bl_label = "Handle"

    length: bpy.props.FloatProperty(name="Grip Length", default=0.15, min=0.02, soft_max=1.0, unit='LENGTH')
    standoff: bpy.props.FloatProperty(name="Standoff", default=0.05, min=0.01, soft_max=0.3, unit='LENGTH')
    bar_size: bpy.props.FloatProperty(name="Bar Size", default=0.02, min=0.005, soft_max=0.1, unit='LENGTH')

    def build(self, context, bm):
        b = self.bar_size
        half = (self.length - b) / 2.0
        cu.add_box(bm, b, b, self.standoff, cx=-half)
        cu.add_box(bm, b, b, self.standoff, cx=half)
        cu.add_box(bm, self.length, b, b, z0=self.standoff)
        return "PRO_Handle"


class OBJECT_OT_pro_create_rail(_CreateOp, bpy.types.Operator):
    """Create a guard rail (top bar on end posts)"""
    bl_idname = "object.pro_create_rail"
    bl_label = "Rail"

    length: bpy.props.FloatProperty(name="Length", default=1.0, min=0.2, soft_max=10.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.9, min=0.2, soft_max=2.0, unit='LENGTH')
    bar_size: bpy.props.FloatProperty(name="Bar Size", default=0.04, min=0.01, soft_max=0.15, unit='LENGTH')

    def build(self, context, bm):
        b = self.bar_size
        half = (self.length - b) / 2.0
        cu.add_box(bm, b, b, self.height - b, cx=-half)
        cu.add_box(bm, b, b, self.height - b, cx=half)
        cu.add_box(bm, self.length, b, b, z0=self.height - b)
        return "PRO_Rail"


class OBJECT_OT_pro_create_vent(_CreateOp, bpy.types.Operator):
    """Create a vent: frame with horizontal louver slats"""
    bl_idname = "object.pro_create_vent"
    bl_label = "Vent"

    width: bpy.props.FloatProperty(name="Width", default=0.40, min=0.1, soft_max=2.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.30, min=0.1, soft_max=2.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.03, min=0.01, soft_max=0.2, unit='LENGTH')
    slats: bpy.props.IntProperty(name="Slats", default=5, min=1, max=20)

    def build(self, context, bm):
        w, h, d, f = self.width, self.height, self.depth, 0.02
        cu.add_box(bm, f, d, h, cx=-(w - f) / 2.0)              # left frame
        cu.add_box(bm, f, d, h, cx=(w - f) / 2.0)               # right frame
        cu.add_box(bm, w - 2 * f, d, f)                         # bottom frame
        cu.add_box(bm, w - 2 * f, d, f, z0=h - f)               # top frame
        span = (h - 2 * f) / (self.slats + 1)
        for i in range(1, self.slats + 1):
            cu.add_box(bm, w - 2 * f, d * 0.5, 0.012, z0=f + span * i - 0.006)
        return "PRO_Vent"


class OBJECT_OT_pro_create_panel(_CreateOp, bpy.types.Operator):
    """Create a flat standing panel"""
    bl_idname = "object.pro_create_panel"
    bl_label = "Panel"

    width: bpy.props.FloatProperty(name="Width", default=0.6, min=0.05, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Height", default=0.6, min=0.05, soft_max=4.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.02, min=0.002, soft_max=0.3, unit='LENGTH')

    def invoke(self, context, event):
        # Seed from the configurable creation_thickness scene property
        self.thickness = context.scene.pro_toolkit.creation_thickness
        return self.execute(context)

    def build(self, context, bm):
        cu.add_box(bm, self.width, self.thickness, self.height)
        return "PRO_Panel"


class OBJECT_OT_pro_create_frame_shape(_CreateOp, bpy.types.Operator):
    """Create a standing rectangular frame (four bars around an opening)"""
    bl_idname = "object.pro_create_frame_shape"
    bl_label = "Frame"

    width: bpy.props.FloatProperty(name="Opening Width", default=0.5, min=0.05, soft_max=4.0, unit='LENGTH')
    height: bpy.props.FloatProperty(name="Opening Height", default=0.5, min=0.05, soft_max=4.0, unit='LENGTH')
    bar_width: bpy.props.FloatProperty(name="Bar Width", default=0.05, min=0.005, soft_max=0.3, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.04, min=0.005, soft_max=0.3, unit='LENGTH')

    def build(self, context, bm):
        w, h, b, d = self.width, self.height, self.bar_width, self.depth
        cu.add_box(bm, b, d, h + 2 * b, cx=-(w + b) / 2.0)
        cu.add_box(bm, b, d, h + 2 * b, cx=(w + b) / 2.0)
        cu.add_box(bm, w, d, b)
        cu.add_box(bm, w, d, b, z0=h + b)
        return "PRO_Frame"


class OBJECT_OT_pro_create_slot_block(_CreateOp, bpy.types.Operator):
    """Create a slot block: a thin elongated volume for slot openings"""
    bl_idname = "object.pro_create_slot_block"
    bl_label = "Slot"
    pro_material = "PRO_Blockout_Red"

    length: bpy.props.FloatProperty(name="Length", default=0.2, min=0.01, soft_max=2.0, unit='LENGTH')
    width: bpy.props.FloatProperty(name="Width", default=0.02, min=0.002, soft_max=0.5, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.05, min=0.005, soft_max=1.0, unit='LENGTH')

    def build(self, context, bm):
        cu.add_box(bm, self.length, self.depth, self.width)
        return "PRO_Slot_Block"


class OBJECT_OT_pro_create_simple_arch(_CreateOp, bpy.types.Operator):
    """Create a semicircular arch band over an opening"""
    bl_idname = "object.pro_create_simple_arch"
    bl_label = "Simple Arch"
    pro_collection = cu.COLL_ARCHITECTURE

    width: bpy.props.FloatProperty(
        name="Opening Width", default=1.2, min=0.2, soft_max=8.0, unit='LENGTH')
    thickness: bpy.props.FloatProperty(
        name="Band Thickness", default=0.2, min=0.02, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.2, min=0.02, soft_max=2.0, unit='LENGTH')
    spring_height: bpy.props.FloatProperty(
        name="Spring Height", description="Height of the arch springing line (0 = arch on the floor)",
        default=1.5, min=0.0, soft_max=5.0, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=12, min=3, max=64)

    def build(self, context, bm):
        if self.spring_height > 0.0:
            # Side supports up to the springing line
            cu.add_box(bm, self.thickness, self.depth, self.spring_height,
                       cx=-(self.width + self.thickness) / 2.0)
            cu.add_box(bm, self.thickness, self.depth, self.spring_height,
                       cx=(self.width + self.thickness) / 2.0)
        cu.add_arch_band(bm, self.width, self.depth, self.thickness,
                         segments=self.segments, z0=self.spring_height)
        return "PRO_Simple_Arch"


class OBJECT_OT_pro_create_hole_cutter(_CreateOp, bpy.types.Operator):
    """Create a wire cylinder to use manually as a Boolean cutter (no boolean is applied)"""
    bl_idname = "object.pro_create_hole_cutter"
    bl_label = "Simple Hole Cutter"

    radius: bpy.props.FloatProperty(name="Radius", default=0.05, min=0.001, soft_max=1.0, unit='LENGTH')
    depth: bpy.props.FloatProperty(name="Depth", default=0.2, min=0.01, soft_max=2.0, unit='LENGTH')
    segments: bpy.props.IntProperty(name="Segments", default=16, min=6, max=64)

    def invoke(self, context, event):
        props = context.scene.pro_toolkit
        self.radius = props.creation_radius
        self.segments = props.creation_segments
        return self.execute(context)

    def execute(self, context):
        bm = bmesh.new()
        cu.add_cylinder(bm, self.radius, self.depth, self.segments)
        obj = cu.finalize_new_object(context, self, "PRO_Hole_Cutter", bm,
                                     cu.COLL_BLOCKOUT, None, wire=True,
                                     at_floor=False)
        obj.display_type = 'WIRE'
        self.report({'INFO'},
                    "PRO_Hole_Cutter created (wire display). Add a Boolean "
                    "modifier on your target object and pick this cutter.")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_create_handle,
    OBJECT_OT_pro_create_rail,
    OBJECT_OT_pro_create_vent,
    OBJECT_OT_pro_create_panel,
    OBJECT_OT_pro_create_frame_shape,
    OBJECT_OT_pro_create_slot_block,
    OBJECT_OT_pro_create_simple_arch,
    OBJECT_OT_pro_create_hole_cutter,
)
