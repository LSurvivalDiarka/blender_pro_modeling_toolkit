# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_guides.py
# v0.1.5: organic shape BASES and character scale GUIDES.
# These are simple, low-poly, editable starting volumes and reference
# helpers — NOT finished assets and NOT prefab characters.
# ──────────────────────────────────────────────────────────────────────

from math import cos, sin, pi, radians

import bpy
import bmesh
from mathutils import Matrix, Vector

from . import character_utils as ch


# ═══════════════════════════════════════════════════════════════════════
#  BMESH BUILDERS (all low poly, base at z=0 where it makes sense)
# ═══════════════════════════════════════════════════════════════════════

def _tapered_tube(bm, r1, r2, length, rings=6, segments=8, bend=0.0):
    """Stacked-ring tapered tube along +Z (editable: real loops).
    *bend* curves the tube on +X quadratically (claws, roots)."""
    loops = []
    for i in range(rings + 1):
        t = i / rings
        r = r1 + (r2 - r1) * t
        z = length * t
        x_off = bend * t * t
        ring = []
        for j in range(segments):
            a = 2.0 * pi * j / segments
            ring.append(bm.verts.new((x_off + cos(a) * r, sin(a) * r, z)))
        loops.append(ring)
    for i in range(rings):
        a, b = loops[i], loops[i + 1]
        for j in range(segments):
            k = (j + 1) % segments
            bm.faces.new((a[j], a[k], b[k], b[j]))
    # caps
    bm.faces.new(tuple(reversed(loops[0])))
    bm.faces.new(tuple(loops[-1]))
    return loops


def _box(bm, w, d, h, cx=0.0, cy=0.0, z0=0.0, rot_y=0.0):
    ret = bmesh.ops.create_cube(bm, size=1.0)
    mat = Matrix.Rotation(rot_y, 4, 'Y') if rot_y else Matrix.Identity(4)
    for v in ret["verts"]:
        v.co.x *= w
        v.co.y *= d
        v.co.z *= h
        v.co = mat @ v.co
        v.co.x += cx
        v.co.y += cy
        v.co.z += h / 2.0 + z0
    return ret["verts"]


def _sphere(bm, r, cx=0.0, cy=0.0, cz=0.0, sx=1.0, sy=1.0, sz=1.0, subdiv=2):
    ret = bmesh.ops.create_icosphere(bm, subdivisions=subdiv, radius=r)
    for v in ret["verts"]:
        v.co.x = v.co.x * sx + cx
        v.co.y = v.co.y * sy + cy
        v.co.z = v.co.z * sz + cz
    return ret["verts"]


def _edge_ring(bm, rx, ry, segments=12, cz=0.0):
    verts = [bm.verts.new((cos(2 * pi * i / segments) * rx,
                           sin(2 * pi * i / segments) * ry, cz))
             for i in range(segments)]
    for i in range(segments):
        bm.edges.new((verts[i], verts[(i + 1) % segments]))
    return verts


def _leaf(bm, length=0.4, width=0.16, segments=5):
    """Flat editable leaf: center spine + mirrored rim, quads."""
    spine = [bm.verts.new((0.0, length * i / segments, 0.0))
             for i in range(segments + 1)]
    left, right = [], []
    for i in range(1, segments):
        t = i / segments
        w = width * sin(pi * t) * 0.5
        left.append(bm.verts.new((-w, length * t, 0.0)))
        right.append(bm.verts.new((w, length * t, 0.0)))
    for i in range(len(left) - 1):
        bm.faces.new((spine[i + 1], left[i], left[i + 1], spine[i + 2]))
        bm.faces.new((spine[i + 2], right[i + 1], right[i], spine[i + 1]))
    bm.faces.new((spine[0], left[0], spine[1]))
    bm.faces.new((spine[1], right[0], spine[0]))
    bm.faces.new((spine[-2], left[-1], spine[-1]))
    bm.faces.new((spine[-1], right[-1], spine[-2]))


# builders: name -> function(bm, props) building geometry
def _b_blob(bm, p):
    _sphere(bm, 0.5, cz=0.5)

def _b_limb(bm, p):
    _tapered_tube(bm, 0.12, 0.08, 0.6)

def _b_joint(bm, p):
    _sphere(bm, 0.1, cz=0.1, subdiv=1)

def _b_eye_socket(bm, p):
    _sphere(bm, 0.08, cz=0.08, sy=0.6, sz=0.7, subdiv=1)

def _b_mouth(bm, p):
    _edge_ring(bm, 0.12, 0.05, segments=12)

def _b_root(bm, p):
    _tapered_tube(bm, 0.09, 0.015, 1.0, rings=8, segments=7, bend=0.25)

def _b_tentacle(bm, p):
    _tapered_tube(bm, 0.10, 0.008, 1.2, rings=10, segments=8, bend=0.15)

def _b_claw(bm, p):
    _tapered_tube(bm, 0.06, 0.004, 0.35, rings=6, segments=6, bend=0.18)

def _b_leaf(bm, p):
    _leaf(bm, 0.4, 0.16)

def _b_petal(bm, p):
    _leaf(bm, 0.3, 0.22, segments=4)


def _b_head_guide(bm, p):
    h = p.character_target_height
    _sphere(bm, h * 0.0625, cz=h - h * 0.0625, sy=1.15, subdiv=1)   # ~h/8 head

def _b_shoulder_guide(bm, p):
    h = p.character_target_height
    _box(bm, h * 0.259, 0.05, 0.05, z0=h * 0.81)                    # biacromial

def _b_hand_guide(bm, p):
    _box(bm, 0.09, 0.02, 0.19)

def _b_foot_guide(bm, p):
    _box(bm, 0.09, 0.26, 0.06)

def _b_tpose(bm, p):
    h = p.character_target_height
    _box(bm, 0.22, 0.12, h)                                         # body bar
    _box(bm, h * 0.95, 0.10, 0.10, z0=h * 0.78)                     # arm span

def _b_apose(bm, p):
    h = p.character_target_height
    _box(bm, 0.22, 0.12, h)
    arm = h * 0.45
    _box(bm, arm, 0.10, 0.10, cx=-arm * 0.42, z0=h * 0.70, rot_y=radians(35))
    _box(bm, arm, 0.10, 0.10, cx=arm * 0.42, z0=h * 0.70, rot_y=radians(-35))

def _b_limb_cyl(bm, p):
    _tapered_tube(bm, 0.06, 0.06, 0.6, rings=4)

def _b_joint_marker(bm, p):
    _sphere(bm, 0.04, cz=0.04, subdiv=1)


# table: suffix -> (label, collection, material, wire, builder)
SHAPES = {
    "organic_blob":   ("Create Organic Blob Base", ch.COLL_ORGANIC, "PRO_Organic_Clay", False, _b_blob),
    "limb_guide":     ("Create Limb Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", False, _b_limb),
    "joint_guide":    ("Create Joint Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", False, _b_joint),
    "eye_socket":     ("Create Eye Socket Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", False, _b_eye_socket),
    "mouth_opening":  ("Create Mouth Opening Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_mouth),
    "root_base":      ("Create Root / Vine Base", ch.COLL_ORGANIC, "PRO_Curve_Root", False, _b_root),
    "tentacle_base":  ("Create Tentacle Base", ch.COLL_ORGANIC, "PRO_Curve_Tentacle", False, _b_tentacle),
    "claw_base":      ("Create Claw Base", ch.COLL_ORGANIC, "PRO_Organic_Clay", False, _b_claw),
    "leaf_base":      ("Create Leaf Shape Base", ch.COLL_ORGANIC, "PRO_Organic_Clay", False, _b_leaf),
    "petal_base":     ("Create Flower Petal Base", ch.COLL_ORGANIC, "PRO_Organic_Clay", False, _b_petal),
    "head_guide":     ("Create Head Proportion Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_head_guide),
    "shoulder_guide": ("Create Shoulder Width Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_shoulder_guide),
    "hand_guide":     ("Create Hand Size Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_hand_guide),
    "foot_guide":     ("Create Foot Size Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_foot_guide),
    "tpose_guide":    ("Create T-Pose Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_tpose),
    "apose_guide":    ("Create A-Pose Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_apose),
    "limb_cylinder":  ("Create Limb Cylinder Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_limb_cyl),
    "joint_marker":   ("Create Joint Marker Guide", ch.COLL_GUIDES, "PRO_Guide_Yellow", True, _b_joint_marker),
}


def _make_shape_op(suffix):
    label, coll, mat, wire, builder = SHAPES[suffix]

    class _Op(bpy.types.Operator):
        bl_idname = f"object.pro_char_{suffix}"
        bl_label = label
        bl_description = (f"{label} — base/guía low-poly editable en el cursor "
                          "(no es un asset final)")
        bl_options = {'REGISTER', 'UNDO'}

        @classmethod
        def poll(cls, context):
            return context.mode == 'OBJECT'

        def execute(self, context):
            p = context.scene.pro_toolkit
            bm = bmesh.new()
            builder(bm, p)
            if bm.faces:
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            me = bpy.data.meshes.new(f"PRO_{suffix}")
            bm.to_mesh(me)
            bm.free()
            obj = bpy.data.objects.new(f"PRO_{suffix}", me)
            ch.get_coll(context, coll).objects.link(obj)
            obj.location = context.scene.cursor.location.copy()
            ch.assign_char_material(obj, mat)
            if wire:
                obj.display_type = 'WIRE'
                obj.show_in_front = True
            obj.hide_render = wire
            for o in context.selected_objects:
                o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({'INFO'}, f"{label} → '{obj.name}' en {coll}")
            return {'FINISHED'}

    _Op.__name__ = f"OBJECT_OT_pro_char_{suffix}"
    return _Op


_shape_classes = tuple(_make_shape_op(s) for s in SHAPES)


class OBJECT_OT_pro_char_human_guide(bpy.types.Operator):
    """Create the human scale reference (target height, default 1.78 m)"""
    bl_idname = "object.pro_char_human_guide"
    bl_label = "Create Human Scale Guide 1.78m"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.pro_toolkit
        h = p.character_target_height
        bm = bmesh.new()
        _box(bm, 0.36, 0.18, h * 0.42, z0=h * 0.45)                 # torso+hips
        _sphere(bm, h * 0.0625, cz=h - h * 0.0625, subdiv=1)        # head
        _box(bm, 0.10, 0.12, h * 0.45)                              # legs block
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        me = bpy.data.meshes.new("PRO_Human_Scale_Guide")
        bm.to_mesh(me)
        bm.free()
        obj = bpy.data.objects.new(f"PRO_Human_Guide_{h:.2f}m", me)
        ch.get_coll(context, ch.COLL_GUIDES).objects.link(obj)
        obj.location = context.scene.cursor.location.copy()
        obj.location.z = 0.0
        ch.assign_char_material(obj, "PRO_Guide_Yellow")
        obj.display_type = 'WIRE'
        obj.show_in_front = True
        obj.hide_render = True
        self.report({'INFO'},
                    f"Guía humana de {h:.2f} m creada (silueta simple, no un personaje)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_bounding_box_guide(bpy.types.Operator):
    """Create a wire bounding-box guide around the active object"""
    bl_idname = "object.pro_char_bounding_box_guide"
    bl_label = "Create Character Bounding Box"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        src = context.active_object
        d = src.dimensions
        bm = bmesh.new()
        _box(bm, max(d.x, 1e-3), max(d.y, 1e-3), max(d.z, 1e-3))
        me = bpy.data.meshes.new("PRO_Char_BBox")
        bm.to_mesh(me)
        bm.free()
        obj = bpy.data.objects.new(f"PRO_BBox_{src.name}", me)
        ch.get_coll(context, ch.COLL_GUIDES).objects.link(obj)
        corners = [src.matrix_world @ Vector(c) for c in src.bound_box]
        center = sum(corners, Vector()) / 8.0
        obj.location = (center.x, center.y, min(c.z for c in corners))
        ch.assign_char_material(obj, "PRO_Guide_Yellow")
        obj.display_type = 'WIRE'
        obj.hide_render = True
        obj.hide_select = True
        self.report({'INFO'},
                    f"BBox de '{src.name}': {d.x:.2f} × {d.y:.2f} × {d.z:.2f} m")
        return {'FINISHED'}


classes = _shape_classes + (
    OBJECT_OT_pro_char_human_guide,
    OBJECT_OT_pro_char_bounding_box_guide,
)
