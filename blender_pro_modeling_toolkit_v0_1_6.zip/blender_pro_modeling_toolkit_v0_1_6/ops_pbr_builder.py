# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_pbr_builder.py
# v0.1.6 — PBR Material Builder: clean Principled-based materials,
# safe conversion of existing materials (always a PBR_ copy, the
# original is NEVER modified), automatic map detection + wiring.
# ──────────────────────────────────────────────────────────────────────

import os

import bpy

from . import material_utils as mu
from . import node_utils

# filename tokens per PBR channel (checked against image name + filepath)
CHANNEL_TOKENS = {
    'BASE': ("basecolor", "base_color", "albedo", "diffuse", "diff",
             "_col", "color"),
    'ROUGHNESS': ("roughness", "rough", "_rgh", "_rough"),
    'METALLIC': ("metallic", "metalness", "metal", "_mtl", "_met"),
    'NORMAL': ("normal", "_nrm", "_nor", "norm"),
    'AO': ("ambientocclusion", "ambient_occlusion", "_ao", "occlusion"),
    'EMISSION': ("emissive", "emission", "_emit"),
    'ALPHA': ("opacity", "alpha", "_opa"),
}

_NODE_X = {-1: -900, 0: -600}


def detect_channel(image):
    """Best-guess PBR channel of *image* from its name/path, or None."""
    hay = (image.name + " " + os.path.basename(image.filepath)).lower()
    for channel, tokens in CHANNEL_TOKENS.items():
        if any(t in hay for t in tokens):
            return channel
    return None


def classify_images(images):
    """dict channel -> image (first match wins; BASE falls back to the
    first color-space image)."""
    out = {}
    for img in images:
        ch = detect_channel(img)
        if ch and ch not in out:
            out[ch] = img
    if 'BASE' not in out:
        for img in images:
            if img.colorspace_settings.name != 'Non-Color':
                out['BASE'] = img
                break
    return out


def detect_material_maps(mat):
    """Detected channel images of an existing material. Wired detection
    (node_utils) wins over filename guessing."""
    maps = {}
    src = node_utils.detect_base_color_source(mat)
    if src["base_texture_image"] is not None:
        maps['BASE'] = src["base_texture_image"]
    nrm = node_utils.find_normal_image(mat)
    if nrm is not None:
        maps['NORMAL'] = nrm
    rgh = node_utils.find_roughness_image(mat)
    if rgh is not None:
        maps['ROUGHNESS'] = rgh
    guessed = classify_images(mu.material_images(mat))
    for ch, img in guessed.items():
        maps.setdefault(ch, img)
    maps["_base_color"] = src["base_color"]
    return maps


def build_pbr_material(name, props, maps=None):
    """Clean PBR node tree: Principled + ordered texture nodes.
    *maps*: optional dict channel -> bpy Image."""
    maps = maps or {}
    mat = node_utils.fresh_material(name)
    nt = mat.node_tree
    nodes, links = nt.nodes, nt.links

    out = node_utils.add_node(nodes, 'ShaderNodeOutputMaterial',
                              "PRO PBR Output", (320, 0))
    bsdf = node_utils.add_node(nodes, 'ShaderNodeBsdfPrincipled',
                               "PRO PBR Shader", (0, 0))
    links.new(bsdf.outputs[0], out.inputs['Surface'])

    base_color = maps.get("_base_color", tuple(props.pbr_base_color))
    bsdf.inputs['Base Color'].default_value = (*base_color[:3], 1.0)
    bsdf.inputs['Roughness'].default_value = props.pbr_roughness
    bsdf.inputs['Metallic'].default_value = props.pbr_metallic
    if 'Alpha' in bsdf.inputs:
        bsdf.inputs['Alpha'].default_value = props.pbr_alpha

    def tex_node(label, image, y, non_color):
        n = node_utils.add_node(nodes, 'ShaderNodeTexImage',
                                f"PRO {label} Texture", (-700, y))
        n.image = image
        if image is not None and non_color:
            image.colorspace_settings.name = 'Non-Color'
        return n

    y = 400
    base_img = maps.get('BASE')
    ao_img = maps.get('AO')
    if base_img is not None:
        n_base = tex_node("Base Color", base_img, y, False)
        if ao_img is not None:
            n_ao = tex_node("AO", ao_img, y - 280, True)
            n_mix = node_utils.add_node(nodes, 'ShaderNodeMix',
                                        "PRO AO Multiply", (-350, y - 100))
            n_mix.data_type = 'RGBA'
            n_mix.blend_type = 'MULTIPLY'
            n_mix.inputs['Factor'].default_value = 0.85
            links.new(n_base.outputs['Color'], n_mix.inputs[6])
            links.new(n_ao.outputs['Color'], n_mix.inputs[7])
            links.new(n_mix.outputs[2], bsdf.inputs['Base Color'])
            y -= 280
        else:
            links.new(n_base.outputs['Color'], bsdf.inputs['Base Color'])
        if 'ALPHA' not in maps and 'Alpha' in bsdf.inputs \
                and props.pbr_alpha < 1.0:
            pass  # numeric alpha already set
        y -= 280
    if maps.get('ROUGHNESS') is not None:
        n = tex_node("Roughness", maps['ROUGHNESS'], y, True)
        links.new(n.outputs['Color'], bsdf.inputs['Roughness'])
        y -= 280
    if maps.get('METALLIC') is not None:
        n = tex_node("Metallic", maps['METALLIC'], y, True)
        links.new(n.outputs['Color'], bsdf.inputs['Metallic'])
        y -= 280
    if maps.get('ALPHA') is not None and 'Alpha' in bsdf.inputs:
        n = tex_node("Alpha", maps['ALPHA'], y, True)
        links.new(n.outputs['Color'], bsdf.inputs['Alpha'])
        if hasattr(mat, "blend_method"):
            mat.blend_method = 'HASHED'
        y -= 280
    if maps.get('EMISSION') is not None:
        sock = bsdf.inputs.get('Emission Color') or bsdf.inputs.get('Emission')
        if sock is not None:
            n = tex_node("Emission", maps['EMISSION'], y, False)
            links.new(n.outputs['Color'], sock)
            if 'Emission Strength' in bsdf.inputs:
                bsdf.inputs['Emission Strength'].default_value = 1.0
            y -= 280
    if maps.get('NORMAL') is not None:
        n_tex = tex_node("Normal", maps['NORMAL'], y, True)
        n_map = node_utils.add_node(nodes, 'ShaderNodeNormalMap',
                                    "PRO Normal Map", (-350, y))
        links.new(n_tex.outputs['Color'], n_map.inputs['Color'])
        links.new(n_map.outputs['Normal'], bsdf.inputs['Normal'])

    mat.diffuse_color = (*base_color[:3], 1.0)
    return mat


class MATERIAL_OT_pro_pbr_create(bpy.types.Operator):
    """Create a clean PBR material from the panel values and assign it
    to the active object (appended as a new slot, nothing replaced)"""
    bl_idname = "material.pro_pbr_create"
    bl_label = "Create PBR Material"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty(name="Name", default="MAT_PBR_New_A")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        mat = build_pbr_material(self.name, props)
        obj = context.active_object
        if obj is not None and obj.type == 'MESH':
            obj.data.materials.append(mat)
            self.report({'INFO'},
                        f"'{mat.name}' creado y añadido a '{obj.name}' "
                        "(nuevo slot).")
        else:
            mat.use_fake_user = True
            self.report({'INFO'}, f"'{mat.name}' creado (fake user).")
        return {'FINISHED'}


class MATERIAL_OT_pro_pbr_from_folder(bpy.types.Operator):
    """Build a PBR material from a texture folder: maps are detected by
    filename (basecolor/roughness/metallic/normal/ao/emission/alpha)"""
    bl_idname = "material.pro_pbr_from_folder"
    bl_label = "Create PBR From Texture Folder"
    bl_options = {'REGISTER', 'UNDO'}

    directory: bpy.props.StringProperty(subtype='DIR_PATH')
    filter_folder: bpy.props.BoolProperty(default=True, options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        exts = {".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".exr",
                ".webp", ".bmp"}
        files = [f for f in sorted(os.listdir(self.directory))
                 if os.path.splitext(f)[1].lower() in exts]
        if not files:
            self.report({'ERROR'}, "La carpeta no contiene imágenes.")
            return {'CANCELLED'}
        images = []
        for f in files:
            try:
                images.append(bpy.data.images.load(
                    os.path.join(self.directory, f), check_existing=True))
            except RuntimeError:
                pass
        maps = classify_images(images)
        if not maps:
            self.report({'ERROR'}, "No se reconoció ningún mapa PBR.")
            return {'CANCELLED'}
        name = "MAT_" + mu.clean_name_token(
            os.path.basename(os.path.normpath(self.directory))) + "_A"
        mat = build_pbr_material(name, props, maps)
        obj = context.active_object
        if obj is not None and obj.type == 'MESH':
            obj.data.materials.append(mat)
        else:
            mat.use_fake_user = True
        found = ", ".join(k for k in maps if not k.startswith("_"))
        self.report({'INFO'}, f"'{mat.name}' creado. Mapas: {found}.")
        return {'FINISHED'}


def _convert_safe(props, mat):
    """PBR_<name> copy built from the detected maps of *mat*.
    Returns (new_mat, detected_channels). Original untouched."""
    maps = detect_material_maps(mat)
    name = f"{mu.PBR_PREFIX}{mat.name}"
    new = build_pbr_material(name, props, maps)
    return new, [k for k in maps if not k.startswith("_")]


class MATERIAL_OT_pro_pbr_convert_active(bpy.types.Operator):
    """Convert the active material to PBR Safe: a clean PBR_<name> copy
    is built from the detected maps and put in the slot; the original
    material is kept untouched (fake user)"""
    bl_idname = "material.pro_pbr_convert_active"
    bl_label = "Convert Active Material to PBR Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (context.mode == 'OBJECT' and obj is not None
                and obj.type == 'MESH' and obj.active_material is not None)

    def execute(self, context):
        props = context.scene.pro_toolkit
        obj = context.active_object
        mat = obj.active_material
        if mat.name.startswith(mu.PBR_PREFIX):
            self.report({'WARNING'}, f"'{mat.name}' ya es una conversión PBR.")
            return {'CANCELLED'}
        new, found = _convert_safe(props, mat)
        mat.use_fake_user = True
        if props.pbr_create_copy:
            obj.material_slots[obj.active_material_index].material = new
        self.report({'INFO'},
                    f"'{new.name}' creado (mapas: {', '.join(found) or 'color plano'})."
                    f" Original '{mat.name}' conservado con fake user.")
        return {'FINISHED'}


class MATERIAL_OT_pro_pbr_convert_selected(bpy.types.Operator):
    """Convert every material on the selected objects to PBR Safe copies
    (slots are repointed to PBR_<name>; originals kept with fake user)"""
    bl_idname = "material.pro_pbr_convert_selected"
    bl_label = "Convert Selected to PBR Safe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        props = context.scene.pro_toolkit
        done = {}
        complex_notes = []
        n_slots = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            for slot in obj.material_slots:
                mat = slot.material
                if mat is None or mat.name.startswith(mu.PBR_PREFIX):
                    continue
                if mat not in done:
                    new, found = _convert_safe(props, mat)
                    mat.use_fake_user = True
                    done[mat] = new
                    if mu.is_heavy(mat):
                        complex_notes.append(mat.name)
                slot.material = done[mat]
                n_slots += 1
        if not done:
            self.report({'INFO'}, "Nada que convertir.")
            return {'CANCELLED'}
        msg = f"{len(done)} material(es) → PBR Safe ({n_slots} slots)."
        if complex_notes:
            msg += " Complejos (revisar): " + ", ".join(complex_notes[:4])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class MATERIAL_OT_pro_pbr_connect_maps(bpy.types.Operator):
    """Connect PBR maps automatically: image nodes already in the ACTIVE
    material are wired to the Principled by filename channel detection"""
    bl_idname = "material.pro_pbr_connect_maps"
    bl_label = "Connect PBR Maps Automatically"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH'
                and obj.active_material is not None
                and obj.active_material.use_nodes)

    def execute(self, context):
        mat = context.active_object.active_material
        bsdf = mu.get_principled(mat)
        if bsdf is None:
            self.report({'ERROR'},
                        f"'{mat.name}' no tiene Principled BSDF — usa "
                        "Convert to PBR Safe.")
            return {'CANCELLED'}
        nt = mat.node_tree
        connected = []
        for node in mu.material_image_nodes(mat):
            if node.image is None:
                continue
            ch = detect_channel(node.image)
            if ch is None:
                continue
            sock = {'BASE': 'Base Color', 'ROUGHNESS': 'Roughness',
                    'METALLIC': 'Metallic', 'ALPHA': 'Alpha'}.get(ch)
            if ch == 'NORMAL':
                nmap = next((n for n in nt.nodes if n.type == 'NORMAL_MAP'),
                            None)
                if nmap is None:
                    nmap = node_utils.add_node(
                        nt.nodes, 'ShaderNodeNormalMap', "PRO Normal Map",
                        (node.location.x + 280, node.location.y))
                node.image.colorspace_settings.name = 'Non-Color'
                nt.links.new(node.outputs['Color'], nmap.inputs['Color'])
                nt.links.new(nmap.outputs['Normal'], bsdf.inputs['Normal'])
                connected.append("NORMAL")
            elif sock and sock in bsdf.inputs \
                    and not bsdf.inputs[sock].is_linked:
                if ch in ('ROUGHNESS', 'METALLIC', 'ALPHA'):
                    node.image.colorspace_settings.name = 'Non-Color'
                nt.links.new(node.outputs['Color'], bsdf.inputs[sock])
                connected.append(ch)
        if not connected:
            self.report({'INFO'}, "Nada que conectar (¿ya está cableado?).")
            return {'CANCELLED'}
        self.report({'INFO'}, "Conectado: " + ", ".join(connected))
        return {'FINISHED'}


class MATERIAL_OT_pro_pbr_create_missing_inputs(bpy.types.Operator):
    """Create labelled placeholder texture nodes for the PBR channels the
    active material is missing (unconnected, ready to drop images in)"""
    bl_idname = "material.pro_pbr_create_missing_inputs"
    bl_label = "Create Missing PBR Inputs"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH'
                and obj.active_material is not None)

    def execute(self, context):
        mat = context.active_object.active_material
        bsdf = mu.get_principled(mat)
        if bsdf is None:
            self.report({'ERROR'}, "El material no tiene Principled BSDF.")
            return {'CANCELLED'}
        nt = mat.node_tree
        wanted = {'Base Color': "PRO Base Color Texture",
                  'Roughness': "PRO Roughness Texture",
                  'Metallic': "PRO Metallic Texture",
                  'Normal': "PRO Normal Texture"}
        created = []
        y = -900
        for sock_name, node_name in wanted.items():
            sock = bsdf.inputs.get(sock_name)
            if sock is None or sock.is_linked or nt.nodes.get(node_name):
                continue
            n = node_utils.add_node(nt.nodes, 'ShaderNodeTexImage',
                                    node_name, (-1100, y))
            n.label = f"{node_name} (placeholder)"
            created.append(sock_name)
            y -= 260
        if not created:
            self.report({'INFO'}, "No faltan entradas PBR.")
            return {'CANCELLED'}
        self.report({'INFO'},
                    "Placeholders creados (sin conectar): "
                    + ", ".join(created))
        return {'FINISHED'}


classes = (
    MATERIAL_OT_pro_pbr_create,
    MATERIAL_OT_pro_pbr_from_folder,
    MATERIAL_OT_pro_pbr_convert_active,
    MATERIAL_OT_pro_pbr_convert_selected,
    MATERIAL_OT_pro_pbr_connect_maps,
    MATERIAL_OT_pro_pbr_create_missing_inputs,
)
