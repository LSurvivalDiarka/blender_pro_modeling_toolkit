# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_char_gameready.py
# v0.1.5: game-ready character prep. One serious audit (all the checks
# in a single markdown report with verdict) + export duplicate, export
# naming and LOD placeholders. Originals are never modified.
# ──────────────────────────────────────────────────────────────────────

import re

import bpy

from . import character_utils as ch

GR_REPORT_NAME = "V015_CHARACTER_GAME_READY_REPORT.md"


def _images_in(obj):
    images = set()
    for m in obj.data.materials:
        if m and m.use_nodes:
            for n in m.node_tree.nodes:
                if n.type == 'TEX_IMAGE' and n.image:
                    images.add(n.image.name)
    return images


class OBJECT_OT_pro_char_gameready_audit(bpy.types.Operator):
    """Game-ready audit for Unity: scale, transforms, materials, textures,
    tri budget, loose parts, UVs, origin, negative scale and manifold.
    Writes V015_CHARACTER_GAME_READY_REPORT.md with a verdict"""
    bl_idname = "object.pro_char_gameready_audit"
    bl_label = "Character Game Ready Audit"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')

    def execute(self, context):
        p = context.scene.pro_toolkit
        obj = context.active_object
        s = ch.mesh_stats(obj)
        tris = ch.approx_tri_count(obj)
        images = _images_in(obj)
        mats = [m for m in obj.data.materials if m]

        checks = []          # (ok, label, detail)
        def check(ok, label, detail):
            checks.append((ok, label, detail))

        scale_ok = all(abs(v - 1.0) <= 1e-4 for v in obj.scale)
        check(scale_ok, "Scale aplicada",
              f"scale = {tuple(round(v, 4) for v in obj.scale)}")
        rot_ok = all(abs(a) <= 1e-4 for a in obj.rotation_euler)
        check(rot_ok, "Rotación aplicada",
              f"rot = {tuple(round(a, 4) for a in obj.rotation_euler)}")
        check(not any(v < 0 for v in obj.scale), "Sin escala negativa",
              "escala negativa invierte normales en Unity")
        check(len(mats) <= 4, "Material count",
              f"{len(mats)} materiales (recomendado ≤ 4 por draw calls)")
        check(len(images) <= 4, "Texture count",
              f"{len(images)} texturas en materiales")
        check(tris <= p.character_tri_budget, "Tri budget",
              f"~{tris:,} tris (presupuesto {p.character_tri_budget:,})")
        check(s["islands"] <= 3, "Loose parts",
              f"{s['islands']} islas (revisar piezas flotantes)")
        check(len(obj.data.uv_layers) >= 1, "UV maps",
              f"{len(obj.data.uv_layers)} UV map(s)")
        height = obj.dimensions.z
        check(abs(height - p.character_target_height) <= p.character_target_height * 0.25,
              "Altura razonable",
              f"{height:.2f} m (objetivo {p.character_target_height:.2f} m)")
        origin_z = obj.matrix_world.translation.z
        from mathutils import Vector
        min_z = min((obj.matrix_world @ Vector(c)).z for c in obj.bound_box)
        check(abs(min_z) <= max(height * 0.05, 0.02), "Origen en la base",
              f"pies en Z={min_z:.3f} (origen Z={origin_z:.3f})")
        check(s["non_manifold"] == 0, "Manifold",
              f"{s['non_manifold']} aristas non-manifold")
        check(s["ngons"] == 0, "Sin n-gons",
              f"{s['ngons']} n-gons (Unity los triangula impredeciblemente)")

        passed = sum(1 for ok, _, _ in checks if ok)
        verdict = ("LISTO para Unity" if passed == len(checks) else
                   "CASI listo" if passed >= len(checks) - 2 else
                   "NO listo")

        lines = [f"# CHARACTER GAME READY REPORT — {obj.name}", "",
                 f"**Veredicto: {verdict}**  ({passed}/{len(checks)} checks OK)",
                 ""]
        for ok, label, detail in checks:
            lines.append(f"- {'✅' if ok else '❌'} **{label}** — {detail}")
        lines += ["", "## Siguientes pasos",
                  "- Corrige los ❌ y vuelve a auditar.",
                  "- Usa *Create Export Duplicate* para bakear modificadores "
                  "en una copia (el original no se toca).",
                  "- *Name Meshes for Export* limpia los nombres para FBX.",
                  "- Exporta a FBX (Unity recomienda FBX, no .blend)."]
        path = ch.write_report(GR_REPORT_NAME, lines)
        self.report({'INFO'} if verdict != "NO listo" else {'WARNING'},
                    f"Game Ready: {verdict} ({passed}/{len(checks)}). "
                    f"Informe: {path}")
        return {'FINISHED'}


class OBJECT_OT_pro_char_create_export_duplicate(bpy.types.Operator):
    """Create an export copy with all modifiers BAKED (the original keeps
    its modifiers untouched), filed in PRO_GameReady_Character"""
    bl_idname = "object.pro_char_create_export_duplicate"
    bl_label = "Create Export Duplicate"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        deps = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(deps)
        me = bpy.data.meshes.new_from_object(
            eval_obj, preserve_all_data_layers=True, depsgraph=deps)
        dup = bpy.data.objects.new(f"{obj.name}_EXPORT", me)
        dup.matrix_world = obj.matrix_world.copy()
        ch.get_coll(context, ch.COLL_GAMEREADY).objects.link(dup)
        for o in context.selected_objects:
            o.select_set(False)
        dup.select_set(True)
        context.view_layer.objects.active = dup
        self.report({'INFO'},
                    f"'{dup.name}' creado con modificadores aplicados "
                    f"({len(me.polygons):,} caras) en {ch.COLL_GAMEREADY}. "
                    "El original conserva sus modificadores.")
        return {'FINISHED'}


class OBJECT_OT_pro_char_name_for_export(bpy.types.Operator):
    """Clean export naming on selected meshes: CHAR_ prefix, no dots,
    mesh datablock renamed to match"""
    bl_idname = "object.pro_char_name_for_export"
    bl_label = "Name Meshes for Export"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        n = 0
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            base = re.sub(r"[.\s]+", "_", obj.name).strip("_")
            if not base.startswith(("CHAR_", "SM_")):
                base = f"CHAR_{base}"
            obj.name = base
            obj.data.name = base
            n += 1
        self.report({'INFO'}, f"{n} malla(s) renombradas para export (CHAR_*)")
        return {'FINISHED'}


class OBJECT_OT_pro_char_create_lod_placeholders(bpy.types.Operator):
    """Create LOD placeholder copies (_LOD1 50%, _LOD2 25%) with Decimate
    modifiers, filed in PRO_GameReady_Character (original untouched)"""
    bl_idname = "object.pro_char_create_lod_placeholders"
    bl_label = "Create LOD Placeholder Copies"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return ch.object_mode_poll(context)

    def execute(self, context):
        obj = context.active_object
        base = re.sub(r"\.\d+$", "", obj.name)
        made = []
        for i, ratio in ((1, 0.5), (2, 0.25)):
            name = f"{base}_LOD{i}"
            if name in bpy.data.objects:
                continue
            dup = obj.copy()
            dup.data = obj.data.copy()
            dup.name = name
            dup.data.name = name
            mod = dup.modifiers.new("PRO_LOD_Decimate", 'DECIMATE')
            mod.ratio = ratio
            ch.get_coll(context, ch.COLL_GAMEREADY).objects.link(dup)
            made.append(name)
        if not made:
            self.report({'INFO'}, "LODs ya existen — nada creado.")
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"LOD placeholders: {', '.join(made)} "
                    "(Decimate no aplicado — ajusta el ratio y aplica al exportar)")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_char_gameready_audit,
    OBJECT_OT_pro_char_create_export_duplicate,
    OBJECT_OT_pro_char_name_for_export,
    OBJECT_OT_pro_char_create_lod_placeholders,
)
