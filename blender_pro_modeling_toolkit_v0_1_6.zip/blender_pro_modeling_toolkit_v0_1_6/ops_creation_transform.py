# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_creation_transform.py
# v0.1.3 Pro Modeling Creation Suite:
#   · Pivot / Origin / Transform helpers (non-destructive, material-safe)
#   · Snap / Measure / Scale tools and scale-reference generators
# Complements ops_pivot_origin.py (origin to bottom/center/cursor and the
# safe apply scale/rotation operators live there and are reused by the UI).
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh
from mathutils import Vector

from . import creation_utils as cu


def _object_poll(context):
    return (context.mode == 'OBJECT'
            and context.active_object is not None)


def _selected_meshes(context):
    return [o for o in context.selected_objects if o.type == 'MESH']


def _world_bbox(obj):
    return [obj.matrix_world @ Vector(c) for c in obj.bound_box]


# ═══════════════════════════════════════════════════════════════════════
#  PIVOT / ORIGIN / TRANSFORM  (new tools for v0.1.3)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_align_to_floor(bpy.types.Operator):
    """Level the object (clear X/Y tilt, keep Z spin) and drop it onto Z = 0"""
    bl_idname = "object.pro_align_to_floor"
    bl_label = "Align Object to Floor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        objs = _selected_meshes(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        for obj in objs:
            obj.rotation_mode = obj.rotation_mode  # keep mode untouched
            eul = obj.rotation_euler
            eul.x = 0.0
            eul.y = 0.0
            context.view_layer.update()
            min_z = min(c.z for c in _world_bbox(obj))
            obj.location.z -= min_z
        self.report({'INFO'}, f"Leveled and floored {len(objs)} object(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_apply_all_transforms_safe(bpy.types.Operator):
    """Apply location, rotation and scale (skips shared/multi-user mesh data; materials and UVs untouched)"""
    bl_idname = "object.pro_apply_all_transforms_safe"
    bl_label = "Apply All Transforms (Safe)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        objs = _selected_meshes(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        prev_active = context.view_layer.objects.active

        applied, skipped = 0, []
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objs:
            if obj.data.users > 1:
                skipped.append(obj.name)
                continue
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            obj.select_set(False)
            applied += 1

        for o in objs:
            o.select_set(True)
        context.view_layer.objects.active = prev_active
        msg = f"Applied all transforms on {applied} object(s)"
        if skipped:
            self.report({'WARNING'},
                        msg + f". Skipped multi-user data: {', '.join(skipped)}")
        else:
            self.report({'INFO'}, msg)
        print(f"[Pro Toolkit] {msg}; skipped: {skipped or 'none'}")
        return {'FINISHED'}


class OBJECT_OT_pro_set_dimensions(bpy.types.Operator):
    """Set exact world dimensions on the active object (uses the Creation Settings width/depth/height)"""
    bl_idname = "object.pro_set_dimensions"
    bl_label = "Set Dimensions"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (_object_poll(context)
                and context.active_object.type == 'MESH')

    def execute(self, context):
        props = context.scene.pro_toolkit
        obj = context.active_object
        old = tuple(obj.dimensions)
        obj.dimensions = (props.creation_width,
                          props.creation_depth,
                          props.creation_height)
        context.view_layer.update()

        applied_note = ""
        if props.creation_apply_scale:
            if obj.data.users > 1:
                applied_note = " (scale NOT applied: multi-user mesh data)"
            else:
                bpy.ops.object.transform_apply(
                    location=False, rotation=False, scale=True)
                applied_note = " (scale applied)"
                print(f"[Pro Toolkit] Scale applied on '{obj.name}' after Set Dimensions")
        self.report(
            {'INFO'},
            f"{obj.name}: {old[0]:.2f}x{old[1]:.2f}x{old[2]:.2f} -> "
            f"{obj.dimensions.x:.2f}x{obj.dimensions.y:.2f}x{obj.dimensions.z:.2f} m"
            + applied_note)
        return {'FINISHED'}


class OBJECT_OT_pro_center_on_origin(bpy.types.Operator):
    """Move selected objects to the world center (X = 0, Y = 0), keeping their height"""
    bl_idname = "object.pro_center_on_origin"
    bl_label = "Center Object on Origin"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        objs = context.selected_objects
        if not objs:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}
        for obj in objs:
            obj.location.x = 0.0
            obj.location.y = 0.0
        self.report({'INFO'}, f"Centered {len(objs)} object(s) on world origin")
        return {'FINISHED'}


class OBJECT_OT_pro_align_to_world_grid(bpy.types.Operator):
    """Snap object locations to the world grid (and optionally rotation to 90 deg steps)"""
    bl_idname = "object.pro_align_to_world_grid"
    bl_label = "Align to World Grid"
    bl_options = {'REGISTER', 'UNDO'}

    grid: bpy.props.FloatProperty(
        name="Grid Step", default=0.1, min=0.001, soft_max=5.0, unit='LENGTH')
    snap_rotation: bpy.props.BoolProperty(
        name="Snap Rotation to 90°", default=False)

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        from math import pi
        objs = context.selected_objects
        if not objs:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}
        g = self.grid
        for obj in objs:
            obj.location = Vector((round(obj.location.x / g) * g,
                                   round(obj.location.y / g) * g,
                                   round(obj.location.z / g) * g))
            if self.snap_rotation:
                step = pi / 2.0
                eul = obj.rotation_euler
                eul.x = round(eul.x / step) * step
                eul.y = round(eul.y / step) * step
                eul.z = round(eul.z / step) * step
        self.report({'INFO'},
                    f"Snapped {len(objs)} object(s) to a {g:g} m grid")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  SNAP / MEASURE / SCALE
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_measure_object(bpy.types.Operator):
    """Measure the active object: dimensions, scale state and mesh stats"""
    bl_idname = "object.pro_measure_object"
    bl_label = "Measure Selected Object"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (_object_poll(context)
                and context.active_object.type == 'MESH')

    def execute(self, context):
        obj = context.active_object
        d, s = obj.dimensions, obj.scale
        uniform = all(abs(v - 1.0) < 1e-5 for v in s)
        me = obj.data
        print(f"[Pro Toolkit] Measure '{obj.name}': "
              f"dims {d.x:.3f} x {d.y:.3f} x {d.z:.3f} m | "
              f"scale ({s.x:.3f}, {s.y:.3f}, {s.z:.3f}) | "
              f"verts {len(me.vertices)} faces {len(me.polygons)}")
        self.report(
            {'INFO'} if uniform else {'WARNING'},
            f"{obj.name}: {d.x:.2f} x {d.y:.2f} x {d.z:.2f} m"
            + ("" if uniform else
               f" — scale is ({s.x:.2f}, {s.y:.2f}, {s.z:.2f}), consider Apply Scale"))
        return {'FINISHED'}


class OBJECT_OT_pro_report_dimensions(bpy.types.Operator):
    """Print the dimensions of every selected object to the console / Info log"""
    bl_idname = "object.pro_report_dimensions"
    bl_label = "Report Dimensions"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        objs = context.selected_objects
        if not objs:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}
        print(f"[Pro Toolkit] Dimensions report ({len(objs)} object(s)):")
        for obj in objs:
            d = obj.dimensions
            print(f"  - {obj.name}: {d.x:.3f} x {d.y:.3f} x {d.z:.3f} m")
        d = (context.active_object or objs[0]).dimensions
        self.report({'INFO'},
                    f"{len(objs)} object(s) reported to console — active: "
                    f"{d.x:.2f} x {d.y:.2f} x {d.z:.2f} m")
        return {'FINISHED'}


class OBJECT_OT_pro_set_real_world_scale(bpy.types.Operator):
    """Normalize to real-world scale: apply object scale so 1 BU = 1 m (reports the result)"""
    bl_idname = "object.pro_set_real_world_scale"
    bl_label = "Set Real World Scale"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        objs = _selected_meshes(context)
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        prev_active = context.view_layer.objects.active
        applied, skipped = 0, []
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objs:
            if obj.data.users > 1:
                skipped.append(obj.name)
                continue
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            d = obj.dimensions
            print(f"[Pro Toolkit] Real-world scale on '{obj.name}': "
                  f"{d.x:.3f} x {d.y:.3f} x {d.z:.3f} m (scale 1,1,1)")
            obj.select_set(False)
            applied += 1
        for o in objs:
            o.select_set(True)
        context.view_layer.objects.active = prev_active
        if skipped:
            self.report({'WARNING'},
                        f"Real-world scale on {applied} object(s). "
                        f"Skipped multi-user data: {', '.join(skipped)}")
        else:
            self.report({'INFO'},
                        f"Real-world scale on {applied} object(s) — scale applied")
        return {'FINISHED'}


class OBJECT_OT_pro_snap_selection_to_grid(bpy.types.Operator):
    """Snap the location of every selected object to a 10 cm grid"""
    bl_idname = "object.pro_snap_selection_to_grid"
    bl_label = "Snap Selection to Grid"
    bl_options = {'REGISTER', 'UNDO'}

    grid: bpy.props.FloatProperty(
        name="Grid Step", default=0.1, min=0.001, soft_max=5.0, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return _object_poll(context)

    def execute(self, context):
        return bpy.ops.object.pro_align_to_world_grid(grid=self.grid)


# ── Scale helper generators ─────────────────────────────────────────────

class _HelperOp:
    bl_options = {'REGISTER', 'UNDO'}
    pro_collection = cu.COLL_HELPERS

    @classmethod
    def poll(cls, context):
        return cu.object_mode_poll(context)


class OBJECT_OT_pro_create_grid_helper(_HelperOp, bpy.types.Operator):
    """Create a wire grid helper for layout snapping (1 m or 10 cm spacing)"""
    bl_idname = "object.pro_create_grid_helper"
    bl_label = "Create Grid Helper"

    spacing: bpy.props.EnumProperty(
        name="Spacing",
        items=(('M1', "1 m grid (10 x 10 m)", ""),
               ('CM10', "10 cm grid (2 x 2 m)", "")),
        default='M1')

    def execute(self, context):
        step, count = (1.0, 10) if self.spacing == 'M1' else (0.1, 20)
        size = step * count
        half = size / 2.0
        bm = bmesh.new()
        for i in range(count + 1):
            x = -half + i * step
            v1, v2 = bm.verts.new((x, -half, 0)), bm.verts.new((x, half, 0))
            bm.edges.new((v1, v2))
            v3, v4 = bm.verts.new((-half, x, 0)), bm.verts.new((half, x, 0))
            bm.edges.new((v3, v4))
        name = "PRO_Grid_1m" if self.spacing == 'M1' else "PRO_Grid_10cm"
        obj = cu.finalize_new_object(context, self, name, bm,
                                     cu.COLL_HELPERS, None, wire=True)
        obj.hide_render = True
        return {'FINISHED'}


class OBJECT_OT_pro_create_ruler(_HelperOp, bpy.types.Operator):
    """Create a 1 m measuring ruler with 10 cm notches"""
    bl_idname = "object.pro_create_ruler"
    bl_label = "Create Measuring Ruler"

    length: bpy.props.FloatProperty(name="Length", default=1.0, min=0.1, soft_max=10.0, unit='LENGTH')

    def execute(self, context):
        bm = bmesh.new()
        cu.add_box(bm, self.length, 0.05, 0.01)
        notches = int(round(self.length / 0.1))
        half = self.length / 2.0
        for i in range(notches + 1):
            x = -half + i * 0.1
            if x > half + 1e-6:
                break
            # Keep end notches inside the bar so the ruler stays exactly 1 m
            x = max(-half + 0.002, min(half - 0.002, x))
            cu.add_box(bm, 0.004, 0.05, 0.02, cx=x, z0=0.01)
        obj = cu.finalize_new_object(context, self, "PRO_Ruler_1m", bm,
                                     cu.COLL_HELPERS, "PRO_Blockout_Yellow")
        obj.hide_render = True
        return {'FINISHED'}


def build_player_reference(bm, height=1.78):
    """Simple human silhouette (boxes): shared by the generic and SF ops."""
    body_h = height * 0.84
    head_h = height - body_h
    cu.add_box(bm, 0.42, 0.24, body_h)                       # legs + torso
    cu.add_box(bm, 0.20, 0.22, head_h, z0=body_h)            # head
    cu.add_box(bm, 0.10, 0.20, 0.55, cx=-0.26, z0=body_h - 0.62)   # left arm
    cu.add_box(bm, 0.10, 0.20, 0.55, cx=0.26, z0=body_h - 0.62)    # right arm


class OBJECT_OT_pro_create_player_reference(_HelperOp, bpy.types.Operator):
    """Create a 1.78 m human scale reference (simple silhouette, not a character)"""
    bl_idname = "object.pro_create_player_reference"
    bl_label = "Player Scale Reference (1.78 m)"

    height: bpy.props.FloatProperty(name="Height", default=1.78, min=0.5, soft_max=2.5, unit='LENGTH')

    def execute(self, context):
        bm = bmesh.new()
        build_player_reference(bm, self.height)
        obj = cu.finalize_new_object(
            context, self, "PRO_Player_Reference", bm,
            cu.COLL_HELPERS, "PRO_Blockout_Green")
        obj.hide_render = True
        self.report({'INFO'},
                    f"PRO_Player_Reference created ({self.height:.2f} m tall)")
        return {'FINISHED'}


class OBJECT_OT_pro_create_door_reference(_HelperOp, bpy.types.Operator):
    """Create a wire door-size reference (0.90 x 2.10 m)"""
    bl_idname = "object.pro_create_door_reference"
    bl_label = "Door Scale Reference"

    def execute(self, context):
        bm = bmesh.new()
        cu.add_box(bm, 0.9, 0.05, 2.1)
        cu.delete_faces_keep_edges(bm)
        obj = cu.finalize_new_object(context, self, "PRO_Door_Reference", bm,
                                     cu.COLL_HELPERS, None, wire=True)
        obj.hide_render = True
        return {'FINISHED'}


class OBJECT_OT_pro_create_shelf_reference(_HelperOp, bpy.types.Operator):
    """Create a wire shelf-size reference (3.00 x 0.55 x 2.10 m)"""
    bl_idname = "object.pro_create_shelf_reference"
    bl_label = "Shelf Scale Reference"

    def execute(self, context):
        bm = bmesh.new()
        cu.add_box(bm, 3.0, 0.55, 2.1)
        cu.delete_faces_keep_edges(bm)
        obj = cu.finalize_new_object(context, self, "PRO_Shelf_Reference", bm,
                                     cu.COLL_HELPERS, None, wire=True)
        obj.hide_render = True
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_align_to_floor,
    OBJECT_OT_pro_apply_all_transforms_safe,
    OBJECT_OT_pro_set_dimensions,
    OBJECT_OT_pro_center_on_origin,
    OBJECT_OT_pro_align_to_world_grid,
    OBJECT_OT_pro_measure_object,
    OBJECT_OT_pro_report_dimensions,
    OBJECT_OT_pro_set_real_world_scale,
    OBJECT_OT_pro_snap_selection_to_grid,
    OBJECT_OT_pro_create_grid_helper,
    OBJECT_OT_pro_create_ruler,
    OBJECT_OT_pro_create_player_reference,
    OBJECT_OT_pro_create_door_reference,
    OBJECT_OT_pro_create_shelf_reference,
)
