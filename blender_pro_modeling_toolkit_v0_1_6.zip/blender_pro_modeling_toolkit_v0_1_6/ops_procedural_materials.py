# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_procedural_materials.py
# v0.1.6 — Procedural material presets: light, image-free, ordered
# node names, reasonable in EEVEE and Cycles (Principled-based).
# Includes the Supermarket Flower (SF_) project presets.
#
# Materials are spec-driven: one builder, one spec dict per preset.
# Nothing on the object is replaced unless Apply to Selected is used.
# ──────────────────────────────────────────────────────────────────────

import bpy

from . import material_utils as mu
from . import node_utils

# spec keys:
#   color, color2          base / secondary RGBA
#   rough, metal, alpha    principled scalars
#   pattern                None|'NOISE'|'BRICK'|'CHECKER'|'WAVE'|'VORONOI'
#   pattern_scale          texture scale
#   pattern_to             'COLOR'|'ROUGH'|'BOTH'
#   bump                   noise bump strength (0 = off)
#   bump_scale             noise scale for the bump
#   emission               flat emission color (ID/debug style) — overrides all
PRESETS = {
    # ── PRO generic set ──────────────────────────────────────────
    'PRO_Mat_Plastic_Black':  dict(color=(0.02, 0.02, 0.02, 1), rough=0.35),
    'PRO_Mat_Plastic_White':  dict(color=(0.92, 0.92, 0.92, 1), rough=0.3),
    'PRO_Mat_Rubber_Dark':    dict(color=(0.03, 0.03, 0.035, 1), rough=0.85,
                                   bump=0.08, bump_scale=180.0),
    'PRO_Mat_Metal_Brushed':  dict(color=(0.65, 0.66, 0.68, 1), rough=0.32,
                                   metal=1.0, pattern='WAVE',
                                   pattern_scale=160.0, pattern_to='ROUGH'),
    'PRO_Mat_Metal_Dark':     dict(color=(0.18, 0.19, 0.21, 1), rough=0.45,
                                   metal=1.0),
    'PRO_Mat_Cardboard':      dict(color=(0.45, 0.30, 0.16, 1), rough=0.9,
                                   pattern='NOISE', pattern_scale=24.0,
                                   pattern_to='COLOR',
                                   color2=(0.38, 0.24, 0.12, 1),
                                   bump=0.05, bump_scale=90.0),
    'PRO_Mat_Glass_Fake':     dict(color=(0.8, 0.9, 1.0, 1), rough=0.05,
                                   alpha=0.12),
    'PRO_Mat_Tile_Floor':     dict(color=(0.85, 0.85, 0.82, 1),
                                   color2=(0.55, 0.55, 0.52, 1), rough=0.25,
                                   pattern='BRICK', pattern_scale=4.0,
                                   pattern_to='COLOR', bump=0.06,
                                   bump_scale=4.0),
    'PRO_Mat_Concrete':       dict(color=(0.55, 0.54, 0.52, 1), rough=0.95,
                                   pattern='NOISE', pattern_scale=8.0,
                                   pattern_to='BOTH',
                                   color2=(0.42, 0.41, 0.40, 1),
                                   bump=0.15, bump_scale=14.0),
    'PRO_Mat_Painted_Wall':   dict(color=(0.88, 0.86, 0.80, 1), rough=0.7,
                                   bump=0.03, bump_scale=60.0),
    'PRO_Mat_Product_Box':    dict(color=(0.85, 0.78, 0.62, 1), rough=0.65,
                                   pattern='NOISE', pattern_scale=40.0,
                                   pattern_to='ROUGH'),
    'PRO_Mat_Label_Paper':    dict(color=(0.96, 0.95, 0.92, 1), rough=0.55),
    'PRO_Mat_Organic_Clay':   dict(color=(0.62, 0.45, 0.38, 1), rough=0.8,
                                   bump=0.1, bump_scale=30.0),
    'PRO_Mat_Retopo_Blue':    dict(color=(0.1, 0.35, 0.9, 1), rough=0.9),
    'PRO_Mat_Bake_Cage':      dict(color=(0.1, 0.6, 0.9, 1), rough=0.5,
                                   alpha=0.25),
    'PRO_Mat_Color_ID':       dict(emission=(1.0, 0.2, 0.2, 1)),
    # ── Supermarket Flower project (SF_) ─────────────────────────
    'SF_Mat_Shelf_Metal':     dict(color=(0.75, 0.76, 0.78, 1), rough=0.35,
                                   metal=1.0, pattern='WAVE',
                                   pattern_scale=120.0, pattern_to='ROUGH'),
    'SF_Mat_Fridge_Plastic':  dict(color=(0.9, 0.91, 0.93, 1), rough=0.4),
    'SF_Mat_Fridge_Glass_Fake': dict(color=(0.75, 0.88, 0.95, 1), rough=0.04,
                                     alpha=0.10),
    'SF_Mat_Floor_Tile':      dict(color=(0.82, 0.82, 0.78, 1),
                                   color2=(0.6, 0.6, 0.56, 1), rough=0.2,
                                   pattern='CHECKER', pattern_scale=6.0,
                                   pattern_to='COLOR'),
    'SF_Mat_Wall_Paint':      dict(color=(0.85, 0.88, 0.84, 1), rough=0.75,
                                   bump=0.02, bump_scale=50.0),
    'SF_Mat_Cardboard_Box':   dict(color=(0.43, 0.28, 0.15, 1), rough=0.9,
                                   pattern='NOISE', pattern_scale=26.0,
                                   pattern_to='COLOR',
                                   color2=(0.36, 0.22, 0.11, 1),
                                   bump=0.05, bump_scale=80.0),
    'SF_Mat_Product_Label':   dict(color=(0.95, 0.93, 0.88, 1), rough=0.5),
    'SF_Mat_Rubber_Black':    dict(color=(0.02, 0.02, 0.02, 1), rough=0.9,
                                   bump=0.06, bump_scale=150.0),
    'SF_Mat_Checkout_Belt':   dict(color=(0.05, 0.05, 0.06, 1), rough=0.6,
                                   pattern='WAVE', pattern_scale=80.0,
                                   pattern_to='ROUGH', bump=0.08,
                                   bump_scale=80.0),
    'SF_Mat_Organic_Flower':  dict(color=(0.75, 0.2, 0.45, 1), rough=0.55,
                                   pattern='VORONOI', pattern_scale=12.0,
                                   pattern_to='COLOR',
                                   color2=(0.55, 0.1, 0.3, 1),
                                   bump=0.08, bump_scale=20.0),
    'SF_Mat_Horror_DarkLeaf': dict(color=(0.05, 0.10, 0.05, 1), rough=0.5,
                                   pattern='VORONOI', pattern_scale=18.0,
                                   pattern_to='BOTH',
                                   color2=(0.02, 0.04, 0.02, 1),
                                   bump=0.12, bump_scale=25.0),
    'SF_Mat_BloodSap_Dark':   dict(color=(0.12, 0.01, 0.02, 1), rough=0.15,
                                   pattern='NOISE', pattern_scale=10.0,
                                   pattern_to='ROUGH',
                                   bump=0.05, bump_scale=15.0),
}

PRESET_ENUM = [(k, k.replace("PRO_Mat_", "").replace("SF_Mat_", "SF · ")
                .replace("_", " "), "")
               for k in PRESETS]


def build_procedural_material(preset):
    """Build (or rebuild) the preset material. Light by design: one
    Principled, at most one pattern texture and one bump noise."""
    spec = PRESETS[preset]
    if spec.get("emission"):
        return mu.build_id_material(preset, spec["emission"])

    mat = node_utils.fresh_material(preset)
    nt = mat.node_tree
    nodes, links = nt.nodes, nt.links

    out = node_utils.add_node(nodes, 'ShaderNodeOutputMaterial',
                              "PRO Output", (300, 0))
    bsdf = node_utils.add_node(nodes, 'ShaderNodeBsdfPrincipled',
                               "PRO Shader", (0, 0))
    links.new(bsdf.outputs[0], out.inputs['Surface'])

    color = spec.get("color", (0.8, 0.8, 0.8, 1))
    bsdf.inputs['Base Color'].default_value = color
    bsdf.inputs['Roughness'].default_value = spec.get("rough", 0.5)
    bsdf.inputs['Metallic'].default_value = spec.get("metal", 0.0)
    alpha = spec.get("alpha", 1.0)
    if alpha < 1.0 and 'Alpha' in bsdf.inputs:
        bsdf.inputs['Alpha'].default_value = alpha
        if hasattr(mat, "blend_method"):
            mat.blend_method = 'BLEND'
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = 'BLENDED'

    coords = None

    def get_coords():
        nonlocal coords
        if coords is None:
            coords = node_utils.add_node(nodes, 'ShaderNodeTexCoord',
                                         "PRO Coords", (-1100, 0))
        return coords

    pattern = spec.get("pattern")
    if pattern:
        scale = spec.get("pattern_scale", 10.0)
        if pattern == 'NOISE':
            tex = node_utils.add_node(nodes, 'ShaderNodeTexNoise',
                                      "PRO Pattern", (-800, 150))
            tex.inputs['Scale'].default_value = scale
            fac_out = tex.outputs['Fac']
        elif pattern == 'VORONOI':
            tex = node_utils.add_node(nodes, 'ShaderNodeTexVoronoi',
                                      "PRO Pattern", (-800, 150))
            tex.inputs['Scale'].default_value = scale
            fac_out = tex.outputs['Distance']
        elif pattern == 'WAVE':
            tex = node_utils.add_node(nodes, 'ShaderNodeTexWave',
                                      "PRO Pattern", (-800, 150))
            tex.inputs['Scale'].default_value = scale
            tex.inputs['Distortion'].default_value = 4.0
            fac_out = tex.outputs['Fac']
        elif pattern == 'CHECKER':
            tex = node_utils.add_node(nodes, 'ShaderNodeTexChecker',
                                      "PRO Pattern", (-800, 150))
            tex.inputs['Scale'].default_value = scale
            fac_out = tex.outputs['Fac']
        else:  # BRICK
            tex = node_utils.add_node(nodes, 'ShaderNodeTexBrick',
                                      "PRO Pattern", (-800, 150))
            tex.inputs['Scale'].default_value = scale
            tex.inputs['Mortar Size'].default_value = 0.012
            fac_out = tex.outputs['Fac']
        links.new(get_coords().outputs['Object'], tex.inputs['Vector'])

        to = spec.get("pattern_to", 'COLOR')
        if to in ('COLOR', 'BOTH') and spec.get("color2"):
            mix = node_utils.add_node(nodes, 'ShaderNodeMix',
                                      "PRO Color Mix", (-420, 150))
            mix.data_type = 'RGBA'
            mix.inputs[6].default_value = color
            mix.inputs[7].default_value = spec["color2"]
            links.new(fac_out, mix.inputs['Factor'])
            links.new(mix.outputs[2], bsdf.inputs['Base Color'])
        if to in ('ROUGH', 'BOTH'):
            rng = node_utils.add_node(nodes, 'ShaderNodeMapRange',
                                      "PRO Rough Range", (-420, -120))
            base_r = spec.get("rough", 0.5)
            rng.inputs['To Min'].default_value = max(0.0, base_r - 0.15)
            rng.inputs['To Max'].default_value = min(1.0, base_r + 0.15)
            links.new(fac_out, rng.inputs['Value'])
            links.new(rng.outputs['Result'], bsdf.inputs['Roughness'])

    if spec.get("bump", 0.0) > 0.0:
        n_noise = node_utils.add_node(nodes, 'ShaderNodeTexNoise',
                                      "PRO Bump Noise", (-800, -400))
        n_noise.inputs['Scale'].default_value = spec.get("bump_scale", 50.0)
        links.new(get_coords().outputs['Object'], n_noise.inputs['Vector'])
        n_bump = node_utils.add_node(nodes, 'ShaderNodeBump',
                                     "PRO Bump", (-420, -400))
        n_bump.inputs['Strength'].default_value = spec["bump"]
        links.new(n_noise.outputs['Fac'], n_bump.inputs['Height'])
        links.new(n_bump.outputs['Normal'], bsdf.inputs['Normal'])

    mat.diffuse_color = color
    return mat


class MATERIAL_OT_pro_proc_create(bpy.types.Operator):
    """Create (or rebuild) the chosen procedural preset material; it is
    stored with fake user and NOT applied to anything"""
    bl_idname = "material.pro_proc_create"
    bl_label = "Create Procedural Material"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(name="Preset", items=PRESET_ENUM)

    def execute(self, context):
        mat = build_procedural_material(self.preset)
        mat.use_fake_user = True
        self.report({'INFO'}, f"'{mat.name}' creado/actualizado (fake user).")
        return {'FINISHED'}


class MATERIAL_OT_pro_proc_apply(bpy.types.Operator):
    """Apply the panel's procedural preset to the selected objects.
    Replaced materials keep a fake user (nothing is lost)"""
    bl_idname = "material.pro_proc_apply"
    bl_label = "Apply Procedural Material to Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        props = context.scene.pro_toolkit
        preset = props.procedural_material_preset
        mat = build_procedural_material(preset)
        mat.use_fake_user = True
        n = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            for slot in obj.material_slots:
                if slot.material is not None:
                    slot.material.use_fake_user = True
            if props.procedural_replace_slots or not obj.material_slots:
                obj.data.materials.clear()
                obj.data.materials.append(mat)
            else:
                obj.data.materials.append(mat)
                obj.active_material_index = len(obj.material_slots) - 1
            n += 1
        mode = "reemplazando slots" if props.procedural_replace_slots \
            else "añadido como slot nuevo"
        self.report({'INFO'},
                    f"'{preset}' aplicado a {n} objeto(s) ({mode}; "
                    "originales con fake user).")
        return {'FINISHED'}


class MATERIAL_OT_pro_proc_create_all_sf(bpy.types.Operator):
    """Create the full Supermarket Flower SF_Mat_* preset library
    (12 materials, fake user, nothing applied)"""
    bl_idname = "material.pro_proc_create_all_sf"
    bl_label = "Create All SF Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = 0
        for key in PRESETS:
            if key.startswith("SF_Mat_"):
                build_procedural_material(key).use_fake_user = True
                n += 1
        self.report({'INFO'}, f"{n} materiales SF creados/actualizados.")
        return {'FINISHED'}


classes = (
    MATERIAL_OT_pro_proc_create,
    MATERIAL_OT_pro_proc_apply,
    MATERIAL_OT_pro_proc_create_all_sf,
)
