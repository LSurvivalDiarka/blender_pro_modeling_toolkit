# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  node_utils.py
# Node-graph builders: cel/toon materials (EEVEE branch + Cycles branch),
# UV checker materials, outline material. All nodes are our own.
#
# v0.1.2.1 — TEXTURE PRESERVING ARCHITECTURE:
#   The cel builder now accepts a base source (image texture, normal map,
#   roughness map) detected from an existing material. Shadows are applied
#   by TINTING the base (multiply) instead of replacing it with a flat
#   color, so existing textures stay visible under the toon bands.
#
# Every cel material has TWO Material Outputs:
#   "PRO Output EEVEE"  (target=EEVEE)  ← Shader to RGB + ColorRamp ramps
#   "PRO Output Cycles" (target=CYCLES) ← Toon BSDF fallback
# so the material is never broken regardless of render engine.
# ──────────────────────────────────────────────────────────────────────

import bpy

OUTLINE_MATERIAL = "PRO_Outline_Black"

CHECKER_MATERIALS = {
    'GRID': "PRO_UV_Checker_Grid",
    'COLOR': "PRO_UV_Checker_Color",
    'DISTORTION': "PRO_UV_Checker_Distortion",
    'DENSITY': "PRO_UV_TexelDensity_Debug",
}


# ═══════════════════════════════════════════════════════════════════════
#  LOW-LEVEL HELPERS
# ═══════════════════════════════════════════════════════════════════════

def fresh_material(name):
    """Get-or-create material *name* with an empty node tree."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.node_tree.nodes.clear()
    return mat


def add_node(nodes, node_type, name, location, label=None):
    node = nodes.new(node_type)
    node.name = name
    node.label = label or name
    node.location = location
    return node


def assign_material(obj, mat):
    """Replace all material slots of *obj* with *mat*.
    Only used for objects without materials or in explicit Replace mode."""
    if obj.type != 'MESH':
        return False
    obj.data.materials.clear()
    obj.data.materials.append(mat)
    return True


def get_base_color(mat):
    """Best-effort base color of an existing material (RGBA tuple)."""
    return detect_base_color_source(mat)["base_color"]


# ═══════════════════════════════════════════════════════════════════════
#  MATERIAL SOURCE DETECTION  (v0.1.2.1)
# ═══════════════════════════════════════════════════════════════════════

def _follow_to_image(socket, max_depth=8):
    """Walk upstream from an *input* socket looking for an Image Texture."""
    stack = [(socket, 0)]
    seen = set()
    while stack:
        sock, depth = stack.pop()
        if depth > max_depth:
            continue
        for link in sock.links:
            node = link.from_node
            if node in seen:
                continue
            seen.add(node)
            if node.type == 'TEX_IMAGE' and node.image is not None:
                return node
            for inp in node.inputs:
                if inp.is_linked:
                    stack.append((inp, depth + 1))
    return None


def detect_base_color_source(material):
    """Inspect *material* and return its base-color source.

    Returns dict:
      base_texture_image  (bpy.types.Image or None)
      base_color          (RGBA tuple)
      has_texture         (bool)
      source_node         (the Image Texture node found, or None)
    Search order: Principled Base Color link (direct or indirect) ->
    Principled default value -> our own "PRO Base Color" RGB node ->
    own "PRO Base Texture" -> first color-space image in the tree ->
    viewport diffuse color.
    """
    info = {"base_texture_image": None,
            "base_color": (0.8, 0.8, 0.8, 1.0),
            "has_texture": False,
            "source_node": None}
    if material is None:
        return info
    info["base_color"] = tuple(material.diffuse_color)
    if not material.use_nodes or material.node_tree is None:
        return info

    nt = material.node_tree
    principled = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if principled is not None:
        inp = principled.inputs.get("Base Color")
        if inp is not None:
            if inp.is_linked:
                tex = _follow_to_image(inp)
                if tex is not None:
                    info.update(base_texture_image=tex.image, has_texture=True,
                                source_node=tex)
                    return info
            info["base_color"] = tuple(inp.default_value)
            return info

    rgb = nt.nodes.get("PRO Base Color")
    if rgb is not None and rgb.type == 'RGB':
        info["base_color"] = tuple(rgb.outputs[0].default_value)

    own = nt.nodes.get("PRO Base Texture")
    if own is not None and own.type == 'TEX_IMAGE' and own.image:
        info.update(base_texture_image=own.image, has_texture=True,
                    source_node=own)
        return info
    for node in nt.nodes:
        if (node.type == 'TEX_IMAGE' and node.image is not None
                and node.image.colorspace_settings.name != 'Non-Color'):
            info.update(base_texture_image=node.image, has_texture=True,
                        source_node=node)
            return info
    return info


def find_normal_image(material):
    """Image plugged into a Normal Map node feeding the material, or None."""
    if material is None or not material.use_nodes:
        return None
    for node in material.node_tree.nodes:
        if node.type == 'NORMAL_MAP':
            tex = _follow_to_image(node.inputs['Color'])
            if tex is not None:
                return tex.image
    own = material.node_tree.nodes.get("PRO Normal Texture")
    if own is not None and own.type == 'TEX_IMAGE':
        return own.image
    return None


def find_roughness_image(material):
    """Image feeding the Principled Roughness input, or None."""
    if material is None or not material.use_nodes:
        return None
    principled = next((n for n in material.node_tree.nodes
                       if n.type == 'BSDF_PRINCIPLED'), None)
    if principled is not None:
        inp = principled.inputs.get("Roughness")
        if inp is not None and inp.is_linked:
            tex = _follow_to_image(inp)
            if tex is not None:
                return tex.image
    own = material.node_tree.nodes.get("PRO Roughness Texture")
    if own is not None and own.type == 'TEX_IMAGE':
        return own.image
    return None


# ═══════════════════════════════════════════════════════════════════════
#  CEL / TOON MATERIAL BUILDER  (texture-preserving core)
# ═══════════════════════════════════════════════════════════════════════

def _build_cel(name, p, base_image=None, normal_image=None, rough_image=None):
    """Core cel builder. If *base_image* is given the texture drives the
    base color and shadows TINT it (multiply); otherwise a flat RGB node
    is used. Normal/roughness images are rewired into the light sources
    so the cel bands actually respond to them."""
    base = tuple(p.get("base_color", (0.8, 0.8, 0.8, 1.0)))
    shadow = tuple(p.get("shadow_color", (0.2, 0.2, 0.25, 1.0)))
    highlight = p.get("highlight_color")
    threshold = p.get("threshold", 0.5)
    bands = p.get("bands", 2)
    softness = p.get("softness", 0.0)
    emission_strength = p.get("emission_strength", 1.0)
    posterize = p.get("posterize_levels")
    halftone = p.get("halftone", False)

    mat = fresh_material(name)
    nt = mat.node_tree
    nodes, links = nt.nodes, nt.links

    # ── Base color source: texture or flat color ────────────────
    if base_image is not None:
        n_tex = add_node(nodes, 'ShaderNodeTexImage', "PRO Base Texture", (-2050, 380))
        n_tex.image = base_image
        base_socket = n_tex.outputs['Color']
        # Optional color correction (saturation/value boost per preset)
        n_hsv = add_node(nodes, 'ShaderNodeHueSaturation', "PRO Color Boost", (-1800, 380))
        n_hsv.inputs['Saturation'].default_value = p.get("saturation", 1.0)
        n_hsv.inputs['Value'].default_value = p.get("value_boost", 1.0)
        links.new(base_socket, n_hsv.inputs['Color'])
        base_socket = n_hsv.outputs['Color']
    else:
        n_base = add_node(nodes, 'ShaderNodeRGB', "PRO Base Color", (-1800, 380))
        n_base.outputs[0].default_value = base
        base_socket = n_base.outputs[0]

    n_shadow_col = add_node(nodes, 'ShaderNodeRGB', "PRO Shadow Color", (-1800, 120))
    n_shadow_col.outputs[0].default_value = shadow

    # Shadowed base = base TINTED by shadow color (texture survives).
    # shadow_density < 1 keeps texture detail readable inside shadows.
    n_shadowed = add_node(nodes, 'ShaderNodeMix', "PRO Shadow Tint", (-1500, 260))
    n_shadowed.data_type = 'RGBA'
    n_shadowed.blend_type = 'MULTIPLY'
    n_shadowed.inputs['Factor'].default_value = p.get("shadow_density", 0.92)
    links.new(base_socket, n_shadowed.inputs[6])
    links.new(n_shadow_col.outputs[0], n_shadowed.inputs[7])

    # ── Optional normal map (drives the cel bands) ───────────────
    normal_socket = None
    if normal_image is not None:
        n_ntex = add_node(nodes, 'ShaderNodeTexImage', "PRO Normal Texture", (-1800, -650))
        n_ntex.image = normal_image
        if n_ntex.image is not None:
            n_ntex.image.colorspace_settings.name = 'Non-Color'
        n_nmap = add_node(nodes, 'ShaderNodeNormalMap', "PRO Normal Map", (-1550, -650))
        links.new(n_ntex.outputs['Color'], n_nmap.inputs['Color'])
        normal_socket = n_nmap.outputs['Normal']

    # ── Light capture (EEVEE branch) ─────────────────────────────
    n_diff = add_node(nodes, 'ShaderNodeBsdfDiffuse', "PRO Light Source", (-1500, -180))
    if normal_socket is not None:
        links.new(normal_socket, n_diff.inputs['Normal'])
    n_s2rgb = add_node(nodes, 'ShaderNodeShaderToRGB', "PRO Shader to RGB", (-1300, -180))
    links.new(n_diff.outputs[0], n_s2rgb.inputs[0])

    # ── Shadow ramp (grayscale bands / posterize levels) ─────────
    n_ramp = add_node(nodes, 'ShaderNodeValToRGB', "PRO Shadow Ramp", (-1100, -120))
    ramp = n_ramp.color_ramp
    ramp.interpolation = 'CONSTANT' if softness <= 0.001 else 'LINEAR'
    links.new(n_s2rgb.outputs[0], n_ramp.inputs['Fac'])

    x = -800
    if posterize:
        levels = max(3, int(posterize))
        while len(ramp.elements) < levels:
            ramp.elements.new(0.5)
        for i, el in enumerate(ramp.elements):
            t = i / (levels - 1)
            el.position = min(0.999, t * 0.85)
            v = 0.15 + 0.85 * t
            el.color = (v, v, v, 1)
        # quantized light x base color/texture
        n_mul = add_node(nodes, 'ShaderNodeMix', "PRO Posterize Mix", (x, 60))
        n_mul.data_type = 'RGBA'
        n_mul.blend_type = 'MULTIPLY'
        n_mul.inputs['Factor'].default_value = 1.0
        links.new(base_socket, n_mul.inputs[6])
        links.new(n_ramp.outputs['Color'], n_mul.inputs[7])
        current = n_mul.outputs[2]
        x += 200
    else:
        els = ramp.elements
        els[0].position = 0.0
        els[0].color = (0, 0, 0, 1)
        if bands >= 3:
            mid = els.new(max(0.02, threshold * 0.55))
            mid.color = (0.5, 0.5, 0.5, 1)
        last = els[-1] if len(els) == 2 else els.new(threshold)
        last.position = min(0.999, threshold)
        last.color = (1, 1, 1, 1)
        if softness > 0.001:
            for el in els[1:]:
                el.position = min(0.999, max(0.0, el.position - softness * 0.5))

        # lit/shadow band mix: A = tinted base, B = full base
        n_mix = add_node(nodes, 'ShaderNodeMix', "PRO Shadow Mix", (x, 60))
        n_mix.data_type = 'RGBA'
        links.new(n_ramp.outputs['Color'], n_mix.inputs['Factor'])
        links.new(n_shadowed.outputs[2], n_mix.inputs[6])
        links.new(base_socket, n_mix.inputs[7])
        current = n_mix.outputs[2]
        x += 200

        # ── Highlight band (additive, keeps texture) ─────────────
        if highlight is not None:
            n_hl_col = add_node(nodes, 'ShaderNodeRGB', "PRO Highlight Color", (-1800, -380))
            n_hl_col.outputs[0].default_value = tuple(highlight)
            n_hl_ramp = add_node(nodes, 'ShaderNodeValToRGB', "PRO Highlight Control", (-1100, -400))
            n_hl_ramp.color_ramp.interpolation = 'CONSTANT'
            n_hl_ramp.color_ramp.elements[0].position = 0.0
            n_hl_ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
            n_hl_ramp.color_ramp.elements[1].position = min(0.999, p.get("highlight_threshold", 0.8))
            n_hl_ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
            links.new(n_s2rgb.outputs[0], n_hl_ramp.inputs['Fac'])
            n_hl_mix = add_node(nodes, 'ShaderNodeMix', "PRO Highlight Mix", (x, -40))
            n_hl_mix.data_type = 'RGBA'
            n_hl_mix.blend_type = 'SCREEN'   # capped: never burns the texture
            links.new(n_hl_ramp.outputs['Color'], n_hl_mix.inputs['Factor'])
            links.new(current, n_hl_mix.inputs[6])
            links.new(n_hl_col.outputs[0], n_hl_mix.inputs[7])
            current = n_hl_mix.outputs[2]
            x += 200

    # ── Specular (additive; reuses roughness map if available) ───
    if p.get("specular"):
        n_gloss = add_node(nodes, 'ShaderNodeBsdfGlossy', "PRO Specular Source", (-1500, -880))
        n_gloss.inputs['Roughness'].default_value = p.get("specular_size", 0.15)
        if rough_image is not None:
            n_rtex = add_node(nodes, 'ShaderNodeTexImage', "PRO Roughness Texture", (-1800, -880))
            n_rtex.image = rough_image
            if n_rtex.image is not None:
                n_rtex.image.colorspace_settings.name = 'Non-Color'
            links.new(n_rtex.outputs['Color'], n_gloss.inputs['Roughness'])
        if normal_socket is not None:
            links.new(normal_socket, n_gloss.inputs['Normal'])
        n_g2rgb = add_node(nodes, 'ShaderNodeShaderToRGB', "PRO Specular to RGB", (-1300, -880))
        links.new(n_gloss.outputs[0], n_g2rgb.inputs[0])
        n_sp_ramp = add_node(nodes, 'ShaderNodeValToRGB', "PRO Specular Ramp", (-1100, -880))
        n_sp_ramp.color_ramp.interpolation = 'CONSTANT'
        n_sp_ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
        n_sp_ramp.color_ramp.elements[1].position = 0.7
        n_sp_ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
        links.new(n_g2rgb.outputs[0], n_sp_ramp.inputs['Fac'])
        n_sp_mix = add_node(nodes, 'ShaderNodeMix', "PRO Specular Mix", (x, -160))
        n_sp_mix.data_type = 'RGBA'
        n_sp_mix.blend_type = 'SCREEN'   # capped highlight pop
        links.new(n_sp_ramp.outputs['Color'], n_sp_mix.inputs['Factor'])
        links.new(current, n_sp_mix.inputs[6])
        n_sp_mix.inputs[7].default_value = tuple(p.get("specular_color", (1, 1, 1, 1)))
        current = n_sp_mix.outputs[2]
        x += 200

    # ── Rim light (additive) ─────────────────────────────────────
    if p.get("rim"):
        n_rim_col = add_node(nodes, 'ShaderNodeRGB', "PRO Rim Color", (-1800, -1130))
        n_rim_col.outputs[0].default_value = tuple(p.get("rim_color", (1, 1, 1, 1)))
        n_lw = add_node(nodes, 'ShaderNodeLayerWeight', "PRO Rim Source", (-1500, -1130))
        n_lw.inputs['Blend'].default_value = p.get("rim_size", 0.35)
        n_rim_ramp = add_node(nodes, 'ShaderNodeValToRGB', "PRO Rim Ramp", (-1300, -1130))
        n_rim_ramp.color_ramp.interpolation = 'CONSTANT'
        n_rim_ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
        n_rim_ramp.color_ramp.elements[1].position = 0.65
        n_rim_ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
        links.new(n_lw.outputs['Facing'], n_rim_ramp.inputs['Fac'])
        n_rim_str = add_node(nodes, 'ShaderNodeMath', "PRO Rim Strength", (-1100, -1130))
        n_rim_str.operation = 'MULTIPLY'
        links.new(n_rim_ramp.outputs['Color'], n_rim_str.inputs[0])
        n_rim_str.inputs[1].default_value = p.get("rim_strength", 0.6)
        n_rim_mix = add_node(nodes, 'ShaderNodeMix', "PRO Rim Light", (x, -280))
        n_rim_mix.data_type = 'RGBA'
        n_rim_mix.blend_type = 'SCREEN'   # rim glow without burning the texture
        links.new(n_rim_str.outputs[0], n_rim_mix.inputs['Factor'])
        links.new(current, n_rim_mix.inputs[6])
        links.new(n_rim_col.outputs[0], n_rim_mix.inputs[7])
        current = n_rim_mix.outputs[2]
        x += 200

    # ── Halftone dots (ink = shadow-tinted base, keeps texture) ──
    if halftone:
        n_tc = add_node(nodes, 'ShaderNodeTexCoord', "PRO Screen Coords", (-1800, -1400))
        n_map = add_node(nodes, 'ShaderNodeMapping', "PRO Dot Scale", (-1550, -1400))
        s = p.get("halftone_scale", 80.0)
        n_map.inputs['Scale'].default_value = (s, s, s)
        links.new(n_tc.outputs['Window'], n_map.inputs['Vector'])
        n_vor = add_node(nodes, 'ShaderNodeTexVoronoi', "PRO Dot Pattern", (-1300, -1400))
        links.new(n_map.outputs['Vector'], n_vor.inputs['Vector'])
        n_inv = add_node(nodes, 'ShaderNodeMath', "PRO Dot Size", (-1100, -1400))
        n_inv.operation = 'SUBTRACT'
        n_inv.inputs[0].default_value = 0.62
        links.new(n_s2rgb.outputs[0], n_inv.inputs[1])
        n_lt = add_node(nodes, 'ShaderNodeMath', "PRO Dot Mask", (-950, -1400))
        n_lt.operation = 'LESS_THAN'
        links.new(n_vor.outputs['Distance'], n_lt.inputs[0])
        links.new(n_inv.outputs[0], n_lt.inputs[1])
        n_ht_mix = add_node(nodes, 'ShaderNodeMix', "PRO Halftone Mix", (x, -400))
        n_ht_mix.data_type = 'RGBA'
        links.new(n_lt.outputs[0], n_ht_mix.inputs['Factor'])
        links.new(current, n_ht_mix.inputs[6])
        links.new(n_shadowed.outputs[2], n_ht_mix.inputs[7])
        current = n_ht_mix.outputs[2]
        x += 200

    # ── EEVEE output ─────────────────────────────────────────────
    # Pure cel = Emission. Presets with pbr_mix > 0 blend in a Principled
    # layer (real speculars + normal/roughness response) for a richer,
    # "stylized PBR" finish that still reads as toon.
    n_emit = add_node(nodes, 'ShaderNodeEmission', "PRO Output Shader", (x, 40))
    n_emit.inputs['Strength'].default_value = emission_strength
    links.new(current, n_emit.inputs['Color'])

    pbr_mix = p.get("pbr_mix", 0.0)
    if pbr_mix > 0.001:
        n_pbr = add_node(nodes, 'ShaderNodeBsdfPrincipled', "PRO PBR Shader", (x, -280))
        links.new(current, n_pbr.inputs['Base Color'])
        n_pbr.inputs['Roughness'].default_value = p.get("pbr_roughness", 0.45)
        rt = nodes.get("PRO Roughness Texture")
        if rt is None and rough_image is not None:
            rt = add_node(nodes, 'ShaderNodeTexImage', "PRO Roughness Texture", (-2050, -880))
            rt.image = rough_image
            if rt.image is not None:
                rt.image.colorspace_settings.name = 'Non-Color'
        if rt is not None:
            links.new(rt.outputs['Color'], n_pbr.inputs['Roughness'])
        if normal_socket is not None:
            links.new(normal_socket, n_pbr.inputs['Normal'])
        n_blend = add_node(nodes, 'ShaderNodeMixShader', "PRO Shader Blend", (x + 220, 40))
        n_blend.inputs['Fac'].default_value = pbr_mix
        links.new(n_emit.outputs[0], n_blend.inputs[1])
        links.new(n_pbr.outputs[0], n_blend.inputs[2])
        eevee_shader_out = n_blend.outputs[0]
        out_x = x + 440
    else:
        eevee_shader_out = n_emit.outputs[0]
        out_x = x + 220

    n_out_e = add_node(nodes, 'ShaderNodeOutputMaterial', "PRO Output EEVEE", (out_x, 40))
    n_out_e.target = 'EEVEE'
    links.new(eevee_shader_out, n_out_e.inputs['Surface'])

    # ── Cycles fallback branch (Toon BSDF, texture kept) ─────────
    n_toon = add_node(nodes, 'ShaderNodeBsdfToon', "PRO Toon BSDF (Cycles)", (x, -700))
    links.new(base_socket, n_toon.inputs['Color'])
    if normal_socket is not None:
        links.new(normal_socket, n_toon.inputs['Normal'])
    n_toon.inputs['Size'].default_value = p.get("toon_size", 0.7)
    n_toon.inputs['Smooth'].default_value = p.get("toon_smooth", 0.0)
    n_out_c = add_node(nodes, 'ShaderNodeOutputMaterial', "PRO Output Cycles", (x + 220, -700))
    n_out_c.target = 'CYCLES'
    links.new(n_toon.outputs[0], n_out_c.inputs['Surface'])

    mat.diffuse_color = base
    return mat


def build_cel_material(name, p):
    """Flat-color cel material (objects without textures / Replace mode)."""
    return _build_cel(name, p)


def build_texture_preserving_toon_material(orig_mat, name, p,
                                           preserve_texture=True):
    """Build a toon material from *orig_mat* keeping its textures.

    Detects base color texture, normal map and roughness map and rebuilds
    the cel graph around them. The original material is NOT modified.
    Returns (material, info_dict) where info_dict reports what was kept.
    """
    src = detect_base_color_source(orig_mat)
    p2 = dict(p)
    p2["base_color"] = src["base_color"]

    base_image = src["base_texture_image"] if preserve_texture else None
    normal_image = find_normal_image(orig_mat) if preserve_texture else None
    rough_image = find_roughness_image(orig_mat) if preserve_texture else None

    mat = _build_cel(name, p2,
                     base_image=base_image,
                     normal_image=normal_image,
                     rough_image=rough_image)
    info = {
        "kept_base_texture": base_image is not None,
        "kept_normal_map": normal_image is not None,
        "kept_roughness": rough_image is not None and bool(p.get("specular")),
        "base_color": tuple(src["base_color"]),
    }
    return mat, info


def update_cel_material(mat, props):
    """Push panel control values into an existing PRO_CEL material's nodes.
    Returns list of updated node names."""
    if mat is None or not mat.use_nodes:
        return []
    nodes = mat.node_tree.nodes
    updated = []

    def set_rgb(node_name, color):
        node = nodes.get(node_name)
        if node is not None and node.type == 'RGB':
            node.outputs[0].default_value = tuple(color)
            updated.append(node_name)

    set_rgb("PRO Base Color", props.cel_base_color)
    set_rgb("PRO Shadow Color", props.cel_shadow_color)
    set_rgb("PRO Highlight Color", props.cel_highlight_color)
    set_rgb("PRO Rim Color", props.cel_rim_color)

    ramp_node = nodes.get("PRO Shadow Ramp")
    if ramp_node is not None and ramp_node.type == 'VALTORGB':
        els = ramp_node.color_ramp.elements
        if len(els) >= 2:
            els[-1].position = min(0.999, props.cel_ramp_threshold)
            updated.append("PRO Shadow Ramp")
        ramp_node.color_ramp.interpolation = (
            'CONSTANT' if props.cel_ramp_hardness >= 0.999 else 'LINEAR')

    rim_str = nodes.get("PRO Rim Strength")
    if rim_str is not None:
        rim_str.inputs[1].default_value = props.cel_rim_strength
        updated.append("PRO Rim Strength")

    base_node = nodes.get("PRO Base Color")
    if base_node is not None:
        mat.diffuse_color = tuple(base_node.outputs[0].default_value)
    return updated


# ═══════════════════════════════════════════════════════════════════════
#  UV CHECKER MATERIALS
# ═══════════════════════════════════════════════════════════════════════

def build_checker_material(kind, scale=8.0):
    """Build one of the PRO_UV checker materials. kind in CHECKER_MATERIALS."""
    name = CHECKER_MATERIALS[kind]
    mat = fresh_material(name)
    nt = mat.node_tree
    nodes, links = nt.nodes, nt.links

    n_tc = add_node(nodes, 'ShaderNodeTexCoord', "PRO UV Coords", (-1000, 0))
    n_map = add_node(nodes, 'ShaderNodeMapping', "PRO Checker Scale", (-800, 0))
    links.new(n_tc.outputs['UV'], n_map.inputs['Vector'])

    n_bsdf = add_node(nodes, 'ShaderNodeBsdfPrincipled', "PRO Checker Shader", (-200, 0))
    n_bsdf.inputs['Roughness'].default_value = 1.0
    n_out = add_node(nodes, 'ShaderNodeOutputMaterial', "PRO Output", (120, 0))
    links.new(n_bsdf.outputs[0], n_out.inputs['Surface'])

    if kind == 'GRID':
        n_map.inputs['Scale'].default_value = (scale, scale, scale)
        n_chk = add_node(nodes, 'ShaderNodeTexChecker', "PRO Checker", (-560, 0))
        n_chk.inputs['Color1'].default_value = (0.85, 0.85, 0.85, 1)
        n_chk.inputs['Color2'].default_value = (0.22, 0.22, 0.22, 1)
        links.new(n_map.outputs['Vector'], n_chk.inputs['Vector'])
        links.new(n_chk.outputs['Color'], n_bsdf.inputs['Base Color'])

    elif kind == 'COLOR':
        n_map.inputs['Scale'].default_value = (scale, scale, scale)
        n_c1 = add_node(nodes, 'ShaderNodeTexChecker', "PRO Checker Fine", (-560, 120))
        n_c1.inputs['Color1'].default_value = (0.9, 0.2, 0.6, 1)
        n_c1.inputs['Color2'].default_value = (0.15, 0.7, 0.7, 1)
        n_c2 = add_node(nodes, 'ShaderNodeTexChecker', "PRO Checker Coarse", (-560, -140))
        n_c2.inputs['Scale'].default_value = 0.25
        n_c2.inputs['Color1'].default_value = (0.95, 0.85, 0.25, 1)
        n_c2.inputs['Color2'].default_value = (0.25, 0.35, 0.9, 1)
        links.new(n_map.outputs['Vector'], n_c1.inputs['Vector'])
        links.new(n_map.outputs['Vector'], n_c2.inputs['Vector'])
        n_mix = add_node(nodes, 'ShaderNodeMix', "PRO Checker Mix", (-380, 0))
        n_mix.data_type = 'RGBA'
        n_mix.inputs['Factor'].default_value = 0.5
        links.new(n_c1.outputs['Color'], n_mix.inputs[6])
        links.new(n_c2.outputs['Color'], n_mix.inputs[7])
        links.new(n_mix.outputs[2], n_bsdf.inputs['Base Color'])

    elif kind == 'DISTORTION':
        n_map.inputs['Scale'].default_value = (scale, scale, scale)
        n_chk = add_node(nodes, 'ShaderNodeTexChecker', "PRO Checker", (-560, 120))
        n_chk.inputs['Color1'].default_value = (0.8, 0.8, 0.8, 1)
        n_chk.inputs['Color2'].default_value = (0.3, 0.3, 0.3, 1)
        links.new(n_map.outputs['Vector'], n_chk.inputs['Vector'])
        n_wave = add_node(nodes, 'ShaderNodeTexWave', "PRO Stripes", (-560, -160))
        n_wave.inputs['Scale'].default_value = scale * 0.5
        if hasattr(n_wave, 'bands_direction'):
            n_wave.bands_direction = 'DIAGONAL'
        links.new(n_map.outputs['Vector'], n_wave.inputs['Vector'])
        n_mix = add_node(nodes, 'ShaderNodeMix', "PRO Distortion Mix", (-380, 0))
        n_mix.data_type = 'RGBA'
        n_mix.blend_type = 'MULTIPLY'
        n_mix.inputs['Factor'].default_value = 0.6
        links.new(n_chk.outputs['Color'], n_mix.inputs[6])
        links.new(n_wave.outputs['Color'], n_mix.inputs[7])
        links.new(n_mix.outputs[2], n_bsdf.inputs['Base Color'])

    elif kind == 'DENSITY':
        fine = scale * 8.0
        n_map.inputs['Scale'].default_value = (fine, fine, fine)
        n_chk = add_node(nodes, 'ShaderNodeTexChecker', "PRO Density Checker", (-560, 0))
        n_chk.inputs['Color1'].default_value = (1.0, 0.3, 0.9, 1)
        n_chk.inputs['Color2'].default_value = (0.95, 0.95, 0.95, 1)
        links.new(n_map.outputs['Vector'], n_chk.inputs['Vector'])
        links.new(n_chk.outputs['Color'], n_bsdf.inputs['Base Color'])

    return mat


# ═══════════════════════════════════════════════════════════════════════
#  OUTLINE MATERIAL
# ═══════════════════════════════════════════════════════════════════════

def build_outline_material(color=(0.0, 0.0, 0.0, 1.0)):
    """Black (or colored) outline material for inverted hull / solidify.

    Culling is done IN the shader (Backfacing -> Transparent) so the
    inverted hull works in every engine — EEVEE Next ignores the
    material's backface-culling flag in final renders, which made the
    hull swallow the model in solid black.
    """
    mat = fresh_material(OUTLINE_MATERIAL)
    nt = mat.node_tree
    nodes, links = nt.nodes, nt.links

    n_col = add_node(nodes, 'ShaderNodeRGB', "PRO Outline Color", (-600, 0))
    n_col.outputs[0].default_value = tuple(color)
    n_emit = add_node(nodes, 'ShaderNodeEmission', "PRO Outline Shader", (-380, 0))
    links.new(n_col.outputs[0], n_emit.inputs['Color'])

    # Shader-level backface culling: faces whose (flipped) normal points
    # away from the camera become fully transparent.
    n_geo = add_node(nodes, 'ShaderNodeNewGeometry', "PRO Outline Facing", (-600, -220))
    n_trans = add_node(nodes, 'ShaderNodeBsdfTransparent', "PRO Outline Cull", (-380, -220))
    n_mix = add_node(nodes, 'ShaderNodeMixShader', "PRO Outline Mix", (-160, 0))
    links.new(n_geo.outputs['Backfacing'], n_mix.inputs['Fac'])
    links.new(n_emit.outputs[0], n_mix.inputs[1])      # frontfacing -> line
    links.new(n_trans.outputs[0], n_mix.inputs[2])     # backfacing  -> invisible

    n_out = add_node(nodes, 'ShaderNodeOutputMaterial', "PRO Output", (60, 0))
    links.new(n_mix.outputs[0], n_out.inputs['Surface'])

    mat.use_backface_culling = True            # viewport solid/material modes
    mat.diffuse_color = tuple(color)
    if hasattr(mat, "surface_render_method"):  # EEVEE Next transparency
        mat.surface_render_method = 'DITHERED'
    if hasattr(mat, "blend_method"):           # legacy EEVEE
        mat.blend_method = 'CLIP'
    if hasattr(mat, "shadow_method"):          # legacy EEVEE only
        mat.shadow_method = 'NONE'
    return mat
