# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_baking.py
# v0.1.6 — Baking Setup, Bake Maps, High-to-Low workflow and
# Color ID / Material ID system.
#
# RULES:
#   - high poly is never modified,
#   - no modifier is applied automatically,
#   - the engine is switched to Cycles for the bake and restored after,
#   - invalid context = clear error report, never a crash,
#   - Color ID stores the original assignments and can restore them.
# ──────────────────────────────────────────────────────────────────────

import json

import bpy

from . import baking_utils as bu
from . import material_utils as mu

ORIG_MATS_KEY = "pro_mtb_original_mats"


# ═══════════════════════════════════════════════════════════════════════
#  ORIGINAL MATERIAL STORE (Color ID / debug assignments)
# ═══════════════════════════════════════════════════════════════════════

def store_original_assignments(context, objs):
    """Remember slot materials per object (only the FIRST time, so an ID
    pass over an ID pass never overwrites the real originals)."""
    data = json.loads(context.scene.get(ORIG_MATS_KEY, "{}"))
    for obj in objs:
        if obj.name in data:
            continue
        data[obj.name] = [s.material.name if s.material else ""
                          for s in obj.material_slots]
    context.scene[ORIG_MATS_KEY] = json.dumps(data)


def restore_original_assignments(context, only=None):
    """Restore stored materials. *only*: optional set of object names to
    restore selectively (the rest stays stored). Returns
    (restored, missing_names)."""
    data = json.loads(context.scene.get(ORIG_MATS_KEY, "{}"))
    restored, missing = 0, []
    remaining = {}
    for obj_name, mat_names in data.items():
        if only is not None and obj_name not in only:
            remaining[obj_name] = mat_names
            continue
        obj = context.scene.objects.get(obj_name)
        if obj is None or obj.type != 'MESH':
            missing.append(obj_name)
            continue
        obj.data.materials.clear()
        for name in mat_names:
            mat = bpy.data.materials.get(name) if name else None
            if name and mat is None:
                missing.append(f"{obj_name}:{name}")
            obj.data.materials.append(mat)
        restored += 1
    context.scene[ORIG_MATS_KEY] = json.dumps(remaining)
    return restored, missing


# ═══════════════════════════════════════════════════════════════════════
#  BAKING SETUP
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_bake_create_collections(bpy.types.Operator):
    """Create the PRO_Bake collection tree (High / Low / Cage / Output)"""
    bl_idname = "object.pro_bake_create_collections"
    bl_label = "Create Bake Collections"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bu.ensure_bake_collections(context)
        self.report({'INFO'},
                    f"Colecciones {bu.COLL_BAKE} / High / Low / Cage / "
                    "Output listas.")
        return {'FINISHED'}


class _SetBakeRole:
    bl_options = {'REGISTER', 'UNDO'}
    role = 'high'

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        colls = bu.ensure_bake_collections(context)
        props = context.scene.pro_toolkit
        n = 0
        last = None
        for obj in mu.scope_objects(context, 'SELECTED'):
            bu.move_to_collection(obj, colls[self.role])
            last = obj
            n += 1
        if last is not None:
            if self.role == 'high':
                props.bake_high_object = last
            else:
                props.bake_low_object = last
        self.report({'INFO'},
                    f"{n} objeto(s) → {colls[self.role].name}. "
                    f"{'High' if self.role == 'high' else 'Low'} activo: "
                    f"'{last.name}'.")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_set_high(_SetBakeRole, bpy.types.Operator):
    """Set the selected objects as HIGH poly (moved to PRO_Bake_High;
    the last one becomes the active high of the panel)"""
    bl_idname = "object.pro_bake_set_high"
    bl_label = "Set as High Poly"
    role = 'high'


class OBJECT_OT_pro_bake_set_low(_SetBakeRole, bpy.types.Operator):
    """Set the selected objects as LOW poly (moved to PRO_Bake_Low;
    the last one becomes the active low of the panel)"""
    bl_idname = "object.pro_bake_set_low"
    bl_label = "Set as Low Poly"
    role = 'low'


class OBJECT_OT_pro_bake_create_cage(bpy.types.Operator):
    """Create a bake cage from the low poly: a copy pushed out along the
    vertex normals by the cage extrusion (same topology, required by
    Cycles cage baking)"""
    bl_idname = "object.pro_bake_create_cage"
    bl_label = "Create Cage From Low"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        low = props.bake_low_object or context.active_object
        if low is None or low.type != 'MESH':
            self.report({'ERROR'}, "Define primero el objeto LOW poly.")
            return {'CANCELLED'}
        colls = bu.ensure_bake_collections(context)
        cage_name = f"{bu.base_name(low.name)}_cage"
        old = bpy.data.objects.get(cage_name)
        if old is not None:
            self.report({'WARNING'},
                        f"'{cage_name}' ya existe — no se duplica. "
                        "Bórralo si quieres regenerarlo.")
            props.bake_cage_object = old
            return {'CANCELLED'}
        cage = low.copy()
        cage.data = low.data.copy()
        cage.name = cage_name
        cage.data.name = cage_name
        colls['cage'].objects.link(cage)
        # push along normals (plain vertex offset: same topology, no modifier)
        ext = props.bake_cage_extrusion
        for v in cage.data.vertices:
            v.co += v.normal * ext
        cage.display_type = 'WIRE'
        cage.hide_render = True
        cage.data.materials.clear()
        cage.data.materials.append(bu.cage_material())
        props.bake_cage_object = cage
        self.report({'INFO'},
                    f"Cage '{cage.name}' creado (+{ext:.3f} m, wire).")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_create_target_image(bpy.types.Operator):
    """Create the bake target image for the active/low object and the
    panel's map type (resolution and prefix from the panel)"""
    bl_idname = "object.pro_bake_create_target_image"
    bl_label = "Create Bake Target Image"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        obj = props.bake_low_object or context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No hay objeto destino (low/activo).")
            return {'CANCELLED'}
        map_type = props.bake_map_type
        non_color = bu.MAP_TYPES[map_type][1]
        name = bu.bake_image_name(props.bake_image_prefix,
                                  bu.base_name(obj.name), map_type)
        img = bu.ensure_bake_image(name, props.bake_resolution, non_color)
        self.report({'INFO'},
                    f"Imagen '{img.name}' lista "
                    f"({props.bake_resolution}px, "
                    f"{'Non-Color' if non_color else 'sRGB'}).")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_create_image_set(bpy.types.Operator):
    """Create the full bake image set (Normal, AO, Diffuse, Roughness,
    Color ID) for the active/low object"""
    bl_idname = "object.pro_bake_create_image_set"
    bl_label = "Create Bake Image Set"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        obj = props.bake_low_object or context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No hay objeto destino (low/activo).")
            return {'CANCELLED'}
        made = []
        for map_type in ('NORMAL', 'AO', 'DIFFUSE', 'ROUGHNESS', 'COLOR_ID'):
            non_color = bu.MAP_TYPES[map_type][1]
            name = bu.bake_image_name(props.bake_image_prefix,
                                      bu.base_name(obj.name), map_type)
            bu.ensure_bake_image(name, props.bake_resolution, non_color)
            made.append(map_type)
        self.report({'INFO'},
                    f"Set de {len(made)} imágenes creado para "
                    f"'{bu.base_name(obj.name)}' ({props.bake_resolution}px).")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_assign_images(bpy.types.Operator):
    """Insert the bake target node (with the panel map's image) into every
    material of the selected objects and make it active for baking"""
    bl_idname = "object.pro_bake_assign_images"
    bl_label = "Assign Bake Images to Materials"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        props = context.scene.pro_toolkit
        map_type = props.bake_map_type
        non_color = bu.MAP_TYPES[map_type][1]
        n = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            name = bu.bake_image_name(props.bake_image_prefix,
                                      bu.base_name(obj.name), map_type)
            img = bu.ensure_bake_image(name, props.bake_resolution, non_color)
            bu.ensure_object_has_material(obj)
            for slot in obj.material_slots:
                if slot.material is not None:
                    bu.ensure_target_node(slot.material, img)
                    n += 1
        self.report({'INFO'},
                    f"Nodo de bake asignado en {n} material(es) "
                    f"(mapa {map_type}).")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_prepare_selected(bpy.types.Operator):
    """Prepare the selected objects for baking: validate UVs, create the
    target image and insert the bake nodes (one click)"""
    bl_idname = "object.pro_bake_prepare_selected"
    bl_label = "Prepare Selected for Baking"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        problems = []
        for obj in mu.scope_objects(context, 'SELECTED'):
            problems += bu.validate_bake(obj)
        if problems:
            self.report({'ERROR'}, " | ".join(problems[:3]))
            return {'CANCELLED'}
        bpy.ops.object.pro_bake_assign_images()
        self.report({'INFO'}, "Objetos preparados para bake. ✅")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_clear_setup(bpy.types.Operator):
    """Remove the PRO bake target nodes from the materials of the selected
    objects (images and collections are kept)"""
    bl_idname = "object.pro_bake_clear_setup"
    bl_label = "Clear Bake Setup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and any(o.type == 'MESH' for o in context.selected_objects))

    def execute(self, context):
        n = 0
        for obj in mu.scope_objects(context, 'SELECTED'):
            for slot in obj.material_slots:
                mat = slot.material
                if mat is None or not mat.use_nodes:
                    continue
                node = mat.node_tree.nodes.get(bu.BAKE_NODE)
                if node is not None:
                    mat.node_tree.nodes.remove(node)
                    n += 1
        self.report({'INFO'}, f"{n} nodo(s) de bake eliminados.")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  BAKE MAPS
# ═══════════════════════════════════════════════════════════════════════

def _bake_one(self, context, map_type, *, low=None, high=None):
    """Shared validated bake path. Returns the log entry or None."""
    props = context.scene.pro_toolkit
    low = low or props.bake_low_object or context.active_object
    problems = bu.validate_bake(low)
    if problems:
        self.report({'ERROR'}, " | ".join(problems))
        return None
    if high is None and props.bake_selected_to_active:
        high = props.bake_high_object
        if high is None:
            cands = [o for o in context.selected_objects
                     if o.type == 'MESH' and o is not low]
            high = cands[0] if cands else None
        if high is None:
            self.report({'ERROR'},
                        "Selected-to-Active activado pero no hay HIGH "
                        "definido (Set as High Poly) ni seleccionado.")
            return None
    cage = props.bake_cage_object if props.bake_use_cage else None
    if props.bake_use_cage and cage is None:
        self.report({'WARNING'},
                    "Use Cage activado pero no hay cage — se usa solo "
                    "Cage Extrusion.")
    non_color = bu.MAP_TYPES[map_type][1]
    name = bu.bake_image_name(props.bake_image_prefix,
                              bu.base_name(low.name), map_type)
    img = bu.ensure_bake_image(name, props.bake_resolution, non_color)
    entry = bu.run_bake(
        context, low, map_type, img,
        high=high, use_cage=props.bake_use_cage, cage_object=cage,
        cage_extrusion=props.bake_cage_extrusion, margin=props.bake_margin,
        output_folder=props.bake_output_folder,
        save=bool(props.bake_output_folder))
    if entry["error"]:
        self.report({'ERROR'}, f"Bake {map_type} falló: {entry['error']}")
    else:
        msg = (f"Bake {map_type} OK → '{img.name}' en {entry['seconds']}s"
               + (f" (guardado: {entry['saved']})" if entry['saved'] else ""))
        self.report({'INFO'}, msg)
    return entry


class _BakeMapOp:
    bl_options = {'REGISTER', 'UNDO'}
    map_type = 'NORMAL'

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        entry = _bake_one(self, context, self.map_type)
        return {'FINISHED'} if entry and not entry["error"] else {'CANCELLED'}


class OBJECT_OT_pro_bake_normal(_BakeMapOp, bpy.types.Operator):
    """Bake a tangent-space Normal map (Cycles; engine restored after)"""
    bl_idname = "object.pro_bake_normal"
    bl_label = "Bake Normal Map"
    map_type = 'NORMAL'


class OBJECT_OT_pro_bake_ao(_BakeMapOp, bpy.types.Operator):
    """Bake Ambient Occlusion (Cycles; engine restored after)"""
    bl_idname = "object.pro_bake_ao"
    bl_label = "Bake Ambient Occlusion"
    map_type = 'AO'


class OBJECT_OT_pro_bake_diffuse(_BakeMapOp, bpy.types.Operator):
    """Bake Diffuse / Base Color (color pass only, no lighting)"""
    bl_idname = "object.pro_bake_diffuse"
    bl_label = "Bake Diffuse / Base Color"
    map_type = 'DIFFUSE'


class OBJECT_OT_pro_bake_roughness(_BakeMapOp, bpy.types.Operator):
    """Bake the Roughness channel"""
    bl_idname = "object.pro_bake_roughness"
    bl_label = "Bake Roughness"
    map_type = 'ROUGHNESS'


class OBJECT_OT_pro_bake_emission(_BakeMapOp, bpy.types.Operator):
    """Bake the Emission channel"""
    bl_idname = "object.pro_bake_emission"
    bl_label = "Bake Emission"
    map_type = 'EMIT'


class OBJECT_OT_pro_bake_combined(_BakeMapOp, bpy.types.Operator):
    """Bake a Combined preview (full lighting; needs lights in the scene)"""
    bl_idname = "object.pro_bake_combined"
    bl_label = "Bake Combined Preview"
    map_type = 'COMBINED'


class OBJECT_OT_pro_bake_color_id(bpy.types.Operator):
    """Bake the Color ID map: assigns ID materials if needed, bakes the
    emission, then restores the original materials"""
    bl_idname = "object.pro_bake_color_id"
    bl_label = "Bake Color ID"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        low = props.bake_low_object or context.active_object
        if low is None or low.type != 'MESH':
            self.report({'ERROR'}, "No hay objeto destino (low/activo).")
            return {'CANCELLED'}
        had_ids = json.loads(context.scene.get(ORIG_MATS_KEY, "{}"))
        auto_assigned = False
        if low.name not in had_ids:
            for o in context.view_layer.objects:
                o.select_set(False)
            low.select_set(True)
            context.view_layer.objects.active = low
            bpy.ops.object.pro_colorid_assign('EXEC_DEFAULT')
            auto_assigned = True
        entry = _bake_one(self, context, 'COLOR_ID', low=low)
        if auto_assigned:
            restore_original_assignments(context, only={low.name})
        if entry is None or entry["error"]:
            return {'CANCELLED'}
        if auto_assigned:
            self.report({'INFO'},
                        "Color ID bakeado y materiales originales "
                        "restaurados automáticamente.")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_selected_maps(bpy.types.Operator):
    """Bake the standard map set (Normal, AO, Diffuse, Roughness) for the
    low/active object in one go"""
    bl_idname = "object.pro_bake_selected_maps"
    bl_label = "Bake Standard Map Set"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        ok = fail = 0
        for map_type in ('NORMAL', 'AO', 'DIFFUSE', 'ROUGHNESS'):
            entry = _bake_one(self, context, map_type)
            if entry is None:
                return {'CANCELLED'}
            if entry["error"]:
                fail += 1
            else:
                ok += 1
        self.report({'WARNING' if fail else 'INFO'},
                    f"Set bakeado: {ok} OK, {fail} con error. "
                    "Ver Bake Report.")
        return {'FINISHED'}


class OBJECT_OT_pro_bake_report(bpy.types.Operator):
    """Write V016_BAKE_REPORT.md with every bake of this session"""
    bl_idname = "object.pro_bake_report"
    bl_label = "Create Bake Report"
    bl_options = {'REGISTER'}

    def execute(self, context):
        path = bu.write_bake_report()
        self.report({'INFO'}, f"Informe escrito: {path}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  HIGH TO LOW
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_hl_create_setup(bpy.types.Operator):
    """Create the High-Low bake setup: collections, classify the selected
    objects by name (_high/_low/_HP/_LP) and store the active pair"""
    bl_idname = "object.pro_hl_create_setup"
    bl_label = "Create High-Low Bake Setup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        colls = bu.ensure_bake_collections(context)
        objs = mu.scope_objects(context, 'SELECTED') or \
            mu.scope_objects(context, 'SCENE')
        n_h = n_l = 0
        for o in objs:
            kind = bu.classify_high_low(o.name)
            if kind == 'high':
                bu.move_to_collection(o, colls['high'])
                n_h += 1
            elif kind == 'low':
                bu.move_to_collection(o, colls['low'])
                n_l += 1
            elif kind == 'cage':
                bu.move_to_collection(o, colls['cage'])
        pairs = bu.pair_by_name(objs)
        if pairs:
            props.bake_low_object, props.bake_high_object = pairs[0]
            props.bake_selected_to_active = True
        self.report({'INFO'},
                    f"Setup: {n_h} high, {n_l} low, {len(pairs)} par(es) "
                    "por nombre."
                    + (f" Par activo: {pairs[0][1].name} → "
                       f"{pairs[0][0].name}." if pairs else
                       " Nombra los objetos *_high / *_low."))
        return {'FINISHED'}


class OBJECT_OT_pro_hl_pair_by_name(bpy.types.Operator):
    """Pair high and low objects by base name and store the first pair
    as the active bake pair"""
    bl_idname = "object.pro_hl_pair_by_name"
    bl_label = "Pair High and Low by Name"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        objs = mu.scope_objects(context, 'SELECTED') or \
            mu.scope_objects(context, 'SCENE')
        pairs = bu.pair_by_name(objs)
        if not pairs:
            self.report({'ERROR'},
                        "Sin pares: usa la convención *_high / *_low "
                        "(_HP/_LP también vale).")
            return {'CANCELLED'}
        props.bake_low_object, props.bake_high_object = pairs[0]
        props.bake_selected_to_active = True
        self.report({'INFO'},
                    "; ".join(f"{h.name} → {l.name}" for l, h in pairs)
                    + f" ({len(pairs)} par(es); el primero queda activo).")
        return {'FINISHED'}


class OBJECT_OT_pro_hl_pair_selected_to_active(bpy.types.Operator):
    """Pair the selected HIGH object(s) to the ACTIVE low object
    (active = low, other selected = high)"""
    bl_idname = "object.pro_hl_pair_selected_to_active"
    bl_label = "Pair Selected High to Active Low"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT' and context.active_object is not None
                and context.active_object.type == 'MESH'
                and len([o for o in context.selected_objects
                         if o.type == 'MESH']) >= 2)

    def execute(self, context):
        props = context.scene.pro_toolkit
        low = context.active_object
        highs = [o for o in context.selected_objects
                 if o.type == 'MESH' and o is not low]
        props.bake_low_object = low
        props.bake_high_object = highs[0]
        props.bake_selected_to_active = True
        self.report({'INFO'},
                    f"Par: '{highs[0].name}' (high) → '{low.name}' (low).")
        return {'FINISHED'}


class OBJECT_OT_pro_hl_validate(bpy.types.Operator):
    """Validate the active high-low pair: meshes, UVs on the low,
    bounding-box overlap and cage consistency"""
    bl_idname = "object.pro_hl_validate"
    bl_label = "Validate High-Low Pair"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        low, high = props.bake_low_object, props.bake_high_object
        problems = []
        if low is None or high is None:
            problems.append("Par incompleto: define low y high.")
        else:
            problems += bu.validate_bake(low)
            if high.type != 'MESH':
                problems.append(f"High '{high.name}' no es un mesh.")
            if low is high:
                problems.append("Low y high son el mismo objeto.")
            from .ops_hardsurface_booleans import _bbox_overlap
            if high.type == 'MESH' and low is not high \
                    and not _bbox_overlap(low, high):
                problems.append("Low y high no se superponen (bounding box).")
            cage = props.bake_cage_object
            if cage is not None and len(cage.data.vertices) != \
                    len(low.data.vertices):
                problems.append("El cage no coincide en topología con el low.")
        if problems:
            self.report({'ERROR'}, " | ".join(problems))
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Par válido: '{high.name}' → '{low.name}'. ✅")
        return {'FINISHED'}


class OBJECT_OT_pro_hl_transfer_material_ids(bpy.types.Operator):
    """Assign one distinct ID material per ORIGINAL material of the HIGH
    poly (originals stored; ready for a Color ID high-to-low bake)"""
    bl_idname = "object.pro_hl_transfer_material_ids"
    bl_label = "Transfer Material IDs"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        high = props.bake_high_object
        if high is None or high.type != 'MESH':
            self.report({'ERROR'}, "Define el objeto HIGH primero.")
            return {'CANCELLED'}
        store_original_assignments(context, [high])
        seen = {}
        for slot in high.material_slots:
            base = slot.material.name if slot.material else "(vacío)"
            if base not in seen:
                color = mu.distinct_color(len(seen))
                seen[base] = mu.build_id_material(
                    f"PRO_ID_{mu.clean_name_token(base)}", color)
            slot.material = seen[base]
        if not high.material_slots:
            high.data.materials.append(
                mu.build_id_material("PRO_ID_Single", mu.distinct_color(0)))
        self.report({'INFO'},
                    f"{len(seen) or 1} ID(s) asignados en '{high.name}' "
                    "(originales guardados — Restore para volver).")
        return {'FINISHED'}


class _HLBakeOp:
    bl_options = {'REGISTER', 'UNDO'}
    map_type = 'NORMAL'

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        low, high = props.bake_low_object, props.bake_high_object
        if low is None or high is None:
            self.report({'ERROR'},
                        "Par high-low no definido — usa Pair by Name o "
                        "Pair Selected to Active.")
            return {'CANCELLED'}
        entry = _bake_one(self, context, self.map_type, low=low, high=high)
        return {'FINISHED'} if entry and not entry["error"] else {'CANCELLED'}


class OBJECT_OT_pro_hl_bake_normal(_HLBakeOp, bpy.types.Operator):
    """Bake the Normal map from the HIGH poly onto the LOW poly
    (selected-to-active, optional cage)"""
    bl_idname = "object.pro_hl_bake_normal"
    bl_label = "Bake Normal High to Low"
    map_type = 'NORMAL'


class OBJECT_OT_pro_hl_bake_ao(_HLBakeOp, bpy.types.Operator):
    """Bake AO from the HIGH poly onto the LOW poly"""
    bl_idname = "object.pro_hl_bake_ao"
    bl_label = "Bake AO High to Low"
    map_type = 'AO'


class OBJECT_OT_pro_hl_bake_color_id(bpy.types.Operator):
    """Bake Color ID high-to-low: ID materials on the high (auto if
    needed), emission bake onto the low, originals restored"""
    bl_idname = "object.pro_hl_bake_color_id"
    bl_label = "Bake Color ID High to Low"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        props = context.scene.pro_toolkit
        low, high = props.bake_low_object, props.bake_high_object
        if low is None or high is None:
            self.report({'ERROR'}, "Par high-low no definido.")
            return {'CANCELLED'}
        had = json.loads(context.scene.get(ORIG_MATS_KEY, "{}"))
        auto = high.name not in had
        if auto:
            bpy.ops.object.pro_hl_transfer_material_ids('EXEC_DEFAULT')
        entry = _bake_one(self, context, 'COLOR_ID', low=low, high=high)
        if auto:
            restore_original_assignments(context, only={high.name})
        return {'FINISHED'} if entry and not entry["error"] else {'CANCELLED'}


# ═══════════════════════════════════════════════════════════════════════
#  COLOR ID / MATERIAL ID
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_colorid_assign(bpy.types.Operator):
    """Assign Color ID materials to the selected objects (one distinct
    color per original material, or per object); originals stored"""
    bl_idname = "object.pro_colorid_assign"
    bl_label = "Assign Color ID Materials"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[('MATERIAL', "Per Material", "One color per original material"),
               ('OBJECT', "Per Object", "One color per object")],
        default='MATERIAL')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        objs = mu.scope_objects(context, 'SELECTED')
        if not objs:
            self.report({'ERROR'}, "Selecciona al menos un mesh.")
            return {'CANCELLED'}
        store_original_assignments(context, objs)
        seen = {}
        idx = 0
        for obj in objs:
            if self.mode == 'OBJECT':
                mat = mu.build_id_material(f"PRO_ID_{obj.name}",
                                           mu.distinct_color(idx))
                idx += 1
                obj.data.materials.clear()
                obj.data.materials.append(mat)
            else:
                if not obj.material_slots:
                    obj.data.materials.append(
                        mu.build_id_material("PRO_ID_Default",
                                             mu.distinct_color(0)))
                    continue
                for slot in obj.material_slots:
                    base = slot.material.name if slot.material else "(vacío)"
                    if base not in seen:
                        seen[base] = mu.build_id_material(
                            f"PRO_ID_{mu.clean_name_token(base)}",
                            mu.distinct_color(len(seen)))
                    slot.material = seen[base]
        self.report({'INFO'},
                    f"Color IDs ({self.mode.lower()}) en {len(objs)} "
                    "objeto(s). Restore Original Materials para volver.")
        return {'FINISHED'}


class OBJECT_OT_pro_colorid_restore(bpy.types.Operator):
    """Restore the material assignments stored before the Color ID /
    debug pass"""
    bl_idname = "object.pro_colorid_restore"
    bl_label = "Restore Original Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        restored, missing = restore_original_assignments(context)
        if restored == 0 and not missing:
            self.report({'INFO'}, "No hay asignaciones guardadas.")
            return {'CANCELLED'}
        msg = f"{restored} objeto(s) restaurados."
        if missing:
            msg += f" No encontrados: {', '.join(missing[:4])}"
        self.report({'WARNING' if missing else 'INFO'}, msg)
        return {'FINISHED'}


class OBJECT_OT_pro_colorid_palette(bpy.types.Operator):
    """Create PRO_ID_Palette: an image with one labelled color swatch per
    PRO_ID material currently in the file"""
    bl_idname = "object.pro_colorid_palette"
    bl_label = "Create ID Palette"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ids = [m for m in bpy.data.materials if m.name.startswith("PRO_ID_")]
        if not ids:
            self.report({'ERROR'},
                        "No hay materiales PRO_ID_* — asigna Color IDs antes.")
            return {'CANCELLED'}
        sw, h = 64, 64
        img = bpy.data.images.get("PRO_ID_Palette")
        if img is not None:
            bpy.data.images.remove(img)
        img = bpy.data.images.new("PRO_ID_Palette", sw * len(ids), h,
                                  alpha=False)
        img.use_fake_user = True
        px = [0.0] * (sw * len(ids) * h * 4)
        for i, mat in enumerate(ids):
            r, g, b, a = mat.diffuse_color
            for y in range(h):
                for x in range(i * sw, (i + 1) * sw):
                    o = (y * sw * len(ids) + x) * 4
                    px[o:o + 4] = (r, g, b, 1.0)
        img.pixels[:] = px
        self.report({'INFO'},
                    f"'PRO_ID_Palette' creada ({len(ids)} colores: "
                    + ", ".join(m.name[7:] for m in ids[:6])
                    + ("…" if len(ids) > 6 else "") + ").")
        return {'FINISHED'}


class OBJECT_OT_pro_colorid_report(bpy.types.Operator):
    """Write a Material ID section into V016_BAKE_REPORT.md (which IDs
    exist, their colors, and what is stored for restore)"""
    bl_idname = "object.pro_colorid_report"
    bl_label = "Create Material ID Report"
    bl_options = {'REGISTER'}

    def execute(self, context):
        ids = [m for m in bpy.data.materials if m.name.startswith("PRO_ID_")]
        data = json.loads(context.scene.get(ORIG_MATS_KEY, "{}"))
        lines = ["# V016 MATERIAL ID REPORT", "",
                 f"- Materiales ID: **{len(ids)}**",
                 f"- Objetos con originales guardados: **{len(data)}**", "",
                 "## IDs"]
        for m in ids:
            r, g, b, _ = m.diffuse_color
            lines.append(f"- `{m.name}` — RGB({r:.2f}, {g:.2f}, {b:.2f})")
        if not ids:
            lines.append("- (ninguno)")
        lines += ["", "## Originales guardados (restaurables)"]
        lines += [f"- {k}: {', '.join(n or '(vacío)' for n in v)}"
                  for k, v in data.items()] or ["- (nada pendiente)"]
        path = mu.write_report("V016_MATERIAL_ID_REPORT.md", lines)
        self.report({'INFO'}, f"Informe escrito: {path}")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_bake_create_collections,
    OBJECT_OT_pro_bake_set_high,
    OBJECT_OT_pro_bake_set_low,
    OBJECT_OT_pro_bake_create_cage,
    OBJECT_OT_pro_bake_create_target_image,
    OBJECT_OT_pro_bake_create_image_set,
    OBJECT_OT_pro_bake_assign_images,
    OBJECT_OT_pro_bake_prepare_selected,
    OBJECT_OT_pro_bake_clear_setup,
    OBJECT_OT_pro_bake_normal,
    OBJECT_OT_pro_bake_ao,
    OBJECT_OT_pro_bake_diffuse,
    OBJECT_OT_pro_bake_roughness,
    OBJECT_OT_pro_bake_emission,
    OBJECT_OT_pro_bake_combined,
    OBJECT_OT_pro_bake_color_id,
    OBJECT_OT_pro_bake_selected_maps,
    OBJECT_OT_pro_bake_report,
    OBJECT_OT_pro_hl_create_setup,
    OBJECT_OT_pro_hl_pair_by_name,
    OBJECT_OT_pro_hl_pair_selected_to_active,
    OBJECT_OT_pro_hl_validate,
    OBJECT_OT_pro_hl_transfer_material_ids,
    OBJECT_OT_pro_hl_bake_normal,
    OBJECT_OT_pro_hl_bake_ao,
    OBJECT_OT_pro_hl_bake_color_id,
    OBJECT_OT_pro_colorid_assign,
    OBJECT_OT_pro_colorid_restore,
    OBJECT_OT_pro_colorid_palette,
    OBJECT_OT_pro_colorid_report,
)
