# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  texture_utils.py
# v0.1.6 — image/texture path helpers: missing detection, relink,
# relative/absolute, sizes, duplicates. Never changes a path silently:
# every mutating helper returns the list of touched images.
# ──────────────────────────────────────────────────────────────────────

import os

import bpy

_INTERNAL_IMAGES = {"Render Result", "Viewer Node"}


def real_images(used_only=False):
    """Project images, skipping Blender's internal buffers and generated
    images (UV grids etc. have no file to manage)."""
    imgs = [i for i in bpy.data.images
            if i.name not in _INTERNAL_IMAGES and i.type == 'IMAGE']
    if used_only:
        used = used_image_set()
        imgs = [i for i in imgs if i in used]
    return imgs


def used_image_set():
    """Images referenced by any material node tree (incl. node groups 1 level)."""
    used = set()
    for mat in bpy.data.materials:
        if not mat.use_nodes or mat.node_tree is None:
            continue
        stack = [mat.node_tree]
        seen = set()
        while stack:
            nt = stack.pop()
            if nt in seen:
                continue
            seen.add(nt)
            for n in nt.nodes:
                if n.type == 'TEX_IMAGE' and n.image is not None:
                    used.add(n.image)
                elif n.type == 'GROUP' and n.node_tree is not None:
                    stack.append(n.node_tree)
    # world + brush textures count as used too
    for tex in bpy.data.textures:
        if getattr(tex, "image", None) is not None:
            used.add(tex.image)
    return used


def image_users():
    """dict image -> sorted list of material names using it."""
    users = {}
    for mat in bpy.data.materials:
        if not mat.use_nodes or mat.node_tree is None:
            continue
        for n in mat.node_tree.nodes:
            if n.type == 'TEX_IMAGE' and n.image is not None:
                users.setdefault(n.image, set()).add(mat.name)
    return {img: sorted(names) for img, names in users.items()}


def image_is_missing(img):
    """True when the image points to a file that does not exist and has
    no packed fallback."""
    if img is None or img.packed_file is not None:
        return False
    if img.source not in {'FILE', 'SEQUENCE', 'TILED'}:
        return False
    if not img.filepath:
        return not img.has_data
    return not os.path.exists(bpy.path.abspath(img.filepath))


def missing_images():
    return [i for i in real_images() if image_is_missing(i)]


def is_path_absolute(img):
    return bool(img.filepath) and not img.filepath.startswith("//") \
        and img.packed_file is None


def image_size(img):
    try:
        return tuple(img.size)
    except Exception:
        return (0, 0)


# ═══════════════════════════════════════════════════════════════════════
#  RELINK
# ═══════════════════════════════════════════════════════════════════════

def index_folder(folder):
    """filename(lower) -> full path for every file under *folder*."""
    table = {}
    for root, _dirs, files in os.walk(folder):
        for fn in files:
            table.setdefault(fn.lower(), os.path.join(root, fn))
    return table


def relink_from_folder(folder, make_relative=True, missing_only=True):
    """Relink images by filename from *folder* (recursive).
    Returns (relinked:[(name, new_path)], not_found:[name])."""
    folder = bpy.path.abspath(folder)
    table = index_folder(folder)
    relinked, not_found = [], []
    for img in real_images():
        if missing_only and not image_is_missing(img):
            continue
        if not missing_only and img.packed_file is not None:
            continue
        base = os.path.basename(img.filepath) or img.name
        hit = table.get(base.lower())
        if hit is None:
            if image_is_missing(img):
                not_found.append(base)
            continue
        img.filepath = bpy.path.relpath(hit) if (make_relative
                                                 and bpy.data.is_saved) else hit
        img.reload()
        relinked.append((img.name, img.filepath))
    return relinked, not_found


def make_paths_relative():
    """Returns list of image names converted. Needs a saved .blend."""
    if not bpy.data.is_saved:
        return None
    changed = []
    for img in real_images():
        if is_path_absolute(img) and os.path.exists(
                bpy.path.abspath(img.filepath)):
            img.filepath = bpy.path.relpath(img.filepath)
            changed.append(img.name)
    return changed


def make_paths_absolute():
    changed = []
    for img in real_images():
        if img.filepath.startswith("//"):
            img.filepath = bpy.path.abspath(img.filepath)
            changed.append(img.name)
    return changed


# ═══════════════════════════════════════════════════════════════════════
#  PACK / DUPLICATES / SIZES
# ═══════════════════════════════════════════════════════════════════════

def packable_images():
    """External images that can be packed: the file exists on disk (or the
    pixels are already in memory for generated/painted images)."""
    out = []
    for i in real_images():
        if i.packed_file is not None or image_is_missing(i):
            continue
        on_disk = bool(i.filepath) and os.path.exists(
            bpy.path.abspath(i.filepath))
        if on_disk or i.has_data:
            out.append(i)
    return out


def find_large_images(max_size):
    out = []
    for img in real_images():
        w, h = image_size(img)
        if max(w, h) > max_size:
            out.append((img, (w, h)))
    return out


def duplicate_image_groups():
    """Images that look like duplicates: same file basename (case-insensitive)
    or identical existing absolute path."""
    by_key = {}
    for img in real_images():
        base = os.path.basename(img.filepath).lower() if img.filepath \
            else img.name.lower()
        by_key.setdefault(base, []).append(img)
    return {k: v for k, v in by_key.items() if len(v) >= 2}


def external_images():
    return [i for i in real_images() if i.packed_file is None and i.filepath]


def embedded_images():
    return [i for i in real_images() if i.packed_file is not None]
