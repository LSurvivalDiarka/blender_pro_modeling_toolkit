# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  retopo_utils.py
# v0.1.5: shared retopo helpers — target resolution, Mirror+Shrinkwrap
# stacks, surface projection (closest point / raycast) and display setup.
# The SOURCE mesh is never modified by these helpers.
# ──────────────────────────────────────────────────────────────────────

import bpy
from mathutils import Vector

from . import character_utils as ch

SHRINKWRAP_NAME = "PRO_Retopo_Shrinkwrap"
MIRROR_NAME = "PRO_Retopo_Mirror"


def get_target(context, retopo_obj=None):
    """Resolve the retopo source/target mesh:
    1) scene prop retopo_target_object,
    2) the object's own PRO shrinkwrap target,
    3) another selected mesh that is not the retopo object."""
    props = context.scene.pro_toolkit
    tgt = props.retopo_target_object
    if tgt is not None and tgt.type == 'MESH':
        return tgt
    if retopo_obj is not None:
        for m in retopo_obj.modifiers:
            if m.type == 'SHRINKWRAP' and m.target is not None:
                return m.target
    for o in context.selected_objects:
        if o.type == 'MESH' and o is not retopo_obj:
            return o
    return None


def add_shrinkwrap(obj, target, offset):
    """Idempotent PRO shrinkwrap (always kept LAST in the stack)."""
    for m in obj.modifiers:
        if m.name == SHRINKWRAP_NAME:
            m.target = target
            m.offset = offset
            return m
    mod = obj.modifiers.new(SHRINKWRAP_NAME, 'SHRINKWRAP')
    mod.wrap_method = 'NEAREST_SURFACEPOINT'
    mod.wrap_mode = 'ABOVE_SURFACE'
    mod.target = target
    mod.offset = offset
    return mod


def add_mirror(obj):
    """Idempotent PRO mirror placed BEFORE the shrinkwrap."""
    for m in obj.modifiers:
        if m.name == MIRROR_NAME:
            return m
    mod = obj.modifiers.new(MIRROR_NAME, 'MIRROR')
    mod.use_axis = (True, False, False)
    mod.use_clip = True
    mod.use_mirror_merge = True
    mod.merge_threshold = 0.001
    mod.show_on_cage = True
    # keep mirror before shrinkwrap
    idx = obj.modifiers.find(MIRROR_NAME)
    sw = obj.modifiers.find(SHRINKWRAP_NAME)
    if sw != -1 and idx > sw:
        for _ in range(idx - sw):
            with bpy.context.temp_override(object=obj):
                bpy.ops.object.modifier_move_up(modifier=MIRROR_NAME)
    return mod


def closest_point_world(target, world_co, depsgraph=None):
    """Closest point on *target*'s evaluated surface, world space.
    Returns (location, normal) or (None, None)."""
    inv = target.matrix_world.inverted()
    local = inv @ world_co
    try:
        if depsgraph is not None:
            ok, loc, nor, _ = target.evaluated_get(depsgraph).closest_point_on_mesh(local)
        else:
            ok, loc, nor, _ = target.closest_point_on_mesh(local)
    except RuntimeError:
        return None, None
    if not ok:
        return None, None
    mw = target.matrix_world
    return mw @ loc, (mw.to_3x3() @ nor).normalized()


def set_retopo_display(obj, in_front=True):
    obj.show_in_front = in_front
    obj.display_type = 'TEXTURED'
    obj.show_wire = True
    obj.show_all_edges = True


def enable_face_snapping(context):
    """Classic retopo snapping: snap to faces, project individual elements."""
    ts = context.scene.tool_settings
    ts.use_snap = True
    try:
        ts.snap_elements = {'FACE'}
    except Exception:
        pass
    for attr in ("use_snap_project", "use_snap_self",
                 "use_snap_align_rotation"):
        if hasattr(ts, attr):
            try:
                setattr(ts, attr, attr == "use_snap_project")
            except Exception:
                pass


def new_grid_object(context, name, cols, rows, size, at, target=None,
                    offset=0.0, mirror=False):
    """Create a flat quad grid object (XY plane) at *at* (Vector), filed in
    PRO_Retopo with the blue material; optional shrinkwrap/mirror stack."""
    import bmesh
    bm = bmesh.new()
    bmesh.ops.create_grid(bm, x_segments=cols, y_segments=rows,
                          size=size / 2.0)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()

    obj = bpy.data.objects.new(name, me)
    ch.link_to_coll(context, obj, ch.COLL_RETOPO)
    obj.location = at
    ch.assign_char_material(obj, "PRO_Retopo_Blue")
    set_retopo_display(obj, in_front=True)

    if mirror:
        add_mirror(obj)
    if target is not None:
        add_shrinkwrap(obj, target, offset)

    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    return obj
