# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_edges_faces.py
# Operators for edges, faces, shapes, selection and bevel
# ──────────────────────────────────────────────────────────────────────

import math
import bpy
import bmesh
from mathutils import Vector

from . import core_toolkit


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _get_bmesh(context):
    obj = context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    return bm, me


def _finish_bmesh(bm, me, destructive=False):
    bmesh.update_edit_mesh(me, loop_triangles=True, destructive=destructive)


def _average_face_normal(faces):
    """Return the normalized average normal of *faces*, or None if degenerate."""
    normal = Vector()
    for f in faces:
        normal += f.normal
    if normal.length < 1e-8:
        return None
    return normal.normalized()


# ═══════════════════════════════════════════════════════════════════════
#  SELECTION TOOLS (basic)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_select_ngons(bpy.types.Operator):
    """Select all faces with more than 4 sides (N-Gons)"""
    bl_idname = "mesh.pro_select_ngons"
    bl_label = "Select N-Gons"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        bpy.ops.mesh.select_all(action='DESELECT')
        bm.faces.ensure_lookup_table()
        count = 0
        for f in bm.faces:
            if len(f.verts) > 4:
                f.select = True
                count += 1
        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Selected {count} N-Gons")
        return {'FINISHED'}


class MESH_OT_pro_select_tris(bpy.types.Operator):
    """Select all triangular faces"""
    bl_idname = "mesh.pro_select_tris"
    bl_label = "Select Tris"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        bpy.ops.mesh.select_all(action='DESELECT')
        bm.faces.ensure_lookup_table()
        count = 0
        for f in bm.faces:
            if len(f.verts) == 3:
                f.select = True
                count += 1
        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Selected {count} Tris")
        return {'FINISHED'}


class MESH_OT_pro_select_non_manifold(bpy.types.Operator):
    """Select all non-manifold edges"""
    bl_idname = "mesh.pro_select_non_manifold"
    bl_label = "Select Non-Manifold"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        bpy.ops.mesh.select_all(action='DESELECT')
        bm.edges.ensure_lookup_table()
        count = 0
        for e in bm.edges:
            if not e.is_manifold:
                e.select = True
                count += 1
        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Selected {count} non-manifold edges")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  CIRCULARIZE LOOP  (Shape Tools)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_circularize(bpy.types.Operator):
    """Project selected vertices onto a perfect circle"""
    bl_idname = "mesh.pro_circularize"
    bl_label = "Circularize Loop"
    bl_options = {'REGISTER', 'UNDO'}

    influence: bpy.props.FloatProperty(
        name="Influence",
        description="Blend between current position and circle",
        default=1.0,
        min=0.0,
        max=1.0,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel = [v for v in bm.verts if v.select]
        if len(sel) < 3:
            self.report({'WARNING'}, "Select at least 3 vertices.")
            return {'CANCELLED'}

        # Compute center and average normal
        center = sum((v.co for v in sel), Vector()) / len(sel)
        avg_normal = sum((v.normal for v in sel), Vector())
        if avg_normal.length < 1e-6:
            avg_normal = Vector((0, 0, 1))
        avg_normal.normalize()

        # Average radius
        radii = [(v.co - center).length for v in sel]
        avg_r = sum(radii) / len(radii)

        # Build a local coordinate frame on the plane
        arbitrary = Vector((0, 0, 1))
        if abs(avg_normal.dot(arbitrary)) > 0.99:
            arbitrary = Vector((0, 1, 0))
        u = avg_normal.cross(arbitrary).normalized()
        v_axis = avg_normal.cross(u).normalized()

        # Sort vertices by angle around the center
        def angle_key(vert):
            d = vert.co - center
            return math.atan2(d.dot(v_axis), d.dot(u))

        sel_sorted = sorted(sel, key=angle_key)

        # Distribute evenly on the circle
        n = len(sel_sorted)
        for i, vert in enumerate(sel_sorted):
            theta = 2.0 * math.pi * i / n
            circle_pos = center + u * (avg_r * math.cos(theta)) + v_axis * (avg_r * math.sin(theta))
            vert.co = vert.co.lerp(circle_pos, self.influence)

        _finish_bmesh(bm, me)
        self.report({'INFO'}, f"Circularized {n} vertices  (r={avg_r:.4f})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  SMART BEVEL  (Bevel / Chamfer)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_bevel(bpy.types.Operator):
    """Bevel with scale preflight: blocks on un-applied scale unless confirmed"""
    bl_idname = "mesh.pro_bevel"
    bl_label = "Smart Bevel"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(
        name="Width",
        default=0.02,
        min=0.0,
        soft_max=2.0,
        step=1,
        precision=4,
    )
    segments: bpy.props.IntProperty(
        name="Segments",
        default=2,
        min=1,
        max=32,
    )
    affect: bpy.props.EnumProperty(
        name="Affect",
        items=[
            ('EDGES', "Edges", "Bevel edges"),
            ('VERTICES', "Vertices", "Bevel vertices"),
        ],
        default='EDGES',
    )
    apply_scale_before_bevel: bpy.props.BoolProperty(
        name="Apply Scale First",
        description="Confirm applying object scale before the bevel (a backup copy is created)",
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        obj = context.edit_object

        # ── Preflight: object scale must be applied ─────────────────
        scale = obj.scale
        scale_not_applied = any(abs(s - 1.0) > 0.001 for s in scale)

        if scale_not_applied and not self.apply_scale_before_bevel:
            self.report(
                {'WARNING'},
                f"Bevel cancelled: scale not applied "
                f"({scale.x:.2f}, {scale.y:.2f}, {scale.z:.2f}). "
                f"Enable 'Apply Scale First' to continue.")
            return {'CANCELLED'}

        if scale_not_applied:
            # Backup, then apply scale to this object only
            bpy.ops.object.mode_set(mode='OBJECT')
            core_toolkit.backup_object(obj)

            deselected = []
            for other in context.selected_objects:
                if other is not obj:
                    other.select_set(False)
                    deselected.append(other)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            for other in deselected:
                other.select_set(True)

            bpy.ops.object.mode_set(mode='EDIT')

        # ── Run native bevel (non-modal so the redo panel stays sane) ──
        bpy.ops.mesh.bevel(
            offset=self.width,
            offset_pct=0,
            segments=self.segments,
            affect=self.affect,
        )

        # ── Ensure a single Weighted Normal modifier at the end ─────
        if not any(m.type == 'WEIGHTED_NORMAL' for m in obj.modifiers):
            mod = obj.modifiers.new(name="Pro_Weighted_Normal", type='WEIGHTED_NORMAL')
            mod.weight = 50
            mod.keep_sharp = True
            wn_msg = " + Weighted Normal added"
        else:
            wn_msg = ""

        self.report({'INFO'},
                    f"Bevel applied (w={self.width:.4f}, segments={self.segments}){wn_msg}")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "width")
        layout.prop(self, "segments")
        layout.prop(self, "affect")
        layout.separator()
        layout.prop(self, "apply_scale_before_bevel")


# ═══════════════════════════════════════════════════════════════════════
#  EXTRUDE ALONG NORMALS  (Face Tools) — pure bmesh, no operator macros
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_extrude(bpy.types.Operator):
    """Extrude selected faces along their averaged normal"""
    bl_idname = "mesh.pro_extrude"
    bl_label = "Extrude Along Normals"
    bl_options = {'REGISTER', 'UNDO'}

    distance: bpy.props.FloatProperty(
        name="Distance",
        default=0.1,
        soft_min=-2.0,
        soft_max=2.0,
        step=1,
        precision=4,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)

        sel_faces = [f for f in bm.faces if f.select]
        if not sel_faces:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}

        normal = _average_face_normal(sel_faces)
        if normal is None:
            self.report({'WARNING'},
                        "Selected faces have opposing normals - cannot find direction.")
            return {'CANCELLED'}

        # Region = selected faces + their edges + their verts
        edges = set()
        verts = set()
        for f in sel_faces:
            edges.update(f.edges)
            verts.update(f.verts)
        geom = list(verts) + list(edges) + sel_faces

        result = bmesh.ops.extrude_face_region(bm, geom=geom)
        new_geom = result["geom"]
        new_verts = [el for el in new_geom if isinstance(el, bmesh.types.BMVert)]
        new_faces = [el for el in new_geom if isinstance(el, bmesh.types.BMFace)]

        bmesh.ops.translate(bm, verts=new_verts, vec=normal * self.distance)

        # Leave only the new cap faces selected (matches native extrude UX)
        for f in bm.faces:
            f.select = False
        for e in bm.edges:
            e.select = False
        for v in bm.verts:
            v.select = False
        for f in new_faces:
            f.select = True
        bm.select_flush_mode()

        _finish_bmesh(bm, me, destructive=True)
        self.report({'INFO'},
                    f"Extruded {len(new_faces)} faces by {self.distance:.4f}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  SOLIDIFY FACES  (Face Tools)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_solidify(bpy.types.Operator):
    """Solidify selected faces using bmesh"""
    bl_idname = "mesh.pro_solidify"
    bl_label = "Solidify Faces"
    bl_options = {'REGISTER', 'UNDO'}

    thickness: bpy.props.FloatProperty(
        name="Thickness",
        default=0.05,
        min=0.0001,
        soft_max=2.0,
        step=1,
        precision=4,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, me = _get_bmesh(context)
        sel_faces = [f for f in bm.faces if f.select]
        if not sel_faces:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}

        bmesh.ops.solidify(bm, geom=sel_faces, thickness=self.thickness)

        _finish_bmesh(bm, me, destructive=True)
        self.report({'INFO'}, f"Solidified {len(sel_faces)} faces (t={self.thickness:.4f})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  SMART INSET  (Face Tools)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_inset(bpy.types.Operator):
    """Inset selected faces (individual or region)"""
    bl_idname = "mesh.pro_inset"
    bl_label = "Smart Inset"
    bl_options = {'REGISTER', 'UNDO'}

    thickness: bpy.props.FloatProperty(
        name="Thickness",
        description="Inset distance",
        default=0.02,
        min=0.0,
        soft_max=1.0,
        step=1,
        precision=4,
    )
    depth: bpy.props.FloatProperty(
        name="Depth",
        description="Inset depth",
        default=0.0,
        soft_min=-1.0,
        soft_max=1.0,
        step=1,
        precision=4,
    )
    use_individual: bpy.props.BoolProperty(
        name="Individual",
        description="Inset each face individually",
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.edit_object is not None)

    def execute(self, context):
        bm, _ = _get_bmesh(context)
        if not any(f.select for f in bm.faces):
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}

        bpy.ops.mesh.inset(
            thickness=self.thickness,
            depth=self.depth,
            use_individual=self.use_individual,
        )
        self.report({'INFO'}, f"Inset faces (t={self.thickness:.4f}  d={self.depth:.4f})")
        return {'FINISHED'}
