# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_uv.py
# Pro UV Suite: UV Map Manager, Seam Tools, Unwrap Tools, Island Tools
# ──────────────────────────────────────────────────────────────────────

import math
import bpy
import bmesh
from mathutils import Vector

from . import uv_utils


# ═══════════════════════════════════════════════════════════════════════
#  POLL MIXINS
# ═══════════════════════════════════════════════════════════════════════

class _MeshObjectOp:
    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')


class _EditMeshOp:
    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and context.edit_object is not None


def _with_object_mode(context, fn):
    """Run fn() in Object Mode, restoring the previous mode afterwards."""
    obj = context.active_object
    prev = obj.mode
    if prev != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    try:
        return fn()
    finally:
        if prev != obj.mode:
            bpy.ops.object.mode_set(mode=prev)


def _require_selected_faces(self, context):
    """Return True if at least one face is selected, else report+False."""
    bm = bmesh.from_edit_mesh(context.edit_object.data)
    if not any(f.select for f in bm.faces):
        self.report({'WARNING'}, "No faces selected.")
        return False
    return True


# ═══════════════════════════════════════════════════════════════════════
#  UV MAP MANAGER  (object-level)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_uv_create_map(_MeshObjectOp, bpy.types.Operator):
    """Create a UV map named UV_Main (if not already present)"""
    bl_idname = "object.pro_uv_create_map"
    bl_label = "Create UV_Main"
    bl_options = {'REGISTER', 'UNDO'}

    map_name: bpy.props.StringProperty(name="Name", default="UV_Main")

    def execute(self, context):
        me = context.active_object.data
        if self.map_name in me.uv_layers:
            self.report({'INFO'}, f"UV map '{self.map_name}' already exists.")
            return {'CANCELLED'}

        def do():
            layer = me.uv_layers.new(name=self.map_name, do_init=True)
            me.uv_layers.active = layer
        _with_object_mode(context, do)
        self.report({'INFO'}, f"Created UV map '{self.map_name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_create_lightmap(_MeshObjectOp, bpy.types.Operator):
    """Create a second UV map named UV_Lightmap for lightmap baking"""
    bl_idname = "object.pro_uv_create_lightmap"
    bl_label = "Create UV_Lightmap"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.active_object.data
        if "UV_Lightmap" in me.uv_layers:
            self.report({'INFO'}, "UV map 'UV_Lightmap' already exists.")
            return {'CANCELLED'}

        def do():
            layer = me.uv_layers.new(name="UV_Lightmap", do_init=True)
            me.uv_layers.active = layer
        _with_object_mode(context, do)
        self.report({'INFO'}, "Created 'UV_Lightmap' (copy of active map). "
                              "Run Lightmap Pack on it next.")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_create_second_channel(_MeshObjectOp, bpy.types.Operator):
    """Create a second UV channel (UV_Channel2) copying the active map"""
    bl_idname = "object.pro_uv_create_second_channel"
    bl_label = "Create 2nd Channel"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.active_object.data
        if "UV_Channel2" in me.uv_layers:
            self.report({'INFO'}, "UV map 'UV_Channel2' already exists.")
            return {'CANCELLED'}

        def do():
            me.uv_layers.new(name="UV_Channel2", do_init=True)
        _with_object_mode(context, do)
        self.report({'INFO'}, "Created 'UV_Channel2' (copy of active map)")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_duplicate_map(_MeshObjectOp, bpy.types.Operator):
    """Duplicate the active UV map"""
    bl_idname = "object.pro_uv_duplicate_map"
    bl_label = "Duplicate Active"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.active_object.data
        if not me.uv_layers:
            self.report({'WARNING'}, "Object has no UV maps.")
            return {'CANCELLED'}
        src = me.uv_layers.active.name

        def do():
            me.uv_layers.new(name=f"{src}_copy", do_init=True)
        _with_object_mode(context, do)
        self.report({'INFO'}, f"Duplicated '{src}'")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_delete_map(_MeshObjectOp, bpy.types.Operator):
    """Delete the active UV map (asks for confirmation)"""
    bl_idname = "object.pro_uv_delete_map"
    bl_label = "Delete Active UV Map"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        me = context.active_object.data
        if not me.uv_layers:
            self.report({'WARNING'}, "Object has no UV maps.")
            return {'CANCELLED'}
        name = me.uv_layers.active.name

        def do():
            me.uv_layers.remove(me.uv_layers.active)
        _with_object_mode(context, do)
        self.report({'INFO'}, f"Deleted UV map '{name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_rename_map(_MeshObjectOp, bpy.types.Operator):
    """Rename the active UV map"""
    bl_idname = "object.pro_uv_rename_map"
    bl_label = "Rename Active"
    bl_options = {'REGISTER', 'UNDO'}

    new_name: bpy.props.StringProperty(name="New Name", default="UV_Main")

    def invoke(self, context, event):
        me = context.active_object.data
        if me.uv_layers:
            self.new_name = me.uv_layers.active.name
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        me = context.active_object.data
        if not me.uv_layers:
            self.report({'WARNING'}, "Object has no UV maps.")
            return {'CANCELLED'}
        old = me.uv_layers.active.name
        me.uv_layers.active.name = self.new_name
        self.report({'INFO'}, f"Renamed '{old}' to '{me.uv_layers.active.name}'")
        return {'FINISHED'}


class OBJECT_OT_pro_uv_set_active_map(_MeshObjectOp, bpy.types.Operator):
    """Cycle the active UV map"""
    bl_idname = "object.pro_uv_set_active_map"
    bl_label = "Next UV Map"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.active_object.data
        if not me.uv_layers:
            self.report({'WARNING'}, "Object has no UV maps.")
            return {'CANCELLED'}
        idx = (me.uv_layers.active_index + 1) % len(me.uv_layers)
        me.uv_layers.active_index = idx
        self.report({'INFO'}, f"Active UV map: '{me.uv_layers.active.name}'")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  UV SEAM TOOLS  (edit mode)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_uv_mark_seam(_EditMeshOp, bpy.types.Operator):
    """Mark selected edges as UV seams"""
    bl_idname = "mesh.pro_uv_mark_seam"
    bl_label = "Mark Seam"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if e.select:
                e.seam = True
                count += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Marked {count} seam edges")
        return {'FINISHED'}


class MESH_OT_pro_uv_clear_seam(_EditMeshOp, bpy.types.Operator):
    """Clear UV seams on selected edges"""
    bl_idname = "mesh.pro_uv_clear_seam"
    bl_label = "Clear Seam"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if e.select and e.seam:
                e.seam = False
                count += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Cleared {count} seam edges")
        return {'FINISHED'}


class MESH_OT_pro_uv_clear_all_seams(_EditMeshOp, bpy.types.Operator):
    """Clear ALL UV seams of the mesh"""
    bl_idname = "mesh.pro_uv_clear_all_seams"
    bl_label = "Clear All Seams"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if e.seam:
                e.seam = False
                count += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Cleared {count} seams (whole mesh)")
        return {'FINISHED'}


class MESH_OT_pro_uv_select_seams(_EditMeshOp, bpy.types.Operator):
    """Select all edges marked as UV seams"""
    bl_idname = "mesh.pro_uv_select_seams"
    bl_label = "Select Seams"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.select_all(action='DESELECT')
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if e.seam:
                e.select = True
                count += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Selected {count} seam edges")
        return {'FINISHED'}


class MESH_OT_pro_uv_mark_sharp_as_seam(_EditMeshOp, bpy.types.Operator):
    """Mark every Sharp edge as a UV seam"""
    bl_idname = "mesh.pro_uv_mark_sharp_as_seam"
    bl_label = "Sharp → Seam"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if not e.smooth:        # marked Sharp
                e.seam = True
                count += 1
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Converted {count} sharp edges to seams")
        return {'FINISHED'}


def _auto_seams(context, angle_threshold, mark_sharp_too=False,
                clear_existing=False, only_selected=False):
    """Core auto-seam logic. Returns number of seams marked."""
    me = context.edit_object.data
    bm = bmesh.from_edit_mesh(me)

    if clear_existing:
        for e in bm.edges:
            if not only_selected or e.select:
                e.seam = False

    count = 0
    for e in bm.edges:
        if only_selected and not e.select:
            continue
        if len(e.link_faces) != 2:
            continue
        angle = e.calc_face_angle(None)
        if angle is not None and angle >= angle_threshold:
            e.seam = True
            if mark_sharp_too:
                e.smooth = False
            count += 1
    bmesh.update_edit_mesh(me)
    return count


class MESH_OT_pro_uv_auto_seams_by_angle(_EditMeshOp, bpy.types.Operator):
    """Mark seams automatically on edges sharper than the angle threshold"""
    bl_idname = "mesh.pro_uv_auto_seams_by_angle"
    bl_label = "Auto Seams by Angle"
    bl_options = {'REGISTER', 'UNDO'}

    angle_threshold: bpy.props.FloatProperty(
        name="Angle", subtype='ANGLE',
        default=math.radians(50.0),
        min=math.radians(1.0), max=math.radians(180.0))
    mark_sharp_too: bpy.props.BoolProperty(name="Also Mark Sharp", default=False)
    clear_existing: bpy.props.BoolProperty(name="Clear Existing Seams", default=False)
    only_selected: bpy.props.BoolProperty(name="Only Selected Edges", default=False)

    def execute(self, context):
        count = _auto_seams(context, self.angle_threshold,
                            self.mark_sharp_too, self.clear_existing,
                            self.only_selected)
        self.report({'INFO'}, f"Auto-marked {count} seams "
                              f"(angle ≥ {math.degrees(self.angle_threshold):.0f}°)")
        return {'FINISHED'}


class MESH_OT_pro_uv_auto_seams_hard_surface(_EditMeshOp, bpy.types.Operator):
    """Hard-surface preset: seams on strong angles (40°), also marked Sharp"""
    bl_idname = "mesh.pro_uv_auto_seams_hard_surface"
    bl_label = "Auto Seams: Hard Surface"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = _auto_seams(context, math.radians(40.0),
                            mark_sharp_too=True, clear_existing=True)
        self.report({'INFO'}, f"Hard-surface seams: {count} edges (40°, sharp marked)")
        return {'FINISHED'}


class MESH_OT_pro_uv_auto_seams_organic(_EditMeshOp, bpy.types.Operator):
    """Organic preset: fewer, softer seams (70°), no sharp marking"""
    bl_idname = "mesh.pro_uv_auto_seams_organic"
    bl_label = "Auto Seams: Organic"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = _auto_seams(context, math.radians(70.0),
                            mark_sharp_too=False, clear_existing=True)
        self.report({'INFO'}, f"Organic seams: {count} edges (70°)")
        return {'FINISHED'}


class MESH_OT_pro_uv_select_boundary_edges(_EditMeshOp, bpy.types.Operator):
    """Select boundary edges (good island borders)"""
    bl_idname = "mesh.pro_uv_select_boundary_edges"
    bl_label = "Select Boundary"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.select_all(action='DESELECT')
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if e.is_boundary:
                e.select = True
                count += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Selected {count} boundary edges")
        return {'FINISHED'}


class MESH_OT_pro_uv_select_open_edges(_EditMeshOp, bpy.types.Operator):
    """Select open edges (boundary + wire edges without faces)"""
    bl_idname = "mesh.pro_uv_select_open_edges"
    bl_label = "Select Open Edges"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.select_all(action='DESELECT')
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        count = 0
        for e in bm.edges:
            if len(e.link_faces) <= 1:
                e.select = True
                count += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Selected {count} open edges")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  UV UNWRAP TOOLS  (edit mode — native operators, 3D-View safe)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_uv_smart_project(_EditMeshOp, bpy.types.Operator):
    """Smart UV Project with sensible presets"""
    bl_idname = "mesh.pro_uv_smart_project"
    bl_label = "Smart UV Project"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('DEFAULT', "Default", "Balanced settings"),
            ('HARD_SURFACE', "Hard Surface", "66° angle, tight margin"),
            ('PROP', "Prop", "45° angle, generous margin"),
        ],
        default='DEFAULT')
    angle_limit: bpy.props.FloatProperty(
        name="Angle Limit", subtype='ANGLE',
        default=math.radians(66.0),
        min=math.radians(1.0), max=math.radians(89.0))
    island_margin: bpy.props.FloatProperty(
        name="Island Margin", default=0.02, min=0.0, max=0.5)

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        if self.preset == 'HARD_SURFACE':
            angle, margin = math.radians(66.0), 0.015
        elif self.preset == 'PROP':
            angle, margin = math.radians(45.0), 0.02
        else:
            angle, margin = self.angle_limit, self.island_margin
        bpy.ops.uv.smart_project(angle_limit=angle, island_margin=margin,
                                 correct_aspect=True, scale_to_bounds=False)
        self.report({'INFO'}, f"Smart UV Project done ({self.preset.lower()})")
        return {'FINISHED'}


class MESH_OT_pro_uv_unwrap_from_seams(_EditMeshOp, bpy.types.Operator):
    """Unwrap selected faces using the marked seams"""
    bl_idname = "mesh.pro_uv_unwrap_from_seams"
    bl_label = "Unwrap (Seams)"
    bl_options = {'REGISTER', 'UNDO'}

    margin: bpy.props.FloatProperty(name="Margin", default=0.02, min=0.0, max=0.5)

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=self.margin,
                          correct_aspect=True)
        self.report({'INFO'}, "Unwrapped from seams")
        return {'FINISHED'}


class _SimpleUnwrapWrapper(_EditMeshOp):
    """Base for thin native-projection wrappers."""
    _label_done = "Projection done"

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        self._run(context)
        self.report({'INFO'}, self._label_done)
        return {'FINISHED'}


class MESH_OT_pro_uv_cube_project(_SimpleUnwrapWrapper, bpy.types.Operator):
    """Cube projection on selected faces"""
    bl_idname = "mesh.pro_uv_cube_project"
    bl_label = "Cube Projection"
    bl_options = {'REGISTER', 'UNDO'}
    _label_done = "Cube projection done"

    cube_size: bpy.props.FloatProperty(name="Cube Size", default=1.0, min=0.001, soft_max=10.0)

    def _run(self, context):
        bpy.ops.uv.cube_project(cube_size=self.cube_size, correct_aspect=True)


class MESH_OT_pro_uv_cylinder_project(_SimpleUnwrapWrapper, bpy.types.Operator):
    """Cylinder projection on selected faces"""
    bl_idname = "mesh.pro_uv_cylinder_project"
    bl_label = "Cylinder Projection"
    bl_options = {'REGISTER', 'UNDO'}
    _label_done = "Cylinder projection done"

    def _run(self, context):
        bpy.ops.uv.cylinder_project(direction='ALIGN_TO_OBJECT', correct_aspect=True)


class MESH_OT_pro_uv_sphere_project(_SimpleUnwrapWrapper, bpy.types.Operator):
    """Sphere projection on selected faces"""
    bl_idname = "mesh.pro_uv_sphere_project"
    bl_label = "Sphere Projection"
    bl_options = {'REGISTER', 'UNDO'}
    _label_done = "Sphere projection done"

    def _run(self, context):
        bpy.ops.uv.sphere_project(direction='ALIGN_TO_OBJECT', correct_aspect=True)


class MESH_OT_pro_uv_project_from_view(_SimpleUnwrapWrapper, bpy.types.Operator):
    """Project UVs from the current viewport view"""
    bl_idname = "mesh.pro_uv_project_from_view"
    bl_label = "Project From View"
    bl_options = {'REGISTER', 'UNDO'}
    _label_done = "Projected from view"

    def _run(self, context):
        bpy.ops.uv.project_from_view(orthographic=False, correct_aspect=True,
                                     scale_to_bounds=False)


class MESH_OT_pro_uv_reset_uvs(_SimpleUnwrapWrapper, bpy.types.Operator):
    """Reset UVs of selected faces (each face fills 0-1)"""
    bl_idname = "mesh.pro_uv_reset_uvs"
    bl_label = "Reset UVs"
    bl_options = {'REGISTER', 'UNDO'}
    _label_done = "UVs reset"

    def _run(self, context):
        bpy.ops.uv.reset()


class MESH_OT_pro_uv_lightmap_pack(_EditMeshOp, bpy.types.Operator):
    """Lightmap Pack on selected faces (no overlaps, good for baking)"""
    bl_idname = "mesh.pro_uv_lightmap_pack"
    bl_label = "Lightmap Pack"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        try:
            bpy.ops.uv.lightmap_pack(PREF_CONTEXT='SEL_FACES',
                                     PREF_BOX_DIV=12, PREF_MARGIN_DIV=0.3)
        except TypeError:
            bpy.ops.uv.lightmap_pack()      # param set varies across versions
        self.report({'INFO'}, "Lightmap pack done")
        return {'FINISHED'}


class MESH_OT_pro_uv_follow_active_quads(_EditMeshOp, bpy.types.Operator):
    """Follow Active Quads (great for strips and grids; needs quad selection)"""
    bl_idname = "mesh.pro_uv_follow_active_quads"
    bl_label = "Follow Active Quads"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(context.edit_object.data)
        active = bm.faces.active
        if active is None or len(active.verts) != 4 or not active.select:
            self.report({'WARNING'}, "Needs a selected ACTIVE quad face.")
            return {'CANCELLED'}
        try:
            bpy.ops.uv.follow_active_quads(mode='LENGTH_AVERAGE')
        except RuntimeError as e:
            self.report({'WARNING'}, f"Follow Active Quads failed: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, "Follow Active Quads done")
        return {'FINISHED'}


class MESH_OT_pro_uv_unwrap_preset(_EditMeshOp, bpy.types.Operator):
    """Apply a complete unwrap preset to the selected faces"""
    bl_idname = "mesh.pro_uv_unwrap_preset"
    bl_label = "Unwrap Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('HARD_SURFACE', "Hard Surface", "Auto seams 40° + unwrap + pack"),
            ('ORGANIC', "Organic", "Unwrap from your seams, soft margins"),
            ('CHARACTER', "Character", "Unwrap + average scale + pack"),
            ('ARCHITECTURE', "Architecture", "Cube projection, 1m grid"),
            ('PROP', "Prop", "Smart project 45° + pack"),
            ('LIGHTMAP', "Lightmap", "Lightmap pack (no overlaps)"),
        ],
        default='PROP')

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        p = self.preset

        if p == 'HARD_SURFACE':
            _auto_seams(context, math.radians(40.0), mark_sharp_too=True,
                        clear_existing=True)
            bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.015)
            uv_utils.run_in_uv_editor(
                context, lambda: bpy.ops.uv.pack_islands(rotate=True, margin=0.015))
        elif p == 'ORGANIC':
            bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.02)
        elif p == 'CHARACTER':
            bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.025)
            uv_utils.run_in_uv_editor(
                context, lambda: (bpy.ops.uv.average_islands_scale(),
                                  bpy.ops.uv.pack_islands(rotate=True, margin=0.025)))
        elif p == 'ARCHITECTURE':
            bpy.ops.uv.cube_project(cube_size=1.0, correct_aspect=True)
        elif p == 'PROP':
            bpy.ops.uv.smart_project(angle_limit=math.radians(45.0),
                                     island_margin=0.02, correct_aspect=True)
            uv_utils.run_in_uv_editor(
                context, lambda: bpy.ops.uv.pack_islands(rotate=True, margin=0.02))
        elif p == 'LIGHTMAP':
            try:
                bpy.ops.uv.lightmap_pack(PREF_CONTEXT='SEL_FACES',
                                         PREF_BOX_DIV=12, PREF_MARGIN_DIV=0.3)
            except TypeError:
                bpy.ops.uv.lightmap_pack()

        self.report({'INFO'}, f"Unwrap preset applied: {p.replace('_', ' ').title()}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  UV ISLAND TOOLS
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_uv_pack_islands(_EditMeshOp, bpy.types.Operator):
    """Pack UV islands of the selected faces (native packer)"""
    bl_idname = "mesh.pro_uv_pack_islands"
    bl_label = "Pack Islands"
    bl_options = {'REGISTER', 'UNDO'}

    margin: bpy.props.FloatProperty(name="Margin", default=0.02, min=0.0, max=0.5)
    rotate: bpy.props.BoolProperty(name="Allow Rotation", default=True)

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        try:
            uv_utils.run_in_uv_editor(
                context,
                lambda: bpy.ops.uv.pack_islands(rotate=self.rotate, margin=self.margin))
        except RuntimeError as e:
            self.report({'WARNING'}, f"Pack Islands failed: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Packed islands (margin={self.margin:.3f})")
        return {'FINISHED'}


class MESH_OT_pro_uv_average_island_scale(_EditMeshOp, bpy.types.Operator):
    """Average the texel scale of the selected islands (native)"""
    bl_idname = "mesh.pro_uv_average_island_scale"
    bl_label = "Average Island Scale"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        try:
            uv_utils.run_in_uv_editor(
                context, lambda: bpy.ops.uv.average_islands_scale())
        except RuntimeError as e:
            self.report({'WARNING'}, f"Average Island Scale failed: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, "Island scales averaged")
        return {'FINISHED'}


class MESH_OT_pro_uv_minimize_stretch(_EditMeshOp, bpy.types.Operator):
    """Minimize UV stretch of the selection (native, fixed iterations)"""
    bl_idname = "mesh.pro_uv_minimize_stretch"
    bl_label = "Minimize Stretch"
    bl_options = {'REGISTER', 'UNDO'}

    iterations: bpy.props.IntProperty(name="Iterations", default=20, min=1, max=200)

    def execute(self, context):
        if not _require_selected_faces(self, context):
            return {'CANCELLED'}
        try:
            uv_utils.run_in_uv_editor(
                context,
                lambda: bpy.ops.uv.minimize_stretch(iterations=self.iterations))
        except RuntimeError as e:
            self.report({'WARNING'}, f"Minimize Stretch failed: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Stretch minimized ({self.iterations} iterations)")
        return {'FINISHED'}


class _IslandTransformOp(_EditMeshOp):
    """Base: apply per-island UV transform to selected faces."""
    _done_msg = "Islands transformed"

    def execute(self, context):
        bm, me, uv_layer = uv_utils.get_uv_bmesh(context)
        sel = uv_utils.selected_faces(bm)
        if not sel:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}
        islands = uv_utils.uv_islands(bm, uv_layer, sel)
        self._apply(islands, uv_layer)
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"{self._done_msg} ({len(islands)} islands)")
        return {'FINISHED'}


class MESH_OT_pro_uv_rotate_islands_90(_IslandTransformOp, bpy.types.Operator):
    """Rotate each selected UV island 90° around its center"""
    bl_idname = "mesh.pro_uv_rotate_islands_90"
    bl_label = "Rotate 90°"
    bl_options = {'REGISTER', 'UNDO'}
    _done_msg = "Rotated 90°"

    def _apply(self, islands, uv_layer):
        for island in islands:
            umin, umax = uv_utils.island_bbox(island, uv_layer)
            c = (umin + umax) * 0.5
            uv_utils.transform_island(
                island, uv_layer,
                lambda uv, c=c: Vector((c.x + (uv.y - c.y), c.y - (uv.x - c.x))))


class MESH_OT_pro_uv_flip_islands_x(_IslandTransformOp, bpy.types.Operator):
    """Mirror each selected UV island horizontally"""
    bl_idname = "mesh.pro_uv_flip_islands_x"
    bl_label = "Flip X"
    bl_options = {'REGISTER', 'UNDO'}
    _done_msg = "Flipped X"

    def _apply(self, islands, uv_layer):
        for island in islands:
            umin, umax = uv_utils.island_bbox(island, uv_layer)
            cx = (umin.x + umax.x) * 0.5
            uv_utils.transform_island(
                island, uv_layer,
                lambda uv, cx=cx: Vector((2 * cx - uv.x, uv.y)))


class MESH_OT_pro_uv_flip_islands_y(_IslandTransformOp, bpy.types.Operator):
    """Mirror each selected UV island vertically"""
    bl_idname = "mesh.pro_uv_flip_islands_y"
    bl_label = "Flip Y"
    bl_options = {'REGISTER', 'UNDO'}
    _done_msg = "Flipped Y"

    def _apply(self, islands, uv_layer):
        for island in islands:
            umin, umax = uv_utils.island_bbox(island, uv_layer)
            cy = (umin.y + umax.y) * 0.5
            uv_utils.transform_island(
                island, uv_layer,
                lambda uv, cy=cy: Vector((uv.x, 2 * cy - uv.y)))


class MESH_OT_pro_uv_fit_to_0_1(_IslandTransformOp, bpy.types.Operator):
    """Scale/move the whole selection to fit the 0-1 UV space"""
    bl_idname = "mesh.pro_uv_fit_to_0_1"
    bl_label = "Fit to 0-1"
    bl_options = {'REGISTER', 'UNDO'}
    _done_msg = "Fitted to 0-1"

    margin: bpy.props.FloatProperty(name="Margin", default=0.01, min=0.0, max=0.2)

    def _apply(self, islands, uv_layer):
        all_faces = [f for isl in islands for f in isl]
        umin, umax = uv_utils.island_bbox(all_faces, uv_layer)
        size = max(umax.x - umin.x, umax.y - umin.y)
        if size < 1e-9:
            return
        scale = (1.0 - 2 * self.margin) / size
        off = Vector((self.margin, self.margin))
        uv_utils.transform_island(
            all_faces, uv_layer,
            lambda uv: (uv - umin) * scale + off)


def _make_align_op(suffix, label, doc, mode):
    """Factory for the 6 island-align operators."""

    class _Op(_IslandTransformOp, bpy.types.Operator):
        bl_idname = f"mesh.pro_uv_align_{suffix}"
        bl_label = label
        bl_options = {'REGISTER', 'UNDO'}
        _done_msg = label

        def _apply(self, islands, uv_layer, _mode=mode):
            all_faces = [f for isl in islands for f in isl]
            gmin, gmax = uv_utils.island_bbox(all_faces, uv_layer)
            gc = (gmin + gmax) * 0.5
            for island in islands:
                imin, imax = uv_utils.island_bbox(island, uv_layer)
                ic = (imin + imax) * 0.5
                if _mode == 'LEFT':
                    d = Vector((gmin.x - imin.x, 0.0))
                elif _mode == 'RIGHT':
                    d = Vector((gmax.x - imax.x, 0.0))
                elif _mode == 'TOP':
                    d = Vector((0.0, gmax.y - imax.y))
                elif _mode == 'BOTTOM':
                    d = Vector((0.0, gmin.y - imin.y))
                elif _mode == 'HORIZONTAL':
                    d = Vector((0.0, gc.y - ic.y))
                else:  # VERTICAL
                    d = Vector((gc.x - ic.x, 0.0))
                if d.length > 1e-12:
                    uv_utils.transform_island(island, uv_layer,
                                              lambda uv, d=d: uv + d)

    _Op.__name__ = f"MESH_OT_pro_uv_align_{suffix}"
    _Op.__doc__ = doc
    return _Op


MESH_OT_pro_uv_align_left = _make_align_op(
    "left", "Align Left", "Align selected islands to the left bound", 'LEFT')
MESH_OT_pro_uv_align_right = _make_align_op(
    "right", "Align Right", "Align selected islands to the right bound", 'RIGHT')
MESH_OT_pro_uv_align_top = _make_align_op(
    "top", "Align Top", "Align selected islands to the top bound", 'TOP')
MESH_OT_pro_uv_align_bottom = _make_align_op(
    "bottom", "Align Bottom", "Align selected islands to the bottom bound", 'BOTTOM')
MESH_OT_pro_uv_align_horizontal = _make_align_op(
    "horizontal", "Align Horizontal", "Center islands on a horizontal line", 'HORIZONTAL')
MESH_OT_pro_uv_align_vertical = _make_align_op(
    "vertical", "Align Vertical", "Center islands on a vertical line", 'VERTICAL')


class MESH_OT_pro_uv_straighten_selection(_EditMeshOp, bpy.types.Operator):
    """Collapse the selected UVs onto a straight line (dominant axis)"""
    bl_idname = "mesh.pro_uv_straighten_selection"
    bl_label = "Straighten Selection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bm, me, uv_layer = uv_utils.get_uv_bmesh(context)
        loops = [loop for f in bm.faces if f.select
                 for loop in f.loops if loop.vert.select]
        if len(loops) < 2:
            self.report({'WARNING'}, "Select UV geometry first (vertices in faces).")
            return {'CANCELLED'}

        us = [l[uv_layer].uv.x for l in loops]
        vs = [l[uv_layer].uv.y for l in loops]
        width = max(us) - min(us)
        height = max(vs) - min(vs)
        if width >= height:
            mean_v = sum(vs) / len(vs)
            for l in loops:
                l[uv_layer].uv.y = mean_v
            axis = "horizontal"
        else:
            mean_u = sum(us) / len(us)
            for l in loops:
                l[uv_layer].uv.x = mean_u
            axis = "vertical"
        bmesh.update_edit_mesh(me)
        self.report({'INFO'}, f"Straightened {len(loops)} UVs ({axis})")
        return {'FINISHED'}


class MESH_OT_pro_uv_rectify_island(_EditMeshOp, bpy.types.Operator):
    """Rectify a quad-grid island: square the active quad + Follow Active Quads"""
    bl_idname = "mesh.pro_uv_rectify_island"
    bl_label = "Rectify Island"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bm, me, uv_layer = uv_utils.get_uv_bmesh(context)
        sel = uv_utils.selected_faces(bm)
        if not sel:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}
        non_quads = sum(1 for f in sel if len(f.verts) != 4)
        if non_quads:
            self.report({'WARNING'},
                        f"Rectify needs an all-quads selection ({non_quads} non-quads found).")
            return {'CANCELLED'}
        active = bm.faces.active
        if active is None or not active.select or len(active.verts) != 4:
            self.report({'WARNING'}, "Set a selected quad as the ACTIVE face first.")
            return {'CANCELLED'}

        # Square the active face's UVs (keep its center and average size)
        uvs = [l[uv_layer].uv.copy() for l in active.loops]
        center = sum(uvs, Vector((0, 0))) / 4.0
        avg_edge = sum((uvs[i] - uvs[(i + 1) % 4]).length for i in range(4)) / 4.0
        s = max(avg_edge, 1e-4) * 0.5
        corners = [Vector((-s, -s)), Vector((s, -s)), Vector((s, s)), Vector((-s, s))]
        for loop, corner in zip(active.loops, corners):
            loop[uv_layer].uv = center + corner
        bmesh.update_edit_mesh(me)

        try:
            bpy.ops.uv.follow_active_quads(mode='LENGTH_AVERAGE')
        except RuntimeError as e:
            self.report({'WARNING'}, f"Rectify failed in Follow Active Quads: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Rectified island ({len(sel)} quads)")
        return {'FINISHED'}


class MESH_OT_pro_uv_square_island(_IslandTransformOp, bpy.types.Operator):
    """Scale each selected island so its bounding box becomes square"""
    bl_idname = "mesh.pro_uv_square_island"
    bl_label = "Square Island"
    bl_options = {'REGISTER', 'UNDO'}
    _done_msg = "Squared"

    def _apply(self, islands, uv_layer):
        for island in islands:
            umin, umax = uv_utils.island_bbox(island, uv_layer)
            w = umax.x - umin.x
            h = umax.y - umin.y
            if w < 1e-9 or h < 1e-9:
                continue
            side = max(w, h)
            c = (umin + umax) * 0.5
            sx, sy = side / w, side / h
            uv_utils.transform_island(
                island, uv_layer,
                lambda uv, c=c, sx=sx, sy=sy: Vector(
                    (c.x + (uv.x - c.x) * sx, c.y + (uv.y - c.y) * sy)))


# ═══════════════════════════════════════════════════════════════════════
#  REGISTRATION EXPORT
# ═══════════════════════════════════════════════════════════════════════

classes = (
    # Map manager
    OBJECT_OT_pro_uv_create_map,
    OBJECT_OT_pro_uv_create_lightmap,
    OBJECT_OT_pro_uv_create_second_channel,
    OBJECT_OT_pro_uv_duplicate_map,
    OBJECT_OT_pro_uv_delete_map,
    OBJECT_OT_pro_uv_rename_map,
    OBJECT_OT_pro_uv_set_active_map,
    # Seams
    MESH_OT_pro_uv_mark_seam,
    MESH_OT_pro_uv_clear_seam,
    MESH_OT_pro_uv_clear_all_seams,
    MESH_OT_pro_uv_select_seams,
    MESH_OT_pro_uv_mark_sharp_as_seam,
    MESH_OT_pro_uv_auto_seams_by_angle,
    MESH_OT_pro_uv_auto_seams_hard_surface,
    MESH_OT_pro_uv_auto_seams_organic,
    MESH_OT_pro_uv_select_boundary_edges,
    MESH_OT_pro_uv_select_open_edges,
    # Unwrap
    MESH_OT_pro_uv_smart_project,
    MESH_OT_pro_uv_unwrap_from_seams,
    MESH_OT_pro_uv_cube_project,
    MESH_OT_pro_uv_cylinder_project,
    MESH_OT_pro_uv_sphere_project,
    MESH_OT_pro_uv_project_from_view,
    MESH_OT_pro_uv_reset_uvs,
    MESH_OT_pro_uv_lightmap_pack,
    MESH_OT_pro_uv_follow_active_quads,
    MESH_OT_pro_uv_unwrap_preset,
    # Islands
    MESH_OT_pro_uv_pack_islands,
    MESH_OT_pro_uv_average_island_scale,
    MESH_OT_pro_uv_minimize_stretch,
    MESH_OT_pro_uv_rotate_islands_90,
    MESH_OT_pro_uv_flip_islands_x,
    MESH_OT_pro_uv_flip_islands_y,
    MESH_OT_pro_uv_fit_to_0_1,
    MESH_OT_pro_uv_align_left,
    MESH_OT_pro_uv_align_right,
    MESH_OT_pro_uv_align_top,
    MESH_OT_pro_uv_align_bottom,
    MESH_OT_pro_uv_align_horizontal,
    MESH_OT_pro_uv_align_vertical,
    MESH_OT_pro_uv_straighten_selection,
    MESH_OT_pro_uv_rectify_island,
    MESH_OT_pro_uv_square_island,
)
