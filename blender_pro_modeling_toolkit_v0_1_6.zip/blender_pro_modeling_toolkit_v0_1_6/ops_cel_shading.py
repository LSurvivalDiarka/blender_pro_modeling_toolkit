# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_cel_shading.py
# Pro Cel Shading Suite: outlines (inverted hull / solidify), Freestyle,
# Line Art (experimental), toon lighting helpers, cel shader controls.
# ──────────────────────────────────────────────────────────────────────

import math
import bpy
import bmesh

from . import node_utils

OUTLINE_SUFFIX = "_OUTLINE"
OUTLINE_MOD_NAME = "PRO_Outline"
KEY_LIGHT_NAME = "PRO_Toon_KeyLight"
RIM_LIGHT_NAME = "PRO_Toon_RimLight"
FILL_LIGHT_NAME = "PRO_Toon_FillLight"
TOON_WORLD_NAME = "PRO_Toon_World"
FREESTYLE_LINESET = "PRO Lines"


class _MeshObjectOp:
    @classmethod
    def poll(cls, context):
        return (context.active_object is not None
                and context.active_object.type == 'MESH')


def _selected_meshes(context):
    objs = [o for o in context.selected_objects if o.type == 'MESH']
    active = context.active_object
    if active and active.type == 'MESH' and active not in objs:
        objs.append(active)
    # never operate on outline objects themselves
    return [o for o in objs if not o.name.endswith(OUTLINE_SUFFIX)]


def _find_hull(obj):
    """Return this object's inverted-hull child, or None."""
    for child in obj.children:
        if child.name.startswith(obj.name) and child.name.endswith(OUTLINE_SUFFIX):
            return child
    return None


# ═══════════════════════════════════════════════════════════════════════
#  INVERTED HULL OUTLINE
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_outline_add_inverted_hull(_MeshObjectOp, bpy.types.Operator):
    """Add an inverted-hull outline object (duplicate + flipped Solidify)"""
    bl_idname = "object.pro_outline_add_inverted_hull"
    bl_label = "Add Inverted Hull"
    bl_options = {'REGISTER', 'UNDO'}

    make_unselectable: bpy.props.BoolProperty(
        name="Make Unselectable",
        description="Disable viewport selection on the outline object",
        default=True)

    def execute(self, context):
        props = context.scene.pro_toolkit
        outline_mat = node_utils.build_outline_material(props.cel_outline_color)
        created = 0
        for obj in _selected_meshes(context):
            if _find_hull(obj) is not None:
                continue
            hull = obj.copy()
            hull.data = obj.data.copy()
            hull.name = f"{obj.name}{OUTLINE_SUFFIX}"
            hull.data.name = hull.name
            hull.modifiers.clear()

            # Single-surface inverted hull: repair normals on the COPY,
            # flip its faces, and inflate with a Displace modifier.
            # (Solidify is wrong for a separate hull object: its inner
            # surface sits on the model and paints it solid black.)
            bm = bmesh.new()
            bm.from_mesh(hull.data)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
            bm.to_mesh(hull.data)
            bm.free()

            hull.data.materials.clear()
            hull.data.materials.append(outline_mat)

            mod = hull.modifiers.new(name=OUTLINE_MOD_NAME, type='DISPLACE')
            mod.direction = 'NORMAL'
            mod.mid_level = 0.0
            # faces are reversed (normals point inward) -> negative
            # strength pushes the shell OUTWARD
            mod.strength = -props.cel_outline_thickness

            for col in obj.users_collection:
                col.objects.link(hull)
            if not hull.users_collection:
                context.collection.objects.link(hull)

            hull.parent = obj
            hull.matrix_parent_inverse = obj.matrix_world.inverted()
            hull.matrix_world = obj.matrix_world.copy()
            hull.hide_select = self.make_unselectable
            hull.display_type = 'TEXTURED'
            created += 1

        if not created:
            self.report({'INFO'}, "Selected objects already have outlines.")
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Added inverted hull to {created} object(s) "
                    f"(thickness {props.cel_outline_thickness:.3f})")
        return {'FINISHED'}


class OBJECT_OT_pro_outline_remove_inverted_hull(_MeshObjectOp, bpy.types.Operator):
    """Remove the inverted-hull outline of the selected objects"""
    bl_idname = "object.pro_outline_remove_inverted_hull"
    bl_label = "Remove Inverted Hull"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        removed = 0
        for obj in _selected_meshes(context):
            hull = _find_hull(obj)
            if hull is None:
                continue
            mesh = hull.data
            bpy.data.objects.remove(hull, do_unlink=True)
            if mesh and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
            removed += 1
        if not removed:
            self.report({'INFO'}, "No outline objects found on the selection.")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Removed {removed} outline object(s)")
        return {'FINISHED'}


class OBJECT_OT_pro_outline_add_solidify_outline(_MeshObjectOp, bpy.types.Operator):
    """Add a Solidify outline on the object itself (extra material slot)"""
    bl_idname = "object.pro_outline_add_solidify_outline"
    bl_label = "Add Solidify Outline"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        outline_mat = node_utils.build_outline_material(props.cel_outline_color)
        added = 0
        for obj in _selected_meshes(context):
            if any(m.name == OUTLINE_MOD_NAME for m in obj.modifiers):
                continue
            if not obj.data.materials:
                self.report({'WARNING'},
                            f"'{obj.name}' has no base material - apply a cel "
                            "preset first (outline needs a material offset).")
                continue
            obj.data.materials.append(outline_mat)
            mod = obj.modifiers.new(name=OUTLINE_MOD_NAME, type='SOLIDIFY')
            mod.thickness = props.cel_outline_thickness
            mod.offset = 1.0
            mod.use_flip_normals = True
            mod.use_rim = False
            mod.material_offset = len(obj.data.materials) - 1
            added += 1
        if not added:
            self.report({'INFO'}, "No objects modified (outline already present "
                                  "or missing base material).")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Added solidify outline to {added} object(s)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  FREESTYLE
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_outline_enable_freestyle(bpy.types.Operator):
    """Enable Freestyle lines (render-time only, visible on F12)"""
    bl_idname = "object.pro_outline_enable_freestyle"
    bl_label = "Enable Freestyle"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.render.use_freestyle = True
        self.report({'INFO'}, "Freestyle ON (lines appear in renders, not viewport)")
        return {'FINISHED'}


class OBJECT_OT_pro_outline_disable_freestyle(bpy.types.Operator):
    """Disable Freestyle lines"""
    bl_idname = "object.pro_outline_disable_freestyle"
    bl_label = "Disable Freestyle"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.render.use_freestyle = False
        self.report({'INFO'}, "Freestyle OFF")
        return {'FINISHED'}


class OBJECT_OT_pro_outline_setup_freestyle_preset(bpy.types.Operator):
    """Enable Freestyle with a clean toon line preset (own lineset)"""
    bl_idname = "object.pro_outline_setup_freestyle_preset"
    bl_label = "Freestyle Toon Preset"
    bl_options = {'REGISTER', 'UNDO'}

    line_thickness: bpy.props.FloatProperty(
        name="Line Thickness (px)", default=2.5, min=0.1, max=20.0)

    def execute(self, context):
        scene = context.scene
        props = scene.pro_toolkit
        scene.render.use_freestyle = True
        scene.render.line_thickness_mode = 'ABSOLUTE'
        scene.render.line_thickness = 1.0

        fs = context.view_layer.freestyle_settings
        lineset = fs.linesets.get(FREESTYLE_LINESET)
        if lineset is None:
            lineset = fs.linesets.new(FREESTYLE_LINESET)
        lineset.select_silhouette = True
        lineset.select_border = True
        lineset.select_crease = True
        lineset.select_edge_mark = False

        style = lineset.linestyle
        style.name = "PRO_Toon_LineStyle"
        style.color = props.cel_outline_color[:3]
        style.thickness = self.line_thickness
        self.report({'INFO'},
                    f"Freestyle toon preset ready (lineset '{FREESTYLE_LINESET}', "
                    f"{self.line_thickness:.1f}px). Lines show in renders (F12).")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  LINE ART (EXPERIMENTAL — Grease Pencil API differs across versions)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_outline_add_line_art_setup(bpy.types.Operator):
    """EXPERIMENTAL: add a Grease Pencil Line Art object for the scene"""
    bl_idname = "object.pro_outline_add_line_art_setup"
    bl_label = "Line Art Setup (Experimental)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        # Grease Pencil v3 (Blender 4.3+) renamed the operator and enums;
        # try the modern call first, then the legacy one.
        attempts = (
            ("grease_pencil_add", {'type': 'LINEART_SCENE'}),
            ("gpencil_add", {'type': 'LRT_SCENE'}),
        )
        for op_name, kwargs in attempts:
            op = getattr(bpy.ops.object, op_name, None)
            if op is None:
                continue
            try:
                op(**kwargs)
                self.report({'INFO'},
                            "Line Art object added (experimental). Adjust the "
                            "Line Art modifier thickness in its properties.")
                return {'FINISHED'}
            except (RuntimeError, TypeError):
                continue
        self.report({'WARNING'},
                    "Line Art setup is not available in this Blender version "
                    "(experimental feature). Use Freestyle or Inverted Hull.")
        return {'CANCELLED'}


# ═══════════════════════════════════════════════════════════════════════
#  OUTLINE PARAMETER UPDATES
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_outline_set_thickness(bpy.types.Operator):
    """Apply the panel's outline thickness to existing outlines + Freestyle"""
    bl_idname = "object.pro_outline_set_thickness"
    bl_label = "Update Thickness"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        t = props.cel_outline_thickness
        updated = 0
        for obj in bpy.data.objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if mod.name != OUTLINE_MOD_NAME:
                    continue
                if mod.type == 'SOLIDIFY':
                    mod.thickness = t
                    updated += 1
                elif mod.type == 'DISPLACE':   # inverted hull shells
                    mod.strength = -t
                    updated += 1
        fs = context.view_layer.freestyle_settings
        lineset = fs.linesets.get(FREESTYLE_LINESET)
        if lineset is not None:
            lineset.linestyle.thickness = max(0.1, t * 125.0)  # m -> px feel
            updated += 1
        self.report({'INFO'}, f"Updated thickness on {updated} outline(s) "
                              f"to {t:.3f}")
        return {'FINISHED'}


class OBJECT_OT_pro_outline_set_color(bpy.types.Operator):
    """Apply the panel's outline color to the outline material + Freestyle"""
    bl_idname = "object.pro_outline_set_color"
    bl_label = "Update Color"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.pro_toolkit
        color = tuple(props.cel_outline_color)
        node_utils.build_outline_material(color)
        fs = context.view_layer.freestyle_settings
        lineset = fs.linesets.get(FREESTYLE_LINESET)
        if lineset is not None:
            lineset.linestyle.color = color[:3]
        self.report({'INFO'}, "Outline color updated (material + Freestyle)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  CEL SHADER CONTROLS
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_cel_apply_custom_settings(_MeshObjectOp, bpy.types.Operator):
    """Push the panel's colors/threshold into the active PRO_CEL material"""
    bl_idname = "object.pro_cel_apply_custom_settings"
    bl_label = "Update Active Material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material
        if mat is None or not (mat.name.startswith("PRO_CEL")
                               or mat.name.startswith("TOON_")):
            self.report({'WARNING'},
                        "Active material is not a PRO cel material. "
                        "Apply a preset first.")
            return {'CANCELLED'}
        updated = node_utils.update_cel_material(mat, context.scene.pro_toolkit)
        if not updated:
            self.report({'WARNING'}, "No PRO nodes found to update.")
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Updated {mat.name}: {', '.join(updated)}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  LIGHTING HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _add_sun(context, name, energy, rotation, sharp=True):
    """Create (or fetch) a named sun light. Returns the object."""
    obj = bpy.data.objects.get(name)
    if obj is None or obj.type != 'LIGHT':
        data = bpy.data.lights.new(name, type='SUN')
        obj = bpy.data.objects.new(name, data)
        context.collection.objects.link(obj)
    obj.data.energy = energy
    if sharp:
        obj.data.angle = 0.0       # crisp cel terminator
    obj.rotation_euler = rotation
    return obj


class OBJECT_OT_pro_cel_add_toon_key_light(bpy.types.Operator):
    """Add a sharp key sun light angled for cel shading"""
    bl_idname = "object.pro_cel_add_toon_key_light"
    bl_label = "Add Key Light"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        existed = KEY_LIGHT_NAME in bpy.data.objects
        _add_sun(context, KEY_LIGHT_NAME, energy=3.0,
                 rotation=(math.radians(50), 0.0, math.radians(30)))
        self.report({'INFO'},
                    f"Key light {'updated' if existed else 'added'} "
                    f"('{KEY_LIGHT_NAME}', sharp shadows)")
        return {'FINISHED'}


class OBJECT_OT_pro_cel_add_rim_light(bpy.types.Operator):
    """Add a back rim sun light for silhouette pop"""
    bl_idname = "object.pro_cel_add_rim_light"
    bl_label = "Add Rim Light"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        existed = RIM_LIGHT_NAME in bpy.data.objects
        _add_sun(context, RIM_LIGHT_NAME, energy=2.0,
                 rotation=(math.radians(-55), 0.0, math.radians(200)))
        self.report({'INFO'},
                    f"Rim light {'updated' if existed else 'added'} "
                    f"('{RIM_LIGHT_NAME}')")
        return {'FINISHED'}


class OBJECT_OT_pro_cel_add_flat_lighting_setup(bpy.types.Operator):
    """Add key + fill lights and a flat toon world (your world is kept in the file)"""
    bl_idname = "object.pro_cel_add_flat_lighting_setup"
    bl_label = "Flat Lighting Setup"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        _add_sun(context, KEY_LIGHT_NAME, energy=3.0,
                 rotation=(math.radians(50), 0.0, math.radians(30)))
        _add_sun(context, FILL_LIGHT_NAME, energy=0.8,
                 rotation=(math.radians(40), 0.0, math.radians(-140)))

        world = bpy.data.worlds.get(TOON_WORLD_NAME)
        if world is None:
            world = bpy.data.worlds.new(TOON_WORLD_NAME)
        world.use_nodes = True
        bg = world.node_tree.nodes.get("Background")
        if bg is not None:
            bg.inputs[0].default_value = (0.045, 0.045, 0.05, 1.0)
            bg.inputs[1].default_value = 1.0
        prev_world = context.scene.world.name if context.scene.world else "none"
        context.scene.world = world
        self.report({'INFO'},
                    f"Flat toon lighting ready (key + fill + '{TOON_WORLD_NAME}'). "
                    f"Previous world '{prev_world}' kept in the file.")
        return {'FINISHED'}


class OBJECT_OT_pro_cel_set_eevee_toon_settings(bpy.types.Operator):
    """Tune scene settings for cel shading (view transform, shadows) — asks first"""
    bl_idname = "object.pro_cel_set_eevee_toon_settings"
    bl_label = "EEVEE Toon Settings"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        changes = []
        if scene.view_settings.view_transform != 'Standard':
            scene.view_settings.view_transform = 'Standard'
            changes.append("view transform -> Standard (no Filmic washing)")
        eevee = scene.eevee
        if hasattr(eevee, "use_shadows") and not eevee.use_shadows:
            eevee.use_shadows = True
            changes.append("shadows ON")
        if hasattr(eevee, "taa_samples") and eevee.taa_samples > 16:
            eevee.taa_samples = 16
            changes.append("viewport samples -> 16")
        if not changes:
            self.report({'INFO'}, "Scene already configured for toon shading.")
            return {'FINISHED'}
        self.report({'INFO'}, "Changed: " + "; ".join(changes))
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_outline_add_inverted_hull,
    OBJECT_OT_pro_outline_remove_inverted_hull,
    OBJECT_OT_pro_outline_add_solidify_outline,
    OBJECT_OT_pro_outline_enable_freestyle,
    OBJECT_OT_pro_outline_disable_freestyle,
    OBJECT_OT_pro_outline_setup_freestyle_preset,
    OBJECT_OT_pro_outline_add_line_art_setup,
    OBJECT_OT_pro_outline_set_thickness,
    OBJECT_OT_pro_outline_set_color,
    OBJECT_OT_pro_cel_apply_custom_settings,
    OBJECT_OT_pro_cel_add_toon_key_light,
    OBJECT_OT_pro_cel_add_rim_light,
    OBJECT_OT_pro_cel_add_flat_lighting_setup,
    OBJECT_OT_pro_cel_set_eevee_toon_settings,
)
