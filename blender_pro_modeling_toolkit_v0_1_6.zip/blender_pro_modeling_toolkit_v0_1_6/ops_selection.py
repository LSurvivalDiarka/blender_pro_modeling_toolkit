# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_selection.py
# Advanced selection operators (Edit Mode)
# ──────────────────────────────────────────────────────────────────────

import math
import bpy
import bmesh


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _edit_mesh_poll(context):
    return context.mode == 'EDIT_MESH' and context.edit_object is not None


def _select_edges_where(context, predicate):
    """Deselect all, switch to edge mode, select edges matching *predicate*.
    Returns the number of selected edges."""
    context.tool_settings.mesh_select_mode = (False, True, False)
    bpy.ops.mesh.select_all(action='DESELECT')

    me = context.edit_object.data
    bm = bmesh.from_edit_mesh(me)
    bm.edges.ensure_lookup_table()
    count = 0
    for e in bm.edges:
        if predicate(e):
            e.select = True
            count += 1
    bm.select_flush_mode()
    bmesh.update_edit_mesh(me)
    return count


# ═══════════════════════════════════════════════════════════════════════
#  Select Boundary Edges
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_select_boundary(bpy.types.Operator):
    """Select all open boundary edges of the mesh"""
    bl_idname = "mesh.pro_select_boundary"
    bl_label = "Select Boundary"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        count = _select_edges_where(context, lambda e: e.is_boundary)
        self.report({'INFO'}, f"Selected {count} boundary edges")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Select Loose Geometry
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_select_loose(bpy.types.Operator):
    """Select loose geometry (verts/edges not attached to faces)"""
    bl_idname = "mesh.pro_select_loose"
    bl_label = "Select Loose"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_loose(extend=False)
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Select Sharp Edges (by angle)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_select_sharp_edges(bpy.types.Operator):
    """Select edges sharper than the given angle"""
    bl_idname = "mesh.pro_select_sharp_edges"
    bl_label = "Select Sharp Edges"
    bl_options = {'REGISTER', 'UNDO'}

    sharpness: bpy.props.FloatProperty(
        name="Sharpness",
        description="Angle threshold between faces",
        subtype='ANGLE',
        default=math.radians(30.0),
        min=math.radians(0.1),
        max=math.radians(180.0),
    )

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.edges_select_sharp(sharpness=self.sharpness)
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Select Seams
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_select_seams(bpy.types.Operator):
    """Select all edges marked as UV seams"""
    bl_idname = "mesh.pro_select_seams"
    bl_label = "Select Seams"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        count = _select_edges_where(context, lambda e: e.seam)
        self.report({'INFO'}, f"Selected {count} seam edges")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Grow / Shrink / Invert Selection
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_grow_selection(bpy.types.Operator):
    """Grow the current selection by one step"""
    bl_idname = "mesh.pro_grow_selection"
    bl_label = "Grow Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bpy.ops.mesh.select_more()
        return {'FINISHED'}


class MESH_OT_pro_shrink_selection(bpy.types.Operator):
    """Shrink the current selection by one step"""
    bl_idname = "mesh.pro_shrink_selection"
    bl_label = "Shrink Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bpy.ops.mesh.select_less()
        return {'FINISHED'}


class MESH_OT_pro_invert_selection(bpy.types.Operator):
    """Invert the current selection"""
    bl_idname = "mesh.pro_invert_selection"
    bl_label = "Invert Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bpy.ops.mesh.select_all(action='INVERT')
        return {'FINISHED'}
