# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_character.py
# Basic character / organic modeling helpers.
# No rigging, no armatures, no auto-retopo — stable basics only.
# ──────────────────────────────────────────────────────────────────────

import bpy
import bmesh


# ═══════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _active_mesh_poll(context):
    return (context.active_object is not None
            and context.active_object.type == 'MESH')


def _edit_mesh_poll(context):
    return context.mode == 'EDIT_MESH' and context.edit_object is not None


# ═══════════════════════════════════════════════════════════════════════
#  Character Mirror (modifier preset)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_character_mirror(bpy.types.Operator):
    """Add an X-axis Mirror modifier with clipping and merge (character preset)"""
    bl_idname = "object.pro_add_character_mirror"
    bl_label = "Character Mirror (X)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_mesh_poll(context)

    def execute(self, context):
        obj = context.active_object
        if any(m.type == 'MIRROR' for m in obj.modifiers):
            self.report({'INFO'}, "Mirror modifier already present.")
            return {'CANCELLED'}

        mod = obj.modifiers.new(name="Pro_Character_Mirror", type='MIRROR')
        mod.use_axis[0] = True
        mod.use_axis[1] = False
        mod.use_axis[2] = False
        mod.use_clip = True
        mod.use_mirror_merge = True
        mod.merge_threshold = 0.001
        mod.show_on_cage = True

        self.report({'INFO'}, "Character Mirror added (X, clip + merge)")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Subdivision Preview (modifier preset)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_subdivision_preview(bpy.types.Operator):
    """Add a Subdivision Surface modifier set up for smooth preview"""
    bl_idname = "object.pro_add_subdivision_preview"
    bl_label = "Subdivision Preview"
    bl_options = {'REGISTER', 'UNDO'}

    levels: bpy.props.IntProperty(
        name="Viewport Levels",
        default=2, min=1, max=4,
    )

    @classmethod
    def poll(cls, context):
        return _active_mesh_poll(context)

    def execute(self, context):
        obj = context.active_object
        if any(m.type == 'SUBSURF' for m in obj.modifiers):
            self.report({'INFO'}, "Subdivision modifier already present.")
            return {'CANCELLED'}

        mod = obj.modifiers.new(name="Pro_Subdivision", type='SUBSURF')
        mod.levels = self.levels
        mod.render_levels = self.levels
        mod.show_only_control_edges = True

        self.report({'INFO'}, f"Subdivision preview added (levels={self.levels})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Shrinkwrap (modifier preset)
# ═══════════════════════════════════════════════════════════════════════

class OBJECT_OT_pro_add_shrinkwrap(bpy.types.Operator):
    """Add a Shrinkwrap modifier (target = other selected object, if any)"""
    bl_idname = "object.pro_add_shrinkwrap"
    bl_label = "Add Shrinkwrap"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_mesh_poll(context)

    def execute(self, context):
        obj = context.active_object
        target = next(
            (o for o in context.selected_objects
             if o is not obj and o.type == 'MESH'),
            None)

        mod = obj.modifiers.new(name="Pro_Shrinkwrap", type='SHRINKWRAP')
        if target is not None:
            mod.target = target
            self.report({'INFO'}, f"Shrinkwrap added (target: {target.name})")
        else:
            self.report({'WARNING'},
                        "Shrinkwrap added without target. "
                        "Select the target mesh too (active = wrapped object).")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Smooth Selection (organic smooth)
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_smooth_selection(bpy.types.Operator):
    """Smooth the selected vertices (organic-friendly)"""
    bl_idname = "mesh.pro_smooth_selection"
    bl_label = "Smooth Selection"
    bl_options = {'REGISTER', 'UNDO'}

    factor: bpy.props.FloatProperty(
        name="Factor", default=0.5, min=0.0, max=1.0)
    repeat: bpy.props.IntProperty(
        name="Repeat", default=2, min=1, max=50)

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.edit_object.data)
        if not any(v.select for v in bm.verts):
            self.report({'WARNING'}, "No vertices selected.")
            return {'CANCELLED'}

        bpy.ops.mesh.vertices_smooth(factor=self.factor, repeat=self.repeat)
        self.report({'INFO'}, f"Smoothed selection (factor={self.factor:.2f}, x{self.repeat})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Inflate / Deflate
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_inflate_deflate(bpy.types.Operator):
    """Inflate (+) or deflate (–) selected vertices along their normals"""
    bl_idname = "mesh.pro_inflate_deflate"
    bl_label = "Inflate/Deflate"
    bl_options = {'REGISTER', 'UNDO'}

    amount: bpy.props.FloatProperty(
        name="Amount",
        description="Positive inflates, negative deflates",
        default=0.05,
        soft_min=-1.0,
        soft_max=1.0,
        step=1,
        precision=4,
    )

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        me = context.edit_object.data
        bm = bmesh.from_edit_mesh(me)
        sel = [v for v in bm.verts if v.select]
        if not sel:
            self.report({'WARNING'}, "No vertices selected.")
            return {'CANCELLED'}

        for v in sel:
            v.co += v.normal * self.amount

        bmesh.update_edit_mesh(me)
        verb = "Inflated" if self.amount >= 0 else "Deflated"
        self.report({'INFO'}, f"{verb} {len(sel)} vertices by {abs(self.amount):.4f}")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Symmetrize X
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_symmetrize_x(bpy.types.Operator):
    """Make the whole mesh symmetric on the X axis"""
    bl_idname = "mesh.pro_symmetrize_x"
    bl_label = "Symmetrize X"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        name="Direction",
        items=[
            ('POSITIVE_X', "+X to -X", "Copy the +X side onto the -X side"),
            ('NEGATIVE_X', "-X to +X", "Copy the -X side onto the +X side"),
        ],
        default='POSITIVE_X',
    )
    threshold: bpy.props.FloatProperty(
        name="Threshold", default=0.0001, min=0.0, max=0.1, precision=5)

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.symmetrize(direction=self.direction, threshold=self.threshold)
        self.report({'INFO'}, f"Symmetrized mesh ({self.direction})")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════
#  Snap to Symmetry X
# ═══════════════════════════════════════════════════════════════════════

class MESH_OT_pro_snap_to_symmetry_x(bpy.types.Operator):
    """Snap slightly asymmetric vertices back to X symmetry"""
    bl_idname = "mesh.pro_snap_to_symmetry_x"
    bl_label = "Snap to Symmetry X"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        name="Direction",
        items=[
            ('POSITIVE_X', "+X to -X", "Snap using the +X side as reference"),
            ('NEGATIVE_X', "-X to +X", "Snap using the -X side as reference"),
        ],
        default='POSITIVE_X',
    )
    threshold: bpy.props.FloatProperty(
        name="Threshold",
        description="Maximum distance to consider vertices as symmetric pairs",
        default=0.05, min=0.0, max=1.0, precision=4)

    @classmethod
    def poll(cls, context):
        return _edit_mesh_poll(context)

    def execute(self, context):
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.symmetry_snap(
            direction=self.direction,
            threshold=self.threshold,
            factor=1.0,
            use_center=True,
        )
        self.report({'INFO'}, f"Snapped vertices to X symmetry ({self.direction})")
        return {'FINISHED'}
