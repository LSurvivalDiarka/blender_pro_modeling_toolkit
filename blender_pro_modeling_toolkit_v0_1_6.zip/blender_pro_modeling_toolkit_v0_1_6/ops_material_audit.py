# ──────────────────────────────────────────────────────────────────────
# Blender Pro Modeling Toolkit  –  ops_material_audit.py
# v0.1.6 — Material Audit: scene/selected material analysis, issue
# finders (select the affected objects) and the markdown report.
# Read-only: nothing here modifies materials.
# ──────────────────────────────────────────────────────────────────────

import bpy

from . import material_utils as mu
from . import texture_utils as tu

# last full audit data (module cache, feeds the report operator)
_LAST_AUDIT = None

TOO_MANY_TEXTURES = 8


def _collect_audit(context, scope):
    """All audit data in one pass. Returns dict."""
    objs = mu.scope_objects(context, scope)
    users = mu.material_users()
    scoped_mats = []
    seen = set()
    for o in objs:
        for slot in o.material_slots:
            if slot.material is not None and slot.material not in seen:
                seen.add(slot.material)
                scoped_mats.append(slot.material)
    all_mats = [m for m in bpy.data.materials if not m.is_grease_pencil]
    unused = mu.unused_materials()
    dup_name = mu.duplicate_groups_by_name()
    dup_color = mu.duplicate_groups_by_color(
        context.scene.pro_toolkit.mat_merge_by_color_tolerance)

    empty_slots = [(o, i) for o in objs
                   for i, s in enumerate(o.material_slots) if s.material is None]
    no_slots = [o for o in objs if not o.material_slots]
    no_nodes = [m for m in scoped_mats if not m.use_nodes or m.node_tree is None]
    no_principled = [m for m in scoped_mats
                     if m.use_nodes and mu.get_principled(m) is None]
    too_many_tex = [(m, len(mu.material_images(m))) for m in scoped_mats
                    if len(mu.material_images(m)) > TOO_MANY_TEXTURES]
    abs_paths = [m for m in scoped_mats if mu.has_absolute_paths(m)]
    missing_imgs = [m for m in scoped_mats if mu.has_missing_images(m)]
    non_pbr = [m for m in scoped_mats if not mu.is_pbr(m)]
    heavy = [m for m in scoped_mats if mu.is_heavy(m)]

    max_size = context.scene.pro_toolkit.texture_max_size_warning
    images = sorted({i for m in scoped_mats for i in mu.material_images(m)},
                    key=lambda i: i.name)
    large = [(i, tu.image_size(i)) for i in images
             if max(tu.image_size(i)) > max_size]
    npot = [(i, tu.image_size(i)) for i in images
            if any(s > 0 and (s & (s - 1)) for s in tu.image_size(i))]

    return {
        "scope": scope, "objects": objs, "materials": scoped_mats,
        "all_materials": all_mats, "users": users, "unused": unused,
        "dup_name": dup_name, "dup_color": dup_color,
        "empty_slots": empty_slots, "no_slots": no_slots,
        "no_nodes": no_nodes, "no_principled": no_principled,
        "too_many_tex": too_many_tex, "abs_paths": abs_paths,
        "missing_imgs": missing_imgs, "non_pbr": non_pbr, "heavy": heavy,
        "images": images, "large": large, "npot": npot,
        "rel_paths": [i for i in images if i.filepath.startswith("//")],
        "abs_images": [i for i in images if tu.is_path_absolute(i)],
    }


def _store_summary(props, d):
    props.mat_audit_done = True
    props.mat_audit_total = len(d["all_materials"])
    props.mat_audit_scoped = len(d["materials"])
    props.mat_audit_unused = len(d["unused"])
    props.mat_audit_duplicates = sum(len(g) - 1 for g in d["dup_name"].values())
    props.mat_audit_missing_tex = len(d["missing_imgs"])
    props.mat_audit_abs_paths = len(d["abs_paths"])
    props.mat_audit_non_pbr = len(d["non_pbr"])
    props.mat_audit_heavy = len(d["heavy"])
    props.mat_audit_empty_slots = len(d["empty_slots"])
    props.mat_audit_images = len(d["images"])


class OBJECT_OT_pro_mat_audit(bpy.types.Operator):
    """Audit materials (selected objects or whole scene) and store a
    summary; use Create Audit Report for the full markdown"""
    bl_idname = "object.pro_mat_audit"
    bl_label = "Audit Materials"
    bl_options = {'REGISTER'}

    scope: bpy.props.EnumProperty(
        items=[('SELECTED', "Selected", ""), ('SCENE', "Scene", "")],
        default='SCENE')

    def execute(self, context):
        global _LAST_AUDIT
        d = _collect_audit(context, self.scope)
        _LAST_AUDIT = d
        _store_summary(context.scene.pro_toolkit, d)
        issues = (len(d["unused"]) + len(d["missing_imgs"]) + len(d["abs_paths"])
                  + len(d["empty_slots"]) + len(d["no_nodes"])
                  + sum(len(g) - 1 for g in d["dup_name"].values()))
        self.report({'INFO'},
                    f"Audit ({self.scope.lower()}): {len(d['materials'])} "
                    f"material(es), {len(d['images'])} imagen(es), "
                    f"{issues} problema(s) potenciales.")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_audit_report(bpy.types.Operator):
    """Write V016_MATERIAL_AUDIT_REPORT.md next to the .blend file
    (or in the temp folder when unsaved)"""
    bl_idname = "object.pro_mat_audit_report"
    bl_label = "Create Audit Report"
    bl_options = {'REGISTER'}

    def execute(self, context):
        global _LAST_AUDIT
        if _LAST_AUDIT is None:
            bpy.ops.object.pro_mat_audit(
                scope=context.scene.pro_toolkit.mat_audit_scope)
        d = _LAST_AUDIT
        users = d["users"]

        def names(items, fmt=lambda x: x.name):
            return [f"- {fmt(x)}" for x in items] or ["- (ninguno)"]

        lines = [
            "# V016 MATERIAL AUDIT REPORT",
            f"Ámbito: **{d['scope']}** · Objetos analizados: {len(d['objects'])}",
            "",
            "## Resumen",
            f"- Materiales totales en el archivo: **{len(d['all_materials'])}**",
            f"- Materiales en el ámbito auditado: **{len(d['materials'])}**",
            f"- Materiales usados (todo el archivo): **{len(users)}**",
            f"- Materiales sin uso: **{len(d['unused'])}**",
            f"- Grupos duplicados por nombre: **{len(d['dup_name'])}** "
            f"({sum(len(g) - 1 for g in d['dup_name'].values())} redundantes)",
            f"- Grupos duplicados por color: **{len(d['dup_color'])}**",
            f"- Imágenes usadas en el ámbito: **{len(d['images'])}** "
            f"(relativas: {len(d['rel_paths'])}, absolutas: {len(d['abs_images'])})",
            "",
            "## Materiales sin uso",
            *names(d["unused"]),
            "",
            "## Duplicados por nombre",
        ]
        for base, mats in d["dup_name"].items():
            lines.append(f"- `{base}`: " + ", ".join(m.name for m in mats))
        if not d["dup_name"]:
            lines.append("- (ninguno)")
        lines += [
            "",
            "## Slots vacíos",
            *([f"- {o.name} (slot {i})" for o, i in d["empty_slots"]]
              or ["- (ninguno)"]),
            "",
            "## Objetos sin material", *names(d["no_slots"]),
            "",
            "## Materiales sin nodos", *names(d["no_nodes"]),
            "",
            "## Materiales sin Principled BSDF", *names(d["no_principled"]),
            "",
            "## Materiales no-PBR", *names(d["non_pbr"]),
            "",
            "## Materiales pesados "
            f"(> {mu.HEAVY_NODE_COUNT} nodos o > {mu.HEAVY_IMAGE_COUNT} imágenes)",
            *names(d["heavy"]),
            "",
            f"## Materiales con demasiadas texturas (> {TOO_MANY_TEXTURES})",
            *([f"- {m.name}: {n} imágenes" for m, n in d["too_many_tex"]]
              or ["- (ninguno)"]),
            "",
            "## Materiales con texturas perdidas", *names(d["missing_imgs"]),
            "",
            "## Materiales con rutas absolutas", *names(d["abs_paths"]),
            "",
            "## Imágenes",
        ]
        for img in d["images"]:
            w, h = tu.image_size(img)
            kind = ("PACKED" if img.packed_file else
                    "MISSING" if tu.image_is_missing(img) else
                    "ABS" if tu.is_path_absolute(img) else "REL")
            lines.append(f"- `{img.name}` {w}x{h} [{kind}] {img.filepath}")
        if not d["images"]:
            lines.append("- (ninguna)")
        max_size = context.scene.pro_toolkit.texture_max_size_warning
        lines += [
            "",
            f"## Texturas grandes (> {max_size}px)",
            *([f"- {i.name} ({w}x{h})" for i, (w, h) in d["large"]]
              or ["- (ninguna)"]),
            "",
            "## Texturas no potencia de 2",
            *([f"- {i.name} ({w}x{h})" for i, (w, h) in d["npot"]]
              or ["- (ninguna)"]),
            "",
            "## Objetos afectados",
        ]
        affected = sorted({o.name for o, _ in d["empty_slots"]}
                          | {o.name for o in d["no_slots"]}
                          | {o.name for m in d["missing_imgs"]
                             for o in users.get(m, [])})
        lines += [f"- {n}" for n in affected] or ["- (ninguno)"]
        lines += [
            "",
            "## Recomendaciones",
        ]
        rec = []
        if d["unused"]:
            rec.append("Ejecutar **Purge Orphan Materials Safe** para los "
                       f"{len(d['unused'])} materiales sin uso.")
        if d["dup_name"]:
            rec.append("Ejecutar **Merge Duplicates by Name** "
                       f"({len(d['dup_name'])} grupos).")
        if d["empty_slots"]:
            rec.append("Ejecutar **Remove Empty Material Slots**.")
        if d["missing_imgs"]:
            rec.append("Usar **Relink Textures From Folder** (Texture Manager).")
        if d["abs_paths"]:
            rec.append("Usar **Make Texture Paths Relative** antes de compartir "
                       "el proyecto.")
        if d["non_pbr"]:
            rec.append("Convertir a PBR con **Convert to PBR Safe** los "
                       "materiales destinados a Unity.")
        if d["large"]:
            rec.append("Revisar las texturas grandes antes de exportar a juego.")
        lines += [f"- {r}" for r in rec] or ["- Sin problemas relevantes. ✅"]

        path = mu.write_report("V016_MATERIAL_AUDIT_REPORT.md", lines)
        self.report({'INFO'}, f"Informe escrito: {path}")
        return {'FINISHED'}


class OBJECT_OT_pro_mat_find_issue(bpy.types.Operator):
    """Find materials/objects with a specific issue and select the
    affected objects (read-only, nothing is modified)"""
    bl_idname = "object.pro_mat_find_issue"
    bl_label = "Find Material Issue"
    bl_options = {'REGISTER', 'UNDO'}

    issue: bpy.props.EnumProperty(
        name="Issue",
        items=[
            ('MISSING_MATERIALS', "Missing Materials", "Objects with no material or empty slots"),
            ('UNUSED', "Unused Materials", "Materials not assigned to any object"),
            ('DUPLICATES', "Duplicate Materials", "Mat / Mat.001 name groups"),
            ('EMPTY_SLOTS', "Empty Material Slots", ""),
            ('NO_NODES', "Without Nodes", ""),
            ('NO_PRINCIPLED', "Without Principled BSDF", ""),
            ('TOO_MANY_TEXTURES', "Too Many Textures", ""),
            ('ABS_PATHS', "Absolute Paths", ""),
            ('MISSING_IMAGES', "Missing Images", ""),
            ('NON_PBR', "Non-PBR", ""),
            ('HEAVY', "Heavy Materials", ""),
            ('TEX_SIZE', "Texture Size Problems", "Too large or non power-of-2"),
        ],
        default='UNUSED')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        d = _collect_audit(context, 'SCENE')
        users = d["users"]
        key = self.issue
        mats, extra = [], ""
        if key == 'MISSING_MATERIALS':
            objs = set(d["no_slots"]) | {o for o, _ in d["empty_slots"]}
            mats = []
        elif key == 'UNUSED':
            mats = d["unused"]; objs = set()
        elif key == 'DUPLICATES':
            mats = [m for g in d["dup_name"].values() for m in g[1:]]
            objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'EMPTY_SLOTS':
            objs = {o for o, _ in d["empty_slots"]}
        elif key == 'NO_NODES':
            mats = d["no_nodes"]; objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'NO_PRINCIPLED':
            mats = d["no_principled"]; objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'TOO_MANY_TEXTURES':
            mats = [m for m, _ in d["too_many_tex"]]
            objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'ABS_PATHS':
            mats = d["abs_paths"]; objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'MISSING_IMAGES':
            mats = d["missing_imgs"]; objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'NON_PBR':
            mats = d["non_pbr"]; objs = {o for m in mats for o in users.get(m, [])}
        elif key == 'HEAVY':
            mats = d["heavy"]; objs = {o for m in mats for o in users.get(m, [])}
        else:  # TEX_SIZE
            bad = {i for i, _ in d["large"]} | {i for i, _ in d["npot"]}
            mats = [m for m in d["materials"]
                    if any(i in bad for i in mu.material_images(m))]
            objs = {o for m in mats for o in users.get(m, [])}
            extra = f" ({len(bad)} imagen(es) problemáticas)"

        for o in context.selected_objects:
            o.select_set(False)
        n_sel = 0
        for o in objs:
            if o.name in context.view_layer.objects:
                o.select_set(True)
                n_sel += 1
        label = next(i[1] for i in
                     self.__class__.issue.keywords['items'] if i[0] == key)
        names = ", ".join(m.name for m in mats[:8]) if mats else ""
        if len(mats) > 8:
            names += ", …"
        if not mats and not objs:
            self.report({'INFO'}, f"{label}: sin resultados. ✅")
        else:
            self.report({'WARNING'},
                        f"{label}: {len(mats)} material(es), "
                        f"{n_sel} objeto(s) seleccionados{extra}. {names}")
        return {'FINISHED'}


classes = (
    OBJECT_OT_pro_mat_audit,
    OBJECT_OT_pro_mat_audit_report,
    OBJECT_OT_pro_mat_find_issue,
)
